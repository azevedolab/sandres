#! /usr/bin/python
# Class to call machine learning methods implemented in the scikit_regression_methods_v1_2.py.
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################

class SMLEARNING(object):
    """Class to create models to predict binding affinty using supervised machine learning
    methods"""
        
    # Define constructor method
    def __init__(self,dir_in,data_in,response_in,reg_method_in,pollog,polcsv,\
    ip,min_elem,max_elem,initial_list):
        
        # Set up initial values for attributes
        self.dir_in = dir_in
        self.data_in = data_in
        self.response_in = response_in
        self.reg_method_in = reg_method_in  
        self.pollog = pollog
        self.polcsv = polcsv
        self.ip = ip
        self.min_elem = min_elem
        self.max_elem = max_elem
        self.total_elem = len(initial_list)
        self.initial_list = initial_list
    
    # Define __str__ method
    def __str__(self):
        rep = "\nSupervised machine learning methods for prediction of binding affinity"
        rep += "\nWorking directory: "+self.dir_in
        rep += "\nDataset: "+self.data_in
        rep += "\nRegression method: "+self.reg_method_in
        
        return rep
        
    # Define polscore_smlearning() method
    def polscore_smlearning(self):
        """ Polscore Method"""
    
        # Import library
        import scikit_regression_methods_v1_2 as pol1     
    
        # Open polscore.log and polscore.csv files
        polscore_log_fo = open(self.dir_in+self.pollog,"a") # WFA 2018 02 19
        polscore_csv_fo = open(self.dir_in+self.polcsv,"a") # WFA 2018 02 19
                        
        # Define numbers of rows and columns 
        columns = self.num_var_in
        rows = len(self.y)
        
        # Looping through to create a list with independent variables
        self.my_indep_variables = []
        for i in range(columns):
            self.my_indep_variables.append("x"+str(i+1)) 
            
        # Show information
        print("\nExplanatory variables: ",self.my_x_axis_label[:len(self.my_x_axis_label)-1])
        print("Response variable: ",self.my_x_axis_label[len(self.my_x_axis_label)-1])
        print("File name: ",self.data_in)
                
        # Create regression model
        polscore_model =   pol1.Multvar_reg_modeling(self.num_var_in,\
        self.y,self.x,'y',self.my_indep_variables,self.reg_method_in)     
        self.my_model_coefs,my_R2,my_R2_adj,my_sd,my_rho,my_rho_p = \
        polscore_model.summary()
        
        # Invoke gen_model_4_polscore() method
        self.gen_model_4_polscore()
                
        # Some editing
        my_model_string1 = self.polscore_model_string.replace("++"," + ")
        my_model_string2 = my_model_string1.replace("--"," - ")
        my_model_string3 = my_model_string2.replace("+  -"," - ")
        my_model_string = my_model_string3.replace("+   "," + ")
    
        # Fix the number of characters
        my_str_7_char = str(self.count_models+1+self.ip) # WFA 2018 02
        if len(my_str_7_char)< 8:
            my_str_in1 = str((7-len(my_str_7_char) )*"0")+my_str_7_char
        
        # Write output information
        line_2_write = "\n\n##################################### POLSCORE MODEL GENERATOR"
        line_2_write += " ###########################################\n"
        polscore_log_fo.write(line_2_write)
        line_2_write = "\nPolynomial equation number "+my_str_in1
        line_2_write += ":"+my_model_string
        polscore_log_fo.write(line_2_write)          
        polscore_log_fo.write("\nFile: "+self.data_in)
        line_2_write = "\nBest fit equation between observed and predicted "        
        line_2_write += "information ("+self.reg_method_in+"): "
        line_2_write += str(self.p1)
        polscore_log_fo.write(line_2_write)
        polscore_log_fo.write('\nR-squared            % -5.6f' % my_R2 )        
        polscore_log_fo.write('\nAdjusted R-square    % -5.6f' % my_R2_adj )        
        polscore_log_fo.write('\nStandard deviation   % -5.6f' % my_sd)        
        polscore_log_fo.write('\nSpearman correlation % -5.6f' % my_rho )        
        polscore_log_fo.write('\np-value              % -5.6f' % my_rho_p )
                
        # Check p-value
        if my_rho_p < 0.0001:
            my_rho_p = 0.000
        
        # Write line in CSV file
        polscore_csv_fo.write("scoring_function_"+my_str_in1+".csv,"+\
                          str(my_R2)+","+str(my_R2_adj)+","+str(my_sd)+","+\
                          str(my_rho)+","+str(my_rho_p)+"\n")

    # Define read_csv_4_polscore() method
    def read_csv_4_polscore(self):
        """Function to read CSV file"""
    
        # Import libraries
        import csv
        import numpy as np
        
        # Read first line to get headers
        csv_in = open(self.dir_in+self.data_in,"r") 
        get_csv_lines = csv.reader(csv_in)
    
        # Set up empty list
        self.my_x_axis_label = []
        
        # Read CSV file first line only
        for line in get_csv_lines:  
            for selected in self.explanatory_in:
                self.my_x_axis_label.append(line[selected])
            self.my_x_axis_label.append(line[self.response_in])
            break
                
        # Close file
        csv_in.close()
            
        # Read CSV file and skips first line
        csv = np.genfromtxt (self.dir_in+self.data_in, delimiter=",", skip_header = 1) 
    
        # Get each column from CSV file
        self.y = csv[:,self.response_in]
        
        # my_matrix = [[0]*number_columns for i in range(number_rows)] 
        number_columns = len(self.explanatory_in)
        number_rows = len(self.y)
        
        #self.x = [[0]*number_columns for i in range(number_rows)]
        self.x = np.array([[0]*number_columns]*number_rows,float)

        # Looping through csv colums to get data
        for k in range(len(self.explanatory_in)):
            for i in range(len(self.y)):
                self.x[i][k] = float(csv[i,self.explanatory_in[k]])

    # Define def gen_model_4_polscore() method
    def gen_model_4_polscore(self):
        """Method to generate POLSCORE models"""
        
        # Import library
        import numpy as np
    
        # Looping through to generate POLSCORE model
        p = 0
        total_variables = self.num_var_in + 1
        self.polscore_model_string = ""
        for i in range(total_variables): # WFA 2018 02 19
            if i == 0:
                p += self.my_model_coefs[i]
                self.polscore_model_string += str("%12.6f"%self.my_model_coefs[i])+"+" 
            else:
                p += self.my_model_coefs[i]*self.x[:,i-1]
                self.polscore_model_string += str("+%12.6f"%self.my_model_coefs[i])+\
                "*("+self.my_x_axis_label[i-1]+")" # WFA 2018 02 19
    
        # Generate best fit line for experimental and 
        # computational POLSCORE model (least-squares polynomial fitting) 
        self.z = np.polyfit(self.y,p, 1)
        self.p1 = np.poly1d(self.z)
    
    # Define gen_lists() method
    def gen_lists(self):
        """Method to generate lists of integer as a combination"""
    
        # Import library
        import itertools
    
        # Set up empty list
        self.output_list = []
    
        # Generate combinations
        for j in range(0,self.total_elem+1):
            for subset in itertools.combinations(self.initial_list,j):
                if len(subset) >= self.min_elem and len(subset) <= self.max_elem:
                    # Some editing
                    aux_str = str(subset)
                    aux_str = aux_str.replace("(","")
                    aux_str = aux_str.replace(")","")
                    aux_str = aux_str.replace(" ","")
                    
                    # Append to the output_list
                    self.output_list.append(aux_str)
    
        # Looping through output_list
        for line in self.output_list:
            print(line)
    
        # Show number of combinations
        print("\nTotal number of combinations: ",len(self.output_list))

    # Define write_lists() method
    def write_lists(self):
        """Method to write out pre-generated lists of integers"""
        
        # Open new file
        lo1 = open(self.dir_in+"list_csv.csv","w")
        
        # Looping through self.output_list
        for line in self.output_list:
            lo1.write(str(line)+"\n")
        
        # Write header in the CSV file
        # polscore_csv_fo = open(self.dir_in+self.polcsv,"a") # WFA 2018 02 21
        # line_2_write = "File,R2,R2 adj,Standard Deviation,Spearman's correlation,p-value\n"
        # polscore_csv_fo.write(line_2_write)
        
        # Close file
        lo1.close()
    
    # Define gen_models() method
    def gen_models(self):
        """Method to generate machine learning models for a specific regression method"""
        
        # Set up empty list
        self.explanatory_in = []
        
        # Assign zero to count_modes
        self.count_models = 0
                    
        # Show information about the regression method    
        print("\nRunning regression method: ",self.reg_method_in)
        
        # Looping through self.output_list to generate self.explanatory_in
        for line1 in self.output_list:
            aux_line = ""
            for line2 in line1:
                aux_line += line2
                if line2 == ",":
                    self.explanatory_in.append(int(aux_line[:len(aux_line)-1]))
                    aux_line = ""
            
            # Set up explanatory variables
            self.explanatory_in.append(int(aux_line[:len(aux_line)]))
            
            # Get self.num_var_in
            self.num_var_in = len(self.explanatory_in)
            
            # Invoke read_csv_4_polscore() method
            self.read_csv_4_polscore()
                        
            # Invoke polscore_smlearning()
            self.polscore_smlearning()
            
            # Update self.count_models
            self.count_models += 1
            
            # Set up empty list
            self.explanatory_in = []
        
        # Show information about the regression method    
        print("\nDone with regression method: ",self.reg_method_in)
        
        # Show information about the total number of models
        print("\nTotal number of models: ",self.count_models)
        
    # Define gen_models_all_methods() method
    def gen_models_all_methods(self):
        """Method to generate machine learning models using all regression methods"""
        
        # Set up empty list
        self.explanatory_in = []
        
        # Set up list of methods
        list_of_methods = ["LinearRegression","Lasso","LassoCV","Ridge","RidgeCV","ElasticNet",\
        "ElasticNetCV"]
        
        # Assign zero to count_modes
        self.count_models = 0
        
        # Looping through methods
        for self.reg_method_in in list_of_methods:
            
            # Show information about the regression method
            print("\nRunning regression method: ",self.reg_method_in)
        
            # Looping through self.output_list to generate self.explanatory_in
            for line1 in self.output_list:
                aux_line = ""
                for line2 in line1:
                    aux_line += line2
                    if line2 == ",":
                        self.explanatory_in.append(int(aux_line[:len(aux_line)-1]))
                        aux_line = ""
            
                # Set up explanatory variables
                self.explanatory_in.append(int(aux_line[:len(aux_line)]))
            
                # Get self.num_var_in
                self.num_var_in = len(self.explanatory_in)
            
                # Invoke read_csv_4_polscore() method
                self.read_csv_4_polscore()
            
                # Invoke polscore_smlearning()
                self.polscore_smlearning()
            
                self.count_models += 1
                self.explanatory_in = []
            
            # Show information about the regression method 
            print("\nDone with regression method: ",self.reg_method_in)
        
        # Show information about the total number of models
        print("\nTotal number of models: ",self.count_models)

