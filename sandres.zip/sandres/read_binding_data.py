#! /usr/bin/python
# Class to add experimental binding information to a CSV file.
# Experimental binding information is on a csklig.in file and the program needs
# as inputs chklig.in and a csv file on which a column with experimental binding information
# will be written.
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################
class Bind(object):
    """Class to handle experimental binding information"""
    
    # Define constructor method
    def __init__(self,proj_dir,chklig,file_in,file_out):
        
        # Define attributes
        self.proj_dir = proj_dir
        self.chklig = chklig
        self.file_in = file_in
        self.file_out = file_out
        
    # Define method to read CSV file
    def read_csv(self):
        """Method to read csv file"""
        
        # Import libraries
        import csv
        import sys
        
        # Set up empty list
        self.csv_list =  []
        
        # Try to open csv file
        try:
            fo1 = open(self.proj_dir+self.file_in,"r")
            csv1 = csv.reader(fo1)
        except IOError:
            sys.exit("\nI can't find "+self.file_in+" file!")
        
        # Get first line
        for line in csv1:
            first = str(line)
            first = first.replace("[","")
            first = first.replace("]","")
            first = first.replace("'","")
            # self.first_line = first+",log("+self.binding_type+")"
            self.first_line = first
            break
            
        # Looping through csv file
        for line in csv1:
            self.csv_list.append(line)
        
        # Close file
        fo1.close()
    
    # Define method to read chklig.in file
    def read_chklig(self):
        """Method to read binding information from a chklig.in file"""
        
        # Import libraries
        import sys
        import csv
        import numpy as np
        
        # Set up empty lists
        self.binding =  []
        self.ligand = []
        
        # Try to open file
        try:
            fo2 = open(self.proj_dir+self.chklig,"r")
            csv2 = csv.reader(fo2)
        except IOError:
            sys.exit("\nI can't find "+self.chklig+" file!")
        
        print("\n Reading binding information...")
        print("Ligand\tBinding Information",end=" (")
        
        # First reading to get binding type 
        for line in csv2:
            if "Type of binding information:" in line[0]:
                index_binding_type = str(line[0]).index(":")
                print(str(line[0])[index_binding_type+1:]+")")
                # Get binding type
                aux_binding_type = str(line[0])[index_binding_type+1:]
                self.binding_type = aux_binding_type.replace(" ","")
                break
        
        # Test type of binding
        if self.binding_type.upper() == "KI" \
        or self.binding_type.upper() == "IC50"\
        or self.binding_type.upper() == "KD"\
        or self.binding_type.upper() == "EC50"\
        or self.binding_type.upper() == "KA":
            # Looping through csv file
            for line in csv2:
                if line[0] == "CHKLIG":
                    print(line[2],"\t",line[5])
                    self.binding.append( np.log10(float(line[5])) - 9 ) 
                    self.ligand.append(line[2])
                
        # For self.binding_type = "DeltaG" 
        elif self.binding_type.upper() == "DELTAG":
            
            # Looping through csv file
            for line in csv2:
                if line[0] == "CHKLIG":
                    print(line[2],"\t",line[5])
                    self.binding.append(float(line[5])) 
                    self.ligand.append(line[2])
        else:
            sys.exit("\nPlease check type of bind, "+self.binding_type+" is not valid!")
            
            
        # Close file
        fo2.close()
    
    # Define add_bind() method
    def add_bind(self):
        """Method to add a column with experimental binding information to a csv file"""
        
        # Set up empty list
        output_list = []
        
        # Open new file
        fo3 = open(self.proj_dir+self.file_out,"w")
        
        # Assign     zero to i
        i = 0
        
        # Looping through self.csv_list and checking ligand presence
        for line1 in self.csv_list:
            for line2 in self.ligand:
                if line2 in line1[0]:
                    aux = str(line1)
                    aux = aux.replace("[","")
                    aux = aux.replace("]","")
                    aux = aux.replace("'","")
                    aux = aux+","+str(self.binding[i])
                    output_list.append(aux)
                    print(aux)
                    i += 1
                    break
        
        # Write first line
        self.first_line = str(self.first_line)+",log("+self.binding_type+")"
        aux_first_line = self.first_line.replace(", ",",")
        fo3.write(aux_first_line+"\n")
        
        # Looping through output_list
        for line in output_list:
            fo3.write(line+"\n")
        
        # Close file
        fo3.close()
                    