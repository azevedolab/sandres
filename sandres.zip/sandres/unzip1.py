#! /usr/bin/python
# Program to unzip files
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################

class UNZIPSDF(object):
    """Class to unzip a sdf file"""
    
    # Define constructor method
    def __init__(self,dir_in,file_in):
        self.dir_in = dir_in
        self.file_in = file_in
    
    # Define dounzip() method
    def dounzip(self):
        """method to unzip"""
        
        # Import library
        import gzip
        
        # Set up empty list
        unzip_list = []
        
        # Try to unzip it
        try:
            f0 = gzip.open(self.dir_in+self.file_in, 'rb')
        except IOError:
            print("\nI can't find ",self.file_in," file!")
            return
        
        # Get data    
        data0 = f0.readlines()
        
        # Looping through data0
        for line in data0:
            aux_zip_line0 = str(line)
            aux_zip_line1 = aux_zip_line0.replace("b","")
            aux_zip_line2 = aux_zip_line1.replace("\\n","")
            aux_zip_line3 = aux_zip_line2.replace("'","")
            unzip_list.append(aux_zip_line3+"\n")
        
        # Close file
        f0.close()
        
        # Open new file
        f1 = open(self.dir_in+self.file_in,"w")
        
        # Looping through unzip_list
        for line in unzip_list:
            f1.write(line)
        
        # Close file
        f1.close()
