#! /usr/bin/python
# Class to generate geninp.in, ststru.in, fndwat.in, and biomat.in files
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################
class GenPre(object):
    """Class to write geninp.in for SAnDReS"""
    
    # Define constructor method
    def __init__(self,dir_in):
        
        # Define attributes
        self.dir_in = dir_in
        self.pdb = []
        self.lig = []
        self.chain = []
        self.res = []
    
    def read_chklig(self):
        """Method to read chklig.in to get strutural data"""
        
        # Import libraries
        import csv
        import sys
        
        
        # Try to open chklig.in
        try:
            fo1 = open(self.dir_in+"chklig.in","r")
            csv1 = csv.reader(fo1)
        except IOError:
            sys.exit("\nI can't find chklig.in file. Finishing program!")
        
        # Looping throug csv1
        for line in csv1:
            if "CHKLIG" in str(line):
                print(line)
                self.pdb.append(line[1])
                self.lig.append(line[2])
                self.chain.append(line[3])
                self.res.append(line[4])
        
        # Close file
        fo1.close()
    
    # Define generate() method
    def generate_all(self):
        """Method to generate geninp.in, ststru.in, fndwat.in, and biomat.in files"""
        
        # Import libraries
        import time
        import os
        
        # String for local time
        my_local_time = str(time.strftime("%Y_%m_%d_%H_%M_%S"))
        my_path = self.dir_in+"Dataset_"+my_local_time
        
        # Create dir
        try:
            os.makedirs(my_path)
        except OSError as exception:
            if exception.errno != errno.EEXIST:
                raise    
        
        # Open new file
        fo2 = open(self.dir_in+"geninp.in","w")
        
        # Write commands
        fo2.write("GENINP,FORALL,chklig.in,ststru.in,biomat.in,fndwat.in,15.0,10\n")
        fo2.write("ENDOF")
        
        # Close file
        fo2.close()
        
        # Show information
        print("\nNew geninp.in has been generated!")
        
        # Open new files
        fo3 = open(self.dir_in+"ststru.in","w")
        fo4 = open(self.dir_in+"fndwat.in","w")
        fo5 = open(self.dir_in+"biomat.in","w")
        
        # Write first line of fndwat.in
        fo4.write("WATDIR,"+str(my_path)+"/\n")
        
        # Write command of biomat.in
        fo5.write("BIOMAT")
        
        # Write commands
        for i in range(len(self.pdb)):
            # Write ststru.in
            fo3.write("STSTRU,"+str(self.pdb[i])+","+str(self.lig[i])+","+\
            str(self.chain[i])+","+str(self.res[i])+"\n")
            
            # Write fndwat.in
            fo4.write("FNDWAT,"+str(self.pdb[i])+","+str(self.lig[i])+","+\
            str(self.chain[i])+","+str(self.res[i])+",15.0,10\n")
            
            # Write biomat.in
            fo5.write(","+str(self.pdb[i]))
        
        # Write last line for both files
        fo3.write("ENDOF")
        fo4.write("ENDOF")
        fo5.write("\nENDOF")
        
        # Close files
        fo3.close()
        fo4.close()
        fo5.close()
        
        # Show information
        print("\nNew ststru.in has been generated!")
        print("\nNew fndwat.in has been generated!")
        print("\nNew biomat.in has been generated!")
        