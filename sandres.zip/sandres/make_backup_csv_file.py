#! /usr/bin/python
# Class to make backup copies of csv files
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################
#
class Backup(object):
    """Class to backup training and test sets"""
    
    # Define constructor method
    def __init__(self):
        
        # Import library
        import time
            
        # String for local time
        self.local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Define make_copy() method
    def make_copy(self,dir_in,file_2_backup):
        """Method to make backup copy"""
        
        # Import library
        import shutil
        
        # Get length of file
        l_of_f = len(file_2_backup)
        
        # Make backup copy
        try:
            shutil.copy2(dir_in+file_2_backup,dir_in+file_2_backup[:l_of_f-4]+"_"+self.local_time+".csv")
            print("\nCopying "+file_2_backup+" to "+file_2_backup[:l_of_f-4]+"_"+self.local_time+"\n")
        except IOError:
            print("\nIOError! I can't find "+file_2_backup+" file!")