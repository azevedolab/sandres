import sys, string, os
os.system( '"C:/Users/labioquest/AppData/Local/Google/Chrome/Application/chrome.exe" http://azevedolab.net/resources/AutoDock4_2A4L_2017a.pdf')
