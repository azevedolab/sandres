#! /usr/bin/python
# scikit_regression_methods_v1_1 for SAnDReS   
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################
#
# Import libraries
from scipy import c_, ones, dot, stats
from scipy.linalg import inv 
from numpy import sqrt, diagonal, average

class Multvar_reg_modeling:
    """
    Input:
        y = dependent variable
        y_varnm = string with the variable label for y
        x = independent variables, note that a constant is added by default
        x_varnm = string or list of variable labels for the independent variables
    
    Output:
        There are no values returned by the class. Summary provides printed output.
        All other measures can be accessed as follows:

        Step 1: Create an OLS instance by passing data to the class

            m = Multvar_reg_modeling(y,x,y_varnm = 'y',x_varnm = ['x1','x2','x3','x4'])

        Step 2: Get specific metrics

            To print the coefficients: 
                >>> print m.b
            To print the coefficients p-values: 
                >>> print m.p
    """

    def __init__(self,num_indep_var,y,x,y_varnm = 'y',x_varnm = '',selected_method_in="LinearRegression"):
        """
        Initializing the Multvar_reg_modeling class. 
        """
        self.num_indep_var = num_indep_var
        self.y = y
        self.x = c_[ones(x.shape[0]),x]
        self.y_varnm = y_varnm
        self.selected_method_in = selected_method_in 
        if not isinstance(x_varnm,list): 
            self.x_varnm = ['const'] + list(x_varnm)
        else:
            self.x_varnm = ['const'] + x_varnm

        # length of vector y
        self.num_elements = len(self.y)
        
        # Estimate model using OLS
        self.basic_statistical_analysis()
    
    def calc_ESS(self):
        """Method to calculate Explained Sum of Squares (ESS)"""
        # Import library
        import numpy as np
        
        # Get number of data points
        n = len(self.y_in)
        
        # Set up array with zeros
        aux = np.zeros(n,dtype=float)
        
        # Calculate mean self.y_in
        mean_y_in = np.mean(self.y_in)
        
        # Looping through data points (self.y_in) and self.y_pred
        for i in range(n):
                aux[i] = (self.y_pred[i] - mean_y_in)**2
        
        # Calculates Explained Sum of Squares (ESS)
        self.ess = np.sum(aux)
    
    def calc_RSS(self):
        """Function to calculate Residual Sum of Squares (RSS)"""
        # Import library
        import numpy as np
        
        # Get number of data points
        n = len(self.y_in)
        
        # Set up array with zeros
        aux = np.zeros(n,dtype=float)
        
        # Looping through data points (self.y_in) and self.y_pred
        for i in range(n):
                aux[i] = (self.y_in[i] - self.y_pred[i])**2
        
        # Calculates Residual Sum of Squares (RSS)
        self.rss = np.sum(aux)
            
    def stat_analysis_of_reg_models(self):
        """Function to carry out statistical analysis of regression models"""
        # import libraries
        from scipy.stats import spearmanr, pearsonr
        import numpy as np
        
        # Set up empty list   
        data_list = []
        
        # Looping through self.y_in to get elements for list
        for i in range(len(self.y_in)):
                aux = float(self.y_in[i][0])
                data_list.append(aux)
        
        # Get Spearman's rank and Person correlation coefficient and p-value         
        self.corr_s,self.pvalue_s = spearmanr(data_list,self.y_pred)
        self.corr_p,self.pvalue_p = pearsonr(data_list,self.y_pred)
        
        # To avoid "nan"
        if str(self.corr_s) == "nan":
            self.corr_s,self.pvalue_s = 0.0,1.0
            
        # Call calc_RSS
        self.calc_RSS()
        
        # Call calc_ess
        self.calc_ESS()
                
        # Basic statistics 
        n = len(self.y_in)                                          # Number of data points
        p = 3                                                           # Number of explanatory variables
        self.r2S = self.corr_p*self.corr_p                                  # R-squares
        self.s_dev = np.sqrt(self.rss/(n-p-1))                # Standard deviation
        #f_stat = (self.ess/p)*( (n-p-1)/self.rss )        # Calculate F-stat                
        
        # Show statistical analysis
        print("\nStatistical Analysis of Regression Model")
        print("Method: Multiple Linear Regression ("+self.reg_method+")")
        print("N = ",n)
        print("Regression model: ",self.reg_model)
        for i in range(len(self.se)):
                print("Standard error in b(",i,") : %.2f "%(2*self.se[i]))
        print("Spearman's rank correlation coefficient : %.3f"%self.corr_s,"p-value: %.3e"%self.pvalue_s)
        print("Pearson's correlation coefficient (r): %.3f"%self.corr_p,"p-value: %.3e"%self.pvalue_p)
        print("r^2: %.3f"%self.r2S)
        #print("Standard deviation (s): %.3f"%self.s_dev)
        #print("Residual sum of squares (RSS): %.4f"%self.rss)
        #print("F-stat: %.4f"%f_stat)
        
    
    def calc_SE_M(self):
        """Function to calculate standard error (SE) Equations taken from http://zip2002.psy.unipd.it/index.php?page=sbcs"""
        # Import library
        import numpy as np
        
        # Get number of rows and columns
        n = len(self.x_in)
        row = n        
        column = len(self.x_in[0])

        # Set up matrices and vectors
        # a = np.array([[0]*column]*row,float)                  # A matrix row(3) x column(
        x = np.array([[0]*(column+1)]*row,float)                # A matrix row x column
        beta = np.zeros(column+1,float)                                 # A vector with column elements
        self.se = np.zeros(column+1,float)                                   # A vector with column+1 elements

        # Beta coefficients
        for i in range(column):
                beta[i] = self.b[i]
        
        # Looping x_in to build x matrix
        for i in range(n):
                x[i][0] = 1.0
                for j in range(column):
                        x[i][j+1] = self.x_in[i][j]
                
        # Calculate transposes
        xt = np.transpose(x)
        yt = np.transpose(self.y_in)
        
        # Calculate [xt]*[x]
        xtx = np.dot(xt,x)
        
        # Calculate inverse of xtx
        #from numpy.linalg import inv
        xtx_inv = inv(xtx) 
        
        # Calculate ms_res
        aux1 = np.dot(yt,self.y_in)
        aux2 = np.dot(beta,xt)
        aux3 = np.dot(aux2,self.y_in)
        epe = aux1 - aux3
        ms_res = epe/(n-column-1)
        
        # looping through standard errors
        for i in range(column+1):
                if ms_res*xtx_inv[i][i]  >= 0:
                        self.se[i] = np.sqrt( ms_res*xtx_inv[i][i] )
                else:
                        self.se[i] = np.sqrt( np.abs( ms_res*xtx_inv[i][i] ) )
        
    
    def gen_modelMultD2(self):
        """Function to generate model (y_pred)"""
        self.y_pred = []
    
        columns =  len(self.b) - 1  
    
        # Looping through data to generate y_pred 
        for i in range(len(self.x_in)):
            aux1 = self.b[0]
            for j in range(columns):
                aux1 += self.b[j+1]*self.x_in[i][j]
            self.y_pred.append(aux1)
            aux1 = 0
            
    def prep_y1(self):
        """Method to prepare y for scikit"""
        self.y_in = []
        for line in self.y:
            aux_list = []
            aux_list.append(line)
            self.y_in.append(aux_list)
    
    def prep_x1(self):
        """Method to prepare x for scikit"""
        self.x_in = []
        for line in self.x:
            aux_list = []
            for aux1 in line[1:]:
                aux_list.append(aux1)
            self.x_in.append(aux_list)

    def scikit_LinearRegression(self):
        """Function to generate a multiple regression model sklearn.linear_model.LinearRegression"""
    
        # import libraries
        from sklearn import linear_model
        import numpy as np
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo = open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file")
        
        # Looping through data
        for line in my_csv:
            if line[0] == "LinearRegression":
                
                # For fit_intercept (whether to calculate the intercept for this model. If set to false, no intercept will be used in
                # calculations (e.g. data is expected to be already centered)
                if line[1] == "True":
                    fit_in = True
                else:
                    fit_in = False
                
                # For normalize (If True, the regressors X will be normalized before regression. This parameter is ignored when
                #  fit_intercept is set to False. When the regressors are normalized, note that this makes the hyperparameters learnt 
                # more robust and almost independent of the number of samples. The same property is not valid for standardized data.
                #  However, if you wish to standardize, please use preprocessing.StandardScaler before calling fit on an estimator 
                # with normalize=False)
                if line[2] == "True":
                    norm_in = True
                else:
                    norm_in =  False
                
                # For copy_X (If True, X will be copied; else, it may be overwritten)
                if line[3] == "True":
                    copy_in = True
                else:
                    copy_in = False
                    
                break
        
        # Close file
        fo.close()

        # Set up string with regression method
        self.reg_method = "LinearRegression"

        # Get a model
        model = linear_model.LinearRegression(fit_intercept=fit_in, normalize=norm_in, copy_X=copy_in)
        model.fit(self.x_in, self.y_in)
                
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
            aux_string = str(  " + %8.3f"%float(model.coef_[0][i])+"x"+str(i+1)  )
            self.reg_model += aux_string
        
        # Get Multiple model 
        alphas = []
        columns = len(self.x_in[0])
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[0][i])
    
        self.b = np.array(alphas)
        
    def scikit_Lasso(self):
        """Function to generate a multiple regression model sklearn.linear_model.Lasso"""
        
        # import library
        from sklearn import linear_model
        import numpy as np
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
        
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "Lasso" and line[0] != "LassoCV":
                
                # For alpha_in
                alpha_in = float(line[1])
                
                # For fit_in
                if line[2] == "True":
                    fit_in = True           # True
                elif line[2] == "False":
                    fit_in = False
                else:
                    print("Problem!")
                
                # For norm_in
                if line[3] == "True":
                    norm_in = True           
                elif line[3] == "False":
                    norm_in = False         # False
                else:
                    print("Problem!")
                
                # For pre_in
                if line[4] == "True":
                    pre_in = True           
                elif line[4] == "False":    # False
                    pre_in = False
                else:
                    print("Problem!")
                
                # For copy_in
                if line[5] == "True":
                    copy_in = True           # True
                elif line[5] == "False":
                    copy_in = False
                else:
                    print("Problem!")
        
                # For max_in and tol_in
                max_in = int(line[6])       # True
                tol_in = float(line[7])   
                
                # For warm_in
                if line[8] == "True":
                    warm_in = True           # True
                elif line[8] == "False":
                    warm_in = False
                else:
                    print("Problem!")
                
                # For pos_in
                if line[9] == "True":
                    pos_in = True           
                elif line[9] == "False":    # False
                    pos_in = False
                else:
                    print("Problem!")
                                    
                # For sel_in
                sel_in = str(line[10])
                
                # For rand_in
                rand_in = int(line[11])
                
                # Finish loop
                break
        
        # Close file
        fo.close()
        
        print("Regression method: ",line[0])
        print("Alpha = %6.3f"%alpha_in)
        print("Fit intercept? "+line[2])
        print("Normalize? "+line[3])
        print("Pre compute? "+line[4])
        print("Copy x array? "+line[5])  
        print("Maximum number of iterations: %6.3e"%max_in)  
        print("Tolerance for the optimization: %6.3e"%tol_in)  
        print("Reuse the solution of the previous call to fit? "+line[8] )
        print("Force the coefficients to be positive? "+line[9])  
        print("Method for coefficients: "+line[10])
        print("Random seed: "+str(rand_in))
                 
        # Set up alpha_array
        alpha_array =  np.linspace(0.9*alpha_in, 1.1*alpha_in, num=3)
        
        # Set up empty list
        residuals = []
        
        # Looping through alpha_array
        for i in alpha_array:
            # Create and fit the model
            model = linear_model.Lasso( alpha = i,          # Constant that multiplies the L1 term. 
                    fit_intercept = fit_in,    # Whether to calculate the intercept for this model.
                    normalize = norm_in,       # If True, the regressors X will be normalized before regression. 
                    precompute = pre_in,       # Whether to use a precomputed Gram matrix to speed up calculations. 
                    copy_X = copy_in,          # If True, X will be copied; else, it may be overwritten.
                    max_iter = max_in,         # The maximum number of iterations.
                    tol = tol_in,              # The tolerance for the optimization:
                    warm_start = warm_in,      # When set to True, reuse the solution of the previous call to fit
                                               # as initialization.
                    positive = pos_in,         # When set to True, forces the coefficients to be positive.
                    selection = sel_in,        # If set to ‘random’, a random coefficient is updated every iteration
                                               # rather than looping over features sequentially by default. 
                    random_state = rand_in     # The seed of the pseudo random number generator that selects a
                                               # random feature to update. 
                                    ) 
            model.fit(self.x_in, self.y_in)
            residuals.append(np.mean((model.predict(self.x_in)- self.y_in)** 2) )
        
        # Get model for minimum residual
        my_min = np.min(residuals)
        y_index = residuals.index(my_min)
        model = linear_model.Lasso(alpha=alpha_array[y_index] )
        model.fit(self.x_in, self.y_in)
        
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
                aux_string = str(  " + %8.3f"%float(model.coef_[i])+"x"+str(i+1)  )
                self.reg_model += aux_string
        
        # Get Multiple model 
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[i])
        
        # Set up array with coefficients
        self.b = np.array(alphas)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Lasso"   
    
    def scikit_LassoCV(self):
        """Function to generate a multiple regression model using iterated sklearn.linear_model.Lasso to
        optimize alpha"""
    
        # import library
        from sklearn import linear_model
        import numpy as np
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
        
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "LassoCV":
                
                # For alpha_in
                alpha_in = float(line[1])
                
                # For fit_in
                if line[2] == "True":
                    fit_in = True           # True
                elif line[2] == "False":
                    fit_in = False
                else:
                    print("Problem!")
                
                # For norm_in
                if line[3] == "True":
                    norm_in = True           # True
                elif line[3] == "False":
                    norm_in = False
                else:
                    print("Problem!")
                
                # For pre_in
                if line[4] == "True":
                    pre_in = True           
                elif line[4] == "False":    # False
                    pre_in = False
                else:
                    print("Problem!")
                
                # For copy_in
                if line[5] == "True":
                    copy_in = True           # True
                elif line[5] == "False":
                    copy_in = False
                else:
                    print("Problem!")
        
                # For max_in and tol_in
                max_in = int(line[6])       # True
                tol_in = float(line[7])   
                
                # For warm_in
                if line[8] == "True":
                    warm_in = True           # True
                elif line[8] == "False":
                    warm_in = False
                else:
                    print("Problem!")
                
                # For pos_in
                if line[9] == "True":
                    pos_in = True           
                elif line[9] == "False":    # False
                    pos_in = False
                else:
                    print("Problem!")
                                    
                # For sel_in
                sel_in = str(line[10])
                
                # For rand_in
                rand_in = int(line[11])
                
                # Finish loop
                break
        
        # Close file
        fo.close()
        
        print("Regression method: ",line[0])
        print("Alpha = %6.3f"%alpha_in)
        print("Fit intercept? "+line[2])
        print("Normalize? "+line[3])
        print("Pre compute? "+line[4])
        print("Copy x array? "+line[5])  
        print("Maximum number of iterations: %6.3e"%max_in)  
        print("Tolerance for the optimization: %6.3e"%tol_in)  
        print("Reuse the solution of the previous call to fit? "+line[8] )
        print("Force the coefficients to be positive? "+line[9])  
        print("Method for coefficients: "+line[10])
        print("Random seed: "+str(rand_in))
        
        # Set up alpha_array
        alpha_array =  np.linspace(0.1, 1.0, num=101)
        
        # Set up empty list
        residuals = []
        
        # Looping through alpha_array
        for i in alpha_array:
            # Create and fit the model
            model = linear_model.Lasso( alpha = i,          # Constant that multiplies the L1 term. 
                    fit_intercept = fit_in,    # Whether to calculate the intercept for this model.
                    normalize = norm_in,       # If True, the regressors X will be normalized before regression. 
                    precompute = pre_in,       # Whether to use a precomputed Gram matrix to speed up calculations. 
                    copy_X = copy_in,          # If True, X will be copied; else, it may be overwritten.
                    max_iter = max_in,         # The maximum number of iterations.
                    tol = tol_in,              # The tolerance for the optimization:
                    warm_start = warm_in,      # When set to True, reuse the solution of the previous call to fit
                                               # as initialization.
                    positive = pos_in,         # When set to True, forces the coefficients to be positive.
                    selection = sel_in,        # If set to ‘random’, a random coefficient is updated every iteration
                                               # rather than looping over features sequentially by default. 
                    random_state = rand_in     # The seed of the pseudo random number generator that selects a
                                               # random feature to update. 
                                    ) 
            model.fit(self.x_in, self.y_in)
            residuals.append(np.mean((model.predict(self.x_in)- self.y_in)** 2) )
        
        # Get model for minimum residual
        my_min = np.min(residuals)
        y_index = residuals.index(my_min)
        model = linear_model.Lasso(alpha=alpha_array[y_index] )
        model.fit(self.x_in, self.y_in)
        
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
                aux_string = str(  " + %8.3f"%float(model.coef_[i])+"x"+str(i+1)  )
                self.reg_model += aux_string
        
        # Get Multiple model 
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[i])
        
        # Set up array with coefficients
        self.b = np.array(alphas)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Lasso with CV"
        
    def scikit_Ridge(self):
        """Function to generate multiple regression model using sklearn.linear_model.Ridge"""
        
        # Import library
        from sklearn import linear_model
        import numpy as np 
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
        
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "Ridge" and line[0] != "RidgeCV":
                
                # For alpha_in
                alpha_in = float(line[1])   # Regularization strength; must be a positive float. It can be > 1.0
                
                # For fit_in
                if line[2] == "True":
                    fit_in = True           # True
                elif line[2] == "False":
                    fit_in = False
                else:
                    print("Problem!")
                
                # For norm_in
                if line[3] == "True":
                    norm_in = True           
                elif line[3] == "False":
                    norm_in = False
                else:
                    print("Problem!")
                                
                # For copy_in
                if line[4] == "True":
                    copy_in = True           # True
                elif line[4] == "False":
                    copy_in = False
                else:
                    print("Problem!")
        
                # For max_in
                if line[5] == "None":
                    max_in = None
                else:
                    max_in = int(line[5])
                
                # For tol_in
                tol_in = float(line[6])   
                
                # For solver_in
                solver_in = line[7] # It can be ‘auto’, ‘svd’, ‘cholesky’, ‘lsqr’, ‘sparse_cg’, ‘sa'
                
                # Finish loop
                break
        
        # Close file
        fo.close()
        
        print("Regression method: ",line[0])
        print("Alpha = %6.3f"%alpha_in)
        print("Fit intercept? "+line[2])
        print("Normalize? "+line[3])
        print("Copy x array? "+line[4])  
        print("Maximum number of iterations: ",max_in)  
        print("Tolerance for the optimization: %6.3e"%tol_in)  
        print("Solver: ",solver_in)
             
        # Get a model
        model = linear_model.Ridge(alpha=alpha_in, fit_intercept = fit_in, normalize = norm_in, copy_X = copy_in, 
                                     max_iter = max_in, tol = tol_in, solver = solver_in )
        model.fit(self.x_in, self.y_in)
                
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
            aux_string = str(  " + %8.3f"%float(model.coef_[0][i])+"x"+str(i+1)  )
            self.reg_model += aux_string
                
        # Get Multiple model 
        alphas = []
        columns = len(self.x_in[0])
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[0][i])
    
        # Set up array with coefficients
        self.b = np.array(alphas)  
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Ridge"
    
    def scikit_RidgeCV(self):
        """Function to generate a multiple regression model using iterated sklearn.linear_model.Ridge"""
        
        # import library
        from sklearn import linear_model
        import numpy as np
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
        
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "RidgeCV":
                
                # For alpha_in1
                alpha_in1 = float(line[1])   # Regularization strength; must be a positive float. It can be > 1.0
                
                # For alpha_in2
                alpha_in2 = float(line[2])   # Regularization strength; must be a positive float. It can be > 1.0
                
                # For delta_alpha
                delta_alpha = float(line[3])
                
                # For fit_in
                if line[4] == "True":
                    fit_in = True           # True
                elif line[4] == "False":
                    fit_in = False
                else:
                    print("Problem!")
                
                # For norm_in
                if line[5] == "True":
                    norm_in = True           # True
                elif line[5] == "False":
                    norm_in = False
                else:
                    print("Problem!")
                                
                # For copy_in
                if line[6] == "True":
                    copy_in = True           # True
                elif line[6] == "False":
                    copy_in = False
                else:
                    print("Problem!")
        
                # For max_in
                if line[7] == "None":
                    max_in = None
                else:
                    max_in = int(line[7])
                
                # For tol_in
                tol_in = float(line[8])   
                
                # For solver_in
                solver_in = line[9] # It can be ‘auto’, ‘svd’, ‘cholesky’, ‘lsqr’, ‘sparse_cg’, ‘sa'
                
                # Finish loop
                break
        
        # Close file
        fo.close()
        
        print("Regression method: ",line[0])
        print("Minimum alpha = %6.3f"%alpha_in1)
        print("Maximum alpha = %6.3f"%alpha_in2)
        print("Delta alpha = %8.4e"%delta_alpha)  
        print("Fit intercept? "+line[4])
        print("Normalize? "+line[5])
        print("Copy x array? "+line[6])  
        print("Maximum number of iterations: ",max_in)  
        print("Tolerance for the optimization: %6.3e"%tol_in)  
        print("Solver: ",solver_in)
        
        # Set up alpha_array
        alpha_array =  np.arange(alpha_in1,alpha_in2,delta_alpha)
        
        # Set up empty list
        residuals = []
        
        # Looping through alpha_array
        for i in alpha_array:
            # Create and fit the model
            model = linear_model.Ridge(alpha=i,copy_X = copy_in, fit_intercept = fit_in, max_iter = max_in,
                                    normalize = norm_in, solver = solver_in, tol = tol_in)  
            model.fit(self.x_in, self.y_in)
            residuals.append(np.mean((model.predict(self.x_in)- self.y_in)** 2) )
        
        # Get model for minimum residual
        my_min = np.min(residuals)
        y_index = residuals.index(my_min)
        model = linear_model.Ridge(alpha=alpha_array[y_index],copy_X = copy_in, fit_intercept = fit_in, 
                                    max_iter = max_in, normalize = norm_in, solver = solver_in, tol = tol_in )
        model.fit(self.x_in, self.y_in)
        
        
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
            aux_string = str(  " + %8.3f"%float(model.coef_[0][i])+"x"+str(i+1)  )
            self.reg_model += aux_string
                
        # Get Multiple model 
        alphas = []
        columns = len(self.x_in[0])
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[0][i])
                    
        # Set up array with coefficients
        self.b = np.array(alphas)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Ridge with CV"
        
    def scikit_ElasticNet(self):
        """Function to generate a multiple regression model sklearn.linear_model.ElasticNet"""
        
        # import library
        from sklearn import linear_model
        import numpy as np
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
        
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "ElasticNet" and line[0] != "ElasticNetCV":
                
                # For alpha_in
                alpha_in = float(line[1])
                
                # For l1_ratio_in
                l1_ratio_in = float(line[2])
                
                # For fit_in
                if line[3] == "True":
                    fit_in = True           # True
                elif line[3] == "False":
                    fit_in = False
                else:
                    print("Problem!")
                
                # For norm_in
                if line[4] == "True":
                    norm_in = True           # True
                elif line[4] == "False":
                    norm_in = False
                else:
                    print("Problem!")
                
                # For pre_in
                if line[5] == "True":
                    pre_in = True           
                elif line[5] == "False":    # False
                    pre_in = False
                else:
                    print("Problem!")
                
                # For max_in 
                max_in = int(line[6])       # True
                
                # For copy_in
                if line[7] == "True":
                    copy_in = True           # True
                elif line[7] == "False":
                    copy_in = False
                else:
                    print("Problem!")
                
                # For tol_in
                tol_in = float(line[8]) 
                  
                # For warm_in
                if line[9] == "True":
                    warm_in = True           # True
                elif line[9] == "False":
                    warm_in = False
                else:
                    print("Problem!")
                
                # For pos_in
                if line[10] == "True":
                    pos_in = True           
                elif line[10] == "False":    # False
                    pos_in = False
                else:
                    print("Problem!")
                
                # For sel_in
                sel_in = str(line[11])
                
                # For rand_in
                if line[12] == "None":
                    rand_in = None
                else:
                    rand_in = int(line[12])
                    
                # Finish loop
                break
        
        # Close file    
        fo.close()
        
        print("Regression method: ",line[0])
        print("Alpha = %6.3f"%alpha_in)
        print("L1 ratio %6.3f"%l1_ratio_in)
        print("Fit intercept? "+line[3])
        print("Normalize? "+line[4])
        print("Pre compute? "+line[5])
        print("Maximum number of iterations: %6.3e"%max_in)   
        print("Copy x array? "+line[7])  
        print("Tolerance for the optimization: %6.3e"%tol_in)  
        print("Reuse the solution of the previous call to fit? "+line[9] )
        print("Force the coefficients to be positive? "+line[10])  
        print("Method for coefficients: ",sel_in)
        print("Random seed: "+str(rand_in))
                         
        # Get a model
        model = linear_model.ElasticNet(alpha = alpha_in, l1_ratio = 0.7, fit_intercept= fit_in, 
                                    normalize = norm_in, precompute = pre_in, 
                                    max_iter = max_in, copy_X = copy_in, tol = tol_in,
                                    warm_start = warm_in, positive = pos_in, 
                                    selection = sel_in, random_state = rand_in
                                    )
        model.fit(self.x_in, self.y_in)
        
        
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
                aux_string = str(  " + %8.3f"%float(model.coef_[i])+"x"+str(i+1)  )
                self.reg_model += aux_string
        
        # Get Multiple model 
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[i])
        
        # Set up array with coefficients
        self.b = np.array(alphas)    
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.ElasticNet"

    def scikit_ElasticNetCV(self):
        """Function to generate a multiple regression model using iterated sklearn.linear_model.ElasticNet to
        optimize alpha"""
    
        # import library
        from sklearn import linear_model
        import numpy as np
        import csv
        import sys
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
        
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "ElasticNetCV":
                
                # For alpha_in1
                alpha_in1 = float(line[1])
                
                # For alpha_in2
                alpha_in2 = float(line[2])
                
                # For step_in
                step_in = int(line[3])
                
                # For l1_ratio_in
                l1_ratio_in = float(line[4])
                
                # For fit_in
                if line[5] == "True":
                    fit_in = True           # True
                elif line[5] == "False":
                    fit_in = False
                else:
                    print("Problem!")
                
                # For norm_in
                if line[6] == "True":
                    norm_in = True           # True
                elif line[6] == "False":
                    norm_in = False
                else:
                    print("Problem!")
                
                # For pre_in
                if line[7] == "True":
                    pre_in = True           
                elif line[7] == "False":    # False
                    pre_in = False
                else:
                    print("Problem!")
                
                # For max_in 
                max_in = int(line[8])       # True
                
                # For copy_in
                if line[9] == "True":
                    copy_in = True           # True
                elif line[9] == "False":
                    copy_in = False
                else:
                    print("Problem!")
                
                # For tol_in
                tol_in = float(line[10]) 
                  
                # For warm_in
                if line[11] == "True":
                    warm_in = True           # True
                elif line[11] == "False":
                    warm_in = False
                else:
                    print("Problem!")
                
                # For pos_in
                if line[12] == "True":
                    pos_in = True           
                elif line[12] == "False":    # False
                    pos_in = False
                else:
                    print("Problem!")
                
                # For sel_in
                sel_in = str(line[13])
                
                # For rand_in
                if line[14] == "None":
                    rand_in = None
                else:
                    rand_in = int(line[14])
                
                # Finish loop
                break
        
        # Close file     
        fo.close()
        
        print("Regression method: ",line[0])
        print("Minimum alpha = %6.3f"%alpha_in1)
        print("Maximum alpha = %6.3f"%alpha_in2)
        print("Steps = %4d"%step_in)
        print("L1 ratio = %6.3f"%l1_ratio_in)
        print("Fit intercept? "+line[5])
        print("Normalize? "+line[6])
        print("Pre compute? "+line[7])
        print("Maximum number of iterations = %6.3e"%max_in)   
        print("Copy x array? "+line[9])  
        print("Tolerance for the optimization = %6.3e"%tol_in)  
        print("Reuse the solution of the previous call to fit? "+line[11] )
        print("Force the coefficients to be positive? "+line[12])  
        print("Method for coefficient: ",sel_in)
        print("Random seed = "+str(rand_in))
        
        # Set up alpha_array
        alpha_array =  np.linspace(alpha_in1, alpha_in2, num = step_in)
        
        # Set up empty list
        residuals = []
        
        # Looping through alpha_array
        for i in alpha_array:
            # Create and fit the model
            model = linear_model.ElasticNet(alpha = i, l1_ratio = l1_ratio_in, fit_intercept= fit_in, 
                                    normalize = norm_in, precompute = pre_in, 
                                    max_iter = max_in, copy_X = copy_in, tol = tol_in,
                                    warm_start = warm_in, positive = pos_in,
                                    selection = sel_in, random_state = rand_in
                                    )     
            model.fit(self.x_in, self.y_in)
            residuals.append(np.mean((model.predict(self.x_in)- self.y_in)** 2) )
        
        # Get model for minimum residual
        my_min = np.min(residuals)
        y_index = residuals.index(my_min)
        model = linear_model.ElasticNet(alpha=alpha_array[y_index],l1_ratio = l1_ratio_in, fit_intercept= fit_in, 
                                    normalize = norm_in, precompute = pre_in, 
                                    max_iter = max_in, copy_X = copy_in, tol = tol_in,
                                    warm_start = warm_in, positive = pos_in
                                    # random_state = rand_in,
                                    #selection = sel_in 
                                    )   
        model.fit(self.x_in, self.y_in)
        
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
                aux_string = str(  " + %8.3f"%float(model.coef_[i])+"x"+str(i+1)  )
                self.reg_model += aux_string
        
        # Get Multiple model 
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[i])
        
        # Set up array with coefficients
        self.b = np.array(alphas)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.ElasticNet with CV"
    
    def scikit_SGDRegressor(self):
        """Function to generate a multiple regression model sklearn.linear_model.SGDRegressor"""
        
        # import libraries
        from sklearn import linear_model
        import numpy as np
        import csv
        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
                
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "SGDRegressor":
                # For alpha (Constant that multiplies the regularization term)
                alpha_in = float(line[1])
                
                # For average (When set to True, computes the averaged SGD weights and stores the result in the coef_ attribute)
                if line[2] == "True":
                    average_in = True
                else:
                    average_in = False
                                
                # For epsilon (Epsilon in the epsilon-insensitive loss functions)
                epsilon_in = float(line[3])
                
                # For eta0 (The initial learning rate [default 0.01])
                eta0_in = float(line[4])
                
                # For fit_intercept (Whether the intercept should be estimated or not. If False, the data is assumed to be already
                # centered)
                if line[5] == "True":
                    fit_intercept_in = True
                else:
                    fit_intercept_in = False
                
                # For li_ratio (The Elastic Net mixing parameter, with 0 <= l1_ratio <= 1. l1_ratio=0 corresponds to L2 penalty,
                # l1_ratio=1 to L1. Defaults to 0.15)
                l1_ratio_in = float(line[6])
                
                # For learning_rate (The learning rate schedule: ‘constant’: eta = eta0 ‘optimal’: eta = 1.0 / (alpha * (t + t0))
                # [default] ‘invscaling’: eta = eta0 / pow(t, power_t))
                learning_rate_in = line[7]
                
                # For loss (The loss function to be used)
                loss_in = line[8]
                
                # For n_iter (The number of passes over the training data (aka epochs).)
                n_iter_in = int(line[9])
                
                # For penalty (The penalty (aka regularization term) to be used)
                penalty_in = line[10]
                
                # For power_t (he exponent for inverse scaling learning rate [default 0.25].)
                power_t_in = float(line[11])
                
                # For random_state (The seed of the pseudo random number generator to use when shuffling the data)
                if line[12] == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[12])
                
                # For shuffle (Whether or not the training data should be shuffled after each epoch. Defaults to True)
                if line[13] == "True":
                    shuffle_in = True
                else:
                    shuffle_in = False
                
                # For warm_start (When set to True, reuse the solution of the previous call to fit as initialization, otherwise, just 
                # erase the previous solution.)
                if line[14] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False
                    
                # Finish loop
                break
        
        # Close file    
        fo.close()
                
        print("Regression method: ",line[0])
        print("Alpha = %.8f"%alpha_in) 
        print("Average = ",average_in)
        print("Epsilon = %.8f"%epsilon_in) 
        print("Eta0 = %.8f"%eta0_in) 
        print("Fit_intercept = ",fit_intercept_in)
        print("L1_ratio = %.8f"%l1_ratio_in) 
        print("Learning rate = ",learning_rate_in)
        print("Loss = ",loss_in)
        print("N_iter = %6d"%n_iter_in)
        print("Penalty = ",penalty_in)
        print("Power_t = %.8f"%power_t_in) 
        print("Random_state = ",random_state_in)
        print("Shuffle = ",shuffle_in)
        print("Warm_start = ",warm_start_in)
        
        y = []
        for line in self.y_in:
            y.append(line[0])
                
        # Create and fit the model
        columns = len(self.x_in[0])
        model = linear_model.SGDRegressor(alpha=alpha_in, average=average_in, epsilon=epsilon_in, eta0=eta0_in,
             fit_intercept=fit_intercept_in, l1_ratio=l1_ratio_in, learning_rate=learning_rate_in,
             loss=loss_in, n_iter=n_iter_in, penalty=penalty_in, power_t=power_t_in,
             random_state=random_state_in, shuffle=shuffle_in, verbose=0, warm_start=warm_start_in)
        
        model.fit(self.x_in, y)

        # Generate string with regression equation
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
                aux_string = str(  " + %8.3f"%float(model.coef_[i])+"x"+str(i+1)  )
                self.reg_model += aux_string
        
        
        # Get Multiple model 
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[i])
        
        # Set up array with coefficients
        self.b = np.array(alphas)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.SGDRegressor"
        
    def scikit_SVR(self):
        """Function to generate a multiple regression SVR"""
        
        # import libraries
        from sklearn.svm import SVR  
        import numpy as np
        import csv
                        
        # Try to open ml.in
        try:
            fo =  open("ml.in","r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find ml.in file! Finishing program execution!")
                
        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "SVR":
                # For C (Penalty parameter C of the error term)
                C_in = float(line[1])
                
                # For cache_size (Specify the size of the kernel cache (in MB)
                cache_size_in = int(line[2])
                
                # For coef0 (Independent term in kernel function. It is only significant in ‘poly’ and ‘sigmoid’)
                coef0_in = float(line[3])
                
                # For degree (Degree of the polynomial kernel function (‘poly’). Ignored by all other kernels)
                degree_in = int(line[4])
                
                # For epsilon (Epsilon in the epsilon-SVR model)
                epsilon_in = float(line[5])   
                
                # For gamma (Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’. If gamma is ‘auto’ then 1/n_features will be used instead
                gamma_in = line[6]
                
                # For kernel (Specifies the kernel type to be used in the algorithm)
                kernel_in = line[7]
                
                # For max_iter (Hard limit on iterations within solver, or -1 for no limit)
                max_iter_in = int(line[8])
                
                # For shrinking (Whether to use the shrinking heuristic.)
                if line[9] == "True":
                    shrinking_in = True
                else:
                    shrinking_in = False
                    
                # For tol (tolerance for stopping criterion)
                tol_in = float(line[10])
                
                # Finish loop
                break
        
        # Close file    
        fo.close()
                
        print("Regression method: ",line[0])
        print("C = %6.3f"%C_in)
        print("Cache size = %5d"%cache_size_in)
        print("Coef0 = %6.3f"%coef0_in)
        print("Degree(s) = %5d"%degree_in)  
        print("Epsilon = %6.3f"%epsilon_in)  
        print("Gamma = %s"%gamma_in)  
        print("Kernel = %s"%kernel_in)
        print("Max iter = %5d"%max_iter_in)
        print("Shrinking = %s"%shrinking_in) 
        print("Tolerance = %.8f"%tol_in)
        
        # Generate y for SVR
        y = []
        for line in self.y_in:
            y.append(line[0])
        
        # Create and fit the model  
        model = SVR(C=C_in, cache_size=cache_size_in, coef0=coef0_in, degree=degree_in, epsilon=epsilon_in, gamma=gamma_in,
                    kernel=kernel_in, max_iter=max_iter_in, shrinking=shrinking_in, tol=tol_in, verbose=False)
        model.fit(self.x_in, y)
        
        # Generate string with regression equation
        columns = len(self.x_in[0])
        self.reg_model = str("y = %8.3f"%float(model.intercept_))
        for i in range(columns):
                aux_string = str(  " + %8.3f"%float(model.coef_[0][i])+"x"+str(i+1)  )
                self.reg_model += aux_string
        
        # Get Multiple model 
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[0][i])
        
        # Set up array with coefficients
        self.b = np.array(alphas)
        
        # Set up string with regression method
        self.reg_method = "SVR"
                        

    def basic_statistical_analysis(self):
        """Method to carry out basic statistical calculation"""
        
        # Prepare arrays for scikit
        self.prep_y1()
        self.prep_x1()
        
        # Select regression method
        if self.selected_method_in == "LinearRegression":
            self.scikit_LinearRegression()
        elif self.selected_method_in == "Lasso":
            self.scikit_Lasso()
        elif self.selected_method_in == "LassoCV":
            self.scikit_LassoCV()
        elif self.selected_method_in == "Ridge":
            self.scikit_Ridge()
        elif self.selected_method_in == "RidgeCV":
            self.scikit_RidgeCV()
        elif self.selected_method_in == "ElasticNet":
            self.scikit_ElasticNet()
        elif self.selected_method_in == "ElasticNetCV":
            self.scikit_ElasticNetCV()
        elif self.selected_method_in == "SGDRegressor":
            self.scikit_SGDRegressor()
        elif self.selected_method_in == "SVR":
            self.scikit_SVR()
        else:
            print("SAnDReS Error! No such regression method!")  
            return None
        
        self.gen_modelMultD2()
        
        self.calc_SE_M()
        
        self.stat_analysis_of_reg_models()
        
        # estimating coefficients, and basic stats
        self.inv_xx = inv(dot(self.x.T,self.x))
        #xy = dot(self.x.T,self.y)
        #self.b = dot(self.inv_xx,xy)                                            # Estimate coefficients
        
        # Former statistical formulas
        self.nobs = self.y.shape[0]                                             # Number of observations
        self.ncoef = self.x.shape[1]                                            # Number of coefficients
        self.df_e = self.nobs - self.ncoef                                      # Degrees of freedom, error 
        self.df_r = self.ncoef - 1                                              # Degrees of freedom, regression 
        
        try:
            self.e = self.y - dot(self.x,self.b)                                    # Residuals
        except:
            self.e = 1.0
    
        self.sse = dot(self.e,self.e)/self.df_e                                 # SSE
        self.se1 = sqrt(diagonal(self.sse*self.inv_xx))                          # Coefficient of standard errors
        self.t = self.b / self.se1                                               # Coefficient of  t-statistics
        self.p = (1-stats.t.cdf(abs(self.t), self.df_e)) * 2                    # Coefficient of  p-values

        # Looping through to calculate RSS (Residual Sum of Squares) and TSS (Total Sum of Squares)
        self.rss1 = 0
        self.tss = 0
        self.aver_y = average(self.y)
        for i in range(len(self.y)):
            try:
                self.rss1 += (self.e[i])**2
            except:
                self.rss1 += 1.0
            self.tss += (self.y[i] - self.aver_y)**2 
        
        self.R2 = 1 - self.rss1/self.tss                                         # model R-squared
        self.R2adj = 1-(1-self.R2)*((self.nobs-1)/(self.nobs-self.ncoef))       # adjusted R-square
        self.F = (self.R2/self.df_r) / ((1-self.R2)/self.df_e)                  # model F-statistic
        self.Fpv = 1-stats.f.cdf(self.F, self.df_r, self.df_e)                  # F-statistic p-value
        self.sd = (self.rss1/( len(self.y) - self.num_indep_var - 1 ) )**0.5     # Calculates standard deviation 
        
    def summary(self):
        """ Method for returning statistical analysis to screen"""
        if str(self.corr_s) == "nan":
            self.corr_s,self.pvalue_s = 0.0,1.0
            
        return self.b, self.R2, self.R2adj,self.sd,self.corr_s,self.pvalue_s
