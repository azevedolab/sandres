#! /usr/bin/python
# Class to calculate binding affinity using a polynomial scoring function
# previously determined by SAnDReS. The polynomial equation is stored in
# the polscore.log like file. 
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################

class Score(object):
    """Class to calculate binding affinity using a polynomial scoring function"""
    
    # Define constructor method
    def __init__(self,proj_dir,file_in,file_out,pol_in,pol_number_in):
        
        # Define attributes
        self.proj_dir = proj_dir
        self.file_in = file_in
        self.file_out = file_out
        self.pol_in = pol_in
        self.pol_number_in = pol_number_in
    
    # Generate aux csv with the right columns to calculate scoring function
    def gen_aux_csv(self):
        """Method to generate an auxiliary csv file with the columns to be used
        in the calculation of the scoring function values."""
        
        # Import library
        import csv
        
        # Set up an empty lists
        self.coef_string_list =  []
        col_2_include = []
        
        # Try to open a specific polscore.log file
        try:
            fo_log = open(self.proj_dir+self.new_file_polscore,"r")
        except IOError:
            print("\nIOError! I can't find "+self.new_file_polscore+" file.")
            return
            
        # Looping through fo_log:
        print("\nReading coefficients names...")
        for line1 in fo_log:
            aux_line = str(line1)
            aux_coef =  ""
            my_flag = False
            if "Polynomial equation number" in aux_line:
                for line2 in aux_line[26:]:
                    if line2 == "(":
                        my_flag = True
                    elif line2 == ")":
                        my_flag = False
                        self.coef_string_list.append(aux_coef[1:])
                        aux_coef = ""
                    if my_flag:
                        aux_coef += line2
                break
        
        # Close file
        fo_log.close()
                                
        # Set up empty list
        self.csv_list_aux =  []
        
        # Try to open csv file
        try:
            fo1 = open(self.proj_dir+self.file_in,"r")
            csv1 = csv.reader(fo1)
        except IOError:
            print("\nI can't find "+self.file_in+" file!")
        
        # Get first line and read the columns to be included
        for line1 in csv1:
            for i, j in enumerate(line1):
                for line2 in self.coef_string_list:
                    if j == line2:
                        col_2_include.append(i)
            break
        
        # Show names of the coefficients
        i = 1
        for line in self.coef_string_list:
            print("Coef(",i,")",line," Column: ",col_2_include[i-1])
            i += 1
        
        print("\nDone!")
        
        # Looping through csv file
        for line1 in csv1:
            aux_line = ""
            for i in col_2_include:
                aux_line += line1[i]+","
                aux_line = aux_line.replace(" ","")
            
            self.csv_list_aux.append(aux_line[:len(aux_line)-1])
        
        # Check if it a training or a test set
        if "test" in self.file_in:
            self.aux_csv_filename = "scoring_function_"+self.pol_number_in+"_test.csv"
        else:
            self.aux_csv_filename = "scoring_function_"+self.pol_number_in+".csv"
        
        # Open new aux csv file
        fo2 = open(self.proj_dir+"Polscore/"+self.aux_csv_filename,"w")
        
        # Prepare first line
        aux = str(self.coef_string_list)
        aux = aux.replace("[","")
        aux = aux.replace("]","")
        aux = aux.replace(" ","")
        aux = aux.replace("'","")
        fo2.write(aux+"\n")
        
        # Looping through self.csv_list_aux
        for line in self.csv_list_aux:
            aux_line_out = str(line)
            aux_line_out = aux_line_out.replace("'","")
            fo2.write(aux_line_out+"\n")
                    
        # Close files
        fo1.close()
        fo2.close()
        
    # Define method to fix number of characters
    def fix_number_characters(self,string_in,fill_in,number_of_characters):
        """Method to fix number of character in a string.
        The fill_in should have a character to be used to fill
        the left part of the string, for instance: 00011235"""
        
        # Fix the number of characters
        if len(string_in)< number_of_characters+1:
            my_str_out = str((number_of_characters-len(string_in) )*fill_in)+string_in
        
        return my_str_out
        
    # Define gen_one_polscore()
    def gen_one_polscore(self):
        """Method to generate a log file using a selected polynomial equation.
        This equation and related information is taken from the original
        polscore.log file generated by SAnDReS"""
        
        # Try to open polscore.log file
        try:
            fo_polscore_2018 = open(self.proj_dir+self.pol_in,"r")
        except IOError:
            print("\nIOError! I can't find "+self.pol_in+" file.")
            return
        
        # Invoke fix_number_characters(self,string_in,fill_in,number_of_characters)
        self.pol_number_in = self.fix_number_characters(self.pol_number_in,"0",7) 
        
        # Looping through self.pol_in
        new_polscore_list = []
        new_polscore_list_flag = False
        for line in fo_polscore_2018:
            aux_pol_2018 = str(line)
            if "Polynomial equation number" in aux_pol_2018:
                if self.pol_number_in in aux_pol_2018:
                    new_polscore_list_flag = True
                    new_polscore_list.append(line)
            elif new_polscore_list_flag and "POLSCORE MODEL GENERATOR" in aux_pol_2018:
                new_polscore_list_flag = False
                break
            elif new_polscore_list_flag:
                new_polscore_list.append(line)
        
        # Close file
        fo_polscore_2018.close()
        
        # Set up new polscore.log name
        self.new_file_polscore = self.pol_in.replace(".log","_"+self.pol_number_in+".log")
        
        # Open new polscore.log like file
        fo_polscore_2018_new = open(self.proj_dir+self.new_file_polscore,"w")
        
        # looping through new_polscore_list
        for line in new_polscore_list:
            fo_polscore_2018_new.write(line)
        
        # Close file
        fo_polscore_2018_new.close()
        
        # Invoke gen_aux_csv()
        self.gen_aux_csv()
                    
                            
    # Define method to read dataset
    def read_dataset(self):
        """Method to read dataset file"""
        
        # Set up empty list
        self.my_output_list = []
        
        # Try to open dataset
        try:
            fo0 = open(self.proj_dir+self.file_in,"r") 
        except IOError:
            print("\nIOError! I can't "+self.file_in+" file")
            return
        
        # Looping through datafile
        for line in fo0:
            aux = str(line)
            aux = aux.replace("[","")
            aux = aux.replace("]","")
            aux = aux.replace("'","")
            self.my_output_list.append(aux)
        
        # Close file
        fo0.close()
        
    # Define method to read aux CSV file
    def read_aux_csv(self):
        """Method to read csv file"""
        
        # Import library
        import csv
        
        # Set up empty matrix
        self.csv_list =  [[]]
        
        # Try to open aux csv file WFA 2018 02 21
        try:
            fo1 = open(self.proj_dir+"Polscore/"+self.aux_csv_filename,"r")
            csv1 = csv.reader(fo1)
        except IOError:
            print("\nI can't find "+self.aux_csv_filename+" file!")
        
        # Get first line
        for line in csv1:
            first = str(line)
            first = first.replace("[","")
            first = first.replace("]","")
            first = first.replace("'","")
            self.first_line = first
            break
            
        # Looping through csv file
        for line in csv1:
            self.csv_list.append(line)
        
        # Get number of columns in self.file_in
        self.n_cols = len(self.csv_list[1])
        
        # Close file
        fo1.close()
            
    # Define calc_col() method
    def calc_bind(self):
        """Method to add a column with polynomial equation based on the weights"""
                
        # Set up empty lists
        self.list_out = []
        self.computated_binding = []
                
        # Looping through self.csv_list as a matrix to calculate binding
        for i in range(1,len(self.csv_list[:])):
            y = self.weights[0]
            line_out = ""
            for j in range(self.n_cols):  # WFA 2018 02 22
                line_out += self.csv_list[i][j]+","
                y += self.weights[j+1]*float(self.csv_list[i][j])
            line_out += self.csv_list[i][j]+","+str(y) # WFA 2018 02 22
            self.list_out.append(line_out)
            self.computated_binding.append(y)
                
    # Define write_csv1() method
    def write_csv1(self):
        """Method to write csv file"""
        
        # Open new csv file
        fo2 = open(self.proj_dir+self.file_out,"w")
                
        for line in self.my_output_list:
            fo2.write(line[:len(line)-1]+",Polscore #"+self.pol_number_in+"\n")
            break
            
        # Looping through self.list_out:
        i = 0
        for line in self.my_output_list[1:]:
            fo2.write(line[:len(line)-1].replace(" ","")+\
            ","+str(self.computated_binding[i])+"\n")
            i += 1
        
        # Close file
        fo2.close()
        
        # Try to open self.aux_csv_filename file
        try:
            fo3 = open(self.proj_dir+"Polscore/"+self.aux_csv_filename,"r")
        except IOError:
            print("\nIOError! I can't find "+self.aux_csv_filename+" file.")
            return
        
        # Set up empty list
        aux_list1 = []
        
        # Get first line
        for line in fo3:
            aux = str(line)
            aux = aux.replace("\n","")
            aux += ",Binding Affinity\n"
            aux_list1.append(aux)
            break
        
        i = 0
        # Get the rest of the lines    
        for line in fo3:
            aux = str(line)
            aux = aux.replace("\n","")
            aux += ","+str(self.computated_binding[i])+"\n"
            aux_list1.append(aux)
            i += 1
        
        # Close file
        fo3.close()
        
        # Open self.aux_csv_filename file
        fo4 = open(self.proj_dir+"Polscore/"+self.aux_csv_filename,"w")
      
        # Looping through aux_list1
        for line in aux_list1:
            fo4.write(line)
        
        # Close file
        fo4.close()
            
    # Define get_weights() method
    def get_weights(self):
        """Method to read weights from a polscore like file"""
                
        # Set up empty list
        self.weights = []
        
        # Try to open a polcore.log like file
        try:
            pol1 = open(self.proj_dir+self.new_file_polscore,"r") # WFA 2018 02 21
        except IOError:
            print("\nIOError! I can't find "+self.pol_in+" file!")
            return
        
        # Get polynomial equation
        for line in pol1:
            aux_str1 = str(line)
            if "Polynomial equation number" in aux_str1:
                i_colon = aux_str1.index(":")
                aux_str2 = aux_str1[i_colon+1:]
                aux_str3 = aux_str2.replace(" ","")
                pol_equation = aux_str3.replace("+-","-")
                break
        
        print("\nPolynomial equation: ",pol_equation)
        
        # Get w0
        w_aux = ""
        flag1 = False
        for char in pol_equation:
            w_aux += char
            if char == ".":
                flag1 = True
            elif flag1:
                if char == "+" or char == "-":
                    w_out = w_aux[:len(w_aux)-1]
                    self.weights.append(float(w_out))
                    break
                
    
        # Cut off w0 from pol_equation
        pol_equation = pol_equation[len(w_out):]

        # Loop while
        while len(pol_equation) > 1:
            # Get weights
            w_aux = ""
            # Looping through the rest of the polynomial equation
            for char in pol_equation:
                w_aux += char
                if char == "*":
                    w1 = w_aux[:len(w_aux)-1]
                    self.weights.append(float(w1))
                    break
        
            # Cut off w1 from pol_equation
            pol_equation = pol_equation[len(w1):]
            index_par = pol_equation.index(")")
            pol_equation = pol_equation[index_par+1:]
                
        # Close file
        pol1.close()
        
        print(self.weights)
    
    # Define add_col_2_dataset() method
    def add_col_2_dataset(self):
        """Method to take care of updating training_set csv file"""
        
        # Invoke gen_one_polscore()
        self.gen_one_polscore()
            
        # Invoke read_aux_csv() method
        self.read_aux_csv()
    
        # Invoke get_weights()
        self.get_weights()
            
        # Invoke calc_bind() method
        self.calc_bind()
    
        # Invoke read_dataset() method
        self.read_dataset()
        
        # Invoke write_csv() method
        self.write_csv1()
        
