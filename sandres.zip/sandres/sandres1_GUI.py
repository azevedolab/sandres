#! /usr/bin/python
# GUI for SAnDReS   
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.   
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1. 
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;  
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and  
# Development  of  Scoring Functions. 
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347 
#
###############################################################################################################
# 
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and 
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net 
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico - 
# National Counsel of Technological 
# and Scientific Development (www.cnpq.br)  
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################

# Import library
import sys

# Set up SAnDReS root directory
sandres_root = "C:/sandres/"

# Set the directory where Python scripts are
sys.path.append(sandres_root)

# Import merge_vina_data functions
import merge_vina_data as mvina     # Additional functions to merge vina data

# Import merge_autodock_data functions
import merge_autodock_data as mautodock     # Additional functions to merge autodock data

# Import merge_autodock_data_epdb functions
import merge_autodock_data_epdb as mautodock_epdb #Additional functions to merge autodock data

def copy_tutorial(tutorial_number):
    """Function to copy tutorial files to project directory"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig,top_tutor_number_entry
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Tutorial Number: "+tutorial_number, \
          font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
              
    # Show Label 
    Label(top_txt, text="Summary", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=135*" ", font = "Arial" ).grid(row = 3,\
        column = 0, stick = W)
    
    def copy_my_tutorial():
        """Function to copy specific tutorial files for project directory"""
        
        # Import libraries
        import shutil
        import csv
        
        # Call clear_sandres_info_file_txt()
        clear_sandres_info_file_txt()
        
        # Set list to be copied
        list_to_be_copied = ["pdbCodes.csv","chklig.in","redock01.csv","ensembledock.csv",
                             "scores_all.csv","decoy_results.csv","polscore.in","polscore.csv",
                             "polscore.log","test_set.csv","training_set.csv","test_set.zip",
                             "training_set.zip","scores_all.zip","Polscore.zip","docking.dlg",
                             "lig.pdbqt","lig_out.pdbqt","DockingResults.mvdresults",
                             "clusters.dock4.csv","clusters.dock4.pdb","lig.mol2","lig.pdb",
                             "receptor.pdb","sandres.in","showinfo.in"]
        
        # Get project directory
        project_dir_string = str(strdir_entry.get())
        
        # Looping through list to be copied to project directory
        for my_file_to_be_copied in list_to_be_copied:
            sandres_line ="Copying "+my_file_to_be_copied+" to "+project_dir_string+" \n"
            print(sandres_line)
            window_txt.insert(END,sandres_line)  # WFA 2018 01 09
            shutil.copy2(sandres_root+"tutorials/tutorial"+tutorial_number+"/"+my_file_to_be_copied,\
                         project_dir_string+my_file_to_be_copied)
        
        # Open pdbCodes.csv
        my_pdb_fo = open(sandres_root+"tutorials/tutorial"+tutorial_number+"/pdbCodes.csv","r")
        my_csv_pdb_fo = csv.reader(my_pdb_fo)
        
        # Looping through PDB access codes
        count_pdbs = 0
        for line in my_csv_pdb_fo:
            for code_in0 in line:
                count_pdbs += 1
                code_in = code_in0.replace(" ","")
                sandres_line = "Copying "+code_in+".pdb and .csv to "+project_dir_string+" \n"
                print(sandres_line)
                window_txt.insert(END,sandres_line)
                
                # Try to copy PDB and CSv files
                try:                            # WFA 2018 01 09
                    shutil.copy2(sandres_root+"tutorials/tutorial"+tutorial_number+"/"+code_in+".pdb",\
                         project_dir_string+code_in+".pdb")
                    shutil.copy2(sandres_root+"tutorials/tutorial"+tutorial_number+"/"+code_in+".csv",\
                         project_dir_string+code_in+".csv")
                except:
                    print("\nI can't find "+sandres_root+"tutorials/tutorial"+tutorial_number+\
                          "/"+code_in+".pdb or .csv")
                    my_pdb_fo.close()
                    return
        
        my_pdb_fo.close()
        
        sandres_line = "\n\nFinished copying tutorial files to "+project_dir_string+"\n"
        print(sandres_line)
        window_txt.insert(END,sandres_line)
        sandres_line = "Total number of files: "+str(2*count_pdbs+4)+"\n\n"
        print(sandres_line)
        window_txt.insert(END,sandres_line)
        
    # Widgets for buttons
    Button(top_txt, text='    Copy Files    ', command=copy_my_tutorial).grid(row = 4, column = 1,\
                                                                                       sticky = E)  
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 4, column = 2,\
                                                                                sticky = W)  
            
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=2, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 9, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 2, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # Open summary file
    my_txt_fo = open(sandres_root+"tutorials/summary"+str(tutorial_number)+".txt","r")
    
    # Read summary file
    my_txt_in = my_txt_fo.readlines()
    
    # Set empty string
    my_summary = ""
    
    # Looping through my_txt_in
    for line in my_txt_in:
        my_summary += line
    
    my_txt_fo.close()
          
    # Read input file content
    top_txt.insert(END,my_summary)

def not_implemented_yet():
    """Function to show message that this function is not implemented yet"""
    
    print("Not implemented yet!")
    
def copy_tutorial_001():
    """Function to copy tutorial001 to project directory"""
    
    copy_tutorial("001")

def run_sandres_in(string_input_file_in):
    """Function to run sandres"""
        
    # Call show_message_in_sandres()
    show_message_in_sandres(" SAnDReS is running "+string_input_file_in+"...","green","light grey")

    # Import library
    from tkinter import messagebox
    
    # Call message.box
    result = messagebox.askyesno("SAnDReS","Do you want to run "+string_input_file_in+"?")
    
    # If run is chosen
    if result:
        # Call clear_inputfile_entry()
        clear_inputfile_entry()
    
        # Call clear_sandres_info_file_txt()
        clear_sandres_info_file_txt()
    
        # Get rid of spaces
        string_input_file_in = string_input_file_in.replace(" ","") 
    
        # Insert new input file name
        inputfile_entry.insert(10,string_input_file_in)
  
        # Get new project directory
        project_dir_string = str(strdir_entry.get())
    
        # Try to open sandres.in
        try:
            my_sandres_input = open(project_dir_string+"sandres.in","w")
        except IOError:
            print("SAnDReS IOError! I can't find ",project_dir_string+"sandres.in")
            project_dir_string = sandres_root+"inputs/" # WFA 2018 01 09 
            print("I've changed the project directory to",project_dir_string)
            clear_strdir_entry()
            strdir_entry.insert(10,project_dir_string)
            print("Please update project directory as your needs!")
        
            try:
                my_sandres_input = open(project_dir_string+"sandres.in","w")
            except IOError:
                print("SAnDReS IOError! I can't find ",project_dir_string+"sandres.in")
                print("Please edit strdir.in at "+sandres_root+"inputs/")
                print("Finishing SAnDReS!")
                sys.exit() 
    
        # Write input file name in sandres.in       
        my_sandres_input.write(string_input_file_in)
        my_sandres_input.close()
    
        # Run script sandres_main_2018.py
        import sandres_main_2018 as sandres
    
        # Call main method
        sandres.main()
    
        # Re-opens sandres.in
        my_sandres_input = open(project_dir_string+"sandres.in","w")
        my_sandres_input.write("showinfo.in")
        my_sandres_input.close()
        
        return
    
    else:
        # Call clear_sandres_info_file_txt()
        clear_sandres_info_file_txt()
        
        print("You gave up running "+string_input_file_in+".")
        
        # Call show_message_in_sandres()
        show_message_in_sandres("SAnDReS is back!","black","light grey")

def update_getstr(format_in):
    """Function to update getstr.in files"""

    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open new getstr.in
    my_getstr_fo = open(project_dir_string+"getstr.in","w")
    
    # Start writing
    my_getstr_fo.write("GETSTR,"+format_in)
    
    # Call readPDB() function to get PDB access codes
    my_pdb_list_in = readPDB()
    
    # Looping through my_pdb_list_in
    for line in my_pdb_list_in:
        my_getstr_fo.write(","+str(line))
    
    # Write last line
    my_getstr_fo.write("\nENDOF")
    
    # Close getstr.in file
    my_getstr_fo.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating new getstr.in!","black","light grey")
    
def readPDB():
    """Function to read PDB access codes stored in pdbCodes.csv and return them as a list."""
    
    # Import library
    import csv
    
    # Set up empty list
    my_pdb_list = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open pdbCodes.csv
    try:
        my_fo = open(project_dir_string+"pdbCodes.csv","r")
        my_csv_fo = csv.reader(my_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"pdbCodes.csv") 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+"pdbCodes.csv")
        return
    
    # Looping through my_csv_fo
    for line in my_csv_fo:
        aux_line0 = str(line)
        aux_line1 = aux_line0.replace("'","")
        aux_line2 = aux_line1.replace("[","")
        aux_line3 = aux_line2.replace("]","")
        my_pdb_list.append(aux_line3)
    
    my_fo.close()
    
    return my_pdb_list

def unifyPDB():
    """Function to delete repeated PDB access codes in pdbCodes.csv"""
    
    # Import library
    import csv
    
    # Set list
    my_pdb_list = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open pdbCodes.csv file
    try:
        my_fo = open(project_dir_string+"pdbCodes.csv","r")
        my_csv = csv.reader(my_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"pdbCodes.csv") 
        print("New pdbCodes.csv file will be generated!")
        return
    
    # Looping through csv file
    for line in my_csv:
        for line1 in line:
            if line1 in my_pdb_list:
                continue
            else:
                my_pdb_list.append(line1)
        
    my_fo.close()
    
    # New pdbCodes.csv file
    my_fo = open(project_dir_string+"pdbCodes.csv","w")
    my_pdb_out = str(my_pdb_list[0])
    
    # Looping through my_pdb_list
    for line in my_pdb_list[1:]:
        my_pdb_out += str(","+line)
    
    # Write pdb access codes
    my_fo.write(my_pdb_out)
    
    # Close new pdbCodes.csv file
    my_fo.close()

def clear_top_pdburl_entry(): 
    """Function to clear txt content in editing window"""
    
    global top_pdburl_entry
    
    top_pdburl_entry.delete(0,END) 

def clear_top_sdfurl_entry(): 
    """Function to clear txt content in editing window"""
    
    global top_sdfurl_entry
    
    top_sdfurl_entry.delete(0,END) 

def clear_omitted_entry(): 
    """Function to clear txt content in editing window"""
    
    global top_omitted_entry
    
    top_omitted_entry.delete(0,END) 
    
def clear_binding_radius_entry():
    """Function to clear top_clear_binding_radius_entry"""
    
    global top_binding_radius_entry
    
    top_binding_radius_entry.delete(0,END)

def clear_google_chrome_entry():
    """Function to clear google_chrome_entry"""
    
    google_chrome_entry.delete(0,END)
    
def save_sandres_par():
    """Function to save sandres_par.csv file with seed"""
    # Defines global variables to allow access to variables from different functions
    global top_txt, top_strdir_entry, top_pdburl_entry, top_sdfurl_entry,top_omitted_entry,top_binding_radius_entry_entry
    
    # Get pdburl
    string_pdburl = str(top_pdburl_entry.get()) 
    
    # Get sdfurl
    string_sdfurl = str(top_sdfurl_entry.get()) 
    
    # Get top_omitted_entry
    string_omitted_entry = str(top_omitted_entry.get()) 
    
    # Get radius_entry
    string_radius_entry =  str(top_binding_radius_entry.get())
    
    # Get google_chrome_entry
    string_google_chrome_entry = str(google_chrome_entry.get())
    
    # Get random_seed_entry
    string_random_seed_entry = str(random_seed_entry.get())
    
    # Open input file
    sandres_par_file = open(sandres_root+"sandres_par.csv","w")
     
    # Write string_pdburl into sandres_par.csv file
    sandres_par_file.write("pdburl,"+string_pdburl+"\n" )
    
    # Write string_sdfurl into sandres_par.csv file
    sandres_par_file.write("sdfurl,"+string_sdfurl+"\n" )
    
    # Write string_omitted_entry into sandres_par.csv file
    sandres_par_file.write("omitted_lig_file,"+string_omitted_entry+"\n" )
        
    # Write string_radius_entry into sandres_par.csv file
    sandres_par_file.write("binding_radius,"+string_radius_entry+"\n")
    
    # Write string_google_chrome_entry into sandres_par.csv file
    sandres_par_file.write("google_chrome,"+string_google_chrome_entry+"\n" )
    
    # Write string_random_seed_entry into sandres_par.csv file
    sandres_par_file.write("random_seed,"+string_random_seed_entry+"\n" )
    
    # Close updated input file
    sandres_par_file.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished updating sandres_par.csv file!","black","light grey")

def clear_random_seed_entry():
    """Function to clear random_seed_entry"""
    
    random_seed_entry.delete(0,END)
    
def sandres_par_GUI():
    """Function to open GUI for SAnDReS program parameters with seed"""
    
    # Import libraries
    from tkinter import messagebox
    import csv
    
    # Defines global variables to allow access to variables from different functions
    global top_txt,top_pdburl_entry,top_sdfurl_entry,top_omitted_entry,top_binding_radius_entry,google_chrome_entry,\
    random_seed_entry
    
    # Call read_preferences
    pdburl_var,sdfurl_var,omitted_var,binding_radius,google_chrome,random_seed = read_preferences()
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Preferences for SAnDReS", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
        
    # Widgets for PDB URL
    Label(top_txt, text="PDB URL:" ).grid(row = 2,column = 0, stick = W)   
    top_pdburl_entry = Entry(top_txt,width = 100)
    top_pdburl_entry.grid(row = 2, column = 0,stick = E)
    top_pdburl_entry.insert(10,pdburl_var)
    # Widgets for buttons
    Button(top_txt, text='Clear', command=clear_top_pdburl_entry).grid(row = 2, column = 1, sticky = E)
    
    # Widgets for SDF URL
    Label(top_txt, text="SDF URL:" ).grid(row = 3,column = 0, stick = W)   
    top_sdfurl_entry = Entry(top_txt,width = 100)
    top_sdfurl_entry.grid(row = 3, column = 0,stick = E)
    top_sdfurl_entry.insert(10,sdfurl_var)
    # Widgets for buttons
    Button(top_txt, text='Clear', command=clear_top_sdfurl_entry).grid(row = 3, column = 1, sticky = E)
    
    # Widgets for omitted ligands
    Label(top_txt, text="File for Omitted Ligands:" ).grid(row = 4,column = 0, stick = W)   
    top_omitted_entry = Entry(top_txt,width = 100)
    top_omitted_entry.grid(row = 4, column = 0,stick = E)
    top_omitted_entry.insert(10,omitted_var)
    # Widgets for buttons
    Button(top_txt, text='Clear', command=clear_omitted_entry).grid(row = 4, column = 1, sticky = E)
    
    # Widgets for omitted Radius of binding site
    Label(top_txt, text="Radius for Binding Site (Angstrom):" ).grid(row = 5,column = 0, stick = W)   
    top_binding_radius_entry = Entry(top_txt,width = 90)
    top_binding_radius_entry.grid(row = 5, column = 0,stick = E)
    top_binding_radius_entry.insert(10,binding_radius)
    # Widgets for buttons
    Button(top_txt, text='Clear', command=clear_binding_radius_entry).grid(row = 5, column = 1, sticky = E)    
    
    # Widgets for chrome exe
    Label(top_txt, text="Google Chrome Executable File:" ).grid(row = 6,column = 0, stick = W)   
    google_chrome_entry = Entry(top_txt,width = 90)
    google_chrome_entry.grid(row = 6, column = 0,stick = E)
    google_chrome_entry.insert(10,google_chrome)
    # Widgets for buttons
    Button(top_txt, text='Clear', command=clear_google_chrome_entry).grid(row = 6, column = 1, sticky = E) 
    
    # Widgets for random seed
    Label(top_txt, text="Random Seed:" ).grid(row = 7,column = 0, stick = W)   
    random_seed_entry = Entry(top_txt,width = 90)
    random_seed_entry.grid(row = 7, column = 0,stick = E)
    random_seed_entry.insert(10,random_seed)
    
    # Widgets for buttons
    Button(top_txt, text='Clear', command=clear_random_seed_entry).grid(row = 7, column = 1, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=250*" " ).grid(row = 8,column = 0, stick = W) 
    
    Button(top_txt, text='Save  ', command=save_sandres_par).grid(row = 9, column = 1,\
                                                                                  sticky = E)
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 9, column = 2, sticky = W)

def count_pdb_files():
    """Function to count PDB files in the ensemble"""
    
    # Import library
    import csv
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    #  Try to open csv file
    try:
        fo1 = open(project_dir_string+"pdbCodes.csv","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("\nIOError! I can't find file pdbCodes.csv!")
        return
    
    # Count PDB codes
    for line in csv1:
        number_of_pdbs = len(line)
        
        # Call show_message_in_sandres()
        show_message_in_sandres("Number of PDB files in the ensemble (pdbCodes.csv): "+str(number_of_pdbs),"black","light grey")
    
        break
    
    # Close file
    fo1.close()

def open_pdbCodes(my_file_2_open):
    """Function to open pdbCodes.csv"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, top_inputfile_entry, top_strdir_entry 
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open file
    try:
        my_info_input_file = open(project_dir_string+my_file_2_open,"r")
    except IOError:
        print("I can't find ",project_dir_string+my_file_2_open)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                                 project_dir_string+my_file_2_open+"\nPlease check input file name!")
        return 
       
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Download Structures", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 105)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,my_file_2_open)
    
    # Widgets for buttons 
    Button(top_txt, text='Save', command=save_edit_screen_to_input_file).grid(row = 2, column = 1, sticky = E)
    Button(top_txt, text='Read', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 6, column = 0, sticky = E)
    Button(top_txt, text=' Count PDB Files ',  command=count_pdb_files).grid(row = 6, column = 1, sticky = W)
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 6, column = 2, sticky = W)  
    
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text="PDB access codes should be separated by comma").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=196*" " ).grid(row = 5,column = 0, stick = W) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 6, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()
       
def getPDB(): 
    """Function to get PDB access codes"""
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open pdbCodes.csv file
    try:
        my_fo = open(project_dir_string+"pdbCodes.csv","r")
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"pdbCodes.csv") 
        print("New pdbCodes.csv file will be generated!")
        # Generate new pdbCodes.csv file
        my_fo = open(project_dir_string+"pdbCodes.csv","w")
    
    # Close file
    my_fo.close()
    
    # Call open_pdbCodes("pdbCodes.csv")
    open_pdbCodes("pdbCodes.csv")
    
def read_log_file(my_log_file):
    """Function to read log file"""
    
    # Import library
    from tkinter import messagebox
    
    # Call clear_sandres_info_file_txt()
    clear_sandres_info_file_txt()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open  input file
    try:
        my_info_log_file = open(project_dir_string+my_log_file,"r")
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+my_log_file) 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+my_log_file+\
                             " \nPlease check directory name!")
        return
        
    # Reads file content
    window_txt.insert(END,my_info_log_file.read()) 
    
    # Close input file        
    my_info_log_file.close()  
    
def clean_binding_info(my_string_in):
    """Function to clean ligand-binding information string"""
    aux_var1 = my_string_in.replace(" ","")
    aux_var2 = aux_var1.replace("...","")
    aux_var3 = aux_var2.replace(">","")
    aux_var4 = aux_var3.replace("<","")       
    
    return aux_var4

def mult_binding_information(string_binding_in):
    """Function to gather binding information from multiple binding information string"""

    my_list_values = []
    
    # Call clean_binding_info()
    my_string_out = clean_binding_info(string_binding_in)
    
    # Process binding information
    my_aux_index1 = my_string_out.find("(")
    my_aux_bind1 = my_string_out[:my_aux_index1]
    my_list_values.append(my_aux_bind1)
    working_string = my_string_out
    count_iterations = 0 
    
    # Loop while to parse binding information
    while (count_iterations < 100) and "#" in working_string:
        my_aux_index2s = working_string.find("#")
        my_aux_bind02 = working_string[my_aux_index2s+1:]
        my_aux_index2e = my_aux_bind02.find("(")
        my_aux_bind2 = my_aux_bind02[:my_aux_index2e]
        my_list_values.append(my_aux_bind2)
        working_string = working_string[my_aux_index2s+1:]
        count_iterations += 1
    
    # Mean
    my_sum = 0
    count_lines = 0
    for my_value in my_list_values:
        try:
            my_sum += float(my_value)
            count_lines +=  1
        except:
            continue
        
    if count_lines > 0:
        my_mean_value = my_sum/count_lines
    else:
        my_mean_value = 0.0
        
    return my_mean_value
    
def update_chklig_in():
    """Function to gather ligand-binding information from CSV files and copy to chklig.in"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    import time
    import shutil 
    
    # Set up empty lists
    my_binding_list = []
    my_chklig_list = []
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Make a copy of chklig.in
    print("\nCopying chklig.in to chklig_"+my_local_time+".in \n")
    shutil.copy2(project_dir_string+"chklig.in",project_dir_string+"chklig_"+my_local_time+".in")
    
    # Try to open chklig.in
    try:
        my_fo1 = open(project_dir_string+"chklig.in","r")
        my_csv1 = csv.reader(my_fo1)
    except:
        print("SAnDReS IOError! I can't find ",project_dir_string+"chklig.in") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+"chklig.in"+\
                             " \nPlease check directory name!")
        return
    
    # Get first line of my_csv1
    for line in my_csv1:
        my_first_line = line[0]
        break
    
    # Looping through the rest of my_csv1
    for line in my_csv1:
        if line[0][0:6] == "CHKLIG":
            # Try to open csv file
            try:
                my_fo2 = open(project_dir_string+line[1].upper()+".csv","r")
                my_csv2 = csv.reader(my_fo2)
            except:
                print("SAnDReS IOError! I can't find ",project_dir_string+line[1].upper()+".csv") 
                print("Please update project directory as your needs!")
                messagebox.showerror("SAnDReS IOError!", "I can't find file "+\
                                     project_dir_string+line[1].upper()+".csv"+" \nPlease check directory name!")
                return
                
            # Looping through csv file with binding information
            for line0 in my_csv2:
                binding_information_flag = True
                if line0[0] == line[1] and line0[1] == line[3] and line0[2] == line[2]:
                    tmp_lig_binding_info0 = line0[3]
                    tmp_lig_binding_info = tmp_lig_binding_info0.replace("-","(MULT)#")
                    
                    if "#" in tmp_lig_binding_info:
                        mult_binding_info = True
                        my_mean_aff = mult_binding_information(tmp_lig_binding_info)
                        my_binding_list.append(my_mean_aff)
                    else:
                        mult_binding_info = False
                        
                        # Call clean_binding_info()
                        my_string_out = clean_binding_info(tmp_lig_binding_info)
                        
                        my_index_var0 = my_string_out.find("(")
                        aux_binding_var0 = my_string_out[:my_index_var0]
                        my_binding_list.append(aux_binding_var0)
            
            if not mult_binding_info:
                try:
                    my_float_binding = float(my_binding_list[0])
                    binding_information_flag = True
                except:
                    print("\nNo binding information for ",line[1])
                    binding_information_flag = False
            else:
                my_float_binding = my_binding_list
            
            my_binding_list = []
            
            # Write information to my_chklig_list. if binding information is present
            if binding_information_flag:
                my_line_out0 = "CHKLIG,"+line[1]+","+line[2]+","+line[3]+","+line[4]+","+\
                str(my_float_binding)
                my_line_out1 = my_line_out0.replace("[","")
                my_line_out2 = my_line_out1.replace("]","")
                my_chklig_list.append(my_line_out2)
            
    my_fo1.close()
    try:
        my_fo2.close()
    except:
        print()
        
    # Open chklig.in to write
    my_chklig_fo = open(project_dir_string+"chklig.in","w")
    
    # Looping through my_chklig_list:
    print("\nNew chklig.in file:")
    my_chklig_fo.write(my_first_line+"\n")
    print(my_first_line)
    for line in my_chklig_list:
        print(line)
        my_chklig_fo.write(line+"\n")
    
    my_chklig_fo.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating new chklig.in!","black","light grey")
       
def filter_PDB_by_EC():    
    """Function to filter PDB files by EC"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    import time
    import shutil 
        
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Make a copy of chklig.in
    print("\nCopying chklig.in to chklig_"+my_local_time+".in \n")
    shutil.copy2(project_dir_string+"chklig.in",project_dir_string+"chklig_"+my_local_time+".in")
    
    # Set up empty lists
    my_ec_list = []
    my_resol_list = []
    my_pdb_list = []
    no_ec_list = []
    
    # Try to open chklig.in
    try:
        my_chklig_in_fo = open(project_dir_string+"chklig.in","r")
        my_csv_fo = csv.reader(my_chklig_in_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"chklig.in") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file chklig.in"+\
                             " \nPlease check directory name!")
        return 
    
    # looping through my_csv_fo
    for line0 in my_csv_fo:
        if line0[0][0] == "#":
            continue
        print("Parsing PDB file: "+line0[1]+".pdb")
        
        # Try to open PDB file
        try:
            my_pdb_fo = open(project_dir_string+line0[1]+".pdb","r")
        except IOError:
            print("SAnDReS IOError! I can't find "+line0[1]+".pdb") 
            print("Please update project directory as your needs!")
            messagebox.showerror("SAnDReS IOError!", "I can't find file "+line0[1]+".pdb"+\
                                 " \nPlease check directory name!")
            return
        
        # looping through PDB file
        ec_ok = False
        for line1 in my_pdb_fo:
            if "COMPND" in line1[0:6] and "EC" in line1[11:13]:
                my_ec_index0 = line1.find(":")
                my_ec_index1 = line1.find(";")
                my_ec_aux = line1[my_ec_index0+1:my_ec_index1]
                my_ec = my_ec_aux.replace(" ","")
                my_ec_list.append(my_ec)
                ec_ok = True
            elif line1[0:21] == "REMARK   2 RESOLUTION" and ec_ok:
                my_resol = float(line1[26:30])
                my_resol_list.append(my_resol)
                my_pdb_list.append(line0[1])
        if ec_ok:
            continue
        else:
            no_ec_list.append(line0[1])
        # Close PDB file
        my_pdb_fo.close()
                           
    
    # looping through list of EC
    my_new_ec_list = []
    my_new_resol_list = []
    my_new_pdb_list = []
    for line1 in my_ec_list:
        for line2 in my_ec_list:
            my_ec_index1 = int(my_ec_list.index(line1))
            my_ec_index2 = int(my_ec_list.index(line2))
            try:
                if my_resol_list[ int(my_ec_index1) ] < my_resol_list[ int(my_ec_index2)]:
                    my_new_ec_list.append(line1)
                    my_new_resol_list.append(my_resol_list[ int(my_ec_index1) ])
                    my_new_pdb_list.append( my_pdb_list[ int(my_ec_index1) ] )
                else:
                    my_new_ec_list.append(line2)
                    my_new_resol_list.append(my_resol_list[ int(my_ec_index2) ])
                    my_new_pdb_list.append( my_pdb_list[ int(my_ec_index2) ] )
            except:
                continue
          
    # looping through new lists
    my_newest_ec_list = []
    my_newest_resol_list = []
    my_newest_pdb_list = []
    print("\nList of EC found in the dataset")
    print("EC \t\tResolution(A)\tPDB Access Code")
    for line in my_new_ec_list:
        if line not in my_newest_ec_list:
            my_ec_index1 = int(my_new_ec_list.index(line))
            if len(line) > 10:
                print(line,"\t",my_new_resol_list[ int(my_ec_index1) ],
                      "\t",my_new_pdb_list[ int(my_ec_index1) ])
            else:
                print(line,"\t\t",my_new_resol_list[ int(my_ec_index1) ],
                      "\t",my_new_pdb_list[ int(my_ec_index1) ] )
            my_newest_ec_list.append(line)
            my_newest_resol_list.append(my_new_resol_list[ int(my_ec_index1) ])
            my_newest_pdb_list.append( my_new_pdb_list[ int(my_ec_index1) ] )
    print()
    
    # Looping through no_ec_list
    print("\nThe following PDB has no EC information")
    for line in no_ec_list:
        print(line)
    
    # Close file
    my_chklig_in_fo.close()
    
    # Get rid of no_ec in the PDB list
    my_pdb_out_list = []
    for line in my_newest_pdb_list:
        if line in no_ec_list:
            continue
        else:
            my_pdb_out_list.append(line)
    
    # Show new list
    print("\nNew PDB list")
    for line in my_pdb_out_list:
        print(line) 
        
    # Try to open chklig.in
    try:
        my_chklig_in_fo = open(project_dir_string+"chklig.in","r")
        my_csv_fo = csv.reader(my_chklig_in_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"chklig.in") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file chklig.in"+\
                             " \nPlease check directory name!")
        return 
    
    # Read first line
    for line0 in my_csv_fo:
        first_line = line0[0]
        break
    
    # looping through my_csv_fo
    my_new_lines_chklig_in = []
    my_new_lines_chklig_in.append(first_line)
    for line0 in my_csv_fo:
        if line0[0][0] == "#":
            continue
        my_aux0 = line0[1].replace(" ","")
        for line1 in my_pdb_out_list:
            my_aux1 = line1.replace(" ","")
            if my_aux0 == my_aux1:
                my_aux_line = "CHKLIG"
                for i in range(1,6):
                    my_aux_line +=","+str(line0[i])
                my_new_lines_chklig_in.append(my_aux_line)
    
    # Close file
    my_chklig_in_fo.close()
    
    # Open chklig.in to write
    my_chklig_in_fo = open(project_dir_string+"chklig.in","w")
    
    # Show chklig.in
    print("\n\nNew chklig.in")
    for line in my_new_lines_chklig_in:
        print(line)
        my_chklig_in_fo.write(line+"\n")
    
    # Close file
    my_chklig_in_fo.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running filter PDB! New chklig.in has been written.",\
                     "black","light grey")

def getbind_all(binding_affinity):
    """Function to generate getbind.in file"""
    
    # Set up initial value for string variable
    my_line_out = "GETBIND,"+binding_affinity.upper()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open new getbind.in
    getbind_fo = open(project_dir_string+"getbind.in","w")
    
    # Get PDB access codes
    my_pdb_list = readPDB()
    
    # Looping through my_pdb_list
    for line in my_pdb_list:
        my_line_out += ","+line.replace(" ","")
    getbind_fo.write(my_line_out+"\n")
    getbind_fo.write("ENDOF")
    
    # Close file
    getbind_fo.close()
            
    # Call run_sandres_in()
    run_sandres_in("getbind.in")
    
    # Show log file content on window_txt
    read_log_file("getbind.log")
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running getbind.in file !","black","light grey")

def getstr_download_GUI():
    """Function to download binding affinity information (csv files)"""
    
    # Defines global variable to allow access with different functions
    global top_txt
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Download Binding Affinity') 
    top_txt.geometry("870x125+20+435")
    
    Label(top_txt, text="Download Binding Affinity Information", font = "Arial" ).grid(row = 0,column = 0)
    
    # Show Empty Label 
    Label(top_txt, text=135*" ", font = "Arial" ).grid(row = 1,\
        column = 10, stick = W)
    
    # Widgets for binding affinity 
    Label(top_txt, text="Type of Binding Affinity:" ).grid(row = 4,column = 0, stick = E)
    
    # Widgets for binding affinity buttons
    Button(top_txt, text='Ki', command = getbind_ki).grid(row = 4, column = 1, sticky = W)
    Button(top_txt, text='Kd', command = getbind_kd).grid(row = 4, column = 2, sticky = W)
    Button(top_txt, text='EC50', command = getbind_ec50).grid(row = 4, column = 3, sticky = W) 
    Button(top_txt, text='IC50', command = getbind_ic50).grid(row = 4, column = 4, sticky = W) 
    Button(top_txt, text='Delta G', command = getbind_deltag).grid(row = 4, column = 5, sticky = W) 
    Button(top_txt, text='Delta H', command = getbind_deltah).grid(row = 4, column = 6, sticky = W)
    Button(top_txt, text='Ka', command = getbind_ka).grid(row = 4, column = 7, sticky = W)
    Button(top_txt, text='None', command = getbind_none).grid(row = 4, column = 8, sticky = W)
    
    # Show Empty Label 
    Label(top_txt, text=75*" ", font = "Arial" ).grid(row = 5,\
        column = 9, stick = W)
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 6, column = 9,\
                                                                                sticky = W)

def getbind_none():
    """Function to generate chklig.in for dataset with no binding information"""
    
    # Import libraries
    from tkinter import messagebox
    import csv
    import time
    import shutil
    
    # Set up empty list
    pdb_list = []
    
    # Set up a warning message
    warning_message = "You should type ligand information for each PDB.\n After editing new chklig.in go to "+\
    "Pre-docking.>Check Ligands"
    
    # Show warning message
    messagebox.showwarning("SAnDReS Warning!", warning_message)
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to make backup of chklig.in
    try:
        shutil.copy2(project_dir_string+"chklig.in",project_dir_string+"chklig_"+my_local_time+".in")
    except:
        print()
        
    # Try to open pdbCodes.csv
    try:
        my_fo = open(project_dir_string+"pdbCodes.csv","r")
        my_csv_fo = csv.reader(my_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"pdbCodes.csv") 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+"pdbCodes.csv")
        return
    
    # Get pdb information
    for line in my_csv_fo:
        for line1 in line:
            aux_line = str(line1).replace(" ","")
            pdb_list.append(aux_line)
    
    my_fo.close()
        
    # Open new chklig.in
    chklig_fo = open(project_dir_string+"chklig.in","w")
    
    # Write first line
    chklig_fo.write("# Type of binding information: None\n")
    
    # Looping through pdb list
    for line in pdb_list:
        chklig_fo.write("CHKLIG,"+line+", , , ,None\n")
    
    chklig_fo.close()
    
    # Call edit_input_file_chklig()
    edit_input_file_chklig()
        
def getbind_ki():
    """Function to prepare file getbind_ki.in"""
    
    # Call getbind_all()
    getbind_all("KI")

def getbind_kd():
    """Function to prepare file getbind_kd.in"""
    
    # Call getbind_all()
    getbind_all("kd")

def getbind_ec50():
    """Function to call getbind_all()"""
    
    # Call getbind_all()
    getbind_all("EC50")

def getbind_ic50():
    """Function to call getbind_all()"""
    
    # Call getbind_all()
    getbind_all("IC50")

def getbind_deltag():
    """Function to call getbind_all()"""
    
    # Call getbind_all()
    getbind_all("deltaG")

def getbind_deltah():
    """Function to call getbind_all()"""
    
    # Call getbind_all()
    getbind_all("deltaH")

def getbind_ka():
    """Function to call getbind_all()"""
    
    # Call getbind_all()
    getbind_all("Ka")
    
def getstr_all(my_sandres_2_run):
    """Function to run getstr.in"""
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS is running "+my_sandres_2_run+"...","green","light grey")    
    
    from tkinter import messagebox
    result = messagebox.askyesno("SAnDReS","Running "+my_sandres_2_run+\
                                 " will try to download files from www.rcsb.org. \nDo you want run it?")
    
    # Checks result
    if result:
        
        # Get new project directory
        project_dir_string = str(strdir_entry.get())
    
        # Call clear_sandres_info_file_txt()
        clear_sandres_info_file_txt()
    
        # Call clear_inputfile_entry()
        clear_inputfile_entry()
    
        # Insert new input file name
        inputfile_entry.insert(10,my_sandres_2_run)
    
        # Open sandres.in
        my_sandres_input = open(project_dir_string+"sandres.in","w")
        my_sandres_input.write(my_sandres_2_run)
        my_sandres_input.close()
    
        # Run script sandres_main_2018.py                   
        import sandres_main_2018 as sandres      
                

        # Call main method
        sandres.main()
    
        # Re-opens sandres.in     
        my_sandres_input = open("sandres.in","w")
        my_sandres_input.write("showinfo.in")
        my_sandres_input.close()
        
        # Show log file content on window_txt
        read_log_file("getstr.log")
    
        # Call show_message_in_sandres()
        show_message_in_sandres("Done! SAnDReS finished running "+my_sandres_2_run+\
                         "! New chkstr.in has been written.","black","light grey")
        
    else:
        # Call clear_sandres_info_file_txt()
        clear_sandres_info_file_txt()
        
        print("You gave up running "+my_sandres_2_run+".")
        
        # Call show_message_in_sandres()
        show_message_in_sandres("SAnDReS is back!","black","light grey")
    
    return

def check_all_formats(my_format_in):
    """Function to check if files have been properly download"""
    
    # Import libraries
    from tkinter import messagebox
    import csv
    import shutil
    import os
     
    # Set initial value for boolean variable
    try_again = False
    
    # Set empty list
    missing_file_codes = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open file
    try:
        getstr_fo =open(project_dir_string+"getstr.in","r")
        my_csv_fo = csv.reader(getstr_fo)
    except:
        print("SAnDReS IOError! I can't find ",project_dir_string+"getstr.in") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+"getstr.in"+\
                             " \nPlease check directory name!")
        try_again = True
        return 
    
    # Looping through getstr.in
    for line in my_csv_fo:
        if line[0].upper() == "GETSTR":
            print()
            
            # Looping through PDB access codes
            for aux_getstr_line in line[2:]:
                getstr_line = aux_getstr_line.replace(" ","")
                getstr_file_fo = open(project_dir_string+getstr_line[0:4]+"."+my_format_in,"r")
                
                # Looping through PDB files
                for line1 in getstr_file_fo:
                    if "<title>Error</title>" in line1:
                        print("Problem with ligand "+getstr_line)
                        missing_file_codes.append(getstr_line)
                        try_again = True
                    elif "This page can't be displayed" in line1:
                        print("Problem with ligand "+getstr_line)
                        missing_file_codes.append(getstr_line)
                        try_again = True
                    elif "RCSB Protein Data Bank Error Page" in line1:
                        print("Problem with ligand "+getstr_line)
                        missing_file_codes.append(getstr_line)
                        try_again = True
                    elif "<title>High User Activity</title>" in line1:
                        print("Problem with ligand "+getstr_line)
                        missing_file_codes.append(getstr_line)
                        try_again = True
                
                # Close file
                getstr_file_fo.close()
    
    # Close file
    getstr_fo.close()
    
    # Show missing PDB access codes if missing_file_codes is not empty
    if len(missing_file_codes) > 0:
        # Show results
        # Clear txt window
        clear_sandres_info_file_txt()
        print("\n\nList of missing PDB codes:")
        window_txt.insert(END, "\n\nList of missing PDB codes:\n")
        for line in missing_file_codes:
            print(line)
            window_txt.insert(END, line+"\n")
    
    # Try to download file(s) again
    if try_again:
        print("\nTrying to download files again...")
        window_txt.insert(END, "\nTrying to download files again...\n")
        
        print("\nWriting getstr_tmp.in file for new download...")
        window_txt.insert(END, "\nWriting getstr_tmp.in file for new download...\n")
        
        # Write getstr_tmp.in
        my_getstr_tmp_fo = open(project_dir_string+"getstr_tmp.in","w")
    
        my_getstr_tmp_fo.write("NEWGET,"+my_format_in)
        
        for line in missing_file_codes:
            aux_4_code = line.replace(" ","")
            file_2_delete = project_dir_string+aux_4_code+"."+my_format_in
            shutil.copy2(file_2_delete,project_dir_string+aux_4_code+"_old."+my_format_in)
            os.remove(file_2_delete)
            my_getstr_tmp_fo.write(","+line)
        
        my_getstr_tmp_fo.write("\nENDOF")
        my_getstr_tmp_fo.close()
        
        #Insert new input file name
        getstr_all("getstr_tmp.in")
        
    # Return 
    return
            
def getstr_PDB():
    """Function to run getstr.in for PDB files"""
    
    # Call unifyPDB()
    unifyPDB()
         
    # Call update_getstr()
    update_getstr("PDB")
        
    # Insert new input file name
    getstr_all("getstr.in")
        
    # Call check_all_formats()
    check_all_formats("PDB")


def pre_download(my_file_in):
    """Function to check if the file is already in the directory"""
    
    # Set up initial value for boolean variable
    file_present = False
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open file
    try:
        my_fo = open(project_dir_string+my_file_in,"r")
        file_present  = True
        my_fo.close()
    except:
        file_present  = False
    
    # Return boolean variable
    return file_present 

def get_lig2extract():
    """Function to get ligand codes from chklig.in and create getligs.in"""
    
    # Import library
    import csv
    
    # Set up empty list
    my_SDF_list = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open chklig.in
    try:
        my_chklig_fo = open(project_dir_string+"chklig.in","r")
        my_csv_fo = csv.reader(my_chklig_fo)
    except:
        print("\nI can't find chklig.in file!")
    
    # Looping through chklig.in
    for line in my_csv_fo:
        if line[0] == "CHKLIG":
            flag_4_file_present = pre_download(line[2]+".sdf")
            if flag_4_file_present:
                print("File "+line[2]+".sdf is here!")
            else:
                my_SDF_list.append(line[2])
        
    # Close csv file
    my_chklig_fo.close()
    
    # Open new getligs.in
    my_getstr_in = open(project_dir_string+"getligs.in","w")
    
    # Write ligand codes to getligs.in
    my_line_out = "GETSTR,SDF"
    for line in my_SDF_list:
        my_line_out += ","+line
    
    my_getstr_in.write(my_line_out)
    
    # Close my_getstr_in file
    my_getstr_in.close()
        
def create_dataset():
    """Function to create a dataset file for active ligands present in chklig.in"""
    
    # Import libraries
    import csv
    import time
    
    # Set up empty list
    my_sdf_list = []
        
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Try to open chklig.in
    try:
        my_chklig_fo = open(project_dir_string+"chklig.in","r")
        my_csv_fo = csv.reader(my_chklig_fo)
    except:
        print("\nI can't find chklig.in file!")
    
    # Looping through chklig.in
    found_ligands = []
    for line in my_csv_fo:
        if line[0] == "CHKLIG":
            
            # Try to open it
            try:
                my_sdf_fo = open(project_dir_string+line[2]+".sdf","r")
            except:
                print("\nI can't find "+line[2]+".sdf file!")
                continue
            
            # Copy sdf to my_sdf_list
            for line0 in my_sdf_fo:
                if line[2].upper() in line0.upper():
                    if line[2] not in found_ligands:
                        my_sdf_list.append("CHEMBL "+line0)
                        found_ligands.append(line[2])
                    else:
                        my_sdf_list.append(line0)
                else:
                    my_sdf_list.append(line0)
            
            # Close sdf file
            my_sdf_fo.close()
            
    # Close csv file
    my_chklig_fo.close()
    
    # Open last_active_dataset.in
    last_active_dataset = open(project_dir_string+"last_active_dataset.in","w")
    last_active_dataset.write("active_dataset_"+my_local_time+".sdf")
    last_active_dataset.close()
    
    # Open new sdf file for the dataset
    dataset_fo = open(project_dir_string+"active_dataset_"+my_local_time+".sdf","w")
    
    # Looping through my_sdf_list
    for line in my_sdf_list:
        dataset_fo.write(line)
    
    print("\nAll active ligands are in active_dataset_"+my_local_time+".sdf\n")
        
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! All active ligands are in active_dataset_"+my_local_time+".sdf","black","light grey")
        
    # Close dataset file
    dataset_fo.close()
    
def extract_sdf():
    """Function to get active ligand codes from chklig.in and download ligands from PDB"""
    
    # Import libraries
    import csv
    import unzip1 as uz
    
    # Call get_lig2extract()
    get_lig2extract()
        
    # Insert new input file name
    getstr_all("getligs.in")
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open chklig.in WFA 2017 12 26
    try:
        my_chklig = open(project_dir_string+"chklig.in","r")
        csv1 = csv.reader(my_chklig)
    except IOError:
        print("\nI can't find chklig.in file!")
        return    
    
    # Looping through chklig.in WFA 2017 12 26
    for line in csv1:
        if "CHKLIG" in line:
            print("\nUnziping ",line[2],".sdf.gz file...")
            
            # Instantiate an object of the UNZIPSDF class WFA 2017 12 26
            z1 = uz.UNZIPSDF(project_dir_string,line[2]+".sdf")
            
            # Call dounzip() method WFA 2017 12 26
            z1.dounzip()
    
    # Call create_dataset()
    create_dataset()
    
    # Close file
    my_chklig.close()
    
    # Beep
    print("\a")
    
def chkstr_GUI():
    """Function to check binding affinity information (csv files)"""
    
    # Defines global variable to allow access with different functions
    global top_txt
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Check Binding Affinity') 
    top_txt.geometry("870x125+20+435")
    
    Label(top_txt, text="Check Binding Affinity Information", font = "Arial" ).grid(row = 0,column = 0)
    
    # Show Empty Label 
    Label(top_txt, text=135*" ", font = "Arial" ).grid(row = 1,\
        column = 10, stick = W)
    
    # Widgets for binding affinity 
    Label(top_txt, text="Type of Binding Affinity:" ).grid(row = 4,column = 0, stick = E)
    
    # Widgets for binding affinity buttons
    Button(top_txt, text='Ki', command = chkstr_ki).grid(row = 4, column = 1, sticky = W)
    Button(top_txt, text='Kd', command = chkstr_kd).grid(row = 4, column = 2, sticky = W)
    Button(top_txt, text='EC50', command = chkstr_ec50).grid(row = 4, column = 3, sticky = W) 
    Button(top_txt, text='IC50', command = chkstr_ic50).grid(row = 4, column = 4, sticky = W) 
    Button(top_txt, text='Delta G', command = chkstr_deltag).grid(row = 4, column = 5, sticky = W) 
    Button(top_txt, text='Delta H', command = chkstr_deltah).grid(row = 4, column = 6, sticky = W)
    Button(top_txt, text='Ka', command = chkstr_ka).grid(row = 4, column = 7, sticky = W)
    
    # Show Empty Label 
    Label(top_txt, text=80*" ", font = "Arial" ).grid(row = 5,\
        column = 8, stick = W)
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 6, column = 9,\
                                                                                sticky = W)
def chkstr(binding_type):
    """Function to run chkstr.in"""
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get rid of old chklig.in
    my_chklig = open(project_dir_string+"chklig.in","w")
    my_chklig.write("# Type of binding information: "+binding_type+"\n")
    my_chklig.close()
     
    # Call run_sandres_in()
    run_sandres_in("chkstr_"+binding_type+".in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running chkstr.in! New chklig.in has been written.",\
                     "black","light grey")
    
    # Show log file content on window_txt
    read_log_file("chkstr.log")

def chkstr_ki():
    """Function to run chkstr_ki.in"""
    
    # Call chkstr()
    chkstr("ki")

def chkstr_kd():
    """Function to run chkstr_kd.in"""
    
    # Call chkstr()
    chkstr("kd")

def chkstr_ec50():
    """Function to run chkstr_ec50.in"""
    
    # Call chkstr()
    chkstr("ec50")
    
def chkstr_ic50():
    """Function to run chkstr_ic50.in"""
    
    # Call chkstr()
    chkstr("ic50")

def chkstr_deltag():
    """Function to run chkstr_deltag.in"""
    
    # Call chkstr()
    chkstr("deltag")

def chkstr_deltah():
    """Function to run chkstr_deltah.in"""
    
    # Call chkstr()
    chkstr("deltah")

def chkstr_ka():
    """Function to run chkstr_ka.in"""
    
    # Call chkstr()
    chkstr("ka")
         
def chklig():
    """Function to run chklig.in"""
    
    # Import library (WFA 2018 01 10)
    import gen_predock_inp as gen
    
    # Get new project directory (WFA 2018 01 10)
    project_dir_string = str(strdir_entry.get())
    
    # Instantiate an object of the class GenPre() (WFA 2018 01 10)
    g1 = gen.GenPre(project_dir_string)
    
    # Call read_chklig() method (WFA 2018 01 10)
    g1.read_chklig()
    
    # Call generate_all() method (WFA 2018 01 10)
    g1.generate_all()
            
    # Call run_sandres_in()
    run_sandres_in("chklig.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running chklig.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("chklig.log")

def geninp():
    """Function to run geninp.in"""
    
    # Call run_sandres_in()
    run_sandres_in("geninp.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished! New input files ststru.in, biomat.in and fndwat.in\
     have been written.","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("geninp.log")

def test_if_file_is_here(file_2_be_tested):
    """Function to check if a file is present in the project directory"""
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open
    try:
        my_fo = open(project_dir_string+file_2_be_tested,"r")
        file_present = True
        my_fo.close()
    except IOError:         
        file_present = False
    
    # Return Boolean variable
    return file_present
    
def show_ststru():
    """Function to show ststru.log"""
    
    # Show log file content on window_txt
    read_log_file("ststru.log")
      
def ststru():
    """Function to run ststru.in"""
    
    my_test_flag = test_if_file_is_here("geninp.in")
    
    # Run geninp.in if geninp.in exists
    if my_test_flag:
        print("\ngeninp.in found in the project directory\n")
    else:
        print("\nSAnDReS IOError! I can't find file geninp.in")
        print("\nPlease click on Filter Dataset button\n")
        return
        
    # Call run_sandres_in()
    run_sandres_in("ststru.in")    
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running ststru.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("ststru.log")

def biomat():
    """Function to run biomat.in"""
    
    # Call run_sandres_in()
    run_sandres_in("biomat.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running biomat.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("biomat.log")
    
def fndwat():
    """Function to run fndwat.in"""
    
    # Call run_sandres_in()
    run_sandres_in("fndwat.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running fndwat.in!","black","light grey")
    
    # Show log file content on window_txt
    #read_log_file("fndwat.log")
    
def update_chklig():
    """Function to update ligand information in chklig.in"""
    
    # Import libraries
    import shutil
    import csv
    import time
    from tkinter import messagebox

    # Set up empty lists for chklig.in information
    my_list_4_chklig_PDB = []
    my_list_4_chklig_lig = []
    my_list_4_chklig_chain = []
    my_list_4_chklig_number = []
    my_list_4_chklig_binding = []
    my_PDB_list_from_log = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Make a copy of chklig.in
    print("\nCopying chklig.in to chklig_"+my_local_time+".in \n")
    shutil.copy2(project_dir_string+"chklig.in",project_dir_string+"chklig_"+my_local_time+".in")

    # Try to open fndwat.log file
    try:
        my_fndwat_log_fo = open(project_dir_string+"fndwat.log","r")
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"fndwat.log") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                             "fndwat.log"+" \nPlease check directory name!")
        return
    
    # Looping through fndwat.log to get PDB access codes 
    pdb_flag = False
    for line in my_fndwat_log_fo:
        if "List of PDB files for which water molecules have been found close to the ligand" in line:
            pdb_flag = True
            continue
        elif "List of PDB files for which water molecules have NOT been found close to the ligand" in line:
            pdb_flag = False
        if pdb_flag:
            if ".pdb" in line:
                my_PDB_list_from_log.append(line[0:4])
    print("\nPDB access codes codes read from fndwat.log.\n\n")
    
    # Try to open chklig.in input file
    try:
        my_chklig_fo = open(project_dir_string+"chklig.in","r")
        my_csv_fo = csv.reader(my_chklig_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",project_dir_string+"chklig.in") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                             "chklig.in"+" \nPlease check directory name!")
        return
        
    # Show first line information
    for my_line in my_csv_fo:
        first_line = str(my_line[0])
        break
    
    # Looping through chklig.in
    for line in my_csv_fo:
        if line[1] in my_PDB_list_from_log: # Check if PDB code in the list my_PDB_list_from_log
            my_list_4_chklig_PDB.append(line[1])
            my_list_4_chklig_lig.append(line[2])
            my_list_4_chklig_chain.append(line[3])
            my_list_4_chklig_number.append(line[4])
            my_list_4_chklig_binding.append(line[5])
    
    # Close old chklig.in
    my_chklig_fo.close()
    
    # Open new chklig.in
    my_new_chklig_fo = open(project_dir_string+"chklig.in","w")
    
    # Write first line in chklig.in
    my_new_chklig_fo.write(first_line+"\n")
    
    # Looping through list of PDB in the old chklig.in
    for i in range(len(my_list_4_chklig_PDB)):
        my_chklig_line = "CHKLIG,"+ my_list_4_chklig_PDB[i]+","+my_list_4_chklig_lig[i]+\
        ","+my_list_4_chklig_chain[i]+","+str(my_list_4_chklig_number[i])+","+\
        str(my_list_4_chklig_binding[i])
        my_new_chklig_fo.write(my_chklig_line+"\n")
    print("\nNew chklig.in has been written.")
    
    # Close files
    my_new_chklig_fo.close()
    my_fndwat_log_fo.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished updating ligand information! New chklig.in has been written.",\
                     "black","light grey")
           
def clean_pltcsv(working_file_in,working_pltcsv_file_in):
    """Function to clean pltcsv.in file, it gets rid of rows for nan and ND values"""
    
    # Import library
    import csv
    
    # Set up boolean variable as False
    update_pltcsv_file = False
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open working_file_in
    try:
        working_file_in_foo = open(project_dir_string+working_file_in,"r")
        working_csv = csv.reader(working_file_in_foo)
    except:
        print("I can't find file "+project_dir_string+working_file_in+"\n")
        print("Please check file name!")
        return
    
    # Open working_pltcsv_file_in
    try:
        working_pltcsv_file_in_foo = open(project_dir_string+working_pltcsv_file_in,"r")
        working_pltcsv = csv.reader(working_pltcsv_file_in_foo)
    except:
        print("I can't find file "+project_dir_string+working_pltcsv_file_in+"\n")
        print("Please check file name!")
        return
    
    # Looping through working_csv in order to identify which lines has "nan" or "ND" in line1[2] or line1[3]
    my_new_working_pltcsv_list = []
    for line1 in working_csv:
        if  "ND" in line1[1] or "ND" in line1[2] or "ND" in line1[3] or "nan" in line1[2] or \
            "nan" in line1[2] or "10.000" in line1[2] or "0.000" in line1[2]:
            update_pltcsv_file = True   # Assigns True to boolean variable
            continue
        else:
            my_new_working_pltcsv_list.append(str(line1[0]))
    
    # Looping through working_pltcsv
    working_pltcsv_list = []
    for line2 in working_pltcsv:
        for line3 in my_new_working_pltcsv_list:
            try:
                if line3 in line2[1]:
                    working_pltcsv_list.append(line2)
            except:
                working_pltcsv_list.append(None)
                
    # Close pltcsv.in file (working_pltcsv_file_in_foo) and csv file
    working_pltcsv_file_in_foo.close()
    working_file_in_foo.close()
    
    # Checks if it is necessary to update pltcsv.in file
    if update_pltcsv_file:    
        print("\nUpdating information in the file "+working_pltcsv_file_in+"\n")
        # Open new pltcsv.in file
        new_pltcsv_in_file = open(project_dir_string+working_pltcsv_file_in,"w")
    
        # Looping through my_new_working_pltcsv_list    
        for line4 in working_pltcsv_list:
            my_aux_var_4_line = ""
            for i in range(len(line4)):
                my_aux_var_4_line += line4[i]+","
            new_pltcsv_in_file.write(my_aux_var_4_line[0:len(my_aux_var_4_line)]+"\n")
    
        # Close new pltcsv.in file
        new_pltcsv_in_file.close()
                          
def get_binding_info():
    """Function to read chklig.in and get the type of binding information"""
    
    # Import library
    from tkinter import messagebox
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Read chklig.in to get the type of binding information
    try:
        my_chklig_fo = open(project_dir_string+"chklig.in","r")
    except IOError:
        print("I can't find file ",project_dir_string+"chklig.in")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                             "chklig.in \nPlease check project directory!")
        return
    
    # Looping through chklig.in to get the type of binding information
    for line0 in my_chklig_fo:
        if "# Type of binding information:" in line0:
            bind_aux0 = line0[30:].upper()
            bind_type0 = bind_aux0.replace(" ","")
            bind_type = bind_type0.replace("\n","")
            break
    
    my_chklig_fo.close()      
    
    if "K" in bind_type or "IC50" in bind_type or "EC50" in bind_type:
        return "log("+bind_type+")"
    else:
        return bind_type

def add_calc_binding_GUI():
    """Function to add a column with calculated binding affinity.
    It could be from any external polscore.log file, for instance
    one generate with another dataset"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,input_score_csv_file_entry
    
    # Import
    import csv
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: SciKit-Learn Regression Methods') 
    top_txt.geometry("870x260+20+435")
        
    Label(top_txt, text="Add Calculated Binding Affinity", font = "Arial" ).grid(row = 0,column = 0)
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file
    my_new_csv_score_file_2018a = str(input_score_csv_file_entry.get())
            
    # Try to open csv file
    try:
        my_fo_2018a = open(project_dir_string+my_new_csv_score_file_2018a,"r")
        my_csv_fo_2018a = csv.reader(my_fo_2018a)
        for line in my_csv_fo_2018a:
            headers_2018a = str(line)+","
            break
        my_fo_2018a.close()
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file_2018a)
        print("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                                 my_new_csv_score_file_2018a+"\nPlease check file name!")
        return
    
    # Set up a list with headers
    aux_character1 = ""
    headers_2018a_list = []
    columns_2018a_list = []
    i = 0
    # Looping through headers_2018a string
    for character1 in headers_2018a:
        aux_character1 += character1
        if character1 == ",":
            aux_character2 = aux_character1[:len(aux_character1)]
            aux_character2 = aux_character2.replace("'","")
            aux_character2 = aux_character2.replace(",","")
            headers_2018a_list.append(aux_character2)
            if "Torsions" not in aux_character2:
                 columns_2018a_list.append(i)
            i += 1
            aux_character1 = ""
    
    # Widgets for scoring function file
    Label(top_txt, text="Scoring function file:" ).grid(row = 1,column = 0, stick = W)   
    top_sf_2018a_entry = Entry(top_txt,width = 120) # it was 94
    top_sf_2018a_entry.grid(row = 1, column = 0,stick = E)
    top_sf_2018a_entry.insert(10,my_new_csv_score_file_2018a )
    
    # Widgets for polscore.log like file
    Label(top_txt, text="Polscore.log like file:" ).grid(row = 2,column = 0, stick = W)   
    top_pol_2018a_entry = Entry(top_txt,width = 120) # it was 94
    top_pol_2018a_entry.grid(row = 2, column = 0,stick = E)
    top_pol_2018a_entry.insert(10,"polscore.log" )
    
    # Widgets for headers
    Label(top_txt, text="Headers:" ).grid(row = 3,column = 0, stick = W)   
    top_header_2018a_entry = Entry(top_txt,width = 140) # it was 94
    top_header_2018a_entry.grid(row = 4, column = 0,stick = E)
    top_header_2018a_entry.insert(10,str(headers_2018a_list))
    
    # Widgets for explanatory variable columns
    Label(top_txt, text="Explanatory variables (column numbers):" ).grid(row = 5,column = 0, stick = W)   
    top_columns_2018a_entry = Entry(top_txt,width = 140) # it was 94
    top_columns_2018a_entry.grid(row = 6, column = 0,stick = E)
    top_columns_2018a_entry.insert(10,str(columns_2018a_list[1:len(columns_2018a_list)-1]))
    
    # Widgets for response variable
    Label(top_txt, text="Response variable:" ).grid(row = 7,column = 0, stick = W)   
    top_response_2018a_entry = Entry(top_txt,width = 110) # it was 94
    top_response_2018a_entry.grid(row = 7, column = 0,stick = E)
    top_response_2018a_entry.insert(10,str(headers_2018a_list[len(headers_2018a_list)-1]).replace("]",""))
    
    # Widgets for response variable column
    Label(top_txt, text="Response variable (column):" ).grid(row = 8,column = 0, stick = W)   
    top_response_col_2018a_entry = Entry(top_txt,width = 110) # it was 94
    top_response_col_2018a_entry.grid(row = 8, column = 0,stick = E)
    top_response_col_2018a_entry.insert(10,str(len(headers_2018a_list)-1))
    
    # Widgets for top_pol_equation_number_2018a_entry
    Label(top_txt, text="Polynomial Equation Number:" ).grid(row = 9,column=0,stick = W)   
    top_pol_equation_number_2018a_entry = Entry(top_txt,width = 108) # it was 94
    top_pol_equation_number_2018a_entry.grid(row = 9, column = 0,stick = E)
    top_pol_equation_number_2018a_entry.insert(10,3)
    
    # Define add_calc_binding_affinity()
    def add_calc_binding_affinity():
        """Function to add a column with calculated binding affinity"""
        # Import Score from calc_binding1
        from calc_binding1 import Score
        
        # Input file                   
        file_in = my_new_csv_score_file_2018a    
    
        # Output file
        file_out = my_new_csv_score_file_2018a   

        # Polscore file
        polscore_in = top_pol_2018a_entry.get()
        
        # Polscore number
        polscore_number_in = str(top_pol_equation_number_2018a_entry.get())
            
        if int(top_pol_equation_number_2018a_entry.get()) > 511:
                
            # For dataset
            print("\nAdding binding affinity column...",end = "")
        
            # Instantiate an object of the Score() class and assign it to s_training
            s_training = Score(project_dir_string,file_in,file_out,polscore_in,polscore_number_in)
        
            # Invoke add_col_2_dataset()
            s_training.add_col_2_dataset()
            print("\nDone!")
        
        else:
            # Fix the number of characters
            my_str_7_char = str(polscore_number_in)
            if len(my_str_7_char)< 8:
                my_str_in1 = str((7-len(my_str_7_char) )*"0")+my_str_7_char
            
            # Get polynomial scoring function number
            pol_number = "number "+my_str_in1
    
            # Try to open polscore.log file
            try:
                my_polscore_log_fo = open(project_dir_string+polscore_in,"r")
            except IOError:
                print("SAnDReS IOError! I can't find "+polscore_in) 
                messagebox.showerror("SAnDReS IOError!", "I can't find file"+polscore_in+\
                             "\nPlease check directory name!")
                return
    
            # Looping through my_polscore_log_fo
            for line in my_polscore_log_fo:
                if "Polynomial equation number " in line:
                    if str(pol_number) in line:
                        my_index_pol_1 = line.index(":")
                        my_index_pol_2 = line.index("+")
                        c_0 =  float(line[my_index_pol_1+1:my_index_pol_2])
                        my_pol_string = line[my_index_pol_2+1:]
    
            my_polscore_log_fo.close()
    
            print("\nPolscore = "+my_pol_string+"\n")
    
            # Call function to count "*" in my_pol_string
            num_var_pol = get_number_ind_var(my_pol_string)
    
            # Call function to get coefficient array
            my_array = get_polynomial_coefficients(float(c_0),int(num_var_pol),my_pol_string)
    
            # Call function to get descriptors
            my_descriptors = get_descriptor_strings(my_pol_string)
    
            # Call calc_new_column_to_score_csv_file(my_array_in,num_ind_var_in)
            my_new_col = calc_new_column_to_score_csv_file(my_array,my_descriptors,num_var_pol,my_str_in1)
    
            # Call calc_new_column_to_test_set_csv_file()
            my_new_test_col = calc_new_column_to_test_set_csv_file(my_array,my_descriptors,num_var_pol,my_str_in1)
    
            # Call gen_new_training_set_csv_file()
            gen_new_training_set_csv_file(my_new_col,my_str_in1)
    
            # Call gen_new_test_set_csv()
            gen_new_test_set_csv(my_new_test_col,my_str_in1)
            
            # Clear scores_all.csv
            clear_scores_all_csv_file_entry()
    
            # Put csv filename back
            input_score_csv_file_entry.insert(10,my_new_csv_score_file_2018a)
            
        
        
    # Widgets for read_entries
    Button(top_txt, text=' Add ', command=add_calc_binding_affinity).grid(row = 10,column=0,sticky = W) 
    
    # Widgets for Close button
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 11, column = 0,\
                                                                                  sticky = W)             
     
    

def reg_brute_force_GUI():
    """Function to call a GUI window to generate regression parameters
    (brute force) and run it"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry
    
    # Import
    import csv
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: SciKit-Learn Regression Methods') 
    top_txt.geometry("870x260+20+435")
        
    Label(top_txt, text="SciKit-Learn Regression Methods (Scoring Function Space)", font = "Arial" ).grid(row = 0,column = 0)
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file
    my_new_csv_score_file_2018a = str(input_score_csv_file_entry.get())
            
    # Try to open csv file
    try:
        my_fo_2018a = open(project_dir_string+my_new_csv_score_file_2018a,"r")
        my_csv_fo_2018a = csv.reader(my_fo_2018a)
        for line in my_csv_fo_2018a:
            headers_2018a = str(line)+","
            break
        my_fo_2018a.close()
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file_2018a)
        print("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                                 my_new_csv_score_file_2018a+"\nPlease check file name!")
        return
    
    # Set up a list with headers
    aux_character1 = ""
    headers_2018a_list = []
    columns_2018a_list = []
    i = 0
    # Looping through headers_2018a string
    for character1 in headers_2018a:
        aux_character1 += character1
        if character1 == ",":
            aux_character2 = aux_character1[:len(aux_character1)]
            aux_character2 = aux_character2.replace("'","")
            aux_character2 = aux_character2.replace(",","")
            headers_2018a_list.append(aux_character2)
            if "Torsions" not in aux_character2:
                 columns_2018a_list.append(i)
            i += 1
            aux_character1 = ""
    
    # Widgets for scoring function file
    Label(top_txt, text="Scoring function file:" ).grid(row = 1,column = 0, stick = W)   
    top_sf_2018a_entry = Entry(top_txt,width = 120) # it was 94
    top_sf_2018a_entry.grid(row = 1, column = 0,stick = E)
    top_sf_2018a_entry.insert(10,"training_set.csv" )
    
    # Widgets for headers
    Label(top_txt, text="Headers:" ).grid(row = 2,column = 0, stick = W)   
    top_header_2018a_entry = Entry(top_txt,width = 140) # it was 94
    top_header_2018a_entry.grid(row = 3, column = 0,stick = E)
    top_header_2018a_entry.insert(10,str(headers_2018a_list))
    
    # Widgets for explanatory variable columns
    Label(top_txt, text="Explanatory variables (column numbers):" ).grid(row = 4,column = 0, stick = W)   
    top_columns_2018a_entry = Entry(top_txt,width = 140) # it was 94
    top_columns_2018a_entry.grid(row = 5, column = 0,stick = E)
    top_columns_2018a_entry.insert(10,str(columns_2018a_list[1:len(columns_2018a_list)-1]))
    
    # Widgets for response variable
    Label(top_txt, text="Response variable:" ).grid(row = 6,column = 0, stick = W)   
    top_response_2018a_entry = Entry(top_txt,width = 110) # it was 94
    top_response_2018a_entry.grid(row = 6, column = 0,stick = E)
    top_response_2018a_entry.insert(10,str(headers_2018a_list[len(headers_2018a_list)-1]).replace("]",""))
    
    # Widgets for response variable column
    Label(top_txt, text="Response variable (column):" ).grid(row = 7,column = 0, stick = W)   
    top_response_col_2018a_entry = Entry(top_txt,width = 110) # it was 94
    top_response_col_2018a_entry.grid(row = 7, column = 0,stick = E)
    top_response_col_2018a_entry.insert(10,str(len(headers_2018a_list)-1))
    
    # Widgets for top_min_number_of_variables_2018a_entry
    Label(top_txt, text="Minimum number of variables:" ).grid(row = 8,column=0,stick = W)   
    top_min_number_of_variables_2018a_entry = Entry(top_txt,width = 108) # it was 94
    top_min_number_of_variables_2018a_entry.grid(row = 8, column = 0,stick = E)
    top_min_number_of_variables_2018a_entry.insert(10,3)
    
    # Widgets for top_max_number_of_variables_2018a_entry
    Label(top_txt, text="Maximum number of variables:" ).grid(row = 9,column=0,stick = W)   
    top_max_number_of_variables_2018a_entry = Entry(top_txt,width = 108) # it was 94
    top_max_number_of_variables_2018a_entry.grid(row = 9, column = 0,stick = E)
    top_max_number_of_variables_2018a_entry.insert(10,5)
    
    # Define run_brute_force()
    def run_brute_force():
        """Function to read entries and run brute force"""
        
        # Import library
        import smlearning as brute 
        
        # Set up empty list
        initial_list = []
        
        # Get data
        file_in_brute_force = top_sf_2018a_entry.get()
        initial_list0 = top_columns_2018a_entry.get()
        response_in = int(top_response_col_2018a_entry.get())
        min_elem = int(top_min_number_of_variables_2018a_entry.get())
        max_elem = int(top_max_number_of_variables_2018a_entry.get())
        
        # Looping through initial_list0
        aux_line_2018a = ""
        for line in initial_list0:
            aux_line_2018a += line
            if line == ",":
                aux_line_2018a = aux_line_2018a.replace(",","")
                aux_line_2018a = aux_line_2018a.replace("[","")
                aux_line_2018a = aux_line_2018a.replace("]","")
                initial_list.append(int(aux_line_2018a))
                aux_line_2018a = ""
        
        # Show gathered information
        print("\nScoring function file: ",file_in_brute_force)
        print("Project directory: ",project_dir_string)
        print("Explanatory varialbles (columns):",initial_list) 
        print("Response varialble (column):",response_in)
        print("Minimum number of variables in the model:",min_elem) 
        print("Maximum number of variables in the model:",max_elem) 
        
        # Set up arguments    
        p_dir =  project_dir_string      # Project directory
        method_in = "ALL"             # Regression method
        pollog = "polscore.log"                    # Polscore log file
        polcsv = "polscore.csv"                    # Polscore csv file
        ip = 511                                   # Initial polynomial eq. number
        
        # Instantiate an object of the SMLEARNING() class
        model1 = brute.SMLEARNING(p_dir,file_in_brute_force,response_in,method_in,pollog,\
        polcsv,ip,min_elem,max_elem,initial_list)
        
        # Invoke gen_lists()
        model1.gen_lists()
        
        # Invoke write_lists() method
        model1.write_lists()
        
        # Check regression method to invoke the right method
        if method_in.upper() == "ALL":
            # Invoke gen_models_all_methods() method
            model1.gen_models_all_methods()
        else:
            # Invoke gen_models() method
            model1.gen_models()
        
              
    # Widgets for read_entries
    Button(top_txt, text='Explore', command=run_brute_force).grid(row = 10,column=0,sticky = W) 
    
    # Widgets for Close button
    Button(top_txt, text='  Close ', bg = "red", command=top_txt.destroy).grid(row = 11, column = 0,\
                                                                                  sticky = W)             
                                                                                  
def reg_methods_GUI():
    """Function to call a GUI window to generate regression parameters and run it"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry, global_p_value, top_number_of_waters_size_entry
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: SciKit-Learn Regression Methods') 
    top_txt.geometry("870x210+20+435")
        
    Label(top_txt, text="SciKit-Learn Regression Methods           ", font = "Arial" ).grid(row = 1,column = 0)
    
    # Widgets for number of water molecules
    reg_method_var  = IntVar()
    
    # Set list for reg_method_list
    reg_method_list = ["LinearRegression ",
                       "Lasso            ",
                       "LassoCV          ",
                       "Ridge            ",
                       "RidgeCV          ",
                       "ElasticNet       ",
                       "ElasticNetCV     ",
                       "SGDRegressor",
                       "SVR"]
                       
    def my_sel1():
        """Function to show number of water molecules"""
        selection = "Regression method: "+str(  reg_method_list[int(reg_method_var.get())] )+15*" "
        Label(top_txt, text=selection ).grid(row = 9,column = 0, stick = W)
    
    # Looping through number of water molecules
    for i in range(len(reg_method_list)):
        if i < 4:
            rad = Radiobutton(top_txt, text = reg_method_list[i], value = i, \
                          variable=reg_method_var, command = my_sel1)
            rad.grid(row = 3,column = i+2, stick = W)
        elif i < 8:
            rad = Radiobutton(top_txt, text = reg_method_list[i], value = i, \
                          variable=reg_method_var, command = my_sel1)
            rad.grid(row = 4,column = i-2, stick = W)
        elif i < 12:
            rad = Radiobutton(top_txt, text = reg_method_list[i], value = i, \
                          variable=reg_method_var, command = my_sel1)
            rad.grid(row = 5,column = i-6, stick = W)
        else:
            rad = Radiobutton(top_txt, text = reg_method_list[i], value = i, \
                          variable=reg_method_var, command = my_sel1)
            rad.grid(row = 6,column = i-10, stick = W)
            
    def setup_reg_par():
        """Function to set up regression parameter"""
        method_2_call_0 = str(reg_method_list[int(reg_method_var.get())] )
        method_2_call_1 = method_2_call_0.replace(" ","")
        print("Regression method: ",method_2_call_1)
        
        def read_my_polscore():   
            """Function to read polscore.in file"""
            
            # Get new project directory
            project_dir_string = str(strdir_entry.get())
            
            # Set up empty list
            my_list_of_polscore = []
            
            # Open polscore.in
            try:
                polscore_fo = open(project_dir_string+"polscore.in","r")
            except IOError:
                print("\nI can't find file polscore.in")
                print("\nPlease check directory and/or file name.")
                from tkinter import messagebox
                messagebox.showerror("SAnDReS IOError!",\
                             "I can't find file polscore.in\
                              \nPlease check project directory!")
                return my_list_of_polscore
                
            # Looping through polscore.in file
            for line_pol in polscore_fo:
                my_index1 = line_pol.index("csv,") + 4
                line_pol_aux = line_pol[my_index1:]
                my_index2 = line_pol_aux.index(",")+1
                my_list_of_polscore.append(line_pol[:my_index1+my_index2])
            
            polscore_fo.close()
            
            return my_list_of_polscore
        
        def write_my_polscore(my_polscore_list_in,polscore_method_in):   
            """Function to write polscore.in file"""
            
            # Get new project directory
            project_dir_string = str(strdir_entry.get())
            
            # Open polscore.in
            polscore_fo = open(project_dir_string+"polscore.in","w")
            
            # Looping through polscore.in file
            for line_pol in my_polscore_list_in:
                polscore_fo.write(line_pol+polscore_method_in+"\n")
            
            polscore_fo.close()
        
        # Looping through MLF methods
        for the_mlr_method in reg_method_list:
            no_space_the_mlr_method = the_mlr_method.replace(" ","")
            if method_2_call_1 == no_space_the_mlr_method:
                my_list_pol001 = read_my_polscore()
                write_my_polscore(my_list_pol001,method_2_call_1)
        
            
    # Widgets for setup_reg_par
    Button(top_txt, text='Set up Parameters', command=setup_reg_par).grid(row = 7, column = 0, sticky = W) 
    
    # Widgets for polscore_GUI
    Button(top_txt, text='Build Polynomial Scoring Functions', command=polscore_GUI).grid(row = 8, column = 0, sticky = W) 
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 8, column = 0,\
                                                                                sticky = E)

def read_access_codes(csv_in):
    """Function to read PDB access codes"""
    
    # Import libraries
    import csv
    import sys
    
    global strdir_entry
    
    # Set up empty lists
    pdbs = []
    ligs = []
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open CSV file
    try:
        fo = open(project_dir_string+str(csv_in),"r")
        my_csv = csv.reader(fo)
    except IOError:
        sys.exit("I can't find "+project_dir_string+str(csv_in)+" file!")
    
    # Looping through CSV file
    for line in my_csv:
        if "CHKLIG" in line:
            aux_list = []
            for line1 in line:
                aux_list.append(line1)
            pdbs.append(aux_list[1])
            ligs.append(aux_list[2])
    
    return pdbs,ligs

def read_lig_PDB(pdb_in,lig_in):
    """Function to read atomic coordinates from a PDB file for a ligand"""
    
    # Import libraries
    import sys
    import numpy as np
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Setup empty lists
    x = []
    y = []
    z = []
    my_lines = []
    
    # Try to open PDB file
    try:
        my_PDB_fo = open(project_dir_string+pdb_in,"r")
    except IOError:
        sys.exit("\nI can't file "+project_dir_string+pdb_in+" file!")
    
    # Looping through PDB file
    for line in my_PDB_fo:
        if line[0:6] == "HETATM" and line[17:20] == lig_in[0:3]:
            if line[13:14] != "H":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
                my_lines.append(line)
    
    # Convert list to array
    x_coord = np.array(x)
    y_coord = np.array(y)
    z_coord = np.array(z)
   
    # Close file
    my_PDB_fo.close()
     
    # Return arrays
    return x_coord, y_coord, z_coord, my_lines

def read_protein_PDB(pdb_in):
    """Function to read atomic coordinates from a PDB file for protein"""
    
    # Import libraries
    import sys
    import numpy as np
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Setup empty lists
    x = []
    y = []
    z = []
    my_lines = []
    
    # Try to open PDB file
    try:
        my_PDB_fo = open(project_dir_string+pdb_in,"r")
    except IOError:
        sys.exit("\nI can't file "+project_dir_string+pdb_in+" file!")
    
    # Looping through PDB file
    for line in my_PDB_fo:
        if line[0:3] == "TER":
            break
        if line[0:6] == "ATOM  " and int(line[22:26]) > 0:
            if line[13:14] != "H":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
                my_lines.append(line)
    
    # Convert list to array
    x_coord = np.array(x)
    y_coord = np.array(y)
    z_coord = np.array(z)
    
    # Close file
    my_PDB_fo.close()
    
    # Return arrays
    return x_coord, y_coord, z_coord, my_lines

def inter_mol(file1,lig):
    """Function to count intermolecular interactions"""
    
    # Import library
    import numpy as np
    
    # Call read_PDB_return_coor_and_lines()
    x1,y1,z1,l1 = read_protein_PDB(file1)    
    x2,y2,z2,_ = read_lig_PDB(file1,lig)
    
    # Get the length of the arrays
    n1 = len(x1)
    n2 = len(x2)
    
    # Looping through residues
    res_num0 = 9999
    count_res = 0
    res_list = []
    for line in l1:
        res_num1 = int(line[22:26])
        if res_num0 != res_num1:
            count_res += 1
            res_num0 = res_num1
            res_list.append(res_num1)
        
    # Set up array
    c = np.zeros(count_res,dtype = int)
    
    # Looping coordinates
    res_num0 = 9999
    count_res = -1
    for i in range(n1):
        for j in range(n2):
            res_num1 = int(l1[i][22:26])
            if res_num0 != res_num1:
                res_num0 = res_num1
                count_res += 1
            d =  np.sqrt( (x1[i] - x2[j] )**2 + (y1[i] - y2[j])**2 + (z1[i] - z2[j])**2 )  
            if d <= 4.5:
                c[count_res] += 1
                        
    return res_list,c

def sum_intermol_contacts(p,l,total_res):
    """Function to sum up intermolecular contacts"""
    
    # Import library
    import numpy as np
    
    global top_nres_entry
    
    nres = int(top_nres_entry.get())
            
    # Set up a zeros array with the number of elements equals to residues
    my_count = np.zeros( nres+1, int )
    
    # Looping through PDB files
    for i in range(len(p)): 
        print("\nReading "+str(p[i])+".pdb ...")       
        
        # Call inter_mol()
        res,count = inter_mol(p[i]+".pdb",l[i])
        for i in range(nres+1):
            if i > 0:
                for line in res:
                    if i == line:
                        my_index = res.index(line)
                        my_count[i] += count[my_index]
                        break
    
    return my_count

def make_csv_contacts(col_in,csv_in):
    """Function to generate a two-column CSV file"""
        
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open new file
    fo = open(project_dir_string+csv_in,"w")
    
    # Looping through data
    i = 0
    for line in col_in:
        fo.write(str(i)+","+str(line)+"\n")
        i += 1
    
    # Close CSV file
    fo.close()

def bar_plot_2(x_1,y_1,x_label_1,y_label_1,font_size_1,title_1,bar_width_1,dpi_1,file_out_1):
    """Function to generate bar plot"""
    
    # Import library
    import matplotlib.pyplot as plt
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Generates plot
    plt.bar(x_1,y_1,color="grey")
    plt.xlabel(x_label_1,fontsize=font_size_1)
    plt.ylabel(y_label_1,fontsize=font_size_1)
    plt.title(title_1)

    # Set up x-axis range
    plt.xlim(0,len(y_1)+2)  

    # Saves plot on png file
    plt.savefig(project_dir_string+file_out_1,DPI=dpi_1)
    
def call_intermol():
    """Function to call intermol() what set free the button"""
    
    # Import library
    from tkinter import messagebox

    # Call show_message_in_sandres()
    show_message_in_sandres(" SAnDReS is counting intermolecular contacts ...","green","light grey")
        
    # Ask yes/no question
    result = messagebox.askyesno("SAnDReS","Do you want to generate intermolecular contact plot?")
    
    if result:
        # Call intermol()
        intermol()
    else:
        # Call show_message_in_sandres()
        show_message_in_sandres("No request for generating plot for intermolecular contacts!","black",
        "light grey")
    
def intermol():
    """Function to set up analysis of intermolecular interactions for SAnDReS"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry,top_strdir_entry,top_distance_cutoff_entry,top_nres_entry,\
    top_xlabel_entry,top_ylabel_entry,top_font_size_entry,top_dpi_entry,top_output_entry,top_chklig_entry
    
    # Import library
    import numpy as np
    
    # Set up the number of residues
    nres = int(top_nres_entry.get())
    
    # Call read_access_codes()
    chklig_in = str(top_chklig_entry.get())
    p,l = read_access_codes(chklig_in)
    
    # Call sum_intermol_contacts()
    c = sum_intermol_contacts(p,l,nres)
        
    # Call make_csv_contacts()
    make_csv_contacts(c,"intermol_contact.csv")
        
    # Set up arguments for function bar_plot_2()
    x = np.arange(0,len(c))                             # Set up x-axis array
    x_label_in = top_xlabel_entry.get()                 # Set up x-axis label    
    y_label_in = top_ylabel_entry.get()                 # Set up y-axis label  
    font_size_in = int(top_font_size_entry.get())       # Set up font size for axis labels
    title_in = ""                                       # Set up title
    bar_width_in = 0.35                                 # Set up bar width to move bar in the xticks
    dpi_in = top_dpi_entry.get()                        # Set up dots per inch
    file_out = top_output_entry.get()                   # Set up output file name
    
    # Call bar_plot()
    bar_plot_2(x,c,x_label_in,y_label_in,font_size_in,title_in,bar_width_in,dpi_in,file_out)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating "+file_out+" file for intermolecular contacts!","black","light grey")

def pre_intermol_GUI():
    """Function to call intermol_GUI """
   
    # Call intermol_GUI()
    intermol_GUI(4.5,298,"Number of Residues","Number of Intermolecular Contacts",14,900,"bar_plot.png",
            "chklig.in")
        
def intermol_GUI(distance_in,nres_in,xlabel_in,ylabel_in,font_size_in,dpi_in,output_in,chklig_in):
    """Function to call intermol"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry,top_strdir_entry,top_distance_cutoff_entry,top_nres_entry,\
    top_xlabel_entry,top_ylabel_entry,top_font_size_entry,top_dpi_entry,top_output_entry,top_chklig_entry
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Intermolecular Contacts') 
    top_txt.geometry("870x220+20+435")
    
    Label(top_txt, text="Plot Intermolecular Contacts"+20*" ", font = "Arial" ).grid(row = 0,column = 0)
        
    # Widget for distance cutoff   
    Label(top_txt, text="Distance cutoff (A):" ).grid(row = 10,column = 0, stick = W)   
    top_distance_cutoff_entry = Entry(top_txt,width = 5)
    top_distance_cutoff_entry.grid(row = 10, column = 0,stick = E)
    top_distance_cutoff_entry.insert(0,str(distance_in))
    
    # Widget for number of residues   
    Label(top_txt, text="Number of residues:" ).grid(row = 11,column = 0, stick = W)   
    top_nres_entry = Entry(top_txt,width = 5)
    top_nres_entry.grid(row = 11, column = 0,stick = E)
    top_nres_entry.insert(0,str(nres_in))
    
    # Widget for x-axis label   
    Label(top_txt, text="X-axis label:" ).grid(row = 12,column = 0, stick = W)   
    top_xlabel_entry = Entry(top_txt,width = 34)
    top_xlabel_entry.grid(row = 12, column = 0,stick = E)
    top_xlabel_entry.insert(0,xlabel_in)
    
    # Widget for y-axis label   
    Label(top_txt, text="Y-axis label:" ).grid(row = 13,column = 0, stick = W)   
    top_ylabel_entry = Entry(top_txt,width = 34)
    top_ylabel_entry.grid(row = 13, column = 0,stick = E)
    top_ylabel_entry.insert(0,ylabel_in)
    
    # Widget for font size   
    Label(top_txt, text="Font size:" ).grid(row = 14,column = 0, stick = W)   
    top_font_size_entry = Entry(top_txt,width = 5)
    top_font_size_entry.grid(row = 14, column = 0,stick = E)
    top_font_size_entry.insert(0,str(font_size_in))
    
    # Widget for DPI   
    Label(top_txt, text="DPI:" ).grid(row = 15,column = 0, stick = W)   
    top_dpi_entry = Entry(top_txt,width = 5)
    top_dpi_entry.grid(row = 15, column = 0,stick = E)
    top_dpi_entry.insert(0,str(dpi_in))
    
    # Widget for output file name   
    Label(top_txt, text="Output file name:" ).grid(row = 16,column = 0, stick = W)   
    top_output_entry = Entry(top_txt,width = 27)
    top_output_entry.grid(row = 16, column = 0,stick = E)
    top_output_entry.insert(0,output_in)
    
    # Widget for file with ligand information   
    Label(top_txt, text="File for ligand data:" ).grid(row = 17,column = 0, stick = W)   
    top_chklig_entry = Entry(top_txt,width = 27)
    top_chklig_entry.grid(row = 17, column = 0,stick = E)
    top_chklig_entry.insert(0,chklig_in)
    
    # Widgets for Plot
    Button(top_txt, text='Plot', command=call_intermol).grid(row = 20, column = 2, sticky = E) 
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 20, column = 3,\
                                                                                sticky = E)

def filter_dataset_GUI(scatter_pltcsv_in,x_label_in,my_x_min_in,my_x_max_in):
    """Function to call a GUI window to generate geninp.in file"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry, global_p_value, top_number_of_waters_size_entry
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Filter Dataset') 
    top_txt.geometry("870x210+20+435")
    
    Label(top_txt, text="Parameters to Filter Dataset", font = "Arial" ).grid(row = 0,column = 0)
    
    # Widgets for sphere radius
    Label(top_txt, text="Sphere radius (A):" ).grid(row = 2,column = 0, stick = W)
    sphere_radius_var  = IntVar()
    
    # Set list for sphere radius
    sphere_radius_list = ["7.5","10.0","12.5","15.0","17.5","20.0","22.5","25.0"]
    
    def my_sel1():
        """Function to show selection of sphere radius"""
        selection = "Radius (A): " + str( sphere_radius_list[int(sphere_radius_var.get())])+"         "
        Label(top_txt, text=selection ).grid(row = 11,column = 0, stick = W)
    
    # Looping through sphere radius
    for i in range(8):
        rad = Radiobutton(top_txt, text = sphere_radius_list[i], value = i, variable=sphere_radius_var,\
                           command = my_sel1)
        rad.grid(row = 3,column = i+2, stick = W)
    
    # Widgets for number of water molecules
    Label(top_txt, text="Number of waters:" ).grid(row = 4,column = 0, stick = W)
    number_of_waters_var  = IntVar()
    
    # Set list for number of water molecules
    number_of_waters_list = ["5       ","10  ",
                   "15      ","20      ","25         ",
                   "30        ","35        ","40       "]
    
    def my_sel2():
        """Function to show number of water molecules"""
        selection = "Waters: "+str(  number_of_waters_list[int(number_of_waters_var.get())] )+"       "
        Label(top_txt, text=selection ).grid(row = 11,column = 0, stick = W)
    
    # Looping through number of water molecules
    for i in range(len(number_of_waters_list)):
        rad = Radiobutton(top_txt, text = number_of_waters_list[i], value = i, \
                          variable=number_of_waters_var, command = my_sel2)
        rad.grid(row = 5,column = i+2, stick = W)
        
    # Widgets for type of filtering
    Label(top_txt, text="Filter? " ).grid(row = 6,column = 0, stick = W)
    filter_var  = IntVar()
    
    # Set list for binding affinity
    filter_list = ["UNIQUE","FORALL"]
    
    def my_sel3():
        """Function to filter"""
        selection = "Filter? "+str(   filter_list[int( filter_var.get())] )+"                    "
        Label(top_txt, text=selection ).grid(row = 11,column = 0, stick = W)
    
    # Looping through filter
    for i in range(2):
        rad = Radiobutton(top_txt, text =  filter_list[i], value = i, \
                          variable= filter_var, command = my_sel3)
        rad.grid(row = 7,column = i+2, stick = W)
     
    def put_par_in_geninp():
        """Function to update values and call geninp function"""
        my_radius = float(sphere_radius_list[int(sphere_radius_var.get())] )
        my_number_of_waters = int(   number_of_waters_list[int(number_of_waters_var.get())] )
        my_filter_choice = str(filter_list[int( filter_var.get())]) 
        
        # Get project directory
        project_dir_string = str(strdir_entry.get())
    
        # Open new geninp.in
        my_geninp_fo = open(project_dir_string+"geninp.in","w")
    
        # Write first line in geninp.in
        my_geninp_fo.write("GENINP,"+my_filter_choice+",chklig.in,ststru.in,biomat.in,fndwat.in,"+\
                           str(my_radius)+","+str(my_number_of_waters)+"\n")
    
        # Write second line in geninp.in
        my_geninp_fo.write("ENDOF")

        print("Parameters: ",my_radius,my_number_of_waters,my_filter_choice)

    # Widgets for Generate geninp.in button
    Button(top_txt, text='Generate geninp.in', command=put_par_in_geninp).grid(row = 10, column = 0, sticky = W) 
    
    # Widgets for geninp.in
    Button(top_txt, text='Filter', command=geninp).grid(row = 10, column = 0, sticky = E) 
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 10, column = 1,\
                                                                                sticky = W)

def edit_filter_dataset():
    """Function to call filter_dataset_GUI """
    
    # Call filter_dataset_GUI()
    filter_dataset_GUI("pltcsv1.in","Docking RMSD ($\AA$)","0.0","12.0")
    
def edit_scatter_pltcsv1():
    """Function to edit pltcsv1.in """
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv1.in","Docking RMSD ($\AA$)","0.0","12.0")
    
def edit_scatter_pltcsv1A():
    """Function to edit pltcsv1A.in """
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv1A.in","Docking RMSD ($\AA$)","0.0","12.0")

def edit_scatter_pltcsv2():
    """Function to edit pltcsv2.in """
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv2.in","Docking RMSD ($\AA$)","0.0","12.0")
    
def edit_scatter_pltcsv2A():
    """Function to edit pltcsv2A.in """
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv2A.in","Docking RMSD ($\AA$)","0.0","12.0")

def edit_scatter_pltcsv3():
    """Function to edit pltcsv3.in """
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv3.in","Docking RMSD ($\AA$)","0.0","12.0")

def edit_scatter_pltcsv3A():
    """Function to edit pltcsv3A.in """
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv3A.in","Docking RMSD ($\AA$)","0.0","12.0")

def edit_scatter_pltcsv4():
    """Function to edit pltcsv4.in """
    
    # Call get_binding_info()
    my_type_of_binding_info = get_binding_info()
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv4.in",str(my_type_of_binding_info),"-12.0","0.1" )   

def edit_scatter_pltcsv4A():
    """Function to edit pltcsv4A.in """
    
    # Call get_binding_info()
    my_type_of_binding_info = get_binding_info()
    
    
    # Call scatter_pltcsv_GUI()
    scatter_pltcsv_GUI("pltcsv4A.in",str(my_type_of_binding_info),"-12.0","0.1" )

def next_pltcsv_file_entry():
    """Function to get next file and update pltcsv_file_entry"""
    
    # Import library
    from tkinter import messagebox
    
    # Define global variable
    global pltcsv_file_entry
    
    # Get file number
    aux = str(pltcsv_file_entry.get())
    ind1 = aux.index(".")
    aux0 = int(aux[7:ind1])
    
    # Call clear_pltcsv_file_entry()
    clear_pltcsv_file_entry()
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open files2plot.in
    try:
        fo = open(project_dir_string+"files2plot.in","r")
    except IOError:
        print("\n I can't find files2plot.in file!")
        return
    
    # Count files
    count_files = 0
    for line in fo:
        count_files += 1
    
    # Close file
    fo.close()
        
    if aux0 < count_files-1 :
        # Next
        pltcsv_file_entry.insert(10,"pltcsv_0"+str(aux0+1)+".in")
        go_and_plot_it()
    else:
        warning_message = "The number of files should be < "+str(count_files+1)
        print("\n"+warning_message)
        pltcsv_file_entry.insert(10,"pltcsv_0"+str(aux0)+".in")
        messagebox.showwarning("SAnDReS Warning!", warning_message)
    
def clear_pltcsv_file_entry():
    """Function to clear pltcsv_file_entry"""
    
    # Define global variable
    global clear_pltcsv_file_entry
    
    # Clear
    pltcsv_file_entry.delete(0,END)
        
def go_and_plot_it():
    """Function to plot it"""
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, ref_lig_entry, pltcsv_file_entry, top_strdir_entry 
    
    my_file_2_plot = str(pltcsv_file_entry.get())
    
    # Set up empty list
    list_out = []
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Add ENDOF to pltcsv file
    my_pltcsv_ready2go = open(project_dir_string+my_file_2_plot,"r")
        
    # Looping through my_pltcsv_ready2go
    for line in my_pltcsv_ready2go:
        if "PLTCSV" in line:
            list_out.append(line)
    my_pltcsv_ready2go.close()
    
    # Re-open pltcsv file to add ENDOF
    my_pltcsv_ready2go = open(project_dir_string+my_file_2_plot,"w")
    for line in list_out:
        my_pltcsv_ready2go.write(line)
    my_pltcsv_ready2go.write("ENDOF")    
    my_pltcsv_ready2go.close()
        
    #pltcsv_all_scatter("my_file_2_plot)
    run_sandres_in(my_file_2_plot)
    
    # Call insert_showinfo_in()
    insert_showinfo_in()

def insert_showinfo_in():
    """Function to insert showinfo.in"""
    
    import csv
    
    # Open strdir.in
    try:
        fo1 = open(sandres_root+"inputs/strdir.in","r")  # WFA 2018 01 09
        csv1 = csv.reader(fo1)
    except IOError:
        print("\nI can't find strdir.in file!")
    
    for line in csv1:
        if line[0] == "STRDIR":
            project_dir_string = str(line[1])
            break
    
    print("\nCurrent project directory: ",project_dir_string)
    
    fo1.close()
    
    # Open and write "showinfo.in" in the sandres.in file
    try:
        aux_name0 = project_dir_string+"sandres.in"
        aux_name1 = aux_name0.replace(" ","")
        fo2 = open(aux_name1,"w")
        fo2.write("showinfo.in")
        fo2.close()
    except IOError:
        print("\nI can't find "+project_dir_string+"sandres.in file!")
    
    # Open and write "showinfo.in" in the sandres.in file
    try:
        aux_name2 = sandres_root+"sandres.in"
        aux_name3 = aux_name2.replace(" ","")
        fo3 = open(aux_name3,"w")
        fo3.write("showinfo.in")
        fo3.close()
    except IOError:
        print("\nI can't find "+sandres_root+"sandres.in file!")
    
    return
    
def exit_plot_pltcsv_GUI():
    """Function to exit plot_pltcsv_GUI()"""
    
    # Defines global variables to allow access to variables from different functions
    #global top_txt, pltcsv_file_entry 
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open and write "showinfo.in" in the sandres.in file
    fo = open(project_dir_string+"sandres.in","w")
    fo.write("showinfo.in")
    fo.close()
    
    # Clear input entry
    clear_inputfile_entry()
    
    # Insert "showinfo.in"
    inputfile_entry.insert(10,"showinfo.in")
    
    # Destroy GUI
    top_txt.destroy()
    
def plot_pltcsv0A_GUI():
    """Function to call GUI to plot pltcsv0A.in"""
    
    # Get new structure directory       
    string_strdir = str(strdir_entry.get())
    
    # Call some_editing_of_pltcsv()
    some_editing_of_pltcsv(string_strdir,"pltcsv0A.in")
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, pltcsv_file_entry, top_strdir_entry 
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x150+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt,text="Plot pltcsv File",font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for pltcsv file
    Label(top_txt, text="File to Plot:" ).grid(row = 3,column = 0, stick = W)   
    pltcsv_file_entry = Entry(top_txt,width = 93)
    pltcsv_file_entry.grid(row = 3, column = 0,stick = E)
    pltcsv_file_entry.insert(10,"pltcsv_00.in")
    
    # Widgets for buttons 
    Button(top_txt, text=' Next ', command=next_pltcsv_file_entry).grid(row = 3, column = 1, sticky = W)
    Button(top_txt, text=' Clear ', command=clear_pltcsv_file_entry).grid(row = 3, column = 1, sticky = E)
    
    # Last buttons
    Button(top_txt, text='Plot pltcsv File', command=go_and_plot_it).grid(row = 7, column = 1, sticky = W)  
    Button(top_txt, text='Edit pltcsv File', command=edit_input_file_pltcsv).grid(row = 7, column = 2,sticky = E) 
    Button(top_txt, text='Close', bg = "red", command=exit_plot_pltcsv_GUI).grid(row = 7, column = 3, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=210*" " ).grid(row = 5,column = 0, stick = W) 

def plot_pltcsv0_GUI():
    """Function to call GUI to plot pltcsv0.in"""
    
    # Get new structure directory       
    string_strdir = str(strdir_entry.get())
    
    # Call some_editing_of_pltcsv()
    some_editing_of_pltcsv(string_strdir,"pltcsv0.in")
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, pltcsv_file_entry, top_strdir_entry 
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x150+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt,text="Plot pltcsv File",font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for pltcsv file
    Label(top_txt, text="File to Plot:" ).grid(row = 3,column = 0, stick = W)   
    pltcsv_file_entry = Entry(top_txt,width = 93)
    pltcsv_file_entry.grid(row = 3, column = 0,stick = E)
    pltcsv_file_entry.insert(10,"pltcsv_00.in")
    
    # Widgets for buttons 
    Button(top_txt, text=' Next ', command=next_pltcsv_file_entry).grid(row = 3, column = 1, sticky = W)
    Button(top_txt, text=' Clear ', command=clear_pltcsv_file_entry).grid(row = 3, column = 1, sticky = E)
    
    # Last buttons
    Button(top_txt, text='Plot pltcsv File', command=go_and_plot_it).grid(row = 7, column = 1, sticky = W) 
    Button(top_txt, text='Edit pltcsv File', command=edit_input_file_pltcsv).grid(row = 7, column = 2,sticky = E) 
    Button(top_txt, text='Close', bg = "red", command=exit_plot_pltcsv_GUI).grid(row = 7, column = 3, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=210*" " ).grid(row = 5,column = 0, stick = W) 

def plot_pltcsv_GUI():
    """Function to call GUI to plot one file"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, pltcsv_file_entry, top_strdir_entry 
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x150+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt,text="Plot pltcsv File",font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for pltcsv file
    Label(top_txt, text="File to Plot:" ).grid(row = 3,column = 0, stick = W)   
    pltcsv_file_entry = Entry(top_txt,width = 93)
    pltcsv_file_entry.grid(row = 3, column = 0,stick = E)
    pltcsv_file_entry.insert(10,"pltcsv_00.in")
    
    # Widgets for buttons 
    Button(top_txt, text=' Next ', command=next_pltcsv_file_entry).grid(row = 3, column = 1, sticky = W)
    Button(top_txt, text=' Clear ', command=clear_pltcsv_file_entry).grid(row = 3, column = 1, sticky = E)
    
    # Last buttons
    Button(top_txt, text='Plot pltcsv File', command=go_and_plot_it  ).grid(row = 7, column = 1, sticky = W) 
    Button(top_txt, text='Edit pltcsv File', command=edit_input_file_pltcsv).grid(row = 7, column = 2,sticky = E)  
    Button(top_txt, text='Close', bg = "red", command=exit_plot_pltcsv_GUI).grid(row = 7, column = 3, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=210*" " ).grid(row = 5,column = 0, stick = W) 

def plot_pltcsv():
    """Function to read files2plot.in and plot them"""
    
    # Get new structure directory       
    string_strdir = str(strdir_entry.get())
    
    # Try to open files2plot.in
    try:
        fo = open(string_strdir+"files2plot.in","r")
    except IOError:
        print("\nI can't find files2plot.in file!")
    
    # Looping through fo
    count_files = 0
    for line in fo:
        count_files += 1
    
    # Call pltcsv_all_scatter()
    pltcsv_all_scatter("pltcsv_00.in")
    
def generate_pltcsv_in(file_number,plt_string):
    """Function to generate pltcsv.in"""
    
    # Get new structure directory       
    string_strdir = str(strdir_entry.get())
    
    # Open new pltcsv.in
    fo = open(string_strdir+"pltcsv_0"+str(file_number)+".in","w")
    
    # Write string in to pltcsv.in file
    line0 = str(plt_string).replace("[","")
    line1 = line0.replace("]","")
    line2 = line1.replace("'","")
    #line3 = line2.replace("\\\\","\\") # WFA 2018 01 09
    line3 = line2.replace("\\\\","/")
    print(line3)
    fo.write(line3+"\n")
    
    # Looping through plt_list
    #for line in plt_list:
    #    line0 = str(line).replace("[","")
    #    line1 = line0.replace("]","")
    #    line2 = line1.replace("'","")
    #    print(line2)
    #    fo.write(line2+"\n")
    
    # Close file
    fo.close()
    
def some_editing_of_pltcsv(dir_in,file_in):
    """Function to carry out some editing of pltcsv files"""
    
    # Import library
    import csv
    
    # Set up empty list
    my_pltcsv_list = []
    
    # Try to open file_in file
    try:
        plt_fo = open(dir_in+file_in)
        plt_csv = csv.reader(plt_fo)
    except IOError:
        print("\nI can't find "+file_in+" file!")
        
    # Looping through plt_csv
    for line in plt_csv:
        aux_line = ""
        i = 0
        for line0 in line:
            if i > 9:
                line1 = line0.replace(" ","")
                i += 1
            else:
                line1 = line0
            aux_line += line1+","

        print(aux_line[:len(aux_line) - 1 ])
        my_pltcsv_list.append(aux_line[:len(aux_line) - 1 ]+"\n")
        
    # Close plt_fo
    plt_fo.close()
    
    # Looping through my_pltcsv_list
    i = 0
    for line in my_pltcsv_list:
        generate_pltcsv_in(i,line)
        i += 1

    # Looping through my_pltcsv_list
    i = 0
    plt_fo1 = open(dir_in+"files2plot.in","w")
    for line in my_pltcsv_list:
        plt_fo1.write("pltcsv_0"+str(i)+".in\n")
        i += 1
    
    # Close plt_fo1
    plt_fo1.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating the pltcsv files!","black","light grey")
    
def scatter_pltcsv_GUI(scatter_pltcsv_in,x_label_in,my_x_min_in,my_x_max_in):
    """Function to call a GUI window to generate pltcsv input file"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry, global_p_value, top_marker_size_entry
    
    # Get new structure directory
    string_strdir = str(strdir_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Generate '+scatter_pltcsv_in+" File to Build Scatter Plot Using Matplotlib") 

    top_txt.geometry("870x500+20+135")
    
    Label(top_txt, text="Parameters for Scatter Plot", font = "Arial" ).grid(row = 0,column = 0)
    
    # Widgets for point colors
    Label(top_txt, text="Point colors:" ).grid(row = 2,column = 0, stick = W)
    point_color_var  = IntVar()
    # Set list for colors available at matplotlib
    point_color_list = ["blue","cyan","green","black","magenta","red","white","yellow"]
    point_color_values = ["b","c","g","k","m","r","w","y"]
    
    def my_sel1():
        """Function to show selection of color"""
        selection = "Color option: " + str( point_color_list[int(point_color_var.get())])+"         "
        Label(top_txt, text=selection ).grid(row = 19,column = 0, stick = W)
    
    # Looping through point colors
    for i in range(8):
        rad = Radiobutton(top_txt, text = point_color_list[i], value = i, variable=point_color_var,\
                           command = my_sel1)
        rad.grid(row = 3,column = i+2, stick = W)
    
    # Widgets for markers
    Label(top_txt, text="Markers to plot:" ).grid(row = 4,column = 0, stick = W)
    marker_var  = IntVar()
    
    # Set list for markers available at matplotlib
    marker_list = ["Square       ","Circle       ","Triangle up  ",
                   "Diamond      ","Hexagon      ","Plus         ",
                   "Cross        ","Point        "]
    marker_value = ["s","o","^","d","h","+","x","."]
    
    def my_sel2():
        """Function to show selection of markers"""
        selection = "Marker: "+str(  marker_list[int(marker_var.get())] )+"       "
        Label(top_txt, text=selection ).grid(row = 19,column = 0, stick = W)
    
    # Looping through markers
    for i in range(len(marker_list)):
        rad = Radiobutton(top_txt, text = marker_list[i], value = i, variable=marker_var, command = my_sel2)
        rad.grid(row = 5,column = i+2, stick = W)
    
    # Widgets for output format
    Label(top_txt, text="Output format:" ).grid(row = 6,column = 0, stick = W)
    output_var  = IntVar()
    
    # Set list for output formats available at matplotlib
    output_list = ["PDF","EPS","PNG","PS","RAW","RGBA","SVG","SVGZ"]
    
    def my_sel3():
        """Function to show selection of output formats"""
        selection = "Format: "+str(  output_list[int(output_var.get())] )+"                    "
        Label(top_txt, text=selection ).grid(row = 19,column = 0, stick = W)
    
    # Looping through output formats
    for i in range(len(output_list)):
        rad = Radiobutton(top_txt, text = output_list[i], value = i, variable=output_var, command = my_sel3)
        rad.grid(row = 7,column = i+2, stick = W)
    
    # Widgets for grid choice
    Label(top_txt, text="Grid? " ).grid(row = 8,column = 0, stick = W)
    grid_var  = IntVar()
    
    # Set list for output formats available at matplotlib
    grid_list = ["Yes","No"]
    
    def my_sel4():
        """Function to show selection of grid choice"""
        selection = "Grid? "+str(  grid_list[int(grid_var.get())] )+"                    "
        Label(top_txt, text=selection ).grid(row = 19,column = 0, stick = W)
    
    # Looping through output formats
    for i in range(2):
        rad = Radiobutton(top_txt, text = grid_list[i], value = i, variable=grid_var, command = my_sel4)
        rad.grid(row = 9,column = i+2, stick = W)
        
    # Widget for x-axis limits   
    Label(top_txt, text="Minimum for x-axis:" ).grid(row = 10,column = 0, stick = W, pady = 4)   
    top_x_min_entry = Entry(top_txt,width = 10)
    top_x_min_entry.grid(row = 10, column = 0,stick = E, pady = 4)
    top_x_min_entry.insert(10,str(my_x_min_in))
    
    # Widget for x-axis limits   
    Label(top_txt, text="Maximum for x-axis:" ).grid(row = 11,column = 0, stick = W, pady = 4)   
    top_x_max_entry = Entry(top_txt,width = 10)
    top_x_max_entry.grid(row = 11, column = 0,stick = E, pady = 4)
    top_x_max_entry.insert(10,str(my_x_max_in))
    
    # Widget for x coordinate for text   
    Label(top_txt, text="X coordinate for text:" ).grid(row = 12,column = 0, stick = W, pady = 4)   
    top_x_coord_entry = Entry(top_txt,width = 10)
    top_x_coord_entry.grid(row = 12, column = 0,stick = E, pady = 4)
    top_x_coord_entry.insert(10,"0.15")
    
    # Widget for y coordinate for text   
    Label(top_txt, text="Y coordinate for text:" ).grid(row = 13,column = 0, stick = W, pady = 4)   
    top_y_coord_entry = Entry(top_txt,width = 10)
    top_y_coord_entry.grid(row = 13, column = 0,stick = E, pady = 4)
    top_y_coord_entry.insert(10,"0.83")
    
    # Widget for x-axis label   
    Label(top_txt, text="X-axis label:" ).grid(row = 14,column = 0, stick = W, pady = 4)   
    top_x_label_entry = Entry(top_txt,width = 20)
    top_x_label_entry.grid(row = 14, column = 0,stick = E, pady = 4)
    top_x_label_entry.insert(10,str(x_label_in))
    
    # Widget for p-value cutoff
    Label(top_txt, text="p-value cutoff:" ).grid(row = 15,column = 0, stick = W, pady = 4)   
    top_p_value_entry = Entry(top_txt,width = 10)
    top_p_value_entry.grid(row = 15, column = 0,stick = E, pady = 4)
    top_p_value_entry.insert(10,"0.50")
    
    # Widget for DPI
    Label(top_txt, text="DPI:" ).grid(row = 16,column = 0, stick = W, pady = 4)   
    top_dpi_entry = Entry(top_txt,width = 20)
    top_dpi_entry.grid(row = 16, column = 0,stick = E, pady = 4)
    top_dpi_entry.insert(10,"300")
    
    # Widget for input file
    Label(top_txt, text="Marker size (pixels):" ).grid(row = 17,column = 0, stick = W, pady = 4)   
    top_marker_size_entry = Entry(top_txt,width = 12)
    top_marker_size_entry.grid(row = 17, column = 0,stick = E, pady = 4)
    top_marker_size_entry.insert(10,"50")
    
    # Widget for input file
    Label(top_txt, text="Input:" ).grid(row = 18,column = 0, stick = W, pady = 4)   
    top_input_entry = Entry(top_txt,width = 20)
    top_input_entry.grid(row = 18, column = 0,stick = E, pady = 4)
    top_input_entry.insert(10,scatter_pltcsv_in)
     
    def plot_with_values_here():
        """Function to update values and call pltcsv function"""
        
        import csv
        
        warning_message = "SAnDReS generates plots for data with more than 5 PDB files and "+\
        "p-value < cutoff value!\n"
        
        from tkinter import messagebox
        messagebox.showwarning("SAnDReS Warning!", warning_message)
    
        my_color = str( point_color_values[int(point_color_var.get())])
        my_marker = str(  marker_value[int(marker_var.get())] )
        my_format = str(  output_list[int(output_var.get())] )
        my_chosen_x_min =  float(top_x_min_entry.get() )
        my_chosen_x_max =  float(top_x_max_entry.get() )
        my_chosen_x_coord = float(top_x_coord_entry.get())
        my_chosen_y_coord = float(top_y_coord_entry.get())
        my_chosen_x_label = str(top_x_label_entry.get())
        my_chosen_p_value = float(top_p_value_entry.get())
        my_chosen_grid = str(  grid_list[int(grid_var.get())] )
        my_chosen_dpi = int(top_dpi_entry.get())
        my_marker_size = float(top_marker_size_entry.get())
        if my_chosen_grid == "Yes" :
            grid_flag = True
        else:
            grid_flag = False
            
        print(my_color,my_marker,my_format,my_chosen_x_min,my_chosen_x_max,
              my_chosen_x_coord,my_chosen_y_coord,my_chosen_x_label,
              my_chosen_p_value,my_marker_size)
        
        # Call gen_all_pltcsv() and pltcsv_all_scatter()
        if scatter_pltcsv_in == "pltcsv4A.in":

            # Call gen_all_pltcsv()
            gen_all_pltcsv("stscor.csv","pltcsv4A.in","TEXT",grid_flag,my_chosen_dpi,\
                           my_color,my_marker,my_format,my_chosen_x_min,my_chosen_x_max,\
                           my_chosen_x_coord,my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv4A.in")
            
        elif scatter_pltcsv_in == "pltcsv4.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("stscor.csv","pltcsv4.in","NOTEXT",grid_flag,my_chosen_dpi,\
                           my_color,my_marker,my_format,my_chosen_x_min,my_chosen_x_max,\
                           my_chosen_x_coord,my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv4.in")
            
        elif scatter_pltcsv_in == "pltcsv3A.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("stensembledock.csv","pltcsv3A.in","TEXT",grid_flag,my_chosen_dpi,\
                           my_color,my_marker,my_format,my_chosen_x_min,my_chosen_x_max,\
                           my_chosen_x_coord,my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv3A.in")
            
        elif scatter_pltcsv_in == "pltcsv3.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("stensembledock.csv","pltcsv3.in","NOTEXT",grid_flag,my_chosen_dpi,\
                           my_color,my_marker,my_format,my_chosen_x_min,my_chosen_x_max,\
                           my_chosen_x_coord,my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv3.in")
            
        elif scatter_pltcsv_in == "pltcsv2A.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("stdock.csv","pltcsv2A.in","TEXT",grid_flag,my_chosen_dpi,my_color,\
                           my_marker,my_format,my_chosen_x_min,my_chosen_x_max,my_chosen_x_coord,\
                           my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv2A.in")
            
        elif scatter_pltcsv_in == "pltcsv2.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("stdock.csv","pltcsv2.in","NOTEXT",grid_flag,my_chosen_dpi,my_color,\
                           my_marker,my_format,my_chosen_x_min,my_chosen_x_max,my_chosen_x_coord,\
                           my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv2.in")
            
        elif scatter_pltcsv_in == "pltcsv1A.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("strmsd.csv","pltcsv1A.in","TEXT",grid_flag,my_chosen_dpi,my_color,\
                           my_marker,my_format,my_chosen_x_min,my_chosen_x_max,my_chosen_x_coord,\
                           my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)
            
            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv1A.in")
            
        elif scatter_pltcsv_in == "pltcsv1.in":
            
            # Call gen_all_pltcsv()
            gen_all_pltcsv("strmsd.csv","pltcsv1.in","NOTEXT",grid_flag,my_chosen_dpi,my_color,\
                           my_marker,my_format,my_chosen_x_min,my_chosen_x_max,my_chosen_x_coord,\
                           my_chosen_y_coord,my_chosen_x_label,\
                           my_chosen_p_value,my_marker_size)

            # Call some_editing_of_pltcsv()
            some_editing_of_pltcsv(string_strdir,"pltcsv1.in")
             
            
    # Widgets for Update button
    Button(top_txt, text='Generate Files', command=plot_with_values_here).grid(row = 18,column = 2,sticky = W) 
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 19, column = 2,\
                                                                                sticky = E) 
    
def histogram_pltcsv0():
    """Function to call gen_pltcsv0() """
    
    # Call gen_pltcsv0()
    gen_pltcsv0()
    
    # Call run_sandres_in()
    #run_sandres_in("pltcsv0.in") 
    
def gen_pltcsv0():
    """Function to generate input files pltcsv0.in and pltcsv0A.in"""      
    
    # Import libraries
    import numpy as np
    import csv 
    
    # Set up a list for label information to be written into pltcsv0A.in "($\AA$)"
    my_labels_pltcsv0A = ["Resolution ($\AA$),Crystallographic Resolution",
                          "Crystallographic Low-resolution Information ($\AA$),Crystallographic Low-resolution Information",
                          "Crystallographic R-factor,Crystallographic R-factor",
                          "Crystallographic R-free,Crystallographic R-free",
                          "Completeness (%),Completeness",
                          "RMSD from Ideal Values (Bond Length)($\AA$),RMSD from Ideal Values (Bond Length)",
                          "RMSD from Ideal Values (Bond Angle)($^\circ$),RMSD from Ideal Values (Bond Angle)",
                          "RMSD from Ideal (Torsion Angle Period 1)($^\circ$),RMSD from Ideal (Torsion Angle Period 1)",
                          "RMSD from Ideal (Torsion Angle Period 2)($^\circ$),RMSD from Ideal (Torsion Angle Period 2)",
                          "RMSD from Ideal (Torsion Angle Period 3)($^\circ$),RMSD from Ideal (Torsion Angle Period 3)",
                          "RMSD from Ideal (Torsion Angle Period 4)($^\circ$),RMSD from Ideal (Torsion Angle Period 4)",
                          "Number of Missing Residues,Number of Missing Residues",
                          "Mean B-value (Active Ligand) ($\AA^2$),Mean B-value (Active Ligand)",
                          "Mean Occupancy (Active ligand),Mean Occupancy (Active Ligand)",
                          "Mean B-value (Whole Structure) ($\AA^2$),Mean B-value (Whole Structure)",
                          "Mean Occupancy (Whole Structure),Mean Occupancy (Whole Structure)",
                          "Mean B-value (Water Molecules)($\AA^2$),Mean B-value (Water Molecules)",
                          "Mean Occupancy (Water Molecules),Mean Occupancy (Water Molecules)",
                          "Mean B-value (Main-chain Protein Atoms)($\AA^2$),Mean B-value (Main-chain Protein Atoms)",
                          "Mean Occupancy (Main-chain Protein Atoms),Mean Occupancy (Main-chain Protein Atoms)",
                          "Mean B-value (Side-chain Protein Atoms)($\AA^2$),Mean B-value (Side-chain Protein Atoms)",
                          "Mean Occupancy (Side-chain Protein Atoms),Mean Occupancy (Side-chain Protein Atoms)"
                          ]

    my_labels_pltcsv0 = [ "Resolution ($\AA$),Occurrence,Crystallographic Resolution",
                          "Crystallographic Low-resolution Information ($\AA$),Occurrence,Crystallographic Low-resolution Information",
                          "Crystallographic R-factor,Occurrence,Crystallographic R-factor",
                          "Crystallographic R-free,Occurrence,Crystallographic R-free",
                          "Completeness (%),Occurrence,Completeness",
                          "RMSD from Ideal Values (Bond Length)($\AA$),Occurrence,RMSD from Ideal Values (Bond Length)",
                          "RMSD from Ideal Values (Bond Angle)($^\circ$),Occurrence,RMSD from Ideal Values (Bond Angle)",
                          "RMSD from Ideal (Torsion Angle Period 1)($^\circ$),Occurrence,RMSD from Ideal (Torsion Angle Period 1)",
                          "RMSD from Ideal (Torsion Angle Period 2)($^\circ$),Occurrence,RMSD from Ideal (Torsion Angle Period 2)",
                          "RMSD from Ideal (Torsion Angle Period 3)($^\circ$),Occurrence,RMSD from Ideal (Torsion Angle Period 3)",
                          "RMSD from Ideal (Torsion Angle Period 4)($^\circ$),Occurrence,RMSD from Ideal (Torsion Angle Period 4)",
                          "Number of Missing Residues,Occurrence,Number of Missing Residues",
                          "Mean B-value (Active Ligand) ($\AA^2$),Occurrence,Mean B-value (Active Ligand)",
                          "Mean Occupancy (Active Ligand),Occurrence,Mean Occupancy (Active Ligand)",
                          "Mean B-value (Whole Structure) ($\AA^2$),Occurrence,Mean B-value (Whole Structure)",
                          "Mean Occupancy (Whole Structure),Occurrence,Mean Occupancy (Whole Structure)",
                          "Mean B-value (Water Molecules)($\AA^2$),Occurrence,Mean B-value (Water Molecules)",
                          "Mean Occupancy (Water Molecules),Occurrence,Mean Occupancy (Water Molecules)",
                          "Mean B-value (Main-chain Protein Atoms)($\AA^2$),Occurrence,Mean B-value (Main-chain Protein Atoms)",
                          "Mean Occupancy (Main-chain Protein Atoms),Occurrence,Mean Occupancy (Main-chain Protein Atoms)",
                          "Mean B-value (Side-chain Protein Atoms)($\AA^2$),Occurrence,Mean B-value (Side-chain Protein Atoms)",
                          "Mean Occupancy (Side-chain Protein Atoms),Occurrence,Mean Occupancy (Side-chain Protein Atoms)"
                          ]
    
    # Set initial values for arrays
    my_array1 = np.array([0]*100000,float)     # np.array([0]*number_of_lines)
    my_array2 = np.array([0]*100000,float)     # np.array([0]*number_of_lines)
    
    # Get new structure directory
    string_strdir = str(strdir_entry.get())
    
    # Open pltcsv0.in and pltcsv0A.in
    my_pltcsv0A = open(string_strdir+"pltcsv0A.in","w")
    my_pltcsv0 = open(string_strdir+"pltcsv0.in","w")
    
    # Looping through number of files = 15 to create pltcsv0.in and pltcsv0A.in
    for line1 in range(22):
        # Looping through to read axis limits from each ststruXXX.csv file
        count_lines = 0
        # Fixes the number of characters with zeros
        my_str_id = str(line1)
        my_str_3_char = str(line1)
        if len(my_str_3_char)< 4:
            my_str_id = str((3-len(my_str_3_char) )*"0")+my_str_3_char
        print("\nReading CSV file ",string_strdir+"ststru"+my_str_id+".csv")  
        
        # Try to open ststru###.csv files
        try:
            my_csv_file_in1 = open(string_strdir+"ststru"+my_str_id+".csv","r")
            my_csv_info1 = csv.reader(my_csv_file_in1)
            # Open CSV files ststru1AXXX.csv
            my_csv_file_out = open(string_strdir+"ststru1A"+my_str_id+".csv","w")
        
            # Looping through to read csv files
            for line2 in my_csv_info1:
                # Reads information for arrays
                my_array1[count_lines] = count_lines
                my_array2[count_lines] = line2[1]
            
                # Write lines to ststr1uAXXX.files
                my_csv_file_out.write(line2[0]+","+line2[1]+"\n")
                count_lines += 1         
        
            # Close ststru1AXXX.csv file
            my_csv_file_out.close()
        
            # Close ststruXXX.csv file
            my_csv_file_in1.close()
        
            # Set values for x_min_lim and x_max_lim
            x_min_lim = 0
            x_max_lim = count_lines
        
            # Uses max and min to get maximum and minimum values in the my_array2
            y_min_lim = np.min(my_array2[0:count_lines-1])
            y_max_lim = np.max(my_array2[0:count_lines-1])
                
            print("Limit information: ",x_min_lim,x_max_lim,y_min_lim,y_max_lim)
        
            # Write information into pltcsv0A.in 
            sandres_line1A = "PLTCSV,ststru1A"+my_str_id+".csv,PLOTPDB,0.0,"+str(x_max_lim)+","+str(y_min_lim)+","+str(y_max_lim)+",Structure Number,"+my_labels_pltcsv0A[line1]+",.,gray,PNG,1,NOTEXT,900 \n"
            print(sandres_line1A)
            my_pltcsv0A.write(sandres_line1A)
        
            # Check the number of lines in the CSV file
            if count_lines > 50:
                max_divisions = 10
            else:
                max_divisions = 5
        
            # Write information into pltcsv0.in    
            sandres_line1 =  "PLTCSV,ststru"+my_str_id+".csv,HISTOGR,2,"+str(y_min_lim)+","+str(y_max_lim)+","+my_labels_pltcsv0[line1]+","+str(max_divisions)+",gray,PNG,NOTEXT,900 \n"
            print(sandres_line1)
            my_pltcsv0.write(sandres_line1)
        
        except IOError:
            print("I didin't find the file "+string_strdir+"ststru"+my_str_id+".csv")
        
    # Write last lines into pltcsv0A.in and closes file
    #my_pltcsv0.write("ENDOF")
    #my_pltcsv0A.write("ENDOF")
    my_pltcsv0.close()
    my_pltcsv0A.close()
    
    # Call some_editing_of_pltcsv()
    #some_editing_of_pltcsv(string_strdir,"pltcsv0.in")
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating pltcsv0.in and pltcsv0A.in for plotting!","black","light grey")
    
def gen_all_pltcsv(my_csv_in,my_pltcsv_in,var_4_text_in,m_grid_flag_in,m_dpi_in,m_color,m_marker,\
                   m_format,m_chosen_x_min,m_chosen_x_max,m_chosen_x_coord,m_chosen_y_coord,\
                   m_chosen_x_label,m_chosen_p_value,m_marker_size):
    """Function to generate all scatter pltcsv.in files"""
    
    # Import libraries
    from tkinter import messagebox
    import numpy as np 
    import csv 

    # Set up initial values for arrays
    my_array1 = np.array([0]*100000,float)     # np.array([0]*number_of_lines)
    my_array2 = np.array([0]*100000,float)     # np.array([0]*number_of_lines)
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
        
    # Try to open stdock.in
    try:
        my_stdock_fo = open(project_dir_string+my_csv_in,"r")
        my_stdock_csv = csv.reader(my_stdock_fo)
    except IOError:
        print("SAnDReS IO Error! I can't find ",project_dir_string+my_csv_in) 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IO Error!", "I can't find file "+project_dir_string+my_csv_in+\
                             " \nPlease check directory name!")
        return
    
    # Open pltcsv_all.in and pltcsv_all_A.in files
    my_pltcsv_all = open(project_dir_string+my_pltcsv_in,"w")
    
    # Looping through stdock.csv
    print("\nSaNDReS generates plots for datasets with more than 5 PDB files and "+\
          "p-value < cutoff value!\n")
    
    for line1 in my_stdock_csv:
        #my_aux_line1_1 = 100
        if my_pltcsv_in == "pltcsv1.in" or my_pltcsv_in == "pltcsv1A.in":
            my_aux_line1_1 = 100
            my_aux_line1_4 = line1[1]
        else:
            my_aux_line1_1 = int(line1[1]) 
            my_aux_line1_4 = line1[6]   # line1[6] for csv file column
        if ("ND" in line1[2]) or (int(my_aux_line1_1) <= 5 or \
                                  (float(line1[3])) >= float(m_chosen_p_value) ):
            print("p-value ",str(line1[3]))
            continue
        else:
            print(line1[0],my_aux_line1_4)
            my_stdock_file_in0 = str(my_aux_line1_4.replace("\t",""))
            my_stdock_file_in = my_stdock_file_in0.replace(" ","")
            
            # Reads information from stdock###.csv
            # Try to open stdockd###.csv file
            try:
                my_csv_fo = open(project_dir_string+my_stdock_file_in,"r")
                my_csv_info = csv.reader(my_csv_fo)      
            except IOError:
                print("I con't find file ",project_dir_string+my_stdock_file_in )
                messagebox.showerror("SAnDReS IO Error!", "I can't find file "+\
                                     project_dir_string+my_stdock_file_in+" \nPlease check project directory!")
                return
    
            # Set count_lines to zero
            count_lines = 0
        
            # Looping through csv file (stdockd###.csv). All csv files have two columns
            for line2 in my_csv_info:                
                my_array1[count_lines] = line2[0]
                my_array2[count_lines] = line2[1]
                count_lines += 1 
                
            print("It was read ",count_lines," points in the file ",my_stdock_file_in,"\n")
            
            # Checks arrays
            my_check_flag = False
            my_check_flag = check2arrays(my_array1[:count_lines],my_array2[:count_lines])  
            
            # Show limits if arrays are fine
            if my_check_flag:
                # Call find_limits
                my_par_in = str(line1[0]).replace("\t","")  
                my_par_in1 = my_par_in.replace(" ","")
                                
                y_min,y_max = find_limits(my_array2[:count_lines])
                if y_min == y_max:
                    y_max = 1.5*y_min
                    if y_max == 0:
                        y_max = np.max(my_array2[:count_lines])
                        if y_max == 0:
                            y_max = y_max + 1
                        
                if var_4_text_in == "TEXT":
                    my_pltcsv_all.write("PLTCSV,"+my_stdock_file_in+",SCATTER,"+str(m_chosen_x_min)+","+\
                                        str(m_chosen_x_max)+","+str(y_min)+","+str(y_max)+","+\
                                        m_chosen_x_label+","+my_par_in1+","+my_par_in1+\
                                        " vs "+m_chosen_x_label+","+\
                                        m_marker+","+m_color+","+m_format+",1,TEXT,"+str(m_chosen_x_coord)+\
                                        ","+str(m_chosen_y_coord)+","+str(m_grid_flag_in)+","+str(m_dpi_in)+\
                                        ","+str(m_marker_size)+"\n")
                else:
                    my_pltcsv_all.write("PLTCSV,"+my_stdock_file_in+",SCATTER,"+str(m_chosen_x_min)+","+\
                                        str(m_chosen_x_max)+","+str(y_min)+","+str(y_max)+","+\
                                        m_chosen_x_label+","+my_par_in1+","+my_par_in1+\
                                        " vs "+m_chosen_x_label+","+\
                                        m_marker+","+m_color+","+m_format+",1,NOTEXT"+","+\
                                        str(m_grid_flag_in)+","+str(m_dpi_in)+\
                                        ","+str(m_marker_size)+"\n")
                    
    # Close file
    my_pltcsv_all.close()

def pltcsv_all_scatter(my_pltcsv_in):
    """Function to generate scatter plot"""
    
    # Call run_sandres_in()
    run_sandres_in(my_pltcsv_in) 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running "+my_pltcsv_in+"!","black","light grey") 
    
    # Show log file content on window_txt
    read_log_file("pltcsv.log")
    
    # Call show_message_in_sandres()
    show_message_in_sandres("\nDone! SAnDReS generates plots for data with more than 5 PDB files and "+\
          "p-value < cutoff value!\n","black","light grey")
        
def show_strmsd():
    """Function to show strmsd.log"""
    
    # Show log file content on window_txt
    read_log_file("strmsd.log")
    
def strmsd():
    """Function to run strmsd.in"""
    
    # Call prepare_input_4_strmsd
    prepare_input_4_strmsd()
    
    # Call run_sandres_in()
    run_sandres_in("strmsd.in") 
        
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running strmsd.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("strmsd.log")

def vina_strmsd():
    """Function to run strmsd.in obtained from vina results"""
    
    # Import library
    import shutil
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb
    pdb_in0 = str(run_vina_pdb_entry.get())+"/" # WFA 2018 01 09
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Copy redock_vina.csv
    try:
        shutil.copy2(dir_in0+"redock_vina.csv",project_dir_string+\
                     "redock_vina.csv")
        input_csv_file_entry.delete(0,END)
        input_csv_file_entry.insert(10,"redock_vina.csv")
    except IOError:
        print("SAnDReS IOError!")
    
    # Call prepare_input_4_strmsd_vina()
    prepare_input_4_strmsd_vina()
        
    # Call run_sandres_in()
    run_sandres_in("strmsd.in") 
        
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running strmsd.in!","black","light grey")
    

    
    # Show log file content on window_txt
    read_log_file("strmsd.log")
    
    # Set up list_to_be_copied
    list_to_be_copied = ["strmsd.in","strmsd.csv","strmsd.log","strmsd000.csv","strmsd001.csv","strmsd002.csv",
    "strmsd003.csv","strmsd004.csv","strmsd005.csv"]
    
    # Try to copy files in list_to_be_copied
    for line in list_to_be_copied:
        try:
            shutil.copy2(project_dir_string+line,dir_in0+line)
        except IOError:
            print()
        
        
def show_stdock():
    """Function to show stdock.log"""
    
    # Show log file content on window_txt
    read_log_file("stdock.log")
    
def stdock1():
    """Function to run stdock1.in"""
        
    # Call run_sandres_in()
    run_sandres_in("stdock1.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running stdock1.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("stdock.log")

def stdock2():
    """Function to run stdock2.in"""
        
    # Call run_sandres_in()
    run_sandres_in("stdock2.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running stdock2.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("stdock.log")

def check2arrays(my_array1_in,my_array2_in):
    """Function to check if "nan" is in an array"""
    
    # Get the length of the my_array1_in
    count_lines = len(my_array1_in)
    
    # Looping through arrays
    my_check_flag = True
    for i in range(count_lines):
        if ( "nan" in str(my_array1_in[i]) ) or ( "nan" in str(my_array2_in[i]) )   :
            my_check_flag = False
            break
        else:
            my_check_flag = True
    
    return my_check_flag 
                
def find_limits(array_in):
    """Finds limits for an array"""
    
    # Import library
    import numpy as np
    
    # Finds limits for the arrays 
    my_array_min = np.amin(array_in)
    my_array_max = np.amax(array_in)
                
    my_array_min = np.around(my_array_min - 0.25*np.abs(my_array_max - my_array_min ) ) 
    my_array_max = np.around(my_array_max + 0.25*np.abs(my_array_max - my_array_min ) ) 
    
    if my_array_min == my_array_max:
        my_array_min = np.amin(array_in)
        my_array_max = np.amax(array_in)
    
    return my_array_min, my_array_max

def show_stensembledock():
    """Function to show stensembledocki.log"""
    
    # Call read_log_file()
    read_log_file("stensembledock.log")
    
def stensembledock():
    """Function to run stensembledock.in"""
    
    # Call run_sandres_in()
    run_sandres_in("stensembledock.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running stensembledock.in!","black","light grey")

    # Show log file
    read_log_file("stensembledock.log")
    
def gen_polscore():
    """Function to generate polscore.in"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new ensemble-docking csv file
    string_ensemble_dock_csv = str(input_ensemble_csv_file_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Edit Input File stscor.in') 
    top_txt.geometry("1020x300+100+130") 
    
    # Widgets for project directory
    Label(top_txt, text="Project Directory:" ).grid(row = 0,column = 0, stick = W, pady = 4 )  
    top_strdir_entry = Entry(top_txt,width = 75) 
    top_strdir_entry.grid(row = 0,column = 0, stick = E, pady = 4)
    Button(top_txt, text='Clear', command=clear_top_strdir_entry).grid(row = 0, column = 1, sticky = E)
    Button(top_txt, text='Update', command=update_top_strdir).grid(row = 0, column = 2, stick = W)
    my_strdir_main_GUI = read_strdir()
    top_strdir_entry.insert(10,my_strdir_main_GUI)
    
    # Widgets for input file name
    Label(top_txt, text="Input File Name:" ).grid(row = 1,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 75)
    top_inputfile_entry.grid(row = 1, column = 0,stick = E)
    top_inputfile_entry.insert(10,"polscore.in")
    
    # Widgets for buttons
    Button(top_txt, text='  Read  ', command=read_input_file).grid(row = 1, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 1, column = 1, sticky = E)
        
    # Widgets for input file name chklig.in
    Label(top_txt, text="Input File for Ligand Information:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry_chklig = Entry(top_txt,width = 75)
    top_inputfile_entry_chklig.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry_chklig.insert(10,"chklig.in")
        
    # Widgets for input file name
    Label(top_txt, text="CSV File Name for Scoring Function:" ).grid(row = 3,column = 0, stick = W)   
    top_inputfile_entry_score = Entry(top_txt,width = 75)
    top_inputfile_entry_score.grid(row = 3, column = 0,stick = E)
    top_inputfile_entry_score.insert(10,string_ensemble_dock_csv)
    
    # Widgets for log factor
    Label(top_txt, text="Type of Binding Affinity:" ).grid(row = 4,column = 0, stick = W)   
    top_inputfile_log_factor = Entry(top_txt,width = 75)
    top_inputfile_log_factor.grid(row = 4, column = 0,stick = E)
    top_inputfile_log_factor.insert(10,"LOG(C)")
    
    # More buttons
    Button(top_txt, text='Generate New polscore.in', command=merge_stscor).grid(row = 6, column = 1, \
                                                                            sticky = W)  
    Button(top_txt, text='  Save  ', command=save_edit_screen_to_input_file).grid(row = 6, column = 1,\
                                                                                  sticky = E)
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 6, column = 2, \
                                                                               sticky = W)  
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=5, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 121, height = 9, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 5, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    
    # Try to open input file
    try:
        my_info_input_file = open(project_dir_string+"polscore.in","r")
    except IOError:
        print("I can't find ",project_dir_string+"polscore.in")
        strdir_entry.insert(10,project_dir_string)
        print("Please update project directory as your needs!")
        return 
            
    # Reads input file content
    top_txt.insert(END,my_info_input_file.read())
    
    # Close input file        
    my_info_input_file.close()  
    
def get_descriptor_strings(my_pol_score_string_in):
    """Function to get descriptos strings from a polynomial string"""
    
    # Looping through polscore to get descritors
    my_aux_line = ""
    my_descriptors_out = []
    for char1 in my_pol_score_string_in:
        my_aux_line += char1
        if char1 == ")":
            my_new_index1 = my_aux_line.index("(")
            my_new_index2 = my_aux_line.index(")")
            my_aux_0 = my_aux_line[my_new_index1+1:my_new_index2]
            my_descriptors_out.append(my_aux_0)
            my_aux_line = ""
   
    print("\nDescriptors: ",str(my_descriptors_out)+"\n\n")
    
    return my_descriptors_out
    
def get_polynomial_coefficients(c_0_in,num_var_pol_in,my_pol_score_string_in):
    """Function to get polynomial coefficients"""
    
    # Import library
    import numpy as np
    
    my_coeffs_out = np.zeros(num_var_pol_in+1)
    my_coeffs_out[0] = c_0_in
    my_aux_line = ""
    
    # Looping through polscore to get coefficients
    i = 1
    for char1 in my_pol_score_string_in:
        my_aux_line += char1
        if char1 == "*":
            if "+" in my_aux_line:
                my_new_index = my_aux_line.index("+")
                my_aux_0 = my_aux_line[my_new_index+2:len(my_aux_line)-1]
            else:
                my_aux_0 = my_aux_line[:len(my_aux_line)-1]
            my_aux_1 = my_aux_0.replace(" ","")
            if ")" in my_aux_1:
                my_par_index = my_aux_1.index(")")
                my_aux_2 = my_aux_1[my_par_index+1:]
            else:
                my_aux_2 = my_aux_1
            
            my_coeffs_out[i] = float(my_aux_2)
            i += 1
            my_aux_line = ""
   
    print("\nPolynomial coefficients: ",str(my_coeffs_out))
    
    return my_coeffs_out
    
def get_number_ind_var(my_pol_string_in):
    """Function to count the number of independent variables in a polynomial equation presented as a string"""
    
    # Looping through my_pol_string to count "*"
    num_var_pol_out = 0
    for char1 in my_pol_string_in:
        if char1 == "*":
            num_var_pol_out += 1
    
    print("\n\nNumber of variables in the polscore: "+str(num_var_pol_out)+"\n")
    
    return num_var_pol_out

def gen_new_test_set_csv(my_col_in,my_pol_in):
    """Function to add a column to test_set.csv"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    import shutil
    import time
    
    # Set empty list
    my_data = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file 
    my_score_csv_file_in = "test_set.csv"
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Try to open scores_all csv file
    try:
        my_score_fo = open(project_dir_string+my_score_csv_file_in,"r")
        my_score_csv_fo = csv.reader(my_score_fo)
    except IOError:
        print("SAnDReS IO Error! I can't find "+my_score_csv_file_in) 
        messagebox.showerror("SAnDReS IO Error!", "I can't find file "+my_score_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Looping through my_score_csv_fo to get previous data for first line
    first_line = ""
    for line in my_score_csv_fo:
        for line0 in line:
            first_line += line0+","
        break
    
    # Looping through the rest of my_score_csv_fo
    for line in my_score_csv_fo:
        my_aux0 = str(line[1:])
        my_aux1 = my_aux0.replace("[","")
        my_aux2 = my_aux1.replace("]","")
        my_aux3 = my_aux2.replace("'","")
        my_data.append(str(line[0])+","+my_aux3)
    
    # Close to re-open later
    my_score_fo.close()
    
    # Make backup of old my_score_csv_file_in 
    try:
        shutil.copy2(project_dir_string+"test_set.csv",project_dir_string+\
                     "test_set_"+my_local_time+".csv")
    except:
        print()
        
    # Re-open my_score_fo
    my_score_fo = open(project_dir_string+"test_set.csv","w")
    
    # Write first line
    my_score_fo.write(first_line+" Polscore #"+my_pol_in+"\n")
    
    # Write data
    i = 0
    for line in my_data:
        my_score_fo.write(str(my_data[i])+","+str(my_col_in[i])+"\n")
        i += 1
    
    # Clear scores_all.csv
    #clear_scores_all_csv_file_entry()
    
    # Insert polscore_all.csv
    #input_score_csv_file_entry.insert(10,"test_set.csv")
    
    # Close for good
    my_score_fo.close()

def gen_new_decoy_set_csv_file(my_col_in,my_pol_in):
    """Function to add a column to decoy file"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    import shutil
    import time
    
    # Defines global variables to allow access with different functions
    global top_pol_number_entry, top_decoy_entry
    
    # Set empty list
    my_data = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get decoy file
    decoy_in = str(top_decoy_entry.get())
    
    # Get scoring function csv file 
    my_score_csv_file_in = decoy_in
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Try to open scores_all csv file
    try:
        my_score_fo = open(project_dir_string+my_score_csv_file_in,"r")
        my_score_csv_fo = csv.reader(my_score_fo)
    except IOError:
        print("SAnDReS IO Error! I can't find "+my_score_csv_file_in) 
        messagebox.showerror("SAnDReS IO Error!", "I can't find file "+my_score_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Looping through my_score_csv_fo to get previous data for first line
    first_line = ""
    for line in my_score_csv_fo:
        for line0 in line:
            first_line += line0+","
        break
    
    # Looping through the rest of my_score_csv_fo
    for line in my_score_csv_fo:
        my_aux0 = str(line[1:])
        my_aux1 = my_aux0.replace("[","")
        my_aux2 = my_aux1.replace("]","")
        my_aux3 = my_aux2.replace("'","")
        my_data.append(str(line[0])+","+my_aux3)
    
    # Close to re-open later
    my_score_fo.close()
    
    # Make backup of old my_score_csv_file_in 
    try:
        shutil.copy2(project_dir_string+decoy_in,project_dir_string+\
                     decoy_in[:len(decoy_in)-4]+"_"+my_local_time+".csv")
    except:
        print()
        
    # Re-open my_score_fo
    my_score_fo = open(project_dir_string+decoy_in,"w")
    
    # Write first line
    my_score_fo.write(first_line+" Polscore #"+my_pol_in+"\n")
    
    # Write data
    i = 0
    for line in my_data:
        my_score_fo.write(str(my_data[i])+","+str(my_col_in[i])+"\n")
        i += 1
    
    # Clear scores_all.csv
    clear_scores_all_csv_file_entry()
    
    # Insert training_set.csv
    #input_score_csv_file_entry.insert(10,"training_set.csv")
    
    # Close for good
    my_score_fo.close()  
    
def gen_new_training_set_csv_file(my_col_in,my_pol_in):
    """Function to add a column to training_set.csv"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    import shutil
    import time
    
    # Set empty list
    my_data = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file 
    my_score_csv_file_in = "training_set.csv"
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Try to open scores_all csv file
    try:
        my_score_fo = open(project_dir_string+my_score_csv_file_in,"r")
        my_score_csv_fo = csv.reader(my_score_fo)
    except IOError:
        print("SAnDReS IOError! I can't find "+my_score_csv_file_in) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_score_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Looping through my_score_csv_fo to get previous data for first line
    first_line = ""
    for line in my_score_csv_fo:
        for line0 in line:
            first_line += line0+","
        break
    
    # Looping through the rest of my_score_csv_fo
    for line in my_score_csv_fo:
        my_aux0 = str(line[1:])
        my_aux1 = my_aux0.replace("[","")
        my_aux2 = my_aux1.replace("]","")
        my_aux3 = my_aux2.replace("'","")
        my_data.append(str(line[0])+","+my_aux3)
    
    # Close to re-open later
    my_score_fo.close()
    
    # Make backup of old my_score_csv_file_in 
    try:
        shutil.copy2(project_dir_string+"training_set.csv",project_dir_string+\
                     "training_set_"+my_local_time+".csv")
    except:
        print()
        
    # Re-open my_score_fo
    my_score_fo = open(project_dir_string+"training_set.csv","w")
    
    # Write first line
    my_score_fo.write(first_line+" Polscore #"+my_pol_in+"\n")
    
    # Write data
    i = 0
    for line in my_data:
        my_score_fo.write(str(my_data[i])+","+str(my_col_in[i])+"\n")
        i += 1
    
    # Clear scores_all.csv
    clear_scores_all_csv_file_entry()
    
    # Insert training_set.csv
    input_score_csv_file_entry.insert(10,"training_set.csv")
    
    # Close for good
    my_score_fo.close()

def calc_new_column_to_test_set_csv_file(my_array_in,my_descriptors_in,num_ind_var_in,pol_number_in):
    """Function to calculate new column to be added to test_set.csv file"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Set empty lists
    my_new_column = []
    first_line = []
    column_numbers = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file     # WFA 2018 01 09
    my_polscore_csv_file_in = project_dir_string+"/Polscore/scoring_function_"+pol_number_in+"_test.csv"
    
    # Try to open scores_all csv file
    try:
        my_polscore_fo = open(my_polscore_csv_file_in,"r")
        my_polscore_csv_fo = csv.reader(my_polscore_fo)
    except IOError:
        print("SAnDReS IOError! I can't find "+my_polscore_csv_file_in) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_polscore_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Read first line
    for line in my_polscore_csv_fo:
        for line0 in line:
            first_line.append(line0)
        break
    
    # Get column numbers
    i = 0
    for line0 in first_line:
        for line1 in my_descriptors_in:
            if line1 == line0:
                column_numbers.append(i)
        i += 1
        
    # Looping through the rest of my_polscore_csv_fo to calc the polynomial value
    for line in my_polscore_csv_fo:
        my_value = my_array_in[0]
        for i in range( len(column_numbers) ):
            my_value += my_array_in[i+1]*float(line[ int(column_numbers[i]) ])
        my_new_column.append(my_value)
    
    my_polscore_fo.close()
    
    return my_new_column

def calc_new_column_to_decoy_csv_file(my_array_in,my_descriptors_in,num_ind_var_in,pol_number_in):
    """Function to calculate new column to be added to decoy csv file"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_pol_number_entry, top_decoy_entry
    
    # Set empty lists
    my_new_column = []
    first_line = []
    column_numbers = []
    my_descriptors_aux = []
    my_coef_aux = []
    pot_4_terms = []
    cross_terms1 = []
    cross_terms2 = []
    cross_col2 = []
    cross_col2_coef = []
 
    # Get new project directory 
    project_dir_string = str(strdir_entry.get())
    
    # Get decoy csv file
    decoy_csv_file = top_decoy_entry.get()
    
    # Get scoring function csv file
    my_decoy_csv_file_in = project_dir_string+decoy_csv_file
    
    # Try to open scores_all csv file
    try:
        my_polscore_fo = open(my_decoy_csv_file_in,"r")
        my_polscore_csv_fo = csv.reader(my_polscore_fo)
    except IOError:
        print("SAnDReS IOError! I can't find "+my_decoy_csv_file_in) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_decoy_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Read first line
    for line in my_polscore_csv_fo:
        for line0 in line:
            first_line.append(line0)
        break
    
    print("\nHeaders: ",first_line)
    print("\nDescriptors: ",my_descriptors_in)
    
    # For terms without "."
    i = 0
    dot_present = False
    for header in first_line:
        for term in my_descriptors_in:
            if "." in term and term not in cross_terms2:
                dot_present = True
                cross_terms1.append(term[:term.index(".")])
                cross_terms1.append(term[term.index(".")+1:])
                cross_terms2.append(term)
                continue
            if "^2" in term:
                my_aux0 = term.replace("^2","")
                my_pot = "2"
            else:
                my_aux0 = term
                my_pot = "1"
            if my_aux0 == header:
                print("Found descriptor: ",header)
                column_numbers.append(str(i))
                if my_pot == "2":
                    my_descriptors_aux.append(header+"^2")
                else:
                    my_descriptors_aux.append(header)
                
                pot_4_terms.append(my_pot)
        i += 1
                
    # Looping through my_descriptos_in list to regression coefficients
    i = 0
    for line in my_descriptors_in:
        # Looping through my_descriptos_aux
        for header in my_descriptors_aux:
            if line == header:
                my_coef_aux.append(my_array_in[i+1])
        i += 1
    
    # For cross terms
    if dot_present:    
        # Looping through cross_terms1
        for term in cross_terms1:
            i = 0
            # Looping through first_line list
            for header in first_line:
                if header == term:
                    print("Cross term: ",term)
                    cross_col2.append(str(i))
                i += 1
        j = 0
        # Looping through my_descriptos_in
        for line in my_descriptors_in:
            if "." in line:
                print(line,my_array_in[j+1])
                cross_col2_coef.append(my_array_in[j+1])
            j += 1
                           
    # Looping through the rest of my_polscore_csv_fo to calc the polynomial values
    for line in my_polscore_csv_fo:
        my_value = my_array_in[0]
        print(line[0],end=" = ")
        for i in range( len(column_numbers) ):
            if pot_4_terms[i] == "2":
                my_value += my_coef_aux[i]*(float(line[ int(column_numbers[i]) ]))**2
                my_aux = my_coef_aux[i]*(float(line[ int(column_numbers[i]) ]))**2
            else:
                my_value += my_coef_aux[i]*float(line[ int(column_numbers[i]) ])
                my_aux = my_coef_aux[i]*float(line[ int(column_numbers[i]) ])
            print(my_aux)
        for j in range(0,len(cross_col2_coef)):
            k = 2*j +1 
            my_value += cross_col2_coef[j]*float(line[ int(cross_col2[k-1])])*float(line[ int(cross_col2[k])])
            my_aux = cross_col2_coef[j]*float(line[ int(cross_col2[k-1])])*float(line[ int(cross_col2[k])])
            print(my_aux)
        print(my_value)
        my_new_column.append(my_value)
        my_value = 0
    
    my_polscore_fo.close()
    
    return my_new_column
         
def calc_new_column_to_score_csv_file(my_array_in,my_descriptors_in,num_ind_var_in,pol_number_in):
    """Function to calculate new column to be added to score csv file"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Set empty lists
    my_new_column = []
    first_line = []
    column_numbers = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file # WFA 2018 01 09
    my_polscore_csv_file_in = project_dir_string+"/Polscore/scoring_function_"+pol_number_in+".csv"
    
    # Try to open scores_all csv file
    try:
        my_polscore_fo = open(my_polscore_csv_file_in,"r")
        my_polscore_csv_fo = csv.reader(my_polscore_fo)
    except IOError:
        print("SAnDReS IOError! I can't find "+my_polscore_csv_file_in) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_polscore_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Read first line
    for line in my_polscore_csv_fo:
        for line0 in line:
            first_line.append(line0)
        break
    
    # Get column numbers
    i = 0
    for line0 in first_line:
        for line1 in my_descriptors_in:
            if line1 == line0:
                column_numbers.append(i)
        i += 1
        
    # Looping through the rest of my_polscore_csv_fo to calc the polynomial value
    for line in my_polscore_csv_fo:
        my_value = my_array_in[0]
        for i in range( len(column_numbers) ):
            my_value += my_array_in[i+1]*float(line[ int(column_numbers[i]) ])
        my_new_column.append(my_value)
    
    my_polscore_fo.close()
    
    return my_new_column

def update_decoy_csv_file_GUI():
    """Function to call update_decoy_csv_file()"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_pol_number_entry, top_decoy_entry
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new scoring function csv file
    my_new_csv_score_file = "decoy_results.csv"
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Insert Polynomial Scoring Functions",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
          
    # Widgets for input file name
    Label(top_txt, text="Decoy File:" ).grid(row = 2,column = 0, stick = W)   
    top_decoy_entry = Entry(top_txt,width = 94) # it was 97
    top_decoy_entry.grid(row = 2, column = 0,stick = E)
    top_decoy_entry.insert(10,my_new_csv_score_file)
        
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 5, column = 0, stick = W)
    
    # More buttons
    Button(top_txt, text='Update CSV File', command=update_decoy_csv_file).grid(row = 2, column = 1, \
                                                                            sticky = W)  
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2, \
                                                                               sticky = W)  
    
    # Widgets for percentage of data in training set
    Label(top_txt, text="Polynomial Eq. Number:" ).grid(row = 6,column = 1, stick = W)   
    top_pol_number_entry = Entry(top_txt,width = 4)
    top_pol_number_entry.grid(row = 6, column = 1,stick = E)
    top_pol_number_entry.insert(10,"55")
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 4, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # Try to open input file
    try:
        my_info_input_file = open(project_dir_string+my_new_csv_score_file,"r")
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find "+\
                    project_dir_string+my_new_csv_score_file+" file! \nPlease check input file name!")
        return
        
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n\n\n" 
    
    # Reads input file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()  

    
def update_decoy_csv_file():
    """Function to update decoy data adding polynomial scoring function results"""
        
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor, top_csv_inputfile_entry, top_pol_number_entry
    
    # Import library
    from tkinter import messagebox
    
    my_aux_pol_number =  str(top_pol_number_entry.get())
    
    # Fix the number of characters
    my_str_7_char = str(my_aux_pol_number)
    if len(my_str_7_char)< 8:
        my_str_in1 = str((7-len(my_str_7_char) )*"0")+my_str_7_char
    else:
        my_str_in1 = my_str_7_char
            
    # Get polynomial scoring function number
    pol_number = "number "+my_str_in1
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
        
    # Try to open polscore.log file
    try:
        my_polscore_log_fo = open(project_dir_string+"polscore.log","r")
    except IOError:
        print("SAnDReS IOError! I can't find polscore.log") 
        messagebox.showerror("SAnDReS IOError!", "I can't find file polscore.log."+\
                             "\nPlease check directory name!")
        return
    
    # Looping through my_polscore_log_fo
    for line in my_polscore_log_fo:
        if "Polynomial equation number " in line:
            if str(pol_number) in line:
                my_index_pol_1 = line.index(":")
                my_index_pol_2 = line.index("+")
                c_0 =  float(line[my_index_pol_1+1:my_index_pol_2])
                my_pol_string = line[my_index_pol_2+1:]
    
    my_polscore_log_fo.close()
    
    print("\nPolscore = "+my_pol_string+"\n")
    
    # Call function to count "*" in my_pol_string
    num_var_pol = get_number_ind_var(my_pol_string)
    
    # Call function to get coefficient array
    my_array = get_polynomial_coefficients(float(c_0),int(num_var_pol),my_pol_string)
    
    # Call function to get descriptors
    my_descriptors = get_descriptor_strings(my_pol_string)
    
    print("\nMy array ",my_array)
    print()
    print("\nMy decriptors: ",my_descriptors)
    print()
    print("\nMy num var pol: ",num_var_pol)
    print()
    print("\nMy string in: ",my_str_in1)
    
    # Call calc_new_column_to_decoy_csv_file(my_array_in,num_ind_var_in)
    my_new_col = calc_new_column_to_decoy_csv_file(my_array,my_descriptors,num_var_pol,my_str_in1)
    
    # Call gen_new_decoy_set_csv_file()
    gen_new_decoy_set_csv_file(my_new_col,my_str_in1)
    
    # Call gen_new_test_set_csv()
    #gen_new_test_set_csv(my_new_test_col,my_str_in1)
                         
def update_score_csv_file():
    """Function to update scoring function csv file"""
    
    # Defines global variables to allow access with different functions
    
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor, top_csv_inputfile_entry
    
    # Import library
    from tkinter import messagebox
    
    my_aux_pol_number = str(top_csv_inputfile_entry.get())
    
    # Fix the number of characters
    my_str_7_char = str(my_aux_pol_number)
    if len(my_str_7_char)< 8:
        my_str_in1 = str((7-len(my_str_7_char) )*"0")+my_str_7_char
            
    # Get polynomial scoring function number
    pol_number = "number "+my_str_in1
    
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # For top_csv_inputfile_entry.get()>511 (to be handled with calc_binding
    if int(top_csv_inputfile_entry.get()) > 511:
        
        # Import Score from calc_binding1
        from calc_binding1 import Score
        
        # Input file                   
        file_in = "training_set.csv"    
    
        # Output file
        file_out = "training_set.csv"   

        # Polscore file
        polscore_in = "polscore.log"
        
        # Polscore number
        polscore_number_in = my_aux_pol_number
                
        # For training set
        print("\nAdding binding affinity column to training set...",end = "")
        
        # Instantiate an object of the Score() class and assign it to s_training
        s_training = Score(project_dir_string,file_in,file_out,polscore_in,polscore_number_in)
        
        # Invoke add_col_2_dataset()
        s_training.add_col_2_dataset()
        print("\nDone!")
        
        # For test set
        print("\nAdding binding affinity column to test set...",end = "")
        
        # Input file                   
        file_in = "test_set.csv"    
        
        # Output file
        file_out = "test_set.csv" 
        
        # Instantiate an object of the Score() class and assign it to s_test
        s_test = Score(project_dir_string,file_in,file_out,polscore_in,polscore_number_in)
        
        # Invoke add_col_2_dataset()
        s_test.add_col_2_dataset()
        print("\nDone!")
        
    else:
        # Try to open polscore.log file
        try:
            my_polscore_log_fo = open(project_dir_string+"polscore.log","r")
        except IOError:
            print("SAnDReS IOError! I can't find polscore.log") 
            messagebox.showerror("SAnDReS IOError!", "I can't find file polscore.log."+\
                             "\nPlease check directory name!")
            return
    
        # Looping through my_polscore_log_fo
        for line in my_polscore_log_fo:
            if "Polynomial equation number " in line:
                if str(pol_number) in line:
                    my_index_pol_1 = line.index(":")
                    my_index_pol_2 = line.index("+")
                    c_0 =  float(line[my_index_pol_1+1:my_index_pol_2])
                    my_pol_string = line[my_index_pol_2+1:]
    
        my_polscore_log_fo.close()
    
        print("\nPolscore = "+my_pol_string+"\n")
    
        # Call function to count "*" in my_pol_string
        num_var_pol = get_number_ind_var(my_pol_string)
    
        # Call function to get coefficient array
        my_array = get_polynomial_coefficients(float(c_0),int(num_var_pol),my_pol_string)
    
        # Call function to get descriptors
        my_descriptors = get_descriptor_strings(my_pol_string)
    
        # Call calc_new_column_to_score_csv_file(my_array_in,num_ind_var_in)
        my_new_col = calc_new_column_to_score_csv_file(my_array,my_descriptors,num_var_pol,my_str_in1)
    
        # Call calc_new_column_to_test_set_csv_file()
        my_new_test_col = calc_new_column_to_test_set_csv_file(my_array,my_descriptors,num_var_pol,my_str_in1)
    
        # Call gen_new_training_set_csv_file()
        gen_new_training_set_csv_file(my_new_col,my_str_in1)
    
        # Call gen_new_test_set_csv()
        gen_new_test_set_csv(my_new_test_col,my_str_in1)
    
     
def update_score_csv_file_GUI():
    """Function to call function to update score function csv file"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor, top_csv_inputfile_entry
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Update Score CSV File') 
    top_txt.geometry("870x80+20+315") 
    
    # Widgets for sorted csv file name
    Label(top_txt, text="Sorted CSV File:" ).grid(row = 0,column = 0, stick = W)   
    top_csv_inputfile_entry = Entry(top_txt,width = 17)
    top_csv_inputfile_entry.grid(row = 0, column = 1,stick = E)
    top_csv_inputfile_entry.insert(0,"sorted_polscore.csv")
    
    # Widgets for Edit button
    Button(top_txt, text='Open Sorted CSV', command=open_my_sorted_csv_file).grid(row = 0, \
                                                column = 3, sticky = W)
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 0, column = 5,\
                                                                                sticky = W) 
    # Widgets for polynomial scoring function
    top_csv_inputfile_entry = Entry(top_txt,width = 17)
    top_csv_inputfile_entry.grid(row = 1, column = 1,stick = W)
    top_csv_inputfile_entry.insert(1,"511")
    
    # open polscore.log to get top_csv_inputfile_entry.get() to read polynomail equation
    # Widgets for Edit button
    Button(top_txt, text='Include Polynomial Eq #', command=update_score_csv_file).grid(row = 1, \
                                                                    column = 0, sticky = W)
        
def sort_polscore():
    """Function to sort polscore results""" 
    
    # Import libraries
    import numpy as np
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Sort Polscore Results') 
    top_txt.geometry("870x100+20+435") 
      
    # Widgets for sorting criteria
    Label(top_txt, text="Sorting Criteria:" ).grid(row = 1,column = 0, stick = W)
    sorting_criteria_var  = IntVar()
    
    # Set list for sorting criteria
    sorting_criteria_list = ["R2","R2 adjusted","Standard deviation","Spearman's correlation","p-value"]
    
    def my_sel1():
        """Function to show sorting criteria"""
        selection = "Sorting criteria: " + str( sorting_criteria_list[int(sorting_criteria_var.get())])+25*" "
        Label(top_txt, text=selection ).grid(row = 10,column = 7, stick = W)
    
    # Looping through point colors
    for i in range(5):
        rad = Radiobutton(top_txt, text = sorting_criteria_list[i], value = i, variable=sorting_criteria_var,\
                           command = my_sel1)
        rad.grid(row = 2,column = i+2, stick = W)
    
    # Widgets for input file name
    Label(top_txt, text="File:" ).grid(row = 3,column = 0, stick = W)   
    top_csv_inputfile_entry = Entry(top_txt,width = 14)
    top_csv_inputfile_entry.grid(row = 3, column = 1,stick = E)
    top_csv_inputfile_entry.insert(3,"polscore.csv")
    
    def sort_my_csv_file():
        """Function to sort the file"""
        import csv
        
        # Set  empty lists
        my_list_in = []
        my_list_col0 = []
        my_list_col1 = []
        my_list_col2 = []
        my_list_col3 = []
        my_list_col4 = []
        my_list_col5 = []
        original_list_in = []
        my_file_list = []
        
        # Get csv file and column number
        my_polscore_csv_file_in = top_csv_inputfile_entry.get()
        my_sorting_criteria_var = sorting_criteria_var.get()
        
        print("Sorting "+my_polscore_csv_file_in+" file...")
        # Try to open csv file
        try:
            my_polscore_fo = open(project_dir_string+my_polscore_csv_file_in,"r")
            my_polscore_csv_fo = csv.reader(my_polscore_fo)
        except IOError:
            print("SAnDReS IOError! I can't find "+my_polscore_csv_file_in) 
            messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_polscore_csv_file_in+\
                             " \nPlease check directory name!")
            return
            
        # For first line
        for line in my_polscore_csv_fo:
            first_line = line[0]
            for line0 in line[1:]:
                first_line += ","+line0
            break
        
        # Looping through the rest of csv file
        for line in my_polscore_csv_fo:
            my_aux = float(line[my_sorting_criteria_var+1])
            my_list_in.append(my_aux)
            original_list_in.append(line[my_sorting_criteria_var+1])
            my_list_col0.append(line[0])
        
            my_file_list.append(line[0])
        
            my_list_col1.append(line[1])
            my_list_col2.append(line[2])
            my_list_col3.append(line[3])
            my_list_col4.append(line[4])
            my_list_col5.append(line[5])
        
        # Set empty list for minimum values
        list_of_min = []
            
        # Looping column to be sorted
        for i in range(len(original_list_in)):
            # Looping through list to convert to array 
            my_array_in = np.zeros(len(my_list_in) )    # Set an array of zeros
            
            # Looping through decreseaing list
            for j in range(len(my_list_in)):
                my_array_in[j] = my_list_in[j]
            
            # Get minimum for the array
            my_min = my_array_in.min()
                    
            list_of_min.append(my_min)   
            my_list_in.remove(my_min)
        
        # Open new csv file sorted_polscore.csv and write first line          
        my_sorted_csv_fo = open(project_dir_string+"sorted_polscore.csv","w")
        my_sorted_csv_fo.write(first_line+"\n")
        
        my_list_of_min = []
        for line in list_of_min:
            if line in my_list_of_min:
                print()
            else:
                my_list_of_min.append(line)
                    
        # Looping through list of minima to write sorted_polscore.csv
        found_files = []
        for line in my_list_of_min:
            i = original_list_in.index(str(line))
            found_files.append(my_list_col0[i])
            my_line_out = my_list_col0[i]+","+my_list_col1[i]+","+my_list_col2[i]+","+\
                            my_list_col3[i]+","+my_list_col4[i]+","+my_list_col5[i]
            my_sorted_csv_fo.write(my_line_out+"\n")
        
        my_sorted_csv_fo.close()
        my_polscore_fo.close()
        
        # Call show_message_in_sandres()
        show_message_in_sandres("Done! SAnDReS finished sorting "+my_polscore_csv_file_in+" file!"\
                                ,"black","light grey")
         
    # Widgets for Update button
    Button(top_txt, text='  Sort  ', command=sort_my_csv_file).grid(row = 3, column = 2, sticky = W) 
    
    # Widgets for Edit button
    Button(top_txt, text='Open Sorted CSV', command=open_my_sorted_csv_file).grid(row = 3, column = 3, sticky = W)
    
    # Widgets for Close button
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 3, column = 4,\
                                                                                sticky = W) 
def polscore_GUI():
    """Function to run polscore.in"""
    
    # Import libraries
    import shutil 
    import time
    import os
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get()) 
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Make backup of old polscore.log polscore.csv
    try:
        shutil.copy2(project_dir_string+"polscore.log",project_dir_string+"polscore_"+my_local_time+".log")
        shutil.copy2(project_dir_string+"polscore.csv",project_dir_string+"polscore_"+my_local_time+".csv")
    except:
        print()
    
    # Remove old polscore.log and polscore.csv
    try:
        os.remove(project_dir_string+"polscore.log")
        os.remove(project_dir_string+"polscore.csv")
    except:
        print()
    
    # Open new polscore.csv file
    my_polscore_csv_fo = open(project_dir_string+"polscore.csv","w")
    
    # Write headers
    my_polscore_csv_fo.write("File,R2,R2 adj,Standard Deviation,Spearman's correlation,p-value\n")
    my_polscore_csv_fo.close()
    
    # Call run_sandres_in()
    run_sandres_in("polscore.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running polscore.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("polscore.log")    

def copy_stscor_results():
    """Function to copy latest stscor results to backup directory"""
    
    # Import libraries
    import shutil
    import errno 
    import time
    import os
    import csv
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
     
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Define new directory name # WFA 2018 01 09
    path = project_dir_string+"/stscor_"+my_local_time+"/"
    
    # Try makedir 
    try:
        os.makedirs(path)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise 
    
    # Try to open
    try:
        my_stscor_fo = open(project_dir_string+"stscor.csv","r")
        my_stscor_csv_fo = csv.reader(my_stscor_fo)
    except:
        print("\nI can't find file "+project_dir_string+"stscor.csv")
    
    # Looping through csv file to copy stscor###.csv to backup directory
    for line in my_stscor_csv_fo:
        my_csv_file0 = str(line[6])
        my_csv_file1 = my_csv_file0.replace("\t","")
        my_csv_file2 = my_csv_file1.replace(" ","")
        print("\nCopying "+my_csv_file2+" to "+path)
        shutil.copy2(project_dir_string+my_csv_file2,path)
    
    # Copy stscor.log to backup directory
    shutil.copy2(project_dir_string+"stscor.log",path)
    
    # Copy stscor.log to backup directory
    shutil.copy2(project_dir_string+"stscor.csv",path)
    
def show_stscor():
    """Function to show stscor.log"""
    
    # Call read_log_file()
    read_log_file("stscor.log")
    
    # Copy scoring function results to backup directory
    copy_stscor_results()
      
def stscor():
    """Function to run stscor.in"""
        
    # Call run_sandres_in()
    run_sandres_in("stscor.in") 
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running stscor.in!","black","light grey")
    
    # Call read_log_file()
    read_log_file("stscor.log")
    
def correct_CSV_file(my_csv_file_in):
    """Function to correct CSV files, if necessary """
    
    # Import libraries
    import shutil 
    import time
    semicolon_flag = False
    
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Set initial list
    my_csv_list_out = []
    
    # Make a copy of my_csv_file_in
    print("\nCopying "+my_csv_file_in+"\nto "+my_csv_file_in[:len(my_csv_file_in)-4]+"_"+\
          my_local_time+".csv   \n")
    shutil.copy2(my_csv_file_in,my_csv_file_in[:len(my_csv_file_in)-4]+"_"+my_local_time+".csv")
    
    # Try open csv file
    try:
        my_file_fo = open(my_csv_file_in,"r")
    except IOError:
        print("SAnDReS IOError! I can't find "+my_csv_file_in) 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_csv_file_in+\
                             " \nPlease check directory name!")
        return
    
    # Test of ";" is in my_file_fo
    for line in my_file_fo:
        if ";" in line:
            semicolon_flag = True
    
    # Close file
    my_file_fo.close()
    
    if semicolon_flag:
        my_file_fo = open(my_csv_file_in,"r")
            
        # Looping through my_file_fo to replace ";" for ",
        for line in my_file_fo:
            new_line = line.replace(";",",")
            my_csv_list_out.append(new_line)
    
        # Close file
        my_file_fo.close()
    
        # Open new my_csv_file_in
        my_new_csv_file_fo = open(my_csv_file_in,"w")
    
        # Looping through my_csv_list_out
        for line in my_csv_list_out:
            my_new_csv_file_fo.write(line)
    
        # Close my_new_csv_file_fo
        my_new_csv_file_fo.close()
    else:
        print("\nFile "+my_csv_file_in+" is a CSV file with ',' \n" )
       
def merge_stdock():
    """Merge CSV file and chklig.in to generate stdock1.in and stdock2.in"""
    
    # Import libraries
    import numpy as np
    import csv
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, input_ensemble_csv_file_entry
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get top_input_file_score (scoring function values)
    string_score = str(input_ensemble_csv_file_entry.get()  )
    
    # Call correct_CSV_file()
    correct_CSV_file(project_dir_string+string_score)
    
    # Get chklig.in
    string_chklig = "chklig.in"
    
    # Try to open CSV files
    try:
        my_rmsd_info = open(project_dir_string+string_score,"r")
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_score)
        return
    my_csv1 = csv.reader(my_rmsd_info) 
    
    try:
        my_chklig_info = open(project_dir_string+string_chklig,"r")
        
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_chklig)
        return
    my_csv2 = csv.reader(my_chklig_info)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished creating new stdock.in!","black","light grey")
    
    # Looping through to get first line information
    my_scoring_function_labels = []
    for line in my_csv1:
        for i in range(len(line)):
            my_aux = line[i].replace(" ","")
            if my_aux == "RMSD":
                rmsd_column = i
            elif i > 0:
                my_scoring_function_labels.append(line[i])            
        break
    
    # Looping through the rest of CSV file
    rmsds = np.zeros(99999)      
    ligands = []
    binding = []
    my_aux_binding = []
    i = 0
    for line in my_csv1:
        try:        # Handles problem when there is no string_score file nor RMSD values
            rmsds[i] = float(line[rmsd_column])  
            ligands.append(line[0])
        except:
            print("SAnDReS Error! No RMSD values!" ) # Variable 'rmsd_column' referenced before assignment!
            print("Please check if file "+string_score+" is in the project directory!")
            messagebox.showerror("SAnDReS Error! No RMSD values!","Please check if file "+string_score+\
                                 " is in the project directory!")
            return
            
        # Looping through to get binding information
        for j in range(len(line)):
            if j != rmsd_column:
                my_aux_binding.append(line[j])
        binding.append(my_aux_binding) 
        my_aux_binding = []
        i +=1
    
    # Close my_rmsd_info file
    my_rmsd_info.close()
    
    # Try to open CSV files
    try:
        my_rmsd_info = open(project_dir_string+string_score,"r")
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_score)
        return
    my_csv1 = csv.reader(my_rmsd_info) 
    
    # Looping through to get first line information
    for line in my_csv1:
        for i in range(len(line)):
            my_aux = line[i].replace(" ","")
            if my_aux == "Torsions":
                tor_column = i           
        break
    
    # Looping through the rest of CSV file
    torsions = np.zeros(99999,int)  
    i = 0
    for line in my_csv1:
        torsions[i] = int(line[tor_column])  
        i +=1
     
    # Looping through chklig.in line information and add rmsd 
    my_aux_list = []
    my_aux_stdock = []
    i = 0
    
    # Looping through my_csv2
    for line in my_csv2:
        if "#" not in line[0]:
            my_aux_list.append("STDOCK")
            for j in range(1,5):
                my_aux_list.append(line[j])
            
            # Looping through ligands    
            for lig in ligands:
                if line[2] in lig:
                    my_aux_list.append(str(rmsds[ int(ligands.index(lig)) ]))
                    my_aux_list.append(str(torsions[ int(ligands.index(lig)) ]))
                    
                    my_aux_list.append( str(line[5]   )  )      # For experimental binding affinitty
                    
                    my_aux_stdock.append(my_aux_list)
            my_aux_list = []
        elif "Type of binding information" in line[0]:
            continue
    
    # Open new stdock1.in and stdock2.in files
    my_new_stdock1 = open(project_dir_string+"stdock1.in","w")
    my_new_stdock2 = open(project_dir_string+"stdock2.in","w")
    
    my_new_stdock1.write("CUTOFF,NTOR,40 \n")
    
    
    my_new_stdock2.write(
"""SPHERE, 15.0 
SPHERE, 20.0 
SPHERE, 25.0     \n""")
    my_new_stdock2.write("CUTOFF,NTOR,40 \n")
    
    # Looping through binding list   
    my_aux_list = []
    my_stdock = []
    for bind in binding:
        # Looping through my_aux_stdock
        for line in my_aux_stdock:
            if line[2] in bind[0]:
                for j in range(len(line)):
                    my_aux_list.append(line[j])
                my_stdock.append(my_aux_list)
                my_aux_list = []
                break
        
    # Writing stdock.in
    count_ligands = 0
    for line in my_stdock:
        count_ligands += 1
        for i in range(len(line)):
            if i < (len(line) -1):
                my_sandres_line = line[i]+","
            else:
                my_sandres_line = line[i]+"\n"
            my_new_stdock1.write(my_sandres_line)
            my_new_stdock2.write(my_sandres_line)
        
    print("\nNew stdock1.in and stdock2.in have been generated.")
    
    # Close files
    my_new_stdock1.close()
    my_new_stdock2.close()
    my_rmsd_info.close()        
    my_chklig_info.close()

def merge_stensembledock():
    """Merge CSV file and chklig.in to generate stensembledock.in"""
    
    # Import libraries
    import numpy as np
    import csv
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig
    
    # Get project directory
    project_dir_string = str(strdir_entry.get()) 

    # Get input_ensemble_csv_file_entry.get() 
    string_score = str(input_ensemble_csv_file_entry.get() )
    
    # Call correct_CSV_file()
    correct_CSV_file(project_dir_string+string_score)
    
    # Assign chklig.in to string_chklig
    string_chklig = "chklig.in"
    
    # Try to open CSV file (my_tor_info keeps scoring functions) (my_csv1)
    try:
        my_tor_info = open(project_dir_string+string_score,"r")
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_score)
        return
    my_csv1 = csv.reader(my_tor_info)
    
    # Check here September 1st 2015 string_score is the ensembledocking file (my_csv1)
    
    # Try to open CSV file (my_chklig_info keeps chklig.in) (my_csv2)
    try:
        my_chklig_info = open(project_dir_string+string_chklig,"r")
        
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_chklig)
        return
    my_csv2 = csv.reader(my_chklig_info)
    
    # Looping through to get first line information
    my_scoring_function_labels = []
    my_scoring_function_columns = []
    for line in my_csv1:
        for i in range(len(line)):
            my_aux = line[i].replace(" ","")
            my_aux1 = my_aux.upper()
            if my_aux1 == "TORSIONS":
                torsion_column = i
            elif my_aux1 == "RMSD":
                rmsd_column = i
            elif i > 0:
                my_scoring_function_labels.append(line[i])  
                my_scoring_function_columns.append(str(i))          
        break
    
    
    # Looping through the rest of my_csv1 
    # to get scoring function information (scoring_function_array), rmsd (rmsd_array), 
    # and torsions (torsion_array)
    # np.array([[0]*column]*row,float)
    scoring_function_array  = np.array([[0]*10000]*len(my_scoring_function_labels),float)   
    count_ligs = 0
    rmsd_array = np.array([0]*10000,float)     # np.array([0]*number_of_lines)
    torsion_array = np.array([0]*10000,float)  # np.array([0]*number_of_lines)
    my_lig_list = []
    for line in my_csv1:
        # Looping through each line to get scoring function
        for i in range(len(my_scoring_function_labels)):
            scoring_function_array[i,count_ligs] = line[int(my_scoring_function_columns[i])]
        # To get rmsd information
        rmsd_array[count_ligs] = line[rmsd_column]
        # To get number of torsion information
        torsion_array[count_ligs] = line[torsion_column]
        # To get ligand information
        my_lig_list.append(line[0]) 
        count_ligs += 1
    
    # close my_tor_info (my_csv1)
    my_tor_info.close()
    
    # Looping through to get chklig.in information and add rmsd_array, torsion_array, 
    #and scoring_function_array
    my_stensembledock_list = []
    my_aux_stensembledock = ""
    my_found_ligs = []
    
    for line in my_csv2:
        my_aux_stensembledock += "STENSEMBLEDOCK"
        # To get the right ligand
        if len(line) > 2:
            for i in range(1,5):
                my_aux_stensembledock += ","+line[i] 
            # Looping through all ligands identified in my_csv1 (my_tor_info)
            for j in range(count_ligs):
                if line[2] in my_lig_list[j]:       # To get rid of repeated ligands
                    if line[2] not in my_found_ligs:
                        my_found_ligs.append(line[2])
                        my_aux_stensembledock += ","+str(rmsd_array[j])            # Add rmsd values
                        my_aux_stensembledock += ","+str(int(torsion_array[j]))    # Add torsion
                        for k in range(len(my_scoring_function_labels)):
                            # Add scoring function values
                            my_aux_stensembledock += ","+str(  scoring_function_array[k,j]   ) 
                        my_stensembledock_list.append(my_aux_stensembledock)
                        break
        
        my_aux_stensembledock = ""
    
    # Open stensembledock.in
    my_stensembledock_fo = open(project_dir_string+"stensembledock.in","w")
    
    # Write first line into my_stensembledock_fo file
    my_stensembledock_fo.write("CUTOFF,NTOR,40\n")
    
    # Get scoring function names 
    my_scoring_function_string0 = str(my_scoring_function_labels)
    my_scoring_function_string1 = my_scoring_function_string0.replace("[","")
    my_scoring_function_string2 = my_scoring_function_string1.replace("]","")
    my_scoring_function_string3 = my_scoring_function_string2.replace(" ","")
    my_scoring_function_string4 = my_scoring_function_string3.replace("'","")
    
    # Write second line into my_stensembledock_fo file
    my_stensembledock_fo.write("SCOREFUNC,"+my_scoring_function_string4+"\n")
   
    # Checking my_stensembledock_list
    print("\nNew stensembledock.in file:")
    for line in my_stensembledock_list:
        my_stensembledock_fo.write(line+"\n")
        print(line)
    
    # Close stensembledock.in file
    my_stensembledock_fo.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished creating new stensembledock.in!","black","light grey")
    
def merge_stscor():
    """Merge CSV file and chklig.in to generate stscor.in"""
    
    # Import libraries
    import numpy as np
    import csv
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor
    
    # Get project directory
    project_dir_string = str(strdir_entry.get()) 

    # Get top_input_file_score (scoring function values)
    string_score = str( input_score_csv_file_entry.get()  )
    
    # Call correct_CSV_file()
    correct_CSV_file(project_dir_string+string_score)
    
    # Assign "chklig.in to string_chklig
    string_chklig = "chklig.in"
    
    # Try to open CSV files
    try:
        my_tor_info = open(project_dir_string+string_score,"r")
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_score)
        return
    my_csv1 = csv.reader(my_tor_info)
    
    # Try to open chklig.in file
    try:
        my_chklig_info = open(project_dir_string+string_chklig,"r")    
    except IOError:
        print("\nSAnDReS Error! I can't find file "+project_dir_string+string_chklig)
        return
    
    my_csv2 = csv.reader(my_chklig_info)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished creating new stscor.in!","black","light grey")
    
    # Looping through to get first line information
    my_scoring_function_labels = []
    for line in my_csv1:
        for i in range(len(line)):
            my_aux = line[i].replace(" ","")
            if my_aux == "Torsions":
                tor_column = i
            elif i > 0:
                my_scoring_function_labels.append(line[i])            
        break
    
    # Looping through the rest of CSV file
    torsions = np.zeros(99999,int)  
    ligands = []
    binding = []
    my_aux_binding = []
    i = 0
    for line in my_csv1:
        torsions[i] = int(line[tor_column])  
        ligands.append(line[0])
        
        # Looping through to get binding information
        for j in range(len(line)):
            if j != tor_column:
                my_aux_binding.append(line[j])
        binding.append(my_aux_binding) 
        my_aux_binding = []
        i +=1
    # Scoring function list binding is complete here
       
    # Looping through chklig.in line information and add torsion
    my_aux_list = []
    my_aux_stscor = []
    i = 0
    
    # Looping through my_csv2
    for line in my_csv2:
        if "#" not in line[0]:
            my_aux_list.append("STSCOR")
            for j in range(1,len(line)):
                my_aux_list.append(line[j])
            
            # Looping through ligands    
            for lig in ligands:
                if line[2] in lig:
                    my_aux_list.append(str(torsions[ int(ligands.index(lig)) ]))
                    my_aux_stscor.append(my_aux_list)
            my_aux_list = []
        elif "Type of binding information" in line[0]:
            continue

    # Open new stscor.in file
    my_new_stscor = open(project_dir_string+"stscor.in","w")
    
    # Looping through binding list   
    my_aux_list = []
    my_stscor = []
    for bind in binding:
        # Looping through my_aux_stscor
        for line in my_aux_stscor:
            if line[2] in bind[0]:
                for j in range(len(line)):
                    my_aux_list.append(line[j])
                for i in range(1,len(bind)):
                    #if i != tor_column:
                    my_aux_list.append(bind[i])
                my_stscor.append(my_aux_list)
                my_aux_list = []
                break
    
    # Writing stscor.in
    # Get top_inputfile_log_factor (type of factor to be used in the scoring function)
    string_log_factor = str(top_inputfile_log_factor.get())
    my_new_stscor.write("CUTOFF,NTOR,40 \n")
    
    # Get scoring function names 
    my_scoring_function_string0 = str(my_scoring_function_labels)
    my_scoring_function_string1 = my_scoring_function_string0.replace("[","")
    my_scoring_function_string2 = my_scoring_function_string1.replace("]","")
    my_scoring_function_string3 = my_scoring_function_string2.replace(" ","")
    my_scoring_function_string4 = my_scoring_function_string3.replace("'","")
    
    # Write second line into my_new_stscor file
    my_new_stscor.write("SCOREFUNC,"+my_scoring_function_string4+"\n")

    # Write third line    
    my_new_stscor.write("FACTORXLOG,"+string_log_factor+" \n")
    count_ligands = 0
    exp_binding_list = []
    if string_log_factor[0] == "-":
        my_log_factor = -1
    else:
        my_log_factor = 1
    
    # Looping through my_stscor
    for line in my_stscor:
        # Try to overcome log problem for deltaG WFA 2017 07 12
        if string_log_factor == "C":
            exp_binding_list.append(float(line[5]))
        else:
            exp_binding_list.append(  my_log_factor*( -9.0 + np.log10(float(line[5])) )  )
        count_ligands += 1
        for i in range(len(line)):
            if i < (len(line) -1):
                my_sandres_line = line[i]+","
            else:
                my_sandres_line = line[i]+"\n"
            my_new_stscor.write(my_sandres_line)
        
    print("\nNew stscor.in has been generated.")
    
    # Close files
    my_new_stscor.close()
    my_tor_info.close()        
    my_chklig_info.close()
    
def check_score_csv_file():
    """Function to check scoring function csv file"""
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new score file
    string_score_file = str(input_score_csv_file_entry.get())
    
    # Check if all ligand codes are in the csv file 
    check_ligand_info(project_dir_string+"chklig.in",3,project_dir_string+string_score_file,1)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished checking ligands in "+string_score_file,"black","light grey")
    
def check_ensembledock_csv_file():
    """Function to check ensemble-docking csv file"""
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new ensembledock file
    string_ensembledock_file = str(input_ensemble_csv_file_entry.get())
    
    # Check if all ligand codes are in the csv file 
    check_ligand_info(project_dir_string+"chklig.in",3,project_dir_string+string_ensembledock_file,1)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished checking ligands in "+string_ensembledock_file,"black","light grey")

def gen_stdock():
    """Function to create menu to generate stdock1.in and stdock2.in input files """
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_inputfile_entry_score,\
    top_inputfile_entry_chklig 
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
        
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Analysis of Correlation Between Structural Parameters and Docking Results", \
          font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for input file name
    Label(top_txt, text=""+"File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 110)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,"stdock1.in")
    
    # Widgets for buttons
    Button(top_txt, text='  Read  ', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 2, column = 1, sticky = E)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 5,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 7,\
        column = 0, stick = W)
    
    # More buttons
    Button(top_txt, text='Generate', command=merge_stdock).grid(row = 9, column = 1, sticky = W)  
    Button(top_txt, text=' Save ', command=save_edit_screen_to_input_file).grid(row = 9, column = 1,\
                                                                                  sticky = E)
    Button(top_txt, text=' Close ', bg = "red", command=top_txt.destroy).grid(row = 9, column = 2,\
                                                                               sticky = W)  
       
    # Widgets for empty label
    Label(top_txt, text=196*" " ).grid(row = 8,column = 0, stick = W)   
   
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row = 6, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 4, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 6, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
        
    # Try to open stdock1.in file 
    try:
        my_info_input_file = open(project_dir_string+"stdock1.in","r")
    except IOError:
        print("I can't find ",project_dir_string+"stdock1.in")
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+project_dir_string+\
                                 "stdock1.in"+"\nPlease check input file name!")
        return 
    
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n"       
    
    # Read input file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()  
    
def dummy_stdock():
    """Function to generate dummy files for stdock1.in and stdock2.in"""
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Create dummy stdock1.in and stdock2.in
    my_stdock1_file = open(project_dir_string+"stdock1.in","w")
    my_stdock2_file = open(project_dir_string+"stdock2.in","w")
    
    # Write information in stdocki1.in and stdock2.in files
    my_stdock1_file.write("# Input file for analysis of correlation between docking RMSD and"+\
                          " structural parameters \n")
    my_stdock2_file.write("# Input file for analysis of correlation between docking RMSD and"+\
                          " structural parameters \n")
    
    my_stdock1_file.write("CUTOFF,NTOR,40 \n")
    my_stdock2_file.write("CUTOFF,NTOR,40 \n")
    
    my_stdock2_file.write(
"""SPHERE, 15.0 
SPHERE, 20.0 
SPHERE, 25.0      \n""")
    my_stdock2_file.write("CUTOFF,NTOR,40 \n")
    
    my_stdock1_file.write("STDOCK, PDB Access Code, Ligand Code, Chain Id, Ligand Number,RMSD,\
    Number of Torsions,Score1,Score2,Score3,... \n")
    my_stdock2_file.write("STDOCK, PDB Access Code, Ligand Code, Chain Id, Ligand Number,RMSD,\
    Number of Torsions,Score1,Score2,Score3,... \n")
    
    my_stdock1_file.close()
    my_stdock2_file.close()
    
    # Call gen_stdock
    gen_stdock()

def get_headers_3vars(col_in,h_x1,h_x2,h_x3,h_x1x2,h_x1x3,h_x2x3,h_x1_2,h_x2_2,h_x3_2):
    """Function to get headers"""
    my_biggest_headers = ""
    if "1" in col_in:
        my_biggest_headers += h_x1+","
    if "2" in col_in:
        my_biggest_headers += h_x2+","
    if "3" in col_in:
        my_biggest_headers += h_x3+","
    if "4" in col_in:
        my_biggest_headers += h_x1x2+","
    if "5" in col_in:
        my_biggest_headers += h_x1x3+","
    if "6" in col_in:
        my_biggest_headers += h_x2x3+","
    if "7" in col_in:
        my_biggest_headers += h_x1_2+","
    if "8" in col_in:
        my_biggest_headers += h_x2_2+","
    if "9" in col_in:
        my_biggest_headers += h_x3_2+","
    
    my_biggest_headers += "Binding Affinity\n"  # Binding affinity
    
    return my_biggest_headers

def read_preferences():
    """Function to read preferences with random seed"""
    
    # Import library
    import csv
    
    # Try to open sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        my_csv = csv.reader(fo)
    except IOError:
        print("\nIOError! I can't find sandres_par.csv file.")
        return None,None,None,None,None,None
    
    # Looping through sandres_par.csv
    for line in my_csv:
        if line[0] == "pdburl":
            pdburl_var = line[1]
        elif line[0]  == "sdfurl":
            sdfurl_var = line[1]
        elif line[0] == "omitted_lig_file":
            omitted_var = line[1]
        elif line[0] == "binding_radius":
            binding_radius =  line[1]
        elif line[0] == "google_chrome":
            google_chrome = line[1]
        elif line[0] == "random_seed":
            random_seed = line[1]
    
    fo.close()
  
    return pdburl_var,sdfurl_var,omitted_var,binding_radius,google_chrome,random_seed
    
def gen_2_random_lists(perc_in,my_len):
    """Function to generate two random lists of integers with seed"""
    
    # Import librariy
    import numpy as np
    
    # Set up empty lists
    list1 = []
    list2 = []
    
    # Call read_preferences
    _,_,_,_,_,random_seed_in = read_preferences()
    
    
    # Set up random seed
    np.random.seed(seed=int(random_seed_in))
    
    # Looping through to generate lists    
    for i in range(my_len):
        my_random = np.random.rand()
        if my_random <= perc_in:
            list1.append(i)
        else:
            list2.append(i)

    return list1, list2
        
def select_training_and_test_sets(my_perc_in,list1):
    """Function to select training and test sets"""

    # Call gen_2_random_lists(my_perc_in,len(list1))
    training_set, test_set = gen_2_random_lists(my_perc_in,len(list1))
        
    return training_set, test_set

def make_scoring_function_csv_3_var(list1_in,list2_in,list3_in,list4_in):
    """Function to shuffle lists for 3 """
    
    # Import libraries
    import numpy as np
    import csv
    import shutil 
    import time
    import make_backup_csv_file as back_csv
    
    # Global variable
    global top_percentage_entry
    
    my_local_time = str(time.strftime("%Y.%m.%d__%Hh%Mmin%Ss"))
 
    my_flag = True
    my_perc = float(top_percentage_entry.get())/100.0
    
    # While loop for generating select_training_and_test_sets()
    count_loop = 0
    while my_flag:

        # Call select_training_and_test_sets(list1)
        my_train, my_test = select_training_and_test_sets(my_perc,list1_in[1:])
                        
        total_len =  len(my_train) + len(my_test)
        limit1 = len(my_train)/total_len
        if limit1 > 0.95*my_perc and limit1 < 1.05*my_perc:
            my_flag = False
        count_loop += 1
        # It worked WFA 2017 08 03
        if count_loop > 1000:
            my_flag = False

    
    print("\nSelected Lines for Training set")
    for line in my_train:
        print(line)
    
    print("\n\nSelected Lines for Test set")
    for line in my_test:
        print(line)
    
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file
    my_score_csv_file_in = input_score_csv_file_entry.get() # Problem it uses scores_all.csv, with all ligands
                                                            # It should be the same ligands in training set
    
    
    # Copy scores_all.csv to scores_all_data_.cav
    shutil.copy2(project_dir_string+my_score_csv_file_in,\
                 project_dir_string+my_score_csv_file_in[:len(my_score_csv_file_in)-4]+\
                 "_"+my_local_time+".csv")
    
    # Try to open scores_all csv file
    try:
        my_score_fo = open(project_dir_string+my_score_csv_file_in,"r")
        my_score_csv_fo = csv.reader(my_score_fo)
    except IOError:
        print("SAnDReS IOError! I can't find "+my_score_csv_file_in) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_score_csv_file_in+\
                             " \nPlease check directory name!")
        return
        
    # Create training_set.csv and test_set.csv
    my_train_fo = open(project_dir_string+"training_set.csv","w")
    my_test_fo = open(project_dir_string+"test_set.csv","w")
    # First line
    for line in my_score_csv_fo:
        my_line_out = ""
        for line_in in line:
            my_line_out0 = line_in.replace("'","")
            my_line_out += ","+my_line_out0
        my_train_fo.write(my_line_out[1:len(my_line_out) ]+"\n")    
        my_test_fo.write(my_line_out[1:len(my_line_out)]+"\n")      
        break

    # The rest of lines
    count_lines_here = 0
    for line in my_score_csv_fo:
        print(line)
        my_line_out = ""
        # Get line to be written
        for line_in in line:
            my_line_out += ","+str(line_in)
        
        # Looping through my_test
        for test_i in my_test:
            test_0 = str(test_i)
            test_1 = test_0.replace(" ","")
            if str(test_1) == str(count_lines_here):
                my_test_fo.write(my_line_out[1:len(my_line_out)]+"\n")
            
        # Looping through my_test
        for test_i in my_train:
            test_0 = str(test_i)
            test_1 = test_0.replace(" ","")
            if str(test_1) == str(count_lines_here):
                #my_train_fo.write(my_line_out[:len(my_line_out) - 1]+"\n" )
                my_train_fo.write( my_line_out[1:len(my_line_out) ]+"\n" )  
        
        count_lines_here += 1
                    
    my_train_fo.close()
    my_test_fo.close()
    my_score_fo.close()
        
    # For headers
    h_x1 = list1_in[0]
    h_x2 = list2_in[0]
    h_x3 = list3_in[0]
    h_x1x2 = h_x1+"."+h_x2
    h_x1x3 = h_x1+"."+h_x3
    h_x2x3 = h_x2+"."+h_x3
    h_x1_2 = h_x1+"^2"
    h_x2_2 = h_x2+"^2"
    h_x3_2 = h_x3+"^2"
    
    # Set up numpy arrays
    x1 = np.zeros( len(list1_in) -1)
    x2 = np.zeros( len(list2_in) -1)
    x3 = np.zeros( len(list3_in) -1)
    my_big_array = np.array([[0]*(len(list1_in) -1)   ]*10,float)        # np.array([[0]*column]*row,float)
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Transfer data to arrays
    for i in range(  len(list1_in[1:]) ):
        x1[i] = list1_in[i+1]
        my_big_array[0][i] = list1_in[i+1]
        x2[i] = list2_in[i+1]
        my_big_array[1][i] = list2_in[i+1]
        x3[i] = list3_in[i+1]
        my_big_array[2][i] = list3_in[i+1]
        my_big_array[9][i] = list4_in[i+1]
    
    # New arrays
    x1x2 = x1*x2
    my_big_array[3] = x1*x2
    x1x3 = x1*x3
    my_big_array[4] = x1*x3
    x2x3 = x2*x3
    my_big_array[5] = x2*x3
    x1_2 = x1*x1
    my_big_array[6] = x1*x1
    x2_2 = x2*x2
    my_big_array[7] = x2*x2
    x3_2 = x3*x3
    my_big_array[8] = x3*x3
        
    # Open file for big table
    my_big_table = open(project_dir_string+"//Polscore//polscore.csv","w")
    
    # Headers
    my_aux_line1 = h_x1+","+h_x2+","+h_x3+","+h_x1x2+","+h_x1x3+","+h_x2x3+","+h_x1_2+","+\
                   h_x2_2+","+h_x3_2+",Binding Affinity\n"
    
    # Write headers in polscore.csv
    my_big_table.write(my_aux_line1)
    
    # Looping through arrays to write polscore.csv
    for i in range( len(x1x2)  ):
        my_aux_line = str(x1[i])+","+str(x2[i])+","+str(x3[i])+","+\
        str(x1x2[i])+","+str(x1x3[i])+","+str(x2x3[i])+","+\
        str(x1_2[i])+","+str(x2_2[i])+","+str(x3_2[i])+","+\
        str(my_big_array[9][i])+"\n"
        my_big_table.write(my_aux_line)
    
    my_big_table.close()
    
        
    # For 3 independent variables a total of 512 files will be generated
    to_be_written = []
    
    # Looping through to generate binary numbers and column number to be written
    for i in range(512):
        my_bin = bin(i)
        my_bin_string0 = str(my_bin)
        my_bin_string1 = my_bin_string0.replace("b","")
        my_bin_string2 = my_bin_string1[1:]
            
        # Fix the number of characters
        my_str_9_char = str(my_bin_string2)
        if len(my_str_9_char)< 10:
            my_str_in = str((9-len(my_str_9_char) )*"0")+my_str_9_char
            
        k = 1
        pol_str =  ""
        my_aux_var_string = ""
        for j in my_str_in:
            if j == "1":
                pol_str += "coef"+str(k)+"*x"+str(k)+" + "
                my_aux_var_string += str(k)+","
            k += 1
        
        to_be_written.append(my_aux_var_string[:len(my_aux_var_string) -1])
        
    # My list of columns to be written
    my_list_of_cols = to_be_written[1:]
        
    print("\nGenerating 511 csv files for polynomial equations...\n")

    # Looping through array data to write scoring_function_####.csv and polscore.in
    my_polscore_in_fo = open(project_dir_string+"polscore.in","w")
    i = 1
    for line in my_list_of_cols:
        # Fix the number of characters
        my_str_7_char = str(i)
        if len(my_str_7_char)< 8:
            my_str_in1 = str((7-len(my_str_7_char) )*"0")+my_str_7_char
        
        # Open scoring_function_###.csv
        my_scoring_function_csv_fo = open(project_dir_string+"//Polscore//scoring_function_"+my_str_in1+".csv","w")
        my_test_function_csv_fo = open(project_dir_string+"//Polscore//scoring_function_"+my_str_in1+"_test.csv","w")
        aux_line2_out = ""
        
        for line1 in line:
            aux_line1_out = line1.replace(","," ")
            aux_line2_out += aux_line1_out
            
        # Get the right headers for each polynomial scoring function 
        my_new_headers = get_headers_3vars(aux_line2_out,h_x1,h_x2,h_x3,h_x1x2,h_x1x3,h_x2x3,h_x1_2,h_x2_2,h_x3_2)
        
        # Recover binary to get the number of independent variables (count_ind_var_in)
        my_new_bin0 = bin(i)
        my_new_bin1 = str(my_new_bin0.replace("b","1"))
        count_ind_var_in = my_new_bin1.count("1") -1 
        
        # Write line to polscore.in
        my_polscore_in_fo.write("POLSCORE,scoring_function_"+my_str_in1+".csv,"+\
                                str(count_ind_var_in)+",LinearRegression\n")
        
        # Write headers    
        my_scoring_function_csv_fo.write(my_new_headers)
        my_test_function_csv_fo.write(my_new_headers)       
        
        # Looping through arrays to write data
        for j in range(  len(my_big_array[0])  ):
            my_biggest_line = ""
            if "1" in aux_line2_out:
                my_biggest_line += str(my_big_array[0][j])+","
            if "2" in aux_line2_out:
                my_biggest_line += str(my_big_array[1][j])+","
            if "3" in aux_line2_out:
                my_biggest_line += str(my_big_array[2][j])+","
            if "4" in aux_line2_out:
                my_biggest_line += str(my_big_array[3][j])+","
            if "5" in aux_line2_out:
                my_biggest_line += str(my_big_array[4][j])+","
            if "6" in aux_line2_out:
                my_biggest_line += str(my_big_array[5][j])+","
            if "7" in aux_line2_out:
                my_biggest_line += str(my_big_array[6][j])+","
            if "8" in aux_line2_out:
                my_biggest_line += str(my_big_array[7][j])+","
            if "9" in aux_line2_out:
                my_biggest_line += str(my_big_array[8][j])+","
                
            my_biggest_line += str(my_big_array[9][j])  # Binding affinity
            
            # Looping through my_test
            for test_i in my_test:
                test_0 = str(test_i)
                test_1 = test_0.replace(" ","")
                if str(test_1) == str(j):
                    my_test_function_csv_fo.write(my_biggest_line+"\n")
            
            # Looping through my_test
            for test_i in my_train:
                test_0 = str(test_i)
                test_1 = test_0.replace(" ","")
                if str(test_1) == str(j):
                    my_scoring_function_csv_fo.write(my_biggest_line+"\n")
                    
        my_scoring_function_csv_fo.close()
        my_test_function_csv_fo.close()        
        i+=1
    
    print("\nDone!\n")
    my_polscore_in_fo.close()
    
    # Call clear_sandres_info_file_txt
    clear_sandres_info_file_txt()
    
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n\n\n" 
    
    # Show message
    window_txt.insert(0.0,"\n\nA total of 511 csv files have been written on\n "+project_dir_string+\
                      "\Polscore directory. \nNew polscore.in file has been generated!"+my_tail)
    
    # Instantiating an object of the Backup() class and assign it to b1
    b1 = back_csv.Backup()
    
    # Invoking make_copy method using project_dir_string and "training_set.csv" as arguments
    b1.make_copy(project_dir_string,"training_set.csv")
    
    # Invoking make_copy method using project_dir_string and "test_set.csv" as arguments
    b1.make_copy(project_dir_string,"test_set.csv")

def pre_newcsvfiles():
    """Function to call the right function for the number of independent variables"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor, top_columns_entry,\
    top_number_of_variables, headers
    
    # Get number of independent variables
    my_number_of_var = 3
    
    if my_number_of_var == 3:
        newcsvfiles_3vars()
        # Call show_message_in_sandres()
        show_message_in_sandres("Done! SAnDReS finished generating Polscore CSV files!","black","light grey")
    else:
        print("SAnDReS Warning! Number of independent variables should be 3!")
        messagebox.showwarning("SAnDReS Warning!", "Number of independent variables should be 3!")
        return
        
def newcsvfiles_3vars():
    """Function to generate new csv files for polscore using 3 independent variables"""
    
    # Import libraries
    import os
    import errno
    import csv
    import math
    
    # Set empty lists
    exp_list = []
    my_sorted_exp_list = []
    lig_list = []
    my_headers_out = []
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor, top_columns_entry,\
    top_number_of_variables, headers
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function csv file
    my_new_csv_score_file = str(input_score_csv_file_entry.get())
    
    # Try to open chklig.in to experimental binding affinity
    try:
        my_chklig_fo = open(project_dir_string+"chklig.in","r")
        my_chklig_csv_fo = csv.reader(my_chklig_fo)
    except:
        print("\nI can't find chklig.in!")
        return
    
    # For first line only
    for line in my_chklig_csv_fo:
        my_aux_line_chklig0 = str(line)
        my_aux_line_chklig1 = my_aux_line_chklig0.replace("'","")
        my_aux_line_chklig2 = my_aux_line_chklig1.replace("[","")
        my_aux_line_chklig3 = my_aux_line_chklig2.replace("]","")
        
        my_binding_type = str(my_aux_line_chklig3[30:].upper())
        break
    # For "k" binding types it is True
    if "K" in my_binding_type or "IC" in my_binding_type:
        my_binding_flag = True
    else:
        my_binding_flag = False
        
    # Looping through the rest oc csv file
    for line in my_chklig_csv_fo:
        if my_binding_flag:
            exp_list.append(  str( -9 + math.log10(float(line[5])))  ) # Log(K) for K's (minus 9 here)
        else:
            exp_list.append(line[5])
        lig_list.append(line[2])
    
    my_chklig_fo.close()
    
    # Get num_var and cols
    num_var = "3"
    
    # Get columns
    cols = top_columns_entry.get()
    my_columns = []
    my_aux_cols0 = cols.replace("[","")
    my_aux_cols1 = my_aux_cols0.replace("]","")
    my_aux_cols = my_aux_cols1.replace("'","")
    my_number = ""
    
    # Looping through columns
    for line in my_aux_cols:
        if line == ",":
            my_columns.append(my_number)
            my_number = ""
            continue
        else:
            my_number+=line
    
    my_columns.append(my_number)
    
    # Try to open csv file
    try:
        my_data_fo = open(project_dir_string+my_new_csv_score_file,"r")
        my_data_csv_fo = csv.reader(my_data_fo)
    except IOError:
        print("\nI can't find "+project_dir_string+my_new_csv_score_file)
        return
    
    # Get first line
    for line in my_data_csv_fo:
        for line1 in line:
            my_headers_out.append(line1)
        break
    
    my_data_fo.close()
    
    print("\n Selected scoring functions: ",my_headers_out[int(my_columns[0])-1],",",
          my_headers_out[int(my_columns[1])-1],",",my_headers_out[int(my_columns[2]) -1]    )
    print("\nNumber of independent variables: "+str(num_var))
    path = project_dir_string+"/Polscore/"
    
    # Try makedir
    try:
        os.makedirs(path)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise
    
    # Open polscore.in
    my_new_pol_fo = open(project_dir_string+"polscore.in","w")
    list_x0,list_x1,list_x2,list_x3 = read_old_csv_file()
        
    # Write first csv file
    my_new_csv_fo = open(path+"polscore_000000.csv","w")
    my_new_csv_fo.write(my_headers_out[ int(my_columns[0]) -1 ]+","+my_headers_out[ int(my_columns[1]) -1]+\
                        ","+my_headers_out[ int(my_columns[2]) -1]+",Binding Affinity\n")
    my_sorted_exp_list.append("Binding Affinity")
    for j in range(len(list_x1)):
        for my_lig in lig_list:
            try:
                if my_lig in list_x0[j]:
                    my_sorted_exp_list.append(exp_list[lig_list.index(my_lig) ])
                    my_new_csv_fo.write(list_x1[j]+","+list_x2[j]+","+list_x3[j]+","+\
                                        exp_list[lig_list.index(my_lig) ]+"\n")
                    break
            except:
                continue
            
    my_new_csv_fo.close()
    
    # For 3 independent variables
    for i in range(10):
        # Fix the number of characters
        my_str_6_char = str(i+1)
        if len(my_str_6_char)< 6:
            my_str_in = str((6-len(my_str_6_char) )*"0")+my_str_6_char
            my_csv_number = my_str_in # We must have three columns
            my_new_csv_file = "polscore_"+my_csv_number+".csv"
            #my_new_csv_fo = open(path+my_new_csv_file,"w")
            #my_new_csv_fo.write("Tests \n")
            my_new_pol_fo.write("POLSCORE,"+my_new_csv_file+"\n")        
            #my_new_csv_fo.close()
    my_new_pol_fo.close()
    
    # Call make_scoring_function_csv_3_var()
    make_scoring_function_csv_3_var(list_x1,list_x2,list_x3,my_sorted_exp_list)

def read_old_csv_file():
    """Function to read specific columns in a csv file"""
    
    # Import library
    import csv
    
    # Set up empty lists
    x0 = []
    x1 = []
    x2 = []
    x3 = []
    my_columns = []
    
    # Get columns
    cols = top_columns_entry.get()
    
    my_aux_cols0 = cols.replace("[","")
    my_aux_cols1 = my_aux_cols0.replace("]","")
    my_aux_cols = my_aux_cols1.replace("'","")
    my_number = ""
    for line in my_aux_cols:
        if line == ",":
            my_columns.append(my_number)
            my_number = ""
            continue
        else:
            my_number+=line
    
    my_columns.append(my_number) 
    
    num_var = "3"
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new scoring function csv file
    my_new_csv_score_file = str(input_score_csv_file_entry.get())
    
    my_file_fo =  open(project_dir_string+my_new_csv_score_file,"r")
    my_csv_fo = csv.reader(my_file_fo)
    
    if int(num_var) == 3:
        for line in my_csv_fo:
            print(line)
            try:
                x0.append(line[0])
                x1.append(line[ int(my_columns[0]) -1 ] )
                x2.append(line[ int(my_columns[1]) -1 ])
                x3.append(line[ int(my_columns[2]) -1 ] )
            except:
                continue
    
    my_file_fo.close()
    
    return x0,x1,x2,x3

def read_actives():
    """Function to read actives"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_decoy_entry, top_active_entry, top_active_percentage_entry
    
    my_active_file = top_active_entry.get()
    
    my_mol_id_actives = read_active_or_decoy_sdf("Actives",my_active_file)
    
    print("\nNumber of actives: "+str(len(my_mol_id_actives)))
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Number of actives: "+str(len(my_mol_id_actives)),"black","light grey")
    
def read_decoys():
    """Function to read decoys"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_decoy_entry, top_active_entry, top_active_percentage_entry
    
    my_decoy_file = top_decoy_entry.get()
    
    my_mol_id_decoys = read_active_or_decoy_sdf("Decoys",my_decoy_file)
    
    print("\nNumber of decoys: "+str(len(my_mol_id_decoys)))
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Number of decoys: "+str(len(my_mol_id_decoys)),"black","light grey")
    
def read_active_or_decoy_sdf(type_of_dataset,sdf_in):
    """Function to read sdf acitve or decoy files"""
    
    # Import library
    from tkinter import messagebox
    
    # Set up empty list for active and decoy molecules
    list_4_ids = []
    
    # Try to open sdf file
    try:
        my_fo = open(sdf_in,"r")
    except IOError:
        print("SAnDReS IOError! I can't find ",sdf_in) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+sdf_in)
        return
    
    my_mols_in = my_fo.readlines()
    
    count_mols = 0
    if type_of_dataset == "Actives":
        # Looping through sdf file
        for line in my_mols_in:
            if line[0:6] == "CHEMBL":
                count_mols += 1
                list_4_ids.append(line)
    elif type_of_dataset == "Decoys":
        # Looping through sdf file
        for line in my_mols_in:
            if line[0:4] == "ZINC":
                count_mols += 1
                list_4_ids.append(line)
    else:
        print("SAnDReS Error! Unrecognizable type of dataset!") 
        messagebox.showerror("SAnDReS Error! Unrecognizable type of dataset! ")
        return None
        
    return list_4_ids

def merge_sdf(active_sdf_in,decoy_sdf_in):
    """Function to merge active and decoy sdf files in one sdf file for VS"""
    
    # Import library
    import time
    
    # Set empty list for ligands
    my_merged_list = []

    # Set list for files
    my_sdf_list = []
    my_sdf_list.append(active_sdf_in)
    my_sdf_list.append(decoy_sdf_in)
    
    print("\nMerging files :")
    for line in my_sdf_list:
        print(line)

    # String for local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # looping through list of sdf files to be merged
    for line in my_sdf_list:
        my_fo = open(line,"r")
        my_lines = my_fo.readlines()
        # Looping through sdf file
        for line0 in my_lines:
            my_merged_list.append(line0)
        my_fo.close()
                   
    # Open new sdf file for the dataset
    dataset_fo = open("actives_decoys_"+my_local_time+".sdf","w")
    
    # Looping through my_sdf_list
    for line in my_merged_list:
        dataset_fo.write(line)
    
    print("\nDone with merging!")
    # Close dataset file
    dataset_fo.close()

def gen_actives_and_decoys(my_final_decoys_list,my_active_file_in,my_decoy_file_in):        
    """Function to generate a sdf file with selected decoys and actives"""
    
    # Import library
    import time
    
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Set empty list for whole dataset
    dataset_list = []
    
    # Fist actives
    # Try to open actives
    try:
        my_fo = open(my_active_file_in,"r")
    except IOError:
        print("\nI can't find file "+my_active_file_in)
        return
    
    my_lines =  my_fo.readlines()
    
    # Looping through lines of sdf file for active molecules
    print("\nWriting actives...")
    for line in my_lines:
        dataset_list.append(line)
    
    # Jump row for decoys for dude dataset
    #dataset_list.append("\n")
    
    # Close active file
    my_fo.close()
    
    print("\nDone!")
    # Now decoys
    # Try to open decoys
    try:
        my_fo = open(my_decoy_file_in,"r")
    except IOError:
        print("\nI can't find file "+my_decoy_file_in)
        return
    
    my_lines =  my_fo.readlines()
    
    print("\nWriting decoys...")
    
    # Looping through lines of sdf file for decoy molecules
    count_lines = 0
    ligand_found = False
    for line in my_lines:
        line_aux = line.replace(" ","")
        if line_aux[0:4] == "$$$$" and ligand_found:
            ligand_found = False
            dataset_list.append("$$$$\n")
        if ligand_found:
            dataset_list.append(line)
        if line_aux in my_final_decoys_list:
            count_lines += 1
            my_final_decoys_list.pop(my_final_decoys_list.index(line_aux))
            dataset_list.append(line)
            ligand_found = True
    
    my_fo.close()
    
    print("\nTotal number of decoys identified in the file ",my_decoy_file_in,": ",count_lines)
    
    # Write final file
    my_composed_dataset_fo = open(project_dir_string+"active_plus_decoys_"+my_local_time+".sdf","w")
    for line in dataset_list:
        # Try to avoid "$$$$ZINC" or "$$$$CHEMBL" in the output file
        if "$$$$ZINC" in line or "$$$$CHEMBL" in line:  
            my_composed_dataset_fo.write("$$$$\n")
            my_composed_dataset_fo.write(line[4:])
        else:
            my_composed_dataset_fo.write(line)
    
    my_composed_dataset_fo.close()
    
    print("\nNew dataset in active_plus_decoys_"+my_local_time+".sdf file!\n")
    
    # Call show_message_in_sandres()
    show_message_in_sandres("New dataset in active_plus_decoys_"+my_local_time+".sdf file!","black","light grey")
    
    print("\nDone!")
    
def gen_list_4_sandres_active_decoy_dataset(active_san_in,decoy_san_in,num_actives,num_decoys,perc_in):
    """Function to get list of decoys to be added to active + decoy file"""
    
    # perc_in (0-1) is percentage of actives in the final active+decoy file
    
    # Import library
    import numpy as np 

    working_decoy_list = decoy_san_in
    list_out = []
    total_of_mols = int((1/perc_in)*num_actives)
    print("\nGenerating dataset with ",total_of_mols," molecules...\n")
    count_mols = num_actives
    while count_mols < total_of_mols:
        my_random1 = np.random.rand()
        my_random_line = int(my_random1*len(decoy_san_in))
        line = working_decoy_list[my_random_line]
        if line not in list_out:
            list_out.append(line)
            count_mols += 1
    
    print("\nDone!")
    print("\nNumber of molecules selected from decoy dateset: ",len(list_out))
    
    return list_out

def gen_sdf_dataset():
    """Function to generate merged file with actives and decoys"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_decoy_entry, top_active_entry, top_active_percentage_entry
    
    # Get entry values
    my_active_file = top_active_entry.get()
    my_decoy_file = top_decoy_entry.get()
    my_perc_in1 = float(top_active_percentage_entry.get())/100.0
    
    # Call all functions
    my_mol_id_actives = read_active_or_decoy_sdf("Actives",my_active_file)
    my_mol_id_decoys = read_active_or_decoy_sdf("Decoys",my_decoy_file)
    merge_sdf(my_active_file,my_decoy_file)
    my_list = gen_list_4_sandres_active_decoy_dataset(my_mol_id_actives,my_mol_id_decoys,\
                                           len(my_mol_id_actives),\
                                           len(my_mol_id_decoys),my_perc_in1)
    
    gen_actives_and_decoys(my_list,my_active_file,my_decoy_file)
    
def prep_dataset():
    """Function to prepare dataset with actives and decoys"""
    
    # Import library
    from tkinter import messagebox

    # Defines global variables to allow access with different functions
    global top_txt, top_decoy_entry, top_active_entry, top_active_percentage_entry
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Prepare Dataset with Actives and Decoys",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    
    # Try to open last_active_dataset.in
    try:
        my_active_fo = open(project_dir_string+"last_active_dataset.in")
    except IOError:
        print("I can't find ",project_dir_string+"last_active_dataset.in")
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                                 "last_active_dataset.in \nPlease check file name!")
        return
    
    # Read last_active_dataset.in
    my_file_4_actives = my_active_fo.readline()
    my_active_fo.close()
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
      
    my_active_file = project_dir_string+my_file_4_actives
    
    # Widgets for actives
    Label(top_txt, text="Actives:" ).grid(row = 2,column = 0, stick = W)   
    top_active_entry = Entry(top_txt,width = 90) 
    top_active_entry.grid(row = 2, column = 0,stick = E)
    top_active_entry.insert(10,my_active_file)
    # WFA 2018 01 09
    my_decoy_file = sandres_root+"Ligands/cdk2/decoys_final.sdf"
    # Widgets for decoys
    Label(top_txt, text="Decoys:" ).grid(row = 3,column = 0, stick = W)   
    top_decoy_entry = Entry(top_txt,width = 90)
    top_decoy_entry.grid(row = 3, column = 0,stick = E)
    top_decoy_entry.insert(10,my_decoy_file)
    
    # Widget for empty label to be included
    Label(top_txt, text=196*" ").grid(row = 4, column = 0, stick = W)
    
    # Widgets for percentage of actives
    Label(top_txt, text="Percentage(%) of Actives:" ).grid(row = 5,column =2, stick = W)   
    top_active_percentage_entry = Entry(top_txt,width = 4)
    top_active_percentage_entry.grid(row = 5, column = 3,stick = E)
    top_active_percentage_entry.insert(10,"10.0")
    
    
    # Widget for empty label to be included
    Label(top_txt, text=196*" ").grid(row = 6, column = 0, stick = W)
    
    # Buttons
    Button(top_txt, text='Count Actives ', command=read_actives).grid(row = 2, column = 2, \
                                                                            sticky = W)  
    Button(top_txt, text=' Import ', command=import_active_file).grid(row = 2, column = 2, \
                                                                            sticky = E)
    Button(top_txt, text='Count Decoys ', command=read_decoys).grid(row = 3, column = 2, \
                                                                            sticky = W)
    Button(top_txt, text=' Import ', command=import_decoy_file).grid(row = 3, column = 2, \
                                                                            sticky = E)
    Button(top_txt, text='Generate Dataset', command=gen_sdf_dataset).grid(row = 7, column = 2, \
                                                                            sticky = W)  
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2, \
                                                                               sticky = E)  
    
def gen_two_cols_score(my_score_in,my_col_in):
    """Function to generate two column score csv file"""
    
    # Import library
    import csv
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())

    # Set empty lists
    new_lig_list = []
    score_list = []

    # Try to open csv file
    try:
        my_fo = open(my_score_in,"r") 
        my_csv = csv.reader(my_fo)
    except:
        print("I cant't find file "+my_score_in+"\n\n")
        return

    # Get first line
    for line in my_csv:
        new_lig_list.append(line[0])
        score_list.append(line[ my_col_in - 1  ])
        break

# Looping through the rest of the csv file
    for line in my_csv:
        for i in range(100):
            # Fixes the number of characters with zeros
            my_str_id = str(i)
            my_str_2_char = str(my_str_id)
            if len(my_str_2_char)< 3:
                my_str_id = str((2-len(my_str_2_char) )*"0")+my_str_2_char
            my_probe = "["+my_str_id+"]"
            if my_probe in line[0]:
                my_new_line = line[0].replace("["+my_str_id+"]","")
                new_lig_list.append(my_new_line)
                score_list.append(line[int(my_col_in) -1 ])
                break

    my_fo.close()

    # Open new csv file for two columns only
    my_str_id = str(my_col_in)
    my_str_3_char = str(my_col_in)
    if len(my_str_3_char)< 4:
        my_str_id = str((3-len(my_str_3_char) )*"0")+my_str_3_char
    my_fo = open(project_dir_string+"score_col_"+my_str_id+".csv","w")

    for i in range(len(score_list) ):
        print(new_lig_list[i],score_list[i])
        line_out = new_lig_list[i]+","+str(score_list[i])+"\n"
        my_fo.write(line_out)

    my_fo.close()

def read_actives_from_csv(file_4_actives):
    """Function to read active molecules"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Set empty list for active molecules
    list_4_actives = []
    
    # Try to open csv file
    try:
        my_fo = open(file_4_actives,"r")
        my_csv = csv.reader(my_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",file_4_actives) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+file_4_actives)
        sys.exit()
    
    print("\nList of active molecules:")
    # Looping through csv file
    for line in my_csv:
        print(line[0])
        list_4_actives.append(line[0])
    
    my_fo.close()

    return list_4_actives

def read_scores(file_4_scores,my_col):
    """Function to read active molecules from csv file"""
    
    # Import libraries
    import csv
    import numpy as np
    from tkinter import messagebox
    
    # Set empty lists for scoring function values and binary_list
    list_4_scores = []
    bin_4_scores = []
    
    # Try to open scoring function csv file
    try:
        my_fo = open(file_4_scores,"r")
        my_csv = csv.reader(my_fo)
    except IOError:
        print("SAnDReS IOError! I can't find ",file_4_scores) 
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+file_4_scores)
        sys.exit()
    
    # For first line only
    for line in my_csv:
        my_header = line[int(my_col) - 1]
        break
            
    # Looping through the rest of csv file
    for line in my_csv:
        list_4_scores.append( (line[0],float(line[int(my_col)-1]) ) )
        if "CHEMBL" in line[0]:
            bin_4_scores.append(0)
        else:
            bin_4_scores.append(1)
    
    # Generate array for binaries
    y_true = np.array(bin_4_scores)
            
    my_fo.close()

    return my_header, list_4_scores, y_true

def get_tpr_fpr(actives_in, scores_in):
    """Function to calculate tpr and fpr"""

    tpr = [0.0]  # true positive rate
    fpr = [0.0]  # false positive rate
    nractives = len(actives_in)
    nrdecoys = len(scores_in) - len(actives_in)

    foundactives = 0.0
    founddecoys = 0.0
    
    # Looping thhrough scores_in to generate tpr and fpr lists
    for idx, (id1, score) in enumerate(scores_in):
        if id1 in actives_in:
            foundactives += 1.0
        else:
            founddecoys += 1.0

        tpr.append(foundactives / float(nractives))
        fpr.append(founddecoys / float(nrdecoys))

    return tpr, fpr

def setup_roc_curve_plot(plt):
    """Function to set up ROC Curve plot"""
    
    # Import library
    import matplotlib.pyplot as plt

    plt.xlabel("False Positive Rate", fontsize=14)
    plt.ylabel("True Positive Rate", fontsize=14)
    plt.title("ROC Curve", fontsize=14)

def gen_roc_curve_plot(plt, my_plot_in, my_dpi_in, randomline=True):
    """Function to generate ROC Curve plot"""
    
    # Import library
    import matplotlib.pyplot as plt

    if randomline:
        x = [0.0, 1.0]
        plt.plot(x, x, linestyle='dashed', color='black', linewidth=2, label='Random')

    plt.xlim(0.0, 1.0)
    plt.ylim(0.0, 1.0)
    plt.legend(fontsize=10, loc='best')
    plt.savefig(my_plot_in, dpi = my_dpi_in)

def add_roc_curve_2_plot(plt, my_actives, my_scores, my_color_in, my_label_in):
    """Function to add ROC Curve to plot (plt) """
    
    # Import library
    import matplotlib.pyplot as plt
    
    # Call get_tpr_fpr()
    tpr, fpr = get_tpr_fpr(my_actives, my_scores)
    
    # Plot
    plt.plot(fpr, tpr, color = my_color_in, linewidth = 2, label = my_label_in)
    
def add_ROC_Curve(actives, scores, label, color, dpi2, plot_file, randomline=True):
    """Function to compose plot"""
    
    # Import library
    import matplotlib.pyplot as plt
    
    plt.figure()
    
    # Call function setup_roc_curve_plot()
    setup_roc_curve_plot(plt)
    
    # Call function add_roc_curve_2_plot()
    add_roc_curve_2_plot(plt, actives, scores, color, label)
    
    # Call function gen_roc_curve_plot()
    gen_roc_curve_plot(plt, plot_file, dpi2,randomline)
    
def gen_roc_roll(file_4_actives_in,file_4_scores_in,col_4_scores_in,plot_name_in):
    """Function to generate ROC curve plot"""
    
    # Import libraries
    import numpy as np
    from sklearn.metrics import roc_auc_score
    from operator import itemgetter
    
    global top_dpi_entry, top_color_entry
    
    # Get dpi
    dpi1 = int(top_dpi_entry.get())
    
    # Get color
    color = str(top_color_entry.get())
    
    # Call function read_actives_from_csv()
    actives = read_actives_from_csv(file_4_actives_in)
    print("Number of active molecules %d found in %s" % (len(actives),file_4_actives_in))
    
    # Call function to read header and scoring function values
    label, scores, y_true = read_scores(file_4_scores_in,col_4_scores_in)
    print("Total number of molecules %d for %s found in %s" % (len(scores), label, file_4_scores_in))

    # Sort scoring function values
    sortedscores = sorted(scores, key=itemgetter(1))
    
    # Set empty list for scores
    my_scores = []
    
    # Looping through scores to generate list for scores
    for line in scores:
        my_scores.append(float(line[1]))
    
    # Make array for scores
    y_scores = np.array(my_scores)
    
    # Calculate AUC
    auc_in = roc_auc_score(y_true, y_scores)
    aux_auc_in = 100*auc_in
    auc_string = str(" ( AUC = %7.3f"%aux_auc_in)+" ) " 
    
    print("Generating ROC Curve ...")
    
    # Call function add_ROC_Curve()
    add_ROC_Curve(actives, sortedscores, label+auc_string, color, dpi1, plot_name_in)
    
    return auc_in

def calc_ef(lig_in,perc_in,n,a):
    """Function to calculate EF"""
    
    # Set initial values for varables
    ht = 0.0
    ha = 0.0
    
    # Looping through list for ef1
    n = n + a
    n_ef1 = round((perc_in/100.0)*n) 
    for i in range(n_ef1):
        line = lig_in[i]
        if "ZINC" in line:
            ht += 1.0
            
        elif "CHEMBL" in line:
            ha += 1.0
            
    # Calculate EF1
    if ht > 0 and a > 0:
        num1 = ha/ht
        den1 = a/n
        ef1 =  num1/den1
        return ef1
    else:
        ef1 = None
        return ef1
    
def gen_ef_stats(my_score_file):
    """Function to generate enrichment factors"""
    
    # Import library
    import csv
    
    # Try to open csv file
    my_fo = open(my_score_file,"r")
    my_csv_fo = csv.reader(my_fo)
    
    # Setup counts
    n = 0.0
    a = 0.0
    
    # Set empty lists
    all_ligs = []
    
    # Get first line
    for line in my_csv_fo:
        header = line[1]
        break
    
    # Looping through the rest tof the csv file
    for line in my_csv_fo:
        if "CHEM" in line[0]:
            a += 1.0
        elif "ZINC" in line[0]:
            n += 1.0
        all_ligs.append(line[0])
    
    # Call calc_ef() for EFs
    ef1 = calc_ef(all_ligs,1.0,n,a)
    ef2 = calc_ef(all_ligs,2.0,n,a)
    ef5 = calc_ef(all_ligs,5.0,n,a)
    ef10 = calc_ef(all_ligs,10.0,n,a)
    ef20 = calc_ef(all_ligs,20.0,n,a)
    
    return header,ef1,ef2,ef5,ef10,ef20

    my_fo.close()

def show_ef_stats():
    """Function to show EF statistical analysis"""
    
    # Show log file content on window_txt
    read_log_file("ef_stats.log")

def sort_csv1(my_csv_file_in,my_col_in):
    """Function to sort a csv file, my_col_in is an integer with col number (human version)"""
    
    # Import libraries
    import csv
    import os
    
    my_col =  int(my_col_in) - 1 # Python column number

    # Open csv file and sort by given column (my_col)
    with open(my_csv_file_in) as sample, open('tmp.csv', "w") as out:
        csv1 = csv.reader(sample)
        header = next(csv1, None)
        csv_writer = csv.writer(out)
        print("Headers: ")
        for line in header:
            print(line)
        print()
        csv_writer.writerows(sorted(csv1, key=lambda x:float(x[my_col])))

    # Close file
    out.close()

    # Re-open csv file
    my_fo = open('tmp.csv', "r")
    my_csv = csv.reader(my_fo)

    # Open new file for sorted csv file
    my_sorted_csv_fo = open(my_csv_file_in[:len(my_csv_file_in) -4]+"_sorted.csv","w")

    # Looping through csv file
    count_lines = 0
    aux_headers0 = str(header)
    aux_headers1 = aux_headers0.replace("[","")
    aux_headers2 = aux_headers1.replace("]","")
    aux_headers3 = aux_headers2.replace("'","")
    my_sorted_csv_fo.write(aux_headers3+"\n")
    for line in my_csv:
        if "ZINC" in str(line) or "CHEM" in str(line):
            my_line_out = line[0]+","+line[1]
            print(my_line_out)
            my_sorted_csv_fo.write(my_line_out+"\n")
            count_lines += 1
    
    print("\nNumber of lines read from csv file: ",count_lines)

    my_fo.close()
    
    # Remove tmp.csv
    os.remove("tmp.csv")

def pre_gen_all_ROC_Curves():
    """Function to call gen_all_ROC_Curves()"""
    
    # Call show_message_in_sandres()
    show_message_in_sandres(" SAnDReS is generating ROC curves","green","light grey")
    
    # Call aux GUI
    from tkinter import messagebox
    result = messagebox.askyesno("SAnDReS","Do you want to generate ROC Curves?")
        
    # If run is chosen
    if result:        
        # Call gen_all_ROC_Curves()
        gen_all_ROC_Curves()
        
def gen_all_ROC_Curves():
    """Function to call gen_two_cols_score() and gen_roc_roll()"""
    
    # Import library
    import csv
    
    global top_columns_entry
    
    # Set empty list
    my_list_4_col = []
    
    my_cols_here = list(top_columns_entry.get())
    my_number = ""
    
    # Looping through my_col_here to generate string numbers from top_columns_entry
    for line in my_cols_here:
        if line == "'":
            if len(my_number)>2:
                print(my_number)
                my_list_4_col.append(my_number)
            my_number = ""
        else:
            my_number += line
        
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get input file name from edit window
    string_input_file = str(top_inputfile_entry.get())
    
    # Generate act1.csv
    try:
        my_fo = open(project_dir_string+string_input_file,"r")
        my_csv_fo = csv.reader(my_fo)
    except IOError:
        print("\nI cant't find file "+string_input_file)
        return
    
    # Open act1.csv
    my_act_fo = open(project_dir_string+"act1.csv","w")
    
    # Looping through csv file to generate act1.csv for active ligands
    for line in my_csv_fo:
        if "CHEM" in line[0]:
            my_aux0 = line[0]
            my_index0 = my_aux0.index("CHEM")
            my_aux1 =  my_aux0[my_index0:]
            my_act_fo.write(my_aux1+"\n")
    
    my_fo.close()
    my_act_fo.close()
    
    # Looping through columns
    for line in my_list_4_col:
        line_aux0 = line.replace("[","")
        line_aux1 = line_aux0.replace("]","")
        line_aux2 = line_aux1.replace("'","")
        print(line_aux2)
        gen_two_cols_score(project_dir_string+string_input_file,int(line_aux2))
    
    my_ef_stats_fo = open(project_dir_string+"ef_stats.csv","w")
    my_ef_log_stat_fo = open(project_dir_string+"ef_stats.log","w")
    
    # Write first line
    my_line_out1 = "Scoring function,AUC(%),EF1,EF2,EF5,EF10,EF20\n"
    my_line_out2 = "Scoring function\t\t\tAUC(%)\tEF1   \tEF2   \tEF5    \tEF10   \tEF20  \n"
    my_ef_stats_fo.write(my_line_out1)
    my_ef_log_stat_fo.write(my_line_out2)
    

    # Looping through list to generate ROC Curves
    for line in my_list_4_col:

        my_score_file = project_dir_string+"score_col_"+str(line)+".csv"
        my_roc_roll = project_dir_string+"roc_curve_col_"+str(line)+".png"
                
        # Call function gen_roc_roll()
        auc = gen_roc_roll(project_dir_string+"act1.csv",my_score_file,"2",my_roc_roll)
                
        auc = 100.0*auc
        
        # Call sort_csv1()
        sort_csv1(my_score_file,2)
        
        # Call gen_stats
        score,ef1,ef2,ef5,ef10,ef20 = gen_ef_stats(my_score_file[:len(my_score_file) - 4]+"_sorted.csv")
        
        # Write my_line_out
        my_line_out1 = score+","+str(auc)+","+str(ef1)+","+str(ef2)+","+str(ef5)+","+str(ef10)+\
                    ","+str(ef20)+"\n"
        my_line_out2 = score+"\t\t\t"+str(auc)[0:6]+"\t"+str(ef1)[0:6]+"\t"+str(ef2)[0:6]+"\t"+\
                    str(ef5)[0:6]+"\t"+str(ef10)[0:6]+"\t"+str(ef20)[0:6]+"\t"+"\n" 
        my_ef_stats_fo.write(my_line_out1)
        my_ef_log_stat_fo.write(my_line_out2)
        print(my_line_out2)
    
    my_ef_stats_fo.close()
    my_ef_log_stat_fo.close()
    
    show_ef_stats()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating ROC curves","black","light grey") 

def update_csv_file_on_GUI():
    """Function to update CSV file on GUI"""
    
    # Import library
    import csv
    
    # Set up empty lists
    headers = []
    my_col_list = []
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_columns_entry,\
    top_header_entry
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new scoring function csv file
    my_new_csv_score_file = top_inputfile_entry.get()
    
    # Clear
    top_columns_entry.delete(0,END) 
    top_header_entry.delete(0,END)
    
    # Try to open csv file
    try:
        my_fo = open(project_dir_string+my_new_csv_score_file,"r")
        my_csv_fo = csv.reader(my_fo)
        for line in my_csv_fo:
            headers = line
            break
        my_fo.close()
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                                 my_new_csv_score_file+"\nPlease check file name!")
        return
    
    
    # Widgets for headers
    top_header_entry.insert(10,headers)
    
    # Looping range(2,len(headers)) to generate a list for colums
    for i in range(1,len(headers)):
        my_str_3_char = str(i+1)
        if len(my_str_3_char)< 4:
            my_str_id = str((3-len(my_str_3_char) )*"0")+my_str_3_char
        my_col_list.append(my_str_id)
        
    # Widgets for columns
    top_columns_entry.insert(10,my_col_list)
       
def par_2_ROC():
    """Function to read parameters to generate ROC curves"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_columns_entry,\
    top_header_entry, my_col_list, top_dpi_entry, top_color_entry
        
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new scoring function csv file
    my_new_csv_score_file = "decoy_results.csv"
          
    # Try to open csv file
    try:
        my_fo = open(project_dir_string+my_new_csv_score_file,"r")
        my_csv_fo = csv.reader(my_fo)
        for line in my_csv_fo:
            headers = line
            break
        my_fo.close()
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                                 my_new_csv_score_file+"\nPlease check file name!")
        return
    
    # Looping range(2,len(headers)) to generate a list for columns
    my_new_str = "["
    for i in range(1,len(headers)):
        my_str_3_char = str(i+1)
        if len(my_str_3_char)< 4:
            my_str_id = "'"+str((3-len(my_str_3_char) )*"0")+my_str_3_char+"',"
            my_new_str += my_str_id
        #my_col_list.append(my_str_id)
                
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x150+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Generate ROC Curves",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
    
    # Widgets for input file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 89) # it was 97
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,my_new_csv_score_file)
    
    # Widgets for headers
    Label(top_txt, text="Headers:" ).grid(row = 3,column = 0, stick = W)   
    top_header_entry = Entry(top_txt,width = 89) # it was 97
    top_header_entry.grid(row = 3, column = 0,stick = E)
    top_header_entry.insert(10,str(headers))
             
    # Widgets for columns
    Label(top_txt, text="Columns:" ).grid(row = 4,column = 0, stick = W)   
    top_columns_entry = Entry(top_txt,width = 89)
    top_columns_entry.grid(row = 4, column = 0,stick = E)
    top_columns_entry.insert(10,my_new_str[:len(my_new_str)-1]+"]")
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 5, column = 0, stick = W)
           
    # More buttons
    Button(top_txt, text='  Generate ROC Curves  ', command=pre_gen_all_ROC_Curves).grid(row = 4, column = 1, \
                                                                            sticky = W)  
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 4, column = 2, \
                                                                               sticky = W)  
                                                                               
    # Widgets for dpi
    Label(top_txt, text="DPI for Plot File:" ).grid(row = 2,column = 1, stick = W)   
    top_dpi_entry = Entry(top_txt,width = 5)
    top_dpi_entry.grid(row = 2, column = 1,stick = E)
    top_dpi_entry.insert(10,"600")
    
    # Widgets for Update CSV file   
    Button(top_txt, text='Update CSV file', command=update_csv_file_on_GUI).grid(row = 2, column = 2, \
                                                                               sticky = W)   

    # Widgets for color
    Label(top_txt, text="Color for Curves:" ).grid(row = 3,column = 1, stick = W)   
    top_color_entry = Entry(top_txt,width = 5)
    top_color_entry.grid(row = 3, column = 1,stick = E)
    top_color_entry.insert(10,"black")
    
def call_pre_newcsvfiles():
    """Function to call pre_newcsvfiles()"""
    
    # Call show_message_in_sandres()
    show_message_in_sandres(" SAnDReS is generating polynomial scoring functions","green","light grey")
    
    # Call aux GUI
    from tkinter import messagebox
    result = messagebox.askyesno("SAnDReS","Do you want to generate polynomial scoring functions?")
        
    # If run is chosen
    if result:        
        # Call pre_newcsvfiles()
        pre_newcsvfiles()

def gen_newcsv():
    """Function to prepare to generate new csv files"""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor, top_columns_entry,\
    top_header_entry, top_number_of_variables,headers, top_percentage_entry
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get new scoring function csv file
    my_new_csv_score_file = str(input_score_csv_file_entry.get() )
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Polynomial Scoring Functions",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
      
    # Try to open csv file
    try:
        my_fo = open(project_dir_string+my_new_csv_score_file,"r")
        my_csv_fo = csv.reader(my_fo)
        for line in my_csv_fo:
            headers = line
            break
        my_fo.close()
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                                 my_new_csv_score_file+"\nPlease check file name!")
        return
    
    # Widgets for input file name
    Label(top_txt, text="Headers:" ).grid(row = 2,column = 0, stick = W)   
    top_header_entry = Entry(top_txt,width = 94) # it was 97
    top_header_entry.grid(row = 2, column = 0,stick = E)
    top_header_entry.insert(10,headers)
    
    my_aux_list = ["7,","8,","13"]
    # Widgets for columns
    Label(top_txt, text="Columns:" ).grid(row = 3,column = 0, stick = W)   
    top_columns_entry = Entry(top_txt,width = 94)
    top_columns_entry.grid(row = 3, column = 0,stick = E)
    top_columns_entry.insert(10,my_aux_list)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 4, column = 0, stick = W)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 6, column = 0, stick = W)
    
    # More buttons
    Button(top_txt, text='Generate CSV Files', command=call_pre_newcsvfiles).grid(row = 3, column = 1, \
                                                                            sticky = W)  
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 8, column = 2, \
                                                                               sticky = W)  
    
    # Widgets for percentage of data in training set
    Label(top_txt, text="Training Set Percentage(%):" ).grid(row = 7,column = 1, stick = W)   
    top_percentage_entry = Entry(top_txt,width = 4)
    top_percentage_entry.grid(row = 7, column = 1,stick = E)
    top_percentage_entry.insert(10,"70.0")
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=5, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 3, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 5, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # Try to open input file
    try:
        my_info_input_file = open(project_dir_string+my_new_csv_score_file,"r")
    except IOError:
        print("I can't find ",project_dir_string+my_new_csv_score_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find "+\
                    project_dir_string+my_new_csv_score_file+" file! \nPlease check input file name!")
        return
        
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n\n\n" 
    
    # Reads input file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()  

def prep_read_binding_data():
    """Function to call read_binding_data"""
    
    # Defines global variables to allow access with different functions
    #global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    #top_inputfile_entry_chklig, top_inputfile_log_factor
    
    #global top_txt, top_inputfile_entry, top_inputfile_entry_score,\
    #top_inputfile_entry_chklig, top_inputfile_log_factor
    
    #global top_txt, top_inputfile_entry,top_inputfile_entry_chklig,\
    #top_inputfile_log_factor
    
    #global top_txt, top_inputfile_entry,top_inputfile_entry_chklig
    global top_txt, top_inputfile_entry

    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get scoring function file
    my_score_file_main_GUI1 = input_score_csv_file_entry.get() 
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Read and Add Binding Affinity to a CSV File",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
    
    # Widgets for input file name
    Label(top_txt, text="Input CSV File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 94)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,str(my_score_file_main_GUI1))
    
    # Widgets for buttons
    Button(top_txt, text='  Read  ', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 2, column = 1, sticky = E)

    # Get output file based on the input file name
    aux_out_score_file = my_score_file_main_GUI1.replace(".csv","_binding.csv")
    
    # Widgets for log factor
    Label(top_txt, text="Output CSV File:" ).grid(row = 3,column = 0, stick = W)   
    top_outputfile_entry = Entry(top_txt,width = 94)
    top_outputfile_entry.grid(row = 3, column = 0,stick = E)
    top_outputfile_entry.insert(10,aux_out_score_file)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 4, column = 0, stick = W)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 6, column = 0, stick = W)
    
    # Define function to run read_binding_data.py
    def run_read_binding_data():
        """Function to run read_binding_data.py"""
        
        # Import library
        import read_binding_data as rbd
        
        # Get file names
        file_in01 = top_inputfile_entry.get()
        file_out01 = top_outputfile_entry.get()
        
        # Instantiate an object of the Bind() class and assign it to e1
        e1 = rbd.Bind(project_dir_string,"chklig.in",file_in01,file_out01) 
    
        # Invoke read_csv() method
        e1.read_csv()
        
        # Invoke read_chklig() method
        e1.read_chklig()
        
        # Invoke add_bind() method
        e1.add_bind()
        
    # More buttons
    Button(top_txt, text='   Generate   ',command=run_read_binding_data).grid(row = 7, column = 1, \
                                                                            sticky = W)  
    Button(top_txt, text='  Save  ', command=save_edit_screen_to_input_file).grid(row = 7, column = 1,\
                                                                                  sticky = E)
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2, \
                                                                               sticky = W)  
    
        
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=5, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 5, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 5, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # Try to open my_score_file_main_GUI1 file 
    try:
        my_info_input_file = open(project_dir_string+my_score_file_main_GUI1,"r")
    except IOError:
        print("I can't find ",project_dir_string+my_score_file_main_GUI1)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+project_dir_string+\
                                 my_score_file_main_GUI1+"\nPlease check input file name!")
        return 
    
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n"       
    
    # Read input file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)


def dummy_stscor():
    """Function to generate dummy stscor.in file"""
        
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Create dummy stscor.in
    my_stscor_fo = open(project_dir_string+"stscor.in","w")
    
    # Write information in stscor.in file
    my_stscor_fo.write("# Input file for analysis of correlation between scoring functions and "+\
                        "experimental binding affinity\n")
    
    my_stscor_fo.write("CUTOFF,NTOR,40 \n")
    #STENSEMBLEDOCK,PDB Access Code, Ligand Code, Chain Id, Ligand Number,RMSD,Score1,Score2,Score3,...\n
    my_stscor_fo.write("""SCOREFUNC,Scoring Function Headers,,....
FACTORXLOG,LOG(C) 
STSCOR,PDB Access Code, Ligand Code, Chain Id, Ligand Number,Experimental Binding Affinity,Torsion,Score1,Score2,....\n""")
    
    my_stscor_fo.close()
    
    # Call gen_stscor
    gen_stscor()
     
def gen_stscor():
    """Function to generate input file stscor.in"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig, top_inputfile_log_factor
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435") 
    
    # Show Label with information about this GUI
    Label(top_txt, text="Analysis of Correlation Between Scoring Functions and Binding Affinity",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
    
    # Widgets for input file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 94)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,"stscor.in")
    
    # Widgets for buttons
    Button(top_txt, text='  Read  ', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 2, column = 1, sticky = E)
        
    # Widgets for log factor
    Label(top_txt, text="Binding Affinity:" ).grid(row = 3,column = 0, stick = W)   
    top_inputfile_log_factor = Entry(top_txt,width = 94)
    top_inputfile_log_factor.grid(row = 3, column = 0,stick = E)
    top_inputfile_log_factor.insert(10,"LOG(C)")
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 4, column = 0, stick = W)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 6, column = 0, stick = W)
    
    # More buttons
    Button(top_txt, text='   Generate   ', command=merge_stscor).grid(row = 7, column = 1, \
                                                                            sticky = W)  
    Button(top_txt, text='  Save  ', command=save_edit_screen_to_input_file).grid(row = 7, column = 1,\
                                                                                  sticky = E)
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2, \
                                                                               sticky = W)  
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=5, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 5, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 5, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # Try to open stscor.in file 
    try:
        my_info_input_file = open(project_dir_string+"stscor.in","r")
    except IOError:
        print("I can't find ",project_dir_string+"stscor.in")
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+project_dir_string+\
                                 "stscor.in"+"\nPlease check input file name!")
        return 
    
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n"       
    
    # Read input file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)

def dummy_stensembledock():
    """Function to create dummy stensembledock.in """
      
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Create dummy stensembledock.in
    my_stensembledock_fo = open(project_dir_string+"stensembledock.in","w")
    
    # Write information in stensembledock.in file
    my_stensembledock_fo.write("# Input file for analysis of correlation between docking (ensembledock) RMSD"+\
     " and scoring functions\n")
    
    my_stensembledock_fo.write("CUTOFF,NTOR,40 \n")
  
    my_stensembledock_fo.write("""SCOREFUNC,Scoring Function Headers,....
STENSEMBLEDOCK,PDB Access Code, Ligand Code, Chain Id, Ligand Number,RMSD,Score1,Score2,Score3,...\n""")
    
    my_stensembledock_fo.close()
    
    # Call gen_stensembledock
    gen_stensembledock()

def gen_stensembledock():
    """Function to generate input file stensembledock.in"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_inputfile_entry, top_strdir_entry,top_inputfile_entry_score,\
    top_inputfile_entry_chklig
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Analysis of Correlation Between Ensemble-Docking RMSD and Scoring Functions",\
           font = "Arial" ).grid(row = 0, column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1, column = 0, stick = W)
    
    # Widgets for input file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 105)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,"stensembledock.in")
    
    # Widgets for buttons
    Button(top_txt, text='  Read  ', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 2, column = 1, sticky = E)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 5, column = 0, stick = W)
    
    # More buttons
    Button(top_txt, text='   Generate   ', command=merge_stensembledock).grid(row = 7, column = 1,\
                                                                                       sticky = W)  
    Button(top_txt, text='  Save  ', command=save_edit_screen_to_input_file).grid(row = 7, column = 1,\
                                                                                   sticky = E)
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2,\
                                                                                sticky = W)  
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 6, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # Try to open stensembledock.in file 
    try:
        my_info_input_file = open(project_dir_string+"stensembledock.in","r")
    except IOError:
        print("I can't find ",project_dir_string+"stensembledock.in")
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+project_dir_string+\
                                 "stensembledock.in"+"\nPlease check input file name!")
        return 
    
    # mt_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n"       
    
    # Read input file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
        
def check_strdir():
    """Function to check strdir"""
    
    # Import libraries
    import os
    from tkinter import messagebox 
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Test if the directory exits
    dir = os.path.isdir(project_dir_string)
  
    # Check if dir is True
    if dir:
        print("\nThe "+project_dir_string+" exists!")
    else:
        print("\nPlease check directory and/or file name.")
        messagebox.showerror("SAnDReS IOError!",\
                             "I didn't find "+project_dir_string+" directory!"+\
                              "\nNew Project Directory set to: c:\sandres\ "+\
                              " \nYou may use \"Find\" button to browse for a new Project Directory!")
        
        # Update project dir
        project_dir_string = sandres_root
        clear_strdir_entry()
        strdir_entry.insert(10,sandres_root)
    
    return
    
def read_strdir():
    """Function to read project directory"""
    
    # Import libraries
    import csv
    from tkinter import messagebox 
    
    # Try to open stdir.in file in the project directory (STRDIR) from c:\sandres\inputs\
    try:
        f_strdir = open(sandres_root+"inputs\strdir.in","r")
        info_in_strdir = csv.reader(f_strdir) 
    except IOError:
        print("\nI can't find file C:\sandres\inputs\strdir.in")
        print("\nPlease check directory and/or file name.")
        messagebox.showerror("SAnDReS IOError!",\
                             "I can't find file C:\sandres\inputs\strdir.in"+\
                              "\nPlease check project directory!")
        return
    
    # Looping through the input file to get the project directory
    for line in info_in_strdir:
        if line[0][0:6].upper() == "STRDIR":
            project_dir_string = line[1].replace(" ","")            
        elif line[0][0:1] == "#":
            continue    # Do nothing
        else:
            sandres_line = "Unrecognizable command strdir.in"
            print(sandres_line)
            sys.exit()
    
    # Returns strdir
    return project_dir_string
    
def update_strdir():
    """Function to update project directory"""
    
    # Import libraries
    import shutil
    from tkinter import messagebox 
    
    # Call check_strdir()
    check_strdir()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
        
    # Open new project directory into c:\sandres\inputs\strdir.in
    f_strdir = open(sandres_root+"inputs\strdir.in",'w')
    f_strdir.write("STRDIR,"+project_dir_string+" \n") 
    f_strdir.close()
    
    # Show information about the update
    print("\nNew Project Directory: %s" % (project_dir_string ) ) 
    print("All structures and input files should be in the directory: %s" % (project_dir_string ))
    
    # Try to open showinfo.in into new project directory # WFA 2018 01 09
    try:
        f_showinfo = open(project_dir_string+"showinfo.in",'w')
        shutil.copy2(sandres_root+"inputs/copyin.in",project_dir_string+"copyin.in") 
        shutil.copy2(sandres_root+"inputs/sandres.in",project_dir_string+"sandres.in") 
    except IOError:
        messagebox.showerror("SAnDReS IOError!",\
                             "I can't find  "+project_dir_string+" directory!"\
                              "\nPlease check project directory!")
        print("SAnDReS IOError! I can't find file ",project_dir_string,"showinfo.in") 
        print("I've changed the project directory information into the file "+sandres_root+"inputs/strdir.in")
        print("New project directory is "+sandres_root)

        clear_strdir_entry()
        strdir_entry.insert(10,sandres_root)
        project_dir_string = sandres_root
        # WFA 2018 01 09
        fo = open(project_dir_string+"/inputs/"+"strdir.in","w")
        fo.write("STRDIR,"+sandres_root+" \n")
        fo.close()
        
        # Copy copyin.in and sandres.in files # WFA 2018 01 09
        f_showinfo = open(project_dir_string+"showinfo.in",'w')
        shutil.copy2(sandres_root+"inputs/copyin.in",project_dir_string+"copyin.in")
        shutil.copy2(sandres_root+"inputs/sandres.in",project_dir_string+"sandres.in")
        
    f_showinfo.write("SHOWINFO, \n") 
    f_showinfo.close()
    
    # Call About()
    About()
    
    show_message_in_sandres("Done! SAnDReS finished updating project directory!","black","light grey")

def update_top_strdir():
    """Function to update top project directory"""
    
    # Get new project directory
    project_dir_string = str(top_strdir_entry.get())
    
    # Open strdir.in into c:\sandres\inputs\strdir.in
    f_strdir = open(sandres_root+"inputs\strdir.in",'w')
    f_strdir.write("STRDIR,"+project_dir_string+" \n") 
    f_strdir.close()
    
    # Show information about the update
    print("\nNew Project Directory: %s" % (project_dir_string ) ) 
    print("All structures and input files should be in the directory: %s" % (project_dir_string ))
    
    # Try to open showinfo.in file into new project directory # WFA 2018 01 09
    try:
        f_showinfo = open(project_dir_string+"showinfo.in",'w')
    except IOError:
        print("SAnDReS IOError! I can't find file ",project_dir_string,"showinfo.in") 
        project_dir_string = sandres_root+"inputs/"
        my_strdir_info = open(project_dir_string+"strdir.in","w")
        my_strdir_info.write("STRDIR,"+project_dir_string)
        my_strdir_info.close()
        print("I've changed the project directory information into the file "+sandres_root+"inputs/strdir.in")
        print("New project directory is "+sandres_root+"inputs/")
        clear_strdir_entry()
        strdir_entry.insert(10,project_dir_string)
        f_showinfo = open(project_dir_string+"showinfo.in",'w')
        
    f_showinfo.write("SHOWINFO, \n") 
    f_showinfo.close()
    
    show_message_in_sandres("Done! SAnDReS finished updating project directory! New directory is "+\
                     project_dir_string,"black","light grey")

    # Updates information into main window
    clear_strdir_entry()
    strdir_entry.insert(10,project_dir_string)
    
    # Updates information into edit menu
    clear_top_strdir_entry()
    top_strdir_entry.insert(10,my_strdir_main_GUI)

def import_database_file(my_file_2_open):
    """Function to import any file from another dir than project dir"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, top_inputfile_entry, top_strdir_entry 
        
    # Try to open file
    try:
        my_info_input_file = open(my_file_2_open,"r")
    except IOError:
        print("I can't find ",my_file_2_open)
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+\
                                 my_file_2_open+"\nPlease check file name!")
        return 
       
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Fast Editor", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 110)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,my_file_2_open)
    
    # Widgets for buttons
    Button(top_txt, text='Save', command=save_edit_screen_to_input_file).grid(row = 2, column = 1, sticky = E)
    Button(top_txt, text='Read', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 6, column = 1, sticky = E)
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 6, column = 2, sticky = W)  
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=196*" " ).grid(row = 5,column = 0, stick = W) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 6, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()
         
def gen_edit_input_file(my_file_2_open):
    """Function to edit any file"""
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, top_inputfile_entry, top_strdir_entry 
    
    # Import library
    from tkinter import messagebox
            
    # Try to open file
    try:
        my_info_input_file = open(my_file_2_open,"r")
    except IOError:
        print("I can't find ",my_file_2_open)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                                 my_file_2_open+"\nPlease check input file name!")
        return 
       
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Fast Editor", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 110)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,my_file_2_open)
    
    # Widgets for buttons
    Button(top_txt, text='Save', command=save_edit_screen_to_input_file).grid(row = 2, column = 1, sticky = E)
    Button(top_txt, text='Read', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 6, column = 1, sticky = E)
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 6, column = 2, sticky = W)  
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=196*" " ).grid(row = 5,column = 0, stick = W) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 6, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()
    
def edit_input_file(my_file_2_open):
    """Function to edit any file"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, top_inputfile_entry, top_strdir_entry 
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open file
    try:
        my_info_input_file = open(project_dir_string+my_file_2_open,"r")
    except IOError:
        print("I can't find ",project_dir_string+my_file_2_open)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                                 project_dir_string+my_file_2_open+"\nPlease check input file name!")
        return 
       
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Fast Editor", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 110)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,my_file_2_open)
    
    # Widgets for buttons
    Button(top_txt, text='Save', command=save_edit_screen_to_input_file).grid(row = 2, column = 1, sticky = E)
    Button(top_txt, text='Read', command=read_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_top_txt).grid(row = 6, column = 1, sticky = E)
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 6, column = 2, sticky = W)  
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=196*" " ).grid(row = 5,column = 0, stick = W) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 6, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()
      
def open_my_sorted_csv_file():
    """Function to open sorted csv file"""
    
    # Call function edit_input_file()
    edit_input_file("sorted_polscore.csv")
    
def edit_vina_config_txt():
    """Function to edit vina config.txt file"""
    
    # Get dir and pdb access code information
    dir_vina_config_txt = vina_dataset_entry.get()
    file_vina_config_txt = run_vina_pdb_entry.get()
    
    # Call function gen_edit_input_file() # WFA 2018 01 09
    gen_edit_input_file(dir_vina_config_txt+"/"+file_vina_config_txt+"/config.txt")

def clear_editing_my_top_txt(): 
    """Function to clear txt content in editing window"""
    
    top_txt.delete(0.0,END) 
    
def read_my_input_file():
    """Function to read input file from edit window"""
    
    # Import library
    from tkinter import messagebox
    
    # Call clear_editing_top_txt()
    clear_editing_my_top_txt()
        
    # Get input file name from edit window
    string_input_file = str(top_inputfile_entry.get())
    
    # Try to open input file
    try:
        my_info_input_file = open(string_input_file,"r")
    except IOError:
        print("I can't find ",string_input_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                    string_input_file+"\nPlease check input file name!")
        return
            
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()   
    
def save_open_screen_to_input_file():
    """Function to save open input file content"""
          
    # Get input file name
    string_input_file = str(top_inputfile_entry.get()) 
    
    # Open input file
    my_info_input_file = open(sandres_root+string_input_file,"w")
     
    # Get input file content from txt window
    string_input_file_content = top_txt.get(0.0,END)
    
    # Write txt window content to input file
    my_info_input_file.write(string_input_file_content.strip())
    
    # Close updated input file
    my_info_input_file.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished updating input file!","black","light grey")

def open_my_input_file(file_in):
    """Function to open a input file"""
    
    global top_inputfile_entry, top_txt
    
    # Import library
    from tkinter import messagebox
        
    # Try to open file
    try:
        my_info_input_file = open(sandres_root+file_in,"r")
    except IOError:
        print("I can't find ",sandres_root+my_file_2_open)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                                 file_in+"\nPlease check input file name!")
        return 
       
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Fast Editor", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for file name
    Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)   
    top_inputfile_entry = Entry(top_txt,width = 110)
    top_inputfile_entry.grid(row = 2, column = 0,stick = E)
    top_inputfile_entry.insert(10,file_in)
    
    # Widgets for buttons
    Button(top_txt, text='Save', command=save_open_screen_to_input_file).grid(row = 2, column = 1, sticky = E)
    Button(top_txt, text='Read', command=read_my_input_file).grid(row = 2, column = 2, sticky = W)  
    Button(top_txt, text='Clear', command=clear_editing_my_top_txt).grid(row = 6, column = 1, sticky = E)
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 6, column = 2, sticky = W)  
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 3, column = 0, stick = W)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=196*" " ).grid(row = 5,column = 0, stick = W) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=4, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 6, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 4, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 
    
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()
    
def open_dpf():
    """Function to open docking.dpf"""
    
    # Call function edit_input_file()
    open_my_input_file("docking.dpf")
    
def edit_specific_file():
    """Function to edit a specific file"""
    
    my_file_main_GUI = input_csv_file_entry.get() 
    
    # Call function edit_input_file()
    edit_input_file(str(my_file_main_GUI))

def edit_score_file():
    """Function to edit score csv file"""
    
    # Call function edit_input_file()
    edit_input_file(input_score_csv_file_entry.get() )

def edit_ensembledock_file():
    """Function to edit ensembledock csv file"""
    
    # Call function edit_input_file()
    edit_input_file(input_ensemble_csv_file_entry.get())

def edit_redock_file():
    """Function to edit redock csv file"""
    
    # Call function edit_input_file()
    edit_input_file(input_csv_file_entry.get())

def import_active_file():
    """Function to import active file"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_decoy_entry, top_active_entry, top_active_percentage_entry
    
    my_active_file = top_active_entry.get()
    
    # Call function import_database_file()
    import_database_file(my_active_file)
    
def import_decoy_file():
    """Function to import decoy file"""
    
    # Defines global variables to allow access with different functions
    global top_txt, top_decoy_entry, top_active_entry, top_active_percentage_entry
    
    my_decoy_file = top_decoy_entry.get()
    
    # Call function import_database_file()
    import_database_file(my_decoy_file)
    
def edit_input_file_pltcsv():
    """Function to edit any input file pltcsv_##.in"""
    
    global pltcsv_file_entry
    
    file_in = pltcsv_file_entry.get()
    
    # Call function edit_input_file()
    edit_input_file(file_in)

def count_pdb_chklig_in():
    """Function to count structures in the chklig.in file"""
    
    # Import library (WFA 2018 01 11)
    import count_str_in_chklig as count_s
    
    # Get project directory (WFA 2018 01 11)
    project_dir_string = str(strdir_entry.get())
    
    # Instantiate an object of the CountStr() class (WFA 2018 01 11)
    num1 = count_s.CountStr(project_dir_string)
    
    # Call read_chklig() method (WFA 2018 01 11)
    num1.read_chklig()
    
    # Call count_pdb() method (WFA 2018 01 11)
    number_of_pdbs = num1.count_pdb()

    # Call show_message_in_sandres() (WFA 2018 01 11)
    show_message_in_sandres("Number of PDB files in the "+       
                            "chklig.in: "+str(number_of_pdbs),"black","light grey")
    
def edit_input_file_chklig():
    """Function to edit input file chklig.in"""
        
    # Call function edit_input_file()
    edit_input_file("chklig.in")
    
    # Call count_pdb_chklig_in()
    count_pdb_chklig_in() 
    
def edit_input_file_pltcsv0():
    """Function to edit input file pltcsv0.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv0.in")

def edit_input_file_pltcsv0A():
    """Function to edit input file pltcsv0A.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv0A.in")
    
def edit_input_file_pltcsv1():
    """Function to edit input file pltcsv1.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv1.in")

def edit_input_file_pltcsv1A():
    """Function to edit input file pltcsv1A.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv1A.in")

def edit_input_file_pltcsv2():
    """Function to edit input file pltcsv2.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv2.in")

def edit_input_file_pltcsv2A():
    """Function to edit input file pltcsv2A.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv2A.in")
    
def edit_input_file_pltcsv3():
    """Function to edit input file pltcsv3.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv3.in")

def edit_input_file_pltcsv3A():
    """Function to edit input file pltcsv3A.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv3A.in")

def edit_input_file_pltcsv4():
    """Function to edit input file pltcsv4.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv4.in")

def edit_input_file_pltcsv4A():
    """Function to edit input file pltcsv4A.in"""
    
    # Call function edit_input_file()
    edit_input_file("pltcsv4A.in")
    
def save_edit_screen_to_input_file():
    """Function to save edit input file content"""
      
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get input file name
    string_input_file = str(top_inputfile_entry.get()) 
    
    # Open input file
    my_info_input_file = open(project_dir_string+string_input_file,"w")
     
    # Get input file content from txt window
    string_input_file_content = top_txt.get(0.0,END)
    
    # Write txt window content to input file
    my_info_input_file.write(string_input_file_content.strip())
    
    # Close updated input file
    my_info_input_file.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished updating input file!","black","light grey")

def read_input_file():
    """Function to read input file from edit window"""
    
    # Import library
    from tkinter import messagebox
    
    # Call clear_editing_top_txt()
    clear_editing_top_txt()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get input file name from edit window
    string_input_file = str(top_inputfile_entry.get())
    
    # Try to open input file
    try:
        my_info_input_file = open(project_dir_string+string_input_file,"r")
    except IOError:
        print("I can't find ",project_dir_string+string_input_file)
        messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                    project_dir_string+string_input_file+"\nPlease check input file name!")
        return
            
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n" 
    
    # Read file content
    top_txt.insert(END,my_info_input_file.read()+my_tail)
    
    # Close input file        
    my_info_input_file.close()       

def read_input_file_chklig():
    """Function to read chklig.in from edit window"""
    
    # Import library
    from tkinter import messagebox
    
    # Call clear_editing_top_txt()
    clear_editing_top_txt()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get input file name from edit window
    string_input_file = "chklig.in"
    
    # Try to open input file
    try:
        my_info_input_file = open(project_dir_string+string_input_file,"r")
    except IOError:
        print("I can't find ",project_dir_string+string_input_file)
        project_dir_string = sandres_root+"inputs/" 
        print("I've changed the project directory to",project_dir_string)
        clear_strdir_entry()
        strdir_entry.insert(10,project_dir_string)
        print("Please update project directory as your needs!")
        
        try:
            my_info_input_file = open(project_dir_string+string_input_file,"r")
        except IOError:
            print("I can't find ",project_dir_string+string_input_file)
            print("Please edit strdir.in at "+sandres_root+"inputs/")
            messagebox.showerror("SAnDReS IOError!", "I can't find input file "+\
                                 project_dir_string+string_input_file+"\nPlease check input file name!")
            return 
        
    # Reads input file content
    top_txt.insert(END,my_info_input_file.read())
    
    # Close input file        
    my_info_input_file.close() 

def run_input_file():
    """Function to run input file"""
      
    # Get new input file
    string_input_file = str(inputfile_entry.get())
    
    # Get rid of sapces
    string_input_file = string_input_file.replace(" ","")
    
    # Call run_sandres_in()
    run_sandres_in(string_input_file)  
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running "+string_input_file,"black","light grey")  
    
def save_screen_to_input_file():
    """Function to Update input file content using txt as input"""
      
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get input file name
    string_input_file = str(inputfile_entry.get())
    
    # Open input file
    my_info_input_file = open(project_dir_string+string_input_file,"w")
     
    # Get input file content from txt window
    string_input_file_content = window_txt.get(0.0,END)
    
    # Write txt window content to input file
    my_info_input_file.write(string_input_file_content.strip())
    
    # Close updated input file
    my_info_input_file.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished updating input file!","black","light grey")
    
def clear_strdir_entry():
    """Function to clear strdir entry"""
    
    strdir_entry.delete(0,END)

def clear_top_strdir_entry():
    """Function to clear strdir entry in the editing window"""
    
    top_strdir_entry.delete(0,END)
    
def clear_inputfile_entry():
    """Function to clear input file entry"""
    
    inputfile_entry.delete(0,END)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS ready to go!","black","light grey")

def clear_input_csv_file_entry():
    """Function to clear input csv file entry"""
    
    input_csv_file_entry.delete(0,END)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished clearing input CSV file name!","black","light grey")

def clear_ensembledock_csv_file_entry():
    """Function to clear ensembledock csv file entry"""
    
    input_ensemble_csv_file_entry.delete(0,END)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished clearing ensembledock CSV file name!","black","light grey")
    
def clear_scores_all_csv_file_entry():
    """Function to clear input csv file entry"""
    
    input_score_csv_file_entry.delete(0,END)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished clearing score CSV file name!","black","light grey")

def clear_sandres_info_file_txt():
    """Function to clear txt content"""
    
    window_txt.delete(0.0,END)
    
def clear_editing_top_txt(): 
    """Function to clear txt content in editing window"""
    
    top_txt.delete(0.0,END) 
        
def prepare_input_4_strmsd_vina():
    """Function to clean csv file and write new strmsd.in file for Vina data"""
    
    # Import library
    from tkinter import messagebox
    
    # Set up empty list for redock_vina.csv
    my_vina_list = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Assigns input_csv_file_entry.get() to redock_csv_file_name
    redock_csv_file_name =  str(input_csv_file_entry.get())
    
    # Try to open files redock_csv_file_name and old_redock_file_name
    try:
        my_redock_file = open(project_dir_string+redock_csv_file_name,"r")
    except IOError:
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+redock_csv_file_name+\
                             " \nPlease check project directory!")
        print("I can't find file ",project_dir_string+redock_csv_file_name)
        return 
     
    # Looping through my_redock_file to get headers
    i = 0
    for line1 in my_redock_file:
        
        # Add line to a list to generate a new redock_vina0.csv file
        my_vina_list.append(str(line1))
        
        # Read headers
        if i == 0:
            my_header_4_pltcsv = line1
        i += 1
    
    # WFA 2018 01 26
    if "Affinity" in my_header_4_pltcsv:
        print("SAnDReS found Affinity as scoring function")
    else:
        print("No Affinity as scoring function!")
    
    # Open new redock_vina0.csv file
    my_new_redock_vina0 = open(project_dir_string+"redck_vina0.csv","w")
    
    # Looping through all lines but the last one of my_vina_list WFA 2018 01 26
    print("\nDocking results generated by AutoDock Vina")
    for line_vina in my_vina_list[:len(my_vina_list)-1]:
        print(line_vina)
        my_new_redock_vina0.write(str(line_vina))
        
    # Set initial values for variables to be used to identify headers from the first line of the csv file
    my_index0 = 0
    my_index1 = 0
    my_headers0 = []
    
    # Looping through first line of csv file to get headers to be added to pltcsv1.in file
    for my_char in my_header_4_pltcsv:
        if my_char == ";" or my_char == ",":
            my_index2 = my_index1
            my_headers0.append(my_header_4_pltcsv[my_index0:my_index2])
            my_index0 = my_index2+1
        my_index1 += 1
    my_headers0.append(my_header_4_pltcsv[my_index0:my_index1].strip()) 
    
    # Try to open strmsd.in file
    try:
        my_strmsd_file_in = open(project_dir_string+"strmsd.in","w")
    except IOError:
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                             " strmsd.in \nPlease check project directory!")
        print("I can't find file ",project_dir_string+"strmsd.in")
        return 
        
    # Start writing strmsd.in 
    my_strmsd_file_in.write("STRMSD,redck_vina0.csv")
                    
    # Write information into strmsd.in file
    my_index0 = 1
    for line1 in my_headers0[1:]: 
        my_strmsd_file_in.write(","+str(my_index0+1)+","+my_headers0[my_index0]) 
        my_index0 += 1
    my_strmsd_file_in.write("\nENDOF")
    
    # Close strmsd.in file
    my_strmsd_file_in.close()
        
    # Close files
    my_redock_file.close()
    my_new_redock_vina0.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating strmsd.in file!","black","light grey")
    
            
def prepare_input_4_strmsd():
    """Function to clean csv file and write new strmsd.in file"""
    
    # Import library
    from tkinter import messagebox
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Assigns input_csv_file_entry.get() to redock_csv_file_name
    redock_csv_file_name =  str(input_csv_file_entry.get())
    
    # Try to open files redock_csv_file_name and old_redock_file_name
    try:
        my_redock_file = open(project_dir_string+redock_csv_file_name,"r")
    except IOError:
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+redock_csv_file_name+\
                             " \nPlease check project directory!")
        print("I can't find file ",project_dir_string+redock_csv_file_name)
        return 
     
    # Looping through my_redock_file to get headers
    print("\nDocking results")
    i = 0
    for line1 in my_redock_file:
        print(line1)
        if i == 0:
            my_header_4_pltcsv = line1
        i += 1
    
    
    # Set initial values for variables to be used to identify headers from the first line of the csv file
    my_index0 = 0
    my_index1 = 0
    my_headers0 = []
    
    # Looping through first line of csv file to get headers to be added to pltcsv1.in file
    for my_char in my_header_4_pltcsv:
        if my_char == ";" or my_char == ",":
            my_index2 = my_index1
            my_headers0.append(my_header_4_pltcsv[my_index0:my_index2])
            my_index0 = my_index2+1
        my_index1 += 1
    my_headers0.append(my_header_4_pltcsv[my_index0:my_index1].strip()) 
    
    # Try to open strmsd.in file
    try:
        my_strmsd_file_in = open(project_dir_string+"strmsd.in","w")
    except IOError:
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+project_dir_string+\
                             " strmsd.in \nPlease check project directory!")
        print("I can't find file ",project_dir_string+"strmsd.in")
        return 
        
    # Start writing strmsd.in 
    my_strmsd_file_in.write("STRMSD,"+redock_csv_file_name)
                    
    # Write information into strmsd.in file
    my_index0 = 1
    for line1 in my_headers0[1:]: 
        my_strmsd_file_in.write(","+str(my_index0+1)+","+my_headers0[my_index0]) 
        my_index0 += 1
    my_strmsd_file_in.write("\nENDOF")
    
    # Close strmsd.in file
    my_strmsd_file_in.close()
        
    # Close files
    my_redock_file.close()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating strmsd.in file!","black","light grey")
    
            
def exit_function():
    """Function to write log file and exit"""
    
    # Import libraries
    import time
    from tkinter import messagebox
    
    my_local_time = str(time.strftime("%Y.%m.%d__%Hh%Mmin%Ss"))
    
    clear_inputfile_entry()
    
    inputfile_entry.insert(10,"showinfo.in")
    
    print("Finishing SAnDReS on ",my_local_time)
    
    # Call insert_showinfo_in()
    insert_showinfo_in()
    
    result = messagebox.askyesno("Continue?", "Do you wish to finish SAnDReS?")
    
    if result:    
        sys.exit()
    else:
        show_message_in_sandres("I'm back...","black","light green") 

def exit_function_4_mvd():
    """Function to exit"""
    
    # Import libraries
    import time
    from tkinter import messagebox
    
    my_local_time = str(time.strftime("%Y.%m.%d__%Hh%Mmin%Ss"))
    
    clear_inputfile_entry()
    
    inputfile_entry.insert(10,"showinfo.in")
    
    print("Finishing SAnDReS on ",my_local_time)
    
    # Call insert_showinfo_in()
    insert_showinfo_in()
    
    result = messagebox.askyesno("Continue?", "You must to finish SAnDReS to run a new MVD protocol.")
    
    if result:    
        sys.exit()
    else:
        show_message_in_sandres("I'm back...","black","light green") 
        
def show_message_in_sandres(my_input_2_show,my_color1,my_color2):
    """Function to show which task is running"""
    
    # Clear Label
    Label(root, text = 180*" " ,fg = my_color1,bg=my_color2,\
          font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)
    
    my_output_message1 = my_input_2_show.strip()
    len_string = len(my_output_message1)
    number_spaces = 50 - len_string 
    my_out_message2 = my_output_message1+number_spaces*" "
    
    # Creates Label
    Label(root, text = my_out_message2 ,fg = my_color1,bg=my_color2,\
          font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)
    
    # Print the same message
    print("\n"+my_input_2_show)
    
    return 
    
def read_help(my_info_in):
    """Function to read help file"""
    
    # Set up directory # WFA 2018 01 09
    my_help_fo = open(sandres_root+"help/help_sandres_1.txt","r")
    
    # Set string
    my_help_lines = ""
    
    # Looping through help file
    for line in my_help_fo:
        if my_info_in in line[0:len(my_info_in)]:
            print("Help for "+my_info_in+"\n")
            break
    
    # Looping through the rest of the help file
    for line in my_help_fo:
        if "***" in line:
            break
        print(line)
        my_help_lines += line
    
    my_help_fo.close()
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x250+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Help Information for "+my_info_in, font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)   
    
    # Widget for empty label to be included before widgets for txt 
    Label(top_txt, text=196*" ").grid(row = 2, column = 0, stick = W)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=196*" " ).grid(row = 4,column = 0, stick = W) 
    
    # Close button
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 5, column = 1, sticky = E) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=3, column = 3,sticky=W) 
    top_txt = Text(top_txt, width = 105, height = 7, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 3, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview)
    
    # my_tail adds new lines to text to be show
    my_tail = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n Press Close to Get Out from Help" 
    
    my_help_lines1 = my_help_lines+my_tail
    
    # Read input file content
    top_txt.insert(END,my_help_lines1)

def about_overview():
    """Function to show information about Overview"""
    
    read_help("Overview")

def about_version():
    """Function to show information about Version"""
    
    read_help("Version")

def about_sandres_paper():
    """Function to show information about SAnDReS Paper"""
    
    read_help("SAnDReS Paper")
    
def about_file():
    """Function to show information about File"""
    
    read_help("File")

def about_download():
    """Function to show help information about Download from PDB"""
    
    read_help("Download")

def about_predocking():
    """Function to show help information about Pre-docking"""
    
    read_help("Pre-Docking")

def about_docking():
    """Function to show help information about Docking"""
    
    read_help("Docking Hub")

def about_docking_results():
    """Function to show help information about Docking Results X Structural Parameters"""
    
    read_help("Structural Parameters")

def about_ensemble_docking():
    """Function to show help information about Ensemble-Docking Results"""
    
    read_help("Ensemble Docking")

def about_scoring_functions():
    """Function to show help information about Scoring Functions"""
    
    read_help("Scoring Functions")

def about_machine_learning_box():
    """Function to show help information about Build Scoring Functions"""
    
    read_help("Machine Learning Box")

def about_decoys():
    """Function to show help information about Decoys"""   
    
    read_help("Decoys")

def about_license():
    """Function to show help information about License"""   
    
    read_help("License")

def get_lig_from_csv1(my_file_in,my_col_in):
    """Function to get ligand information from a csv file and return as a list."""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Set initial values for a list
    my_list_in = []
    
    # Open file
    try:
        my_fo = open(my_file_in,"r")
        my_csv = csv.reader(my_fo)
    except IOError:
        print("I can't find file ",my_file_in)
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_file_in)
        return my_list_in

    # Looping through a csv file
    print("\nList of ligands found in the",my_file_in," file")
    
    # For the headers
    for line in my_csv:
        break
    
    count_lig = 0
    # For the rest of the file
    for line in my_csv:
        if line[my_col_in - 1][0:3] in my_list_in:
            print("More than one line for ligand!",line[my_col_in - 1][0:3])
        my_list_in.append(line[my_col_in - 1][0:3])
        print(line[my_col_in - 1][0:3])
        count_lig += 1

    print("I found ",count_lig," in the file ",my_file_in)

    # Close file
    my_fo.close()
    
    # Return list with ligands
    return my_list_in

def get_lig_from_csv2(my_file_in,my_col_in,my_char_in):
    """Function to get ligand information from a csv file and return as a list with a character to \
    specify position of the ligand."""
    
    # Import libraries
    import csv
    from tkinter import messagebox
    
    # Set initial values for list
    my_list_in = []

    # Open second file 
    try:
        my_fo = open(my_file_in,"r")
        my_csv = csv.reader(my_fo)
    except IOError:
        print("I can't find file ",my_file_in)
        messagebox.showerror("SAnDReS IOError!", "I can't find file "+my_file_in)
        return my_list_in
        
    print("\n\nList of ligand in the",my_file_in," file.\n")

    # Looping through a csv file
    # For the headers
    for line in my_csv:
        break
    
    count_lig = 0
    # For the rest of the file
    for line in my_csv:
        my_index = line[my_col_in - 1][0:8].find(my_char_in)
        my_string = line[my_col_in - 1][my_index+1:my_index+4]
        print(my_string)
        my_list_in.append(my_string)
        count_lig += 1
    print("Total number of ligands ",count_lig,"\n\n")
    
    # Close second file
    my_fo.close()
    
    # Return list
    return my_list_in

def compare_2_lists(my_csv_file_in,list1,list2):
    """Function to check if ligands in the list1 are present in the list2"""
    
    # Import library
    from tkinter import messagebox
    
    # Set initial value for count_lig
    count_lig = 0
    
    # Set initial list
    list_of_missing_lig = []
    
    # Double loop to identify ligands present in chklig.in and not in the csv file
    total_flag = False
    for line in list1:
        my_flag = True
        for lig in list2:
            if lig == line:
                my_flag = False
        if my_flag:
            print("Missing Ligand: ",line)
            list_of_missing_lig.append(line)
            count_lig += 1
            total_flag = True
    if total_flag:    
        print("\nTotal number of ligands not found", count_lig)
        print("SAnDReS: Ligand(s) missing! I can't find one or more ligands in the csv file!") 
        print("Please check ligands in the"+my_csv_file_in+" file!")
        messagebox.showwarning("SAnDReS Error!: Ligand missing!",\
                                "I can't find one or more ligands in the csv file!\
                                 \nPlease check ligands in the"+my_csv_file_in+" file!")
        return list_of_missing_lig
    else:
        print("\nNo missing ligands!\n")
        return None
    
def check_ligand_info(my_in_file,my_in_file_col,my_result_csv_file,my_result_file_col):
    """Function to check if all ligands in chklig.in are in a csv file"""
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Open missing_ligand.log
    my_missing_lig_fo = open(project_dir_string+"missing_ligand.log","w")
    
    # Call function get_lig_from_csv1()
    my_list_in1 = get_lig_from_csv1(my_in_file,my_in_file_col)
    
    # Return if SAnDReS can't find csv file
    if len(my_list_in1)>0:
        print()
    else:
        print("\nReturning to SAnDReS main GUI")
        return
    
    # Call function get_lig_from_csv2()
    my_list_in2 = get_lig_from_csv2(my_result_csv_file,my_result_file_col,"]")
    
    # Return if SAnDReS can't find csv file
    if len(my_list_in2)>0:
        print()
    else:
        print("\nReturning to SAnDReS main GUI")
        return

    # Call function compare_2_lists()
    my_list_of_missing_lig = compare_2_lists(my_result_csv_file,my_list_in1,my_list_in2)
    
    # To avoid TypeError
    try:
        my_aux_count = len(my_list_of_missing_lig)
    except TypeError:
        my_aux_count = 0
        clear_sandres_info_file_txt()

    if my_aux_count > 0:
        clear_sandres_info_file_txt()
        my_missing_lig_fo.write("List of missing ligand(s)\n")
        window_txt.insert(END, "List of missing ligand(s)\n")
        for line in my_list_of_missing_lig:
            my_missing_lig_fo.write("Ligand: "+line+"\n")
            window_txt.insert(END, "Ligand: "+line+"\n" )
    else:
        clear_sandres_info_file_txt()
        my_missing_lig_fo.write("No missing ligands!")
        window_txt.insert(END, "\nNo missing ligands!\n" )
    
    # Close missing_ligand.log
    my_missing_lig_fo.close()

def dir_chooser():
    """Function to return dir name to be open"""
    
    root = Tk()
    root.withdraw()
    dir_name = str(filedialog.askdirectory()  )
    #dir_name_windows = dir_name.replace("/","\\") # WFA 2018 01 09
    dir_name_windows = dir_name
    # Clear strdir
    clear_strdir_entry()
    
    # To avoid problems with void dir
    if dir_name == "":
        my_backup_strdir = strdir_entry.get()
        strdir_entry.insert(10,my_backup_strdir)
    else:
        # Insert new strdir
        strdir_entry.insert(10,dir_name_windows+"/")
    
    # Update strdir
    update_strdir()

def get_pdb_files_in_a_dir(dir_in):
    """Functions to get PDB file names in a given dir"""
    
    # Import library
    import glob
    
    # Get files in a dir # WFA 2018 01 09
    my_pdbs = glob.glob(dir_in+"/docked_Pose/*.pdb")
    
    # Call clear_gemdock_GUI()
    clear_gemdock_GUI()
    
    # Set up empty list
    my_files = []
    
    # Looping through PDB files # WFA 2018 01 09
    for line in my_pdbs:
        my_string = str(line)
        my_index = my_string.index("/") + 1
        my_string = my_string[my_index:]
        got_it = True
        
        # While loop to get file names # WFA 2018 01 09
        while got_it:
            my_key = "/"
            if my_key in my_string:
                my_index = my_string.index("/") + 1
                my_string = my_string[my_index:]
            else:
                my_files.append(my_string)
                break

    print("\nList of files found on "+dir_in+"/docked_Pose")  # WFA 2018 01 09
    for line in my_files:
        print(line)
    
    print("\nTotal number of PDB files : ",len(my_files))
    
    return my_files

def clear_vina_dataset_entry():
    """Function to clear vina_dataset_entry"""
        
    # Clear
    vina_dataset_entry.delete(0,END)

def clear_vina_command_entry():
    """Function to clear vina_command_entry"""
        
    # Clear
    vina_command_entry.delete(0,END)
    
def clear_gemdock_GUI():
    """Function to clear txt window"""
    
    # Defines global variables to allow access to variables from different functions
    global top_txt
    
    # Clear 
    top_txt.delete(0.0,END) 

def clear_gemdock_dir_entry():
    """Function to clear gemdock_dir_entry"""
    
    # Define global variable
    global gemdock_dir_entry
    
    # Clear
    gemdock_dir_entry.delete(0,END)

def show_gemdock_dir():
    """Function to show gemdock dir content"""
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, gemdock_dir_entry, strdir_entry, gemdock_dir_entry
    
    # Get new structure directory
    gemdock_dir = str(gemdock_dir_entry.get())
    
    # Call get_pdb_files_in_a_dir()
    pdbs = get_pdb_files_in_a_dir(gemdock_dir)
    
    # Looping through pdbs
    for line in pdbs:
        print(line)
        top_txt.insert(END,line+"\n")

def clear_gemdock_lig():
    """Function to clear ligand entry"""
    
    # Defines global variables to allow access to variables from different functions
    global ref_lig_entry
    
    # Clear 
    ref_lig_entry.delete(0,END) 

def clear_gemdock_results():
    """Function to clear gemdock result entry"""
    
    # Defines global variables to allow access to variables from different functions
    global gemdock_xls_entry
    
    # Clear 
    gemdock_xls_entry.delete(0,END) 

def clear_gemdock_csv():
    """Function to clear gemdock csv entry"""
    
    # Defines global variables to allow access to variables from different functions
    global csv_entry
    
    # Clear 
    csv_entry.delete(0,END) 



def clear_swissdock_ref_lig_entry():
    """Function to clear swissdock_ref_lig_entry"""
    
    # Clear swissdock_ref_lig_entry
    swissdock_ref_lig_entry.delete(0,END) 
    
def clear_swissdock_dir_entry():
    """Function to clear swissdock_dir_entry"""
    
    # Clear swissdock_dir_entry
    swissdock_dir_entry.delete(0,END) 
    
def clear_swissdock_pdb_entry():
    """Function to clear swissdock_pdb_entry"""
    
    # Clear swissdock_pdb_entry
    swissdock_pdb_entry.delete(0,END) 

def clear_sandres_csv_entry():
    """Function to clear sandres_csv_entryy"""
        
    # Clear sandres_csv_entry
    sandres_csv_entry.delete(0,END) 
    
def read_xls(file_in):
    """Function to read xls file""" 
    
    # Defines global variable to allow access to variables from different functions
    global gemdock_dir_entry
    
    my_dir = gemdock_dir_entry.get()
        
    # Read XLS file content
    my_xls =  open(my_dir+file_in,"r")
    
    # Set up empty list
    my_csv = []
    
    # Looping through my_xls
    for line in my_xls:
        line_out0 = line.replace("\t",",")
        line_out1 = line_out0.replace("\n","")
        my_csv.append(line_out1)
    
    my_xls.close()
        
    return my_csv

def read_PDB_swissdock(pdb_in):
    """Function to read atomic coordinates from a PDB file for swissdock results"""
    
    # Import library
    import numpy as np
        
    # Get project directory
    project_dir_string = str(swissdock_dir_entry.get())
        
    # Setup empty lists
    x = []
    y = []
    z = []
    
    # Try to open PDB file
    try:
        my_PDB_fo = open(project_dir_string+pdb_in,"r")
    except IOError:
        print("\nI can't file "+project_dir_string+pdb_in+" file!")
        print("\a")
        input("\nPress enter to continue!")
        return x,y,z
    
    # Looping through PDB file
    for line in my_PDB_fo:
        if line[0:6] == "HETATM" or line[0:6] == "ATOM  ":
            if line[13:14] != "H" and line[12:13] != "H":
                print(line)
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
    
    # Convert list to array
    x_coord = np.array(x)
    y_coord = np.array(y)
    z_coord = np.array(z)
    
    # Return arrays
    return x_coord, y_coord, z_coord
    
def read_PDB_return_coord(pdb_in):
    """Function to read atomic coordinates from a PDB file"""
    
    # Defines global variables to allow access to variables from different functions
    global ref_lig_entry, gemdock_dir_entry
    
    # Import library
    import numpy as np
    
    my_dir = gemdock_dir_entry.get()
        
    # Setup empty lists
    x = []
    y = []
    z = []
    
    # Try to open PDB file # WFA 2018 01 09
    try:
        my_PDB_fo = open(my_dir+"/docked_Pose/"+pdb_in,"r")
    except IOError:
        print("\nI can't file "+my_dir+"/docked_Pose/"+pdb_in+" file!")
        print("\a")
        input("\nPress enter to continue!")
        return x,y,z
    
    # Looping through PDB file
    for line in my_PDB_fo:
        if line[0:6] == "HETATM" or line[0:6] == "ATOM  ":
            if line[13:14] != "H":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
    
    # Convert list to array
    x_coord = np.array(x)
    y_coord = np.array(y)
    z_coord = np.array(z)
    
    # Return arrays
    return x_coord, y_coord, z_coord


def calc_swissdock_rmsd(x1,y1,z1,x2,y2,z2):
    """Function to calculate RMSD from swissdock results"""
    
    # Import library
    import math
    
    # Set count to zero
    sum_d2 = 0
    
    # Assign len(x1) to n (size of array)
    n =  len(x1)
    
    # Looping through all atomic coordinates to calculate sum of d2
    for i in range(n):
        # Calculate the square of Euclidian distance between two points
        d2 =  ( x1[i] - x2[i] )**2 + (y1[i] - y2[i])**2 + (z1[i] - z2[i])**2
        sum_d2 += d2
    
    # If n> 0 calculate rmsd
    if n >= 0 :
        rmsd = math.sqrt(sum_d2/n)
    else:
        rmsd =  None

    # Return rmsd
    return rmsd
    
def calc_rmsd(x1,y1,z1,x2,y2,z2):
    """Function to calculate RMSD"""
    
    # Import library
    import math
    
    # Set count to zero
    sum_d2 = 0
    
    # Assign len(x1) to n (size of array)
    n =  len(x1)
    
    # Looping through all atomic coordinates to calculate sum of d2
    for i in range(n):
        # Calculate the square of Euclidian distance between two points
        d2 =  ( x1[i] - x2[i] )**2 + (y1[i] - y2[i])**2 + (z1[i] - z2[i])**2  
        sum_d2 += d2
    
    # If n> 0 calculate rmsd
    if n > 0 :
        rmsd = math.sqrt(sum_d2/n)
    else:
        rmsd =  None
    
    # Return rmsd
    return rmsd

def read_write_gem_csv_file(csv_in,my_pdb_in,my_rmsd_in,csv_out):    
    """Function to read and write new csv file"""
    
    # Defines global variable to allow access to variables from different functions
    global gemdock_dir_entry
    
    # Set up dir
    my_dir = gemdock_dir_entry.get()
    
    # Get new structure directory
    string_strdir = str(strdir_entry.get())
        
    # Set up empty list
    list_out = []
    
    # Looping through my_csv
    for line in csv_in:
        
        # Take care of the header
        if "Ligand" in line[0]:
            continue
        
        # Take care of the rest of the data    
        if "#" not in line[0]:
            i = 0
            # Looping through pdb codes in the my_pdb_in
            for pdb in my_pdb_in:
                my_aux_line0 = str(line)
                if pdb in my_aux_line0:
                    my_aux_line1 = my_aux_line0.replace("\t",",")
                    my_aux_line2 = my_aux_line1.replace("[","")
                    my_aux_line3 = my_aux_line2.replace("]","")
                    line_out0 = my_aux_line3+","+str("%6.3f"%my_rmsd_in[i])
                    line_out1 = line_out0.replace("'","")
                    list_out.append(line_out1)
                i += 1
    
    # Open csv file    
    my_fo2 = open(my_dir+csv_out,"w")
    
    # Write first row
    my_header2 = csv_in[1].replace("#","")
    my_header3 = my_header2+"RMSD"
    my_header4 = my_header3.replace("'","")
    my_fo2.write(my_header4+"\n")
    
    # Looping through list_out
    for line in list_out:
        my_fo2.write(line+"\n")
    
    print("\nNew CSV file has been written with RMSD data: ",csv_out)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("New CSV file has been written with RMSD data: "+csv_out,"black","light grey")
    
    # Close files
    my_fo2.close()
   
def gen_gemdock_csv():
    """Function to generate gemdock csv file"""
    
    # Import library
    import shutil
    
    # Defines global variables to allow access to variables from different functions
    global strdir_entry, gemdock_xls_entry, csv_entry,gemdock_dir_entry
    
    file_in = gemdock_xls_entry.get()
    
    # Get new structure directory
    string_strdir = str(strdir_entry.get())
    
    # Set up dir
    my_dir = gemdock_dir_entry.get()
    
    # Copy crystallogrophic position to docked_Pose directory
    my_ref_gem_lig_aux = str(ref_lig_entry.get())
    my_ref_gem_lig = my_ref_gem_lig_aux.replace(" ","")
    print(my_ref_gem_lig)
    print(string_strdir)
    try:    # WFA 2018 01 09
        shutil.copy2(string_strdir+my_ref_gem_lig,string_strdir+"docked_Pose/"+my_ref_gem_lig)
    except:
        print()
    
    # Call read_xls()
    my_csv = read_xls(file_in)
        
    # Call read_PDB_return_coord() to get atomic coordinates as arrays
    pdb_in0 = ref_lig_entry.get()
    pdb_in = pdb_in0.replace(" ","")
    x1,y1,z1 = read_PDB_return_coord(pdb_in)
        
    # Call get_pdb_files_in_a_dir()
    my_pdb_files = get_pdb_files_in_a_dir(my_dir)
    
    # Looping through my_pdb_files
    my_pdb_list = []
    my_rmsd_list = []
    for line in my_pdb_files:
        if pdb_in not in line:
            
            # Call read_PDB_return_coord() to get atomic coordinates as arrays
            x2,y2,z2 = read_PDB_return_coord(line)
    
            # Call calc_rmsd()
            my_rmsd_list.append(calc_rmsd(x1,y1,z1,x2,y2,z2))
            
            # Append line to my_pdb_list
            my_pdb_list.append(line)
    
    # Call read_write_gem_csv_file()
    csv_out0 = csv_entry.get()
    csv_out = csv_out0.replace(" ","")
    read_write_gem_csv_file(my_csv,my_pdb_list,my_rmsd_list,csv_out)

def gem2sandres_GUI():
    """Function to call GUI to prepare input to convert GemDock output to SAnDReS CSV file"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, gemdock_dir_entry, ref_lig_entry, gemdock_xls_entry, csv_entry, top_strdir_entry,\
    gemdock_dir_entry 
          
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Set up gemdock_dir # WFA 2018 01 09
    gemdock_dir = project_dir_string+"GemDock/"
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x270+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="GemDock Parameters (Convert from GemDock (XLS) to SAnDReS (CSV))", \
    font = "Arial" ).grid(row = 0,column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
    
    # Widgets for reference ligand
    Label(top_txt, text="Reference Ligand (PDB):" ).grid(row = 2,column = 0, stick = W)   
    ref_lig_entry = Entry(top_txt,width = 84)
    ref_lig_entry.grid(row = 2, column = 0,stick = E)
    ref_lig_entry.insert(10," ")
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_gemdock_lig).grid(row = 2, column = 1, sticky = W)
    
    # Widgets for GemDock xls file
    Label(top_txt, text="GemDock Results (XLS):" ).grid(row = 3,column = 0, stick = W)   
    gemdock_xls_entry = Entry(top_txt,width = 84)
    gemdock_xls_entry.grid(row = 3, column = 0,stick = E)
    gemdock_xls_entry.insert(10,"gemdock.xls")
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_gemdock_results).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for csv file
    Label(top_txt, text="Re-dock Results (CSV):" ).grid(row = 4,column = 0, stick = W)   
    csv_entry = Entry(top_txt,width = 84)
    csv_entry.grid(row = 4, column = 0,stick = E)
    csv_entry.insert(10,"gemdock.csv")
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_gemdock_csv).grid(row = 4, column = 1, sticky = W)
    
    # Widgets for GemDock dir
    Label(top_txt, text="GemDock dir:" ).grid(row = 5,column = 0, stick = W)   
    gemdock_dir_entry = Entry(top_txt,width = 84)
    gemdock_dir_entry.grid(row = 5, column = 0,stick = E)
    gemdock_dir_entry.insert(10,gemdock_dir)
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_gemdock_dir_entry).grid(row = 5, column = 1, sticky = W)
    
    # Last buttons
    Button(top_txt, text='  Show  ', command=show_gemdock_dir).grid(row = 8, column = 0, sticky = E)  
    Button(top_txt, text='  Generate CSV File  ', command=gen_gemdock_csv  ).grid(row = 8, column = 1, sticky = W)  
    Button(top_txt, text='  Close  ', bg = "red", command=top_txt.destroy).grid(row = 8, column = 1, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=200*" " ).grid(row = 6,column = 0, stick = W) 
    
    # Widgets for txt
    top_scrollbar = Scrollbar(top_txt)
    top_scrollbar.grid(row=7, column = 2,sticky=W) 
    top_txt = Text(top_txt, width = 100, height = 3, yscrollcommand=top_scrollbar.set)        
    top_txt.grid(row = 7, column = 0, columnspan = 2, sticky = W)
    top_scrollbar.config(command=top_txt.yview) 

def clear_autodock_results():
    """Function to clear autodock result entry"""
    
    # Defines global variables to allow access to variables from different functions
    global autodock_dlg_entry
    
    # Clear 
    autodock_dlg_entry.delete(0,END) 

def clear_pdbqt_results():
    """Function to clear autodock pdbqt entry"""
    
    # Defines global variables to allow access to variables from different functions
    global autodock_pdbqt_entry
    
    # Clear 
    autodock_pdbqt_entry.delete(0,END) 

def clear_ligand_pdbqt():
    """Function to clear ligand pdbqt entry"""
    
    # Defines global variables to allow access to variables from different functions
    global ligand_pdbqt_entry
    
    # Clear 
    ligand_pdbqt_entry.delete(0,END) 
    
def clear_mvd_results():
    """Function to clear mvd result entry"""
    
    # Defines global variables to allow access to variables from different functions
    global mvdresults_entry
    
    # Clear 
    mvdresults_entry.delete(0,END) 

def clear_autodock_csv():
    """Function to clear autock csv entry"""
    
    # Defines global variables to allow access to variables from different functions
    global autodock_csv_entry
    
    # Clear 
    autodock_csv_entry.delete(0,END) 
    
def clear_mvd_csv():
    """Function to clear mvd csv entry"""
    
    # Defines global variables to allow access to variables from different functions
    global mvd_csv2_entry
    
    # Clear 
    mvd_csv2_entry.delete(0,END) 

def read_mvdresults_4_dataset(dir_in,mvd_in):
    """Function to read *.mvdresults file and return a list"""
    import sys
        
    # Set up empty list
    my_list = []
    
    # Try to open a file 
    try:
        fo = open(dir_in+mvd_in,"r")
    except IOError:
        sys.exit("\nIOError!")
        fo.close()
        return my_list
    
    # Looping through fo and avoid E-Intra (tors, ligand atoms) in the header 
    for line in fo:
        if line[0] != "#":
            line_aux1 = str(line)
            line_aux2 = line_aux1.replace(",","")
            line_aux3 =  line_aux2.replace("\t",",")
            my_list.append(line_aux3)
    
    fo.close()
    return my_list
    
def read_mvdresults(mvd_in):
    """Function to read *.mvdresults file and return a list"""
    import sys
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Set up empty list
    my_list = []
    
    # Try to open a file 
    try:
        fo = open(project_dir_string+mvd_in,"r")
    except IOError:
        sys.exit("\nIOError!")
        fo.close()
        return my_list
    
    # Looping through fo and avoid E-Intra (tors, ligand atoms) in the header 
    for line in fo:
        if line[0] != "#":
            line_aux1 = str(line)
            line_aux2 = line_aux1.replace(",","")
            line_aux3 =  line_aux2.replace("\t",",")
            my_list.append(line_aux3)
    
    fo.close()
    return my_list

def write_aux_csv_4_dataset(dir_in,list_in):
    """Function to write a CSV file"""
    
    # Set CSV file name
    my_csv_file_name =  "my_aux.csv"
    
    # Open CSV file
    fo = open(dir_in+my_csv_file_name,"w")
    
    # Looping through list_in
    for line in list_in:
        fo.write(line)
    
    # Close file
    fo.close()
    
def write_aux_csv(list_in):
    """Function to write a CSV file"""
    
    # Set CSV file name
    my_csv_file_name =  "my_aux.csv"
    
    # Open CSV file
    fo = open(my_csv_file_name,"w")
    
    # Looping through list_in
    for line in list_in:
        fo.write(line)
    
    # Close file
    fo.close()
    
def read_aux_csv():
    """Function to read my_aux.csv and return list with column 26 (filename)"""
    import csv
    import sys
    
    # Set up empty list
    list_col_26 = []
    
    # Try to open file
    try:
        fo = open("my_aux.csv","r")
        my_csv = csv.reader(fo)
    except IOError:
        sys.exit("IOError")
    
    # Looping through my_csv
    for line in my_csv:
        
        if "Filename" in line[26]:
            aux_line =  line[26]
        else:
            aux_line = line[26][:len(line[26]) - 5 ]
                
        list_col_26.append(aux_line)
    
    return list_col_26

def write_csv_4_dataset(dir_in,list_in,my_file_name,cols_in):
    """Function to write CSV file"""
    
    # Import libraries
    import csv
    import sys
        
    # Try to open CSV file
    try:
        fo0 = open(dir_in+"my_aux.csv","r")
        my_csv = csv.reader(fo0)
    except IOError:
        sys.exit("\IOError!")
        
    # Looping through my_csv file:
    my_list_out = []
    for line in my_csv:
        my_aux_line = line[int(cols_in[1])]  +","
        for i in range(int(cols_in[0]) ):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[0])+1,int(cols_in[1])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[1])+1,int(cols_in[2])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[2])+1,int(cols_in[3])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[3])+1,int(cols_in[4])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[4])+1,int(cols_in[5])):
            my_aux_line += line[i]+","
        print(my_aux_line[:len(my_aux_line)-1])
        my_list_out.append(my_aux_line[:len(my_aux_line)-1]+"\n")
            
    fo0.close()
    
    # Open CSV file
    fo = open(dir_in+my_file_name,"w")

    # Looping through list_in
    i = 0
    for line in my_list_out:
        line_aux = line
        fo.write(line_aux)
        i += 1
        
    # Close file
    fo.close()
    
def write_csv(list_in,my_file_name,cols_in):
    """Function to write CSV file"""
    import csv
    import sys
    
    # Get project directory
    string_strdir = str(strdir_entry.get())
    
    # Try to open CSV file
    try:
        fo0 = open("my_aux.csv","r")
        my_csv = csv.reader(fo0)
    except IOError:
        sys.exit("\IOError!")
        
    # Looping through my_csv file:
    my_list_out = []
    for line in my_csv:
        my_aux_line = line[int(cols_in[1])]  +","
        for i in range(int(cols_in[0]) ):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[0])+1,int(cols_in[1])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[1])+1,int(cols_in[2])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[2])+1,int(cols_in[3])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[3])+1,int(cols_in[4])):
            my_aux_line += line[i]+","
        for i in range(int(cols_in[4])+1,int(cols_in[5])):
            my_aux_line += line[i]+","
        print(my_aux_line[:len(my_aux_line)-1])
        my_list_out.append(my_aux_line[:len(my_aux_line)-1]+"\n")
            
    fo0.close()
    
    # Open CSV file
    fo = open(string_strdir+my_file_name,"w")

    # Looping through list_in
    i = 0
    for line in my_list_out:
        line_aux = line
        fo.write(line_aux)
        i += 1
        
    # Close file
    fo.close()
    
def get_bad_columns_4_dataset(dir_in):
    """Function to get the number for columns Filename, Name, and Ligand"""
    
    # Import libraries
    import csv
    import sys
    
    # Set up empty list
    no_fly_cols = []
    
    # Try to open CSV file
    try:
        fo = open(dir_in+"my_aux.csv","r")
        my_csv = csv.reader(fo)
    except IOError:
        sys.exit("\nIOError!")
    
    # Looping through first line:
    for line in my_csv:
        i = 0
        for line1 in line:
            if "Filename" in line1:
                no_fly_cols.append(i)
            elif "Ligand" in line1:
                no_fly_cols.append(i)
            elif "MW" in line1:
                no_fly_cols.append(i)
            elif "Name" in line1:
                no_fly_cols.append(i)
            elif "Run" in line1:
                no_fly_cols.append(i)
            elif "SMILES" in line1:
                no_fly_cols.append(i)
            i += 1
        break
        
    return no_fly_cols
    
def get_bad_columns():
    """Function to get the number for columns Filename, Name, and Ligand"""
    import csv
    import sys
    
    no_fly_cols = []
    
    # Try to open CSV file
    try:
        fo = open("my_aux.csv","r")
        my_csv = csv.reader(fo)
    except IOError:
        sys.exit("\nIOError!")
    
    # Looping through first line:
    for line in my_csv:
        i = 0
        for line1 in line:
            if "Filename" in line1:
                no_fly_cols.append(i)
            elif "Ligand" in line1:
                no_fly_cols.append(i)
            elif "MW" in line1:
                no_fly_cols.append(i)
            elif "Name" in line1:
                no_fly_cols.append(i)
            elif "Run" in line1:
                no_fly_cols.append(i)
            elif "SMILES" in line1:
                no_fly_cols.append(i)
            i += 1
        break
        
    return no_fly_cols
    
def gen_mvd_csv_4_dataset(file_name1,file_name2,my_string_strdir):
    """Function to generate csv for sandres for dataset"""
    
    # Import libraries
    import csv
    import time
    import shutil
            
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Make backup of old redock01.csv 
    try:
        shutil.copy2(my_string_strdir+(file_name2.replace(" ","")),my_string_strdir+\
                     "redock01_"+my_local_time+".csv")
    except:
        print()
    
    # Call read_mvdresults_4_dataset()
    my_list = read_mvdresults_4_dataset(my_string_strdir,file_name1)
    
    # Call write_aux_csv_4_dataset()
    write_aux_csv_4_dataset(my_string_strdir,my_list)
    
    # Call get_bad_columns_4_dataset()
    my_cols =  get_bad_columns_4_dataset(my_string_strdir)
        
    # Call write_csv_4_dataset()
    write_csv_4_dataset(my_string_strdir,my_list,file_name2,my_cols)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("New CSV file has been written with RMSD data: "+file_name2,"black","light grey")
    
def gen_mvd_csv():
    """Function to generate csv for sandres"""
    
    # Import libraries
    import csv
    import time
    import shutil
    
    # Defines global variables to allow access to variables from different functions
    global mvdresults_entry, mvd_csv2_entry, strdir_entry
    
    # Get input file names and structure dir
    file_name1 = mvdresults_entry.get()
    file_name2 = mvd_csv2_entry.get()
    string_strdir = str(strdir_entry.get())
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Make backup of old redock01.csv 
    try:
        shutil.copy2(string_strdir+(file_name2.replace(" ","")),string_strdir+\
                     "redock01_"+my_local_time+".csv")
    except:
        print()
    
    # Call read_mvdresults()
    my_list = read_mvdresults(file_name1)
    
    # Call write_aux_csv()
    write_aux_csv(my_list)
    
    # Call get_bad_columns()
    my_cols =  get_bad_columns()
    
    # Call write_csv()
    write_csv(my_list,file_name2,my_cols)
    
    # Call show_message_in_sandres()
    show_message_in_sandres("New CSV file has been written with RMSD data: "+file_name2,"black","light grey")
    
def docking_simulations_GUI():
    """Function to run docking simulations using AutoDock, AutoDock Vina, and MVD"""
    
    # Defines global variable to allow access with different functions
    global top_txt
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Protein-Ligand Docking Simulations') 
    top_txt.geometry("870x125+125+137")
    
    Label(top_txt, text="Docking Simulations", font = "Arial" ).grid(row = 0,column = 0)
    
    # Show Empty Label 
    Label(top_txt, text=135*" ", font = "Arial" ).grid(row = 1,\
        column = 10, stick = W)
    
    # Widgets for docking program
    Label(top_txt, text="Program for Docking:" ).grid(row = 4,column = 0, stick = E)
    
    # Widgets for docking program buttons
    Button(top_txt, text='AutoDock 4', command = run_autodock_GUI).grid(row = 4, column = 1, sticky = W)
    Button(top_txt, text='AutoDock Vina', command = run_vina_GUI).grid(row = 4, column = 2, sticky = W)
    Button(top_txt, text='Molegro Virtual Docker (MVD)', command = run_mvd_moldock_GUI).grid(row = 4, column = 3, sticky = W) 
    
    # Show Empty Label 
    Label(top_txt, text=60*" ", font = "Arial" ).grid(row = 5,\
        column = 5, stick = W)
    
    # Widgets for Close button
    Button(top_txt, text=' Close ', bg = "red", command=top_txt.destroy).grid(row = 4, column = 4,\
                                                                                sticky = W)
                                                                                
def import_docking_results_GUI():
    """Function to import docking results from AutoDock, AutoDock Vina, GemDock, and MVD"""
    
    # Defines global variable to allow access with different functions
    global top_txt
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Import Docking Results') 
    top_txt.geometry("870x125+20+435")
    
    Label(top_txt, text="Import Docking Results", font = "Arial" ).grid(row = 0,column = 0)
    
    # Show Empty Label 
    Label(top_txt, text=135*" ", font = "Arial" ).grid(row = 1,\
        column = 10, stick = W)
    
    # Widgets for binding affinity 
    Label(top_txt, text="Program Used for Docking:" ).grid(row = 4,column = 0, stick = E)
    
    # Widgets for binding affinity buttons
    Button(top_txt, text='AutoDock 4', command =autodock2sandres_GUI).grid(row = 4, column = 1, sticky = W)
    Button(top_txt, text='AutoDock Vina', command = vina2sandres_GUI).grid(row = 4, column = 2, sticky = W)
    Button(top_txt, text='GemDock', command = gem2sandres_GUI).grid(row = 4, column = 3, sticky = W) 
    Button(top_txt, text='Molegro Virtual Docker', command = mvd2sandres_GUI).grid(row = 4, column = 4, sticky = W) 
    Button(top_txt, text='SwissDock', command = swissdock2sandres_GUI).grid(row = 4, column = 5, sticky = W) 
    
    # Show Empty Label 
    Label(top_txt, text=75*" ", font = "Arial" ).grid(row = 5,\
        column = 5, stick = W)
    
    # Widgets for Close button
    Button(top_txt, text=' Close ', bg = "red", command=top_txt.destroy).grid(row = 6, column = 5,\
                                                                                sticky = E)
                                                                            
def autodock2sandres_GUI():
    """Function to call GUI to prepare input to convert AutoDock to SAnDReS"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, autodock_dir_entry, ref_lig_entry, autodock_dlg_entry, autodock_csv_entry, top_strdir_entry 
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x150+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="AutoDock (Convert from AutoDock to SAnDReS)", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for Autodock .dlg file
    Label(top_txt, text="AutoDock File (.dlg):" ).grid(row = 3,column = 0, stick = W)   
    autodock_dlg_entry = Entry(top_txt,width = 86)
    autodock_dlg_entry.grid(row = 3, column = 0,stick = E)
    autodock_dlg_entry.insert(10,"docking.dlg")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autodock_results).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for csv file
    Label(top_txt, text="SAnDReS CSV File:" ).grid(row = 4,column = 0, stick = W)   
    autodock_csv_entry = Entry(top_txt,width = 86)
    autodock_csv_entry.grid(row = 4, column = 0,stick = E)
    autodock_csv_entry.insert(10,"redock01.csv")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autodock_csv).grid(row = 4, column = 1, sticky = W)
    
    # Last buttons
    Button(top_txt, text='Generate CSV File', command=gen_autodock_csv  ).grid(row = 7, column = 1, sticky = W)  
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=210*" " ).grid(row = 5,column = 0, stick = W) 

def write_swissdock_pdb(file_in,list_in):
    """Function to write a pdb file"""
    
    # Get project directory
    project_dir_string = str(swissdock_dir_entry.get())
    
    fo1 = open(project_dir_string+file_in,"w")

    # Looping throughd ata
    for line in list_in:
        fo1.write(line)
    
    # Close file
    fo1.close()

def write_swissdock_pdb_sorted(file_in,list_in):
    """Function to write a pdb file"""
    
    # Set up empty lists
    list1 = []
    list_out = []

    # Get project directory
    project_dir_string = str(swissdock_dir_entry.get())
    
    # Try to open file
    try:
        fo0 = open(project_dir_string+file_in,"r")
    except IOError:
        print("\nSAnDReS IOError! I can't find "+file_in+" file!")
        return
    
    # Read data
    for line in fo0:
        list1.append(line)
    
    fo0.close()
    
    # Open new file
    fo1 = open(project_dir_string+file_in,"w")
    

    # Looping through list of atoms to get the right order of atoms
    for atm in list_in:
        for line in list1:
            if str(line[12:15]) == str(atm):
                list_out.append(line)
                
    # Looping through list_out
    for line in list_out:
        fo1.write(line)
    
    fo1.close()
    
def make_csv_backup(dir_in,file_in):
    """Function to make a backup of file_in"""
    
    # Import libraries
    import time
    import shutil
        
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    print(my_local_time)
    
    # Get index for root
    my_index = file_in.index(".csv")
    my_root = file_in[:my_index]

    # Make backup of old redock01.csv 
    try:
        shutil.copy2(dir_in+file_in,dir_in+\
                     my_root+"_"+my_local_time+".csv")
        print("\nSAnDReS copied "+dir_in+file_in+" to "+dir_in+\
                     my_root+"_"+my_local_time+".csv\n")
        
    except:
        print("I can't make a back up of .csv file. Please check folder and file names!")
        return
    
def make_swissdock_csv(Cluster,ClusterRank,Energy,SimpleFitness,FullFitness,InterFull,IntraFull,solvFull,surfFull,\
    extraFull,deltaGcompsolvpol,deltaGcompsolvnonpol,deltaGprotsolvpol,deltaGprotsolvnonpol,deltaGligsolvpol,\
    deltaGligsolvnonpol,deltaGvdw,deltaGelec,deltaG,rmsd_list):
    """Function to generate csv file for swissdock results"""
    
    # Get project directory
    project_dir_string = str(swissdock_dir_entry.get())
    
    # Get csv file name
    file_1 = str(sandres_csv_entry.get())
    
    # Call make_csv_backup()
    make_csv_backup(project_dir_string,file_1)
    
    fo = open(project_dir_string+file_1,"w")
    
    # Write first line (header)
    fo.write("Cluster and ClusterRank,Energy,SimpleFitness,FullFitness,InterFull,IntraFull,solvFull,surfFull,"+\
    "extraFull,deltaGcompsolvpol,deltaGcompsolvnonpol,deltaGprotsolvpol,deltaGprotsolvnonpol,deltaGligsolvpol,"+\
    "deltaGligsolvnonpol,deltaGvdw,deltaGelec,deltaG,RMSD\n")
    
    n_poses = len(Cluster)
    aux = ""
    # Looping through lists to write swissdock results
    for i in range(n_poses):
        aux += str(Cluster[i])+" "+str(ClusterRank[i])+","+str(Energy[i])+","
        aux += str(SimpleFitness[i])+","+str(FullFitness[i])+","+str(InterFull[i])+","
        aux += str(IntraFull[i])+","+str(solvFull[i])+","+str(surfFull[i])+","+str(extraFull[i])+","
        aux += str(deltaGcompsolvpol[i])+","+str(deltaGcompsolvnonpol[i])+","+str(deltaGprotsolvpol[i])+","
        aux += str(deltaGprotsolvnonpol[i])+","+str(deltaGligsolvpol[i])+","+str(deltaGligsolvnonpol[i])+","
        aux += str(deltaGvdw[i])+","+str(deltaGelec[i])+","+str(deltaG[i])+","+str(rmsd_list[i])
        fo.write(aux+"\n")
        aux = ""
    
    fo.close()
    
def get_list_atoms(dir_in,file_in):
    """Function to get the list of atoms"""
    
    # Set up empty list
    list1 = []
    
    # Try to open file
    try:
        fo = open(dir_in+file_in,"r")
    except IOError:
        print("\nSAnDReS IOError! I can't find "+file_in+" file!")
        return
    
    # Looping through data to get list of atoms
    for line in fo:
        if line[12:13] != "H" and line[13:14] != "H":
            list1.append(line[13:16])
    
    fo.close()
    
    return list1
    
def read_swissdock_data(n_atoms_in):
    """Function to read swissdock pdb file"""
    
    # Import library
    import numpy as np
    
    # Get mol2 file name
    file_mol2 = str(swissdock_ref_lig_entry.get())
    
    # Get index of .mol2 to generate root
    mol2_index = file_mol2.index(".mol2")
    
    # Get root for pdb file            
    root_pdb_file = file_mol2[:mol2_index]
    print("\nReference ligand: ",root_pdb_file+".pdb\n")              
    
    # Call read_PDB_swissdock() to get reference ligand coordinates
    rx0,ry0,rz0 = read_PDB_swissdock(root_pdb_file+".pdb")
    
    # Get pdb file name
    file_1 = swissdock_pdb_entry.get()
    
    # Get project directory
    project_dir_string = str(swissdock_dir_entry.get())
    
    # Get SAnDReS csv file name
    sandres_swissdock_file = str(sandres_csv_entry.get())
    
    # call get_list_atoms()
    swiss_list_atoms = get_list_atoms(project_dir_string,root_pdb_file+".pdb")
    
    # Set up empty lists
    atom_list1 = []
    lines_out1 = []
    Energy = []
    SimpleFitness = []
    FullFitness = []
    InterFull = []
    IntraFull = []
    solvFull = []
    surfFull = []
    extraFull = []
    deltaGcompsolvpol = []
    deltaGcompsolvnonpol = []
    deltaGprotsolvpol = []
    deltaGprotsolvnonpol = []
    deltaGligsolvpol = []
    deltaGligsolvnonpol = []
    deltaGvdw = []
    deltaGelec = []
    deltaG = []
    Cluster = []
    ClusterRank = []
    rmsd_list = []
                
    # Try to open file
    try:
        fo1 = open(project_dir_string+file_1,"r")
    except IOError:
        print("\nI can't find "+file_1+" file!")
        return 
        
    count_atm = 0
    
    # Looping through swissdock results
    for line in fo1:
        if "REMARK  Cluster:" in line:
            remark_cluster = str(line)
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            cluster_number = int(swiss_aux0000[index_swiss+1:] )
            Cluster.append( int(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  ClusterRank:" in line:
            aux000 = str(line)
            aux_line = remark_cluster[8:len(remark_cluster)-1]+" Cluster Number "+aux000[20:len(aux000)-1]
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            cluster_rank = int(swiss_aux0000[index_swiss+1:] )
            ClusterRank.append( int(swiss_aux0000[index_swiss+1:] ))
            count_atm = 0
        elif "REMARK  Energy:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            Energy.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  SimpleFitness:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            SimpleFitness.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  FullFitness:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            FullFitness.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  InterFull:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            InterFull.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  IntraFull:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            IntraFull.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  solvFull:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            solvFull.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  surfFull:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            surfFull.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  extraFull:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            extraFull.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGcompsolvpol:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGcompsolvpol.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGcompsolvnonpol:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGcompsolvnonpol.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGprotsolvpol:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGprotsolvpol.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGprotsolvnonpol:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGprotsolvnonpol.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGligsolvpol:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGligsolvpol.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGligsolvnonpol:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGligsolvnonpol.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGvdw:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGvdw.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaGelec:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaGelec.append( float(swiss_aux0000[index_swiss+1:] ))
        elif "REMARK  deltaG:" in line:
            swiss_aux0000 = str(line)
            index_swiss = swiss_aux0000.index(":")
            deltaG.append( float(swiss_aux0000[index_swiss+1:] ))
        elif line[0:6] == "ATOM  " and count_atm < n_atoms_in:
            if line[13:14] != "H" and line[12:13] !="H":
                lines_out1.append(line)
            count_atm += 1
        if count_atm >= n_atoms_in:
            # Write last line
            lines_out1.append("END")
            
            # Define pose file name
            pose_file_name = "swissdock_pose_"+str(cluster_number)+"_"+str(cluster_rank)+".pdb"
            
            # Call write_swissdock_pdb()
            write_swissdock_pdb(pose_file_name,lines_out1)
            
            # Call write_swissdock_pdb_sorted (to have the atom list as refence ligand)
            write_swissdock_pdb_sorted(pose_file_name,swiss_list_atoms)
            
            # Call read_PDB_swissdock() to get the atomic coordinates for the pose
            x,y,z = read_PDB_swissdock(pose_file_name)
            
            # Call calc_swissdock_rmsd()
            rmsd = calc_swissdock_rmsd(rx0,ry0,rz0,x,y,z)
            
            rmsd_list.append(rmsd)
            lines_out1 = []
            count_atm = 0
            

            #break
    
    # Call make_swissdock_csv()
    make_swissdock_csv(Cluster,ClusterRank,Energy,SimpleFitness,FullFitness,InterFull,IntraFull,solvFull,surfFull,\
    extraFull,deltaGcompsolvpol,deltaGcompsolvnonpol,deltaGprotsolvpol,deltaGprotsolvnonpol,deltaGligsolvpol,\
    deltaGligsolvnonpol,deltaGvdw,deltaGelec,deltaG,rmsd_list)
    
    print("\nA total of ",len(rmsd_list)," poses were extracted from ",file_1)
    print("\nA new ",sandres_swissdock_file," csv file has been generated with swissdock results.\n")
        
def read_swissdock_mol2():
    """Function to read mol2 and return atomic coordinates and atom string"""
    
    # Import library
    import numpy as np
    
    # Set up empty lists
    atom_list = []      # List of non-hydrogen atoms
    x,y,z = [],[],[]
    
    # Get file name
    file_1 = swissdock_ref_lig_entry.get()

    # Get project directory
    project_dir_string = str(swissdock_dir_entry.get())
    
    # Try to open mol2 file
    try:
        fo1 = open(project_dir_string+file_1,"r")
    except IOError:
        print("\nI can't find "+file_1+" file!")
        return x,y,z,atom_list
    
    # Looping through file_1
    atoms = False
    for line in fo1:
        print(line)
        if "@<TRIPOS>BOND" in line:
            break
        if line[47:48] != "H" and atoms:
            atom_list.append(line[8:12])        # 4 characters
            x.append(float(line[17:26]))
            y.append(float(line[27:36]))
            z.append(float(line[37:46]))
        if "@<TRIPOS>ATOM" in line:
            atoms = True
    fo1.close()
    
    # Convert to array
    x_coord = np.array(x)
    y_coord = np.array(y)
    z_coord = np.array(z)
    
    return x_coord,y_coord,z_coord,atom_list
        
def swissdock2sandres_GUI():
    """Function to call GUI to prepare input to convert SwissDock to SAnDReS"""
    
    # Import library
    from tkinter import messagebox
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, swissdock_pdb_entry, sandres_csv_entry, swissdock_dir_entry,swissdock_ref_lig_entry
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x200+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="SwissDock (Convert from SwissDock to SAnDReS)", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for the directory where the docking result files are
    Label(top_txt, text="Directory for SwissDock: " ).grid(row = 2,column = 0, stick = W)   
    swissdock_dir_entry = Entry(top_txt,width = 86)
    swissdock_dir_entry.grid(row = 2, column = 0,stick = E)
    swissdock_dir_entry.insert(10,project_dir_string)
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_swissdock_dir_entry).grid(row = 2, column = 1, sticky = W)
    
    # Widgets for reference ligand (.mol2) 
    Label(top_txt, text="Reference Ligand (.mol2): " ).grid(row = 3,column = 0, stick = W)   
    swissdock_ref_lig_entry = Entry(top_txt,width = 86)
    swissdock_ref_lig_entry.grid(row = 3, column = 0,stick = E)
    swissdock_ref_lig_entry.insert(10,"lig.mol2")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_swissdock_ref_lig_entry).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for docking results .pdb file
    Label(top_txt, text="Docking Results (.pdb):" ).grid(row = 4,column = 0, stick = W)   
    swissdock_pdb_entry = Entry(top_txt,width = 86)
    swissdock_pdb_entry.grid(row = 4, column = 0,stick = E)
    swissdock_pdb_entry.insert(10,"clusters.dock4.pdb")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_swissdock_pdb_entry).grid(row = 4, column = 1, sticky = W)
    
    # Widgets for SAnDReS csv file
    Label(top_txt, text="SAnDReS CSV File:" ).grid(row = 5,column = 0, stick = W)   
    sandres_csv_entry = Entry(top_txt,width = 86)
    sandres_csv_entry.grid(row = 5, column = 0,stick = E)
    sandres_csv_entry.insert(10,"redock01.csv")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_sandres_csv_entry).grid(row = 5, column = 1, sticky = W)
    
    # Last buttons
    Button(top_txt, text='Generate CSV File', command=gen_swissdock_csv  ).grid(row = 8, column = 1, sticky = W)  
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 8, column = 2, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=220*" " ).grid(row = 6,column = 0, stick = W) 
    
def next_run_vina_pdb_entry():
    """Function to insert next pdb access code read from the chklig.in"""
    
    # Import library
    from tkinter import messagebox
    
    # Call aux GUI
    from tkinter import messagebox
    
    # Call read_pdbs_chklig()
    pdb_list = read_pdbs_chklig()
    
    # Get running run_vina_pdb_entry
    running_pdb = str(run_vina_pdb_entry.get())
    
    # Looping through pdb_list
    i = 0
    for line in pdb_list:
        if running_pdb == line:
            break
        i += 1
        
    # To finish after last pdb access code
    if i > (len(pdb_list)-2):
        my_message1 = "SAnDReS Message. The Number of PDB files in chklig.in is "+str(len(pdb_list))
        my_message2 = "The Number of PDB files in chklig.in should be less than "+str(len(pdb_list))
        print(my_message1+"\n"+my_message2)
        print("\a")
        messagebox.showerror(my_message1, my_message2)
        return
    else:
        # Clear run_vina_pdb_entry
        run_vina_pdb_entry.delete(0,END)
        # Insert next pdb access code in run_vina_pdb_entry
        run_vina_pdb_entry.insert(10,str(pdb_list[i+1]))
            
def read_pdbs_chklig():
    """Function to read pdb access codes from chklig.in and return a list"""
    
    # Import library
    import csv
    
    # Set up empty list
    pdb_vina_list = []
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open csv file
    try:
        fo1 = open(project_dir_string+"chklig.in","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("\nSAnDReS IOError! I can't find chklig.in file!")
        return pdb_vina_list
    
    # Looping through chklig.in
    for line in csv1:
        if "CHKLIG" == line[0]:
            pdb_vina_list.append(line[1])
    
    fo1.close()
    
    return pdb_vina_list

def read_dataset_dir():
    """Function to read dataset dir from fndwat.in and return a string"""
    
    # Import library
    import csv
    
    # Set up empty string
    dir_vina_string = ""
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open csv file
    try:
        fo1 = open(project_dir_string+"fndwat.in","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("\nSAnDReS IOError! I can't find fndwat.in file!")
        return dir_vina_string
    
    # Looping through fndwat.in
    for line in csv1:
        if "WATDIR" == line[0]:
            dir_vina_string += str(line[1])
            break
    
    fo1.close()
    
    return dir_vina_string
        
def copy_vina_inputs(dir_source,dir_target):
    """Function to copy vina inputs"""
    
    # Import library
    import shutil
    
    list1 = ["lig.pdbqt","receptor.pdbqt","config.txt","vina.exe"]
    
    # Looping through files to be copied
    for line in list1:
        # Copy file
        shutil.copy2(dir_source+line,dir_target+line)
        
def write_py_file_4_vina(string_in,dir_in):
    """Function to write a .py file for vina"""
        
    # Write a .py file
    fo = open(dir_in+"sandres_run_vina.py","w")
    
    fo.write("import sys, string, os\n")
    
    fo.write(string_in)
    
    fo.close()

def run_my_vina_exe():
    """Function to run vina.exe --config config.txt --log log.txt"""
    
    # Import libraries
    import sys, string, os
    from tkinter import messagebox
    
    # Now run the script
    os.system( '"python sandres_run_vina.py"' )
        
def copy_vina_outputs(dir_source,dir_target):
    """Function to copy vina outputs"""
    
    # Import library
    import shutil
    
    list1 = ["lig_out.pdbqt","log.txt"]
    
    # Looping through files to be copied
    for line in list1:
        # Copy file
        shutil.copy2(dir_source+line,dir_target+line)

def copy_vina_score_outputs(dir_source,dir_target,number_in):
    """Function to copy vina outputs"""
    
    # Import library
    import shutil
    
    # Set up empty
    list1 = []
    
    # Add files to be copied
    list1.append("lig_"+number_in+".pdbqt")
    list1.append("log_score_"+number_in+".txt")
    list1.append("config_"+number_in+".txt")
    
    # Looping through files to be copied
    for line in list1:
        
        # Copy file
        shutil.copy2(dir_source+line,dir_target+line)

def show_warning_message_pop_up(my_message1,my_message2):
    """Function to show a warning message in a pop-up window"""
    
    # Import library
    from tkinter import messagebox
    
    # Show warning message
    messagebox.showwarning(my_message1, my_message2)
    print("\n"+my_message1+"\n"+my_message2)

def check_vina_lig_pdb():
    """Function to check lig.pdb before running vina"""
    
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty list
    lig_in = []
    lig_out = []
    
    try:
        fo = open(dir_in0+"lig.pdb","r")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return
    
    # Looping through lig.pdb
    low_occ = False
    for line in fo:
        if line[0:6] == "ATOM   " or line[0:6] == "HETATM":
            if float(line[56:60]) < 1.00:
                low_occ = True
        lig_in.append(line)
    
    fo.close()
    
    # Looping through lig_in:
    former_line_12_16 = "    "
    for i in range(len(lig_in)-1):
        line1 = str(lig_in[i])
        line2 = str(lig_in[i+1])
        if line1[0:6] == "ATOM   " or line1[0:6] == "HETATM":
            if line2[0:6] == "ATOM   " or line2[0:6] == "HETATM":
                if float(line1[56:60]) > 0.50:
                    aux = line1[0:16]+" "+line1[17:]
                    lig_out.append(aux)
                elif line1[12:16] == line2[12:16]:
                    if float(line1[56:60]) >= float(line2[56:60]):
                        aux = line1[0:16]+" "+line1[17:]
                        lig_out.append(aux)
                    else:
                        aux = line2[0:16]+" "+line2[17:]
                        lig_out.append(aux)
    
    lig_out.append("END")
                        
    # If low_occ is found new lig.pdb is generated
    if low_occ:
        print("\nOccupancy factor < 1.00 identified in lig.pdb! Writing highest occupancy atoms...",end="")
        
        # Open new lig.pdb
        fo = open(dir_in0+"lig.pdb","w")
        
        # Looping through lig_out
        for line in lig_out:
            print(line)
            fo.write(line)
        
        print("done!")
    
        fo.close()
        
def check_vina_input():
    """Function to check if lig.pdbqt, receptor.pdbqt, and config.txt files are in the running directory"""
    
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up list of files to be checked
    list_of_files = ["lig.pdbqt","receptor.pdbqt","config.txt"]
    
    # Set up initial state for boolean variable
    check_input = True
    
    # Looping through list of files
    for line in list_of_files:
        print("\nChecking if ",line," is in the ",dir_in0," directory...", end="")
        try:
            fo = open(dir_in0+line,"r")
            print("done!\n")
        except IOError:
            my_message1 = "SAnDReS IOError!"
            my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
            show_warning_message_pop_up(my_message1,my_message2)
            check_input = False
            break
    
    return check_input
            
def get_energy_terms_vina_log(mdl_in):
    """Function to get vina energy terms"""

    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Try to open lig_out.pdbqt
    try:
        fo = open(sandres_root+"log_score_"+mdl_in+".txt","r")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return None,None,None,None,None,None
    
    # looping through data
    for line in fo:
        # Get Affinity
        if line[0:9] == "Affinity:":
            a = float(line[9:18])
        elif line[0:17] == "    gauss 1     :":
            g1 = float(line[17:])
        elif line[0:17] == "    gauss 2     :":
            g2 = float(line[17:])
        elif line[0:17] == "    repulsion   :":
            r = float(line[17:])
        elif line[0:17] == "    hydrophobic :":
            h = float(line[17:])
        elif line[0:17] == "    Hydrogen    :":
            H = float(line[17:])
    
    return a,g1,g2,r,h,H

def pre_merge_autodock_data_GA():
    """Function to call functions from merge_autodock_data() for docking with GA"""
    
    # Get project directory # WFA 2018 01 09
    project_dir_string = str(strdir_entry.get())
    
    spec_redock_file = "GA/redock_autodock.csv"
    spec_epdb_file = "EPDB/epdb_autodock.csv"
    
    # Call mautodock.merge_redock_results()
    mautodock.merge_redock_results(spec_redock_file,spec_epdb_file,project_dir_string)
    
    # Call clear_ensembledock_csv_file_entry()
    clear_ensembledock_csv_file_entry()
    
    # Insert "ensembledock_autodock.csv"
    input_ensemble_csv_file_entry.insert(10,"ensembledock_autodock.csv")
    
    # Call clear_scores_all_csv_file_entry
    clear_scores_all_csv_file_entry()
    
    # Insert "scores_all_autodock.csv"
    input_score_csv_file_entry.insert(10,"scores_all_autodock.csv")
    
    # Call show_message_in_sandres()
    my_new_message_2_show = "SAnDReS generated ensembledock_autodock.csv and scores_all_autodock.csv files"
    show_message_in_sandres(my_new_message_2_show,"black","light grey")
    
def pre_merge_autodock_data_LGA():
    """Function to call functions from merge_autodock_data() for docking with LGA"""
    
    # Get project directory # WFA 2018 01 09
    project_dir_string = str(strdir_entry.get())
    
    spec_redock_file = "LGA/redock_autodock.csv"
    spec_epdb_file = "EPDB/epdb_autodock.csv"
    
    # Call mautodock.merge_redock_results()
    mautodock.merge_redock_results(spec_redock_file,spec_epdb_file,project_dir_string)
    
    # Call clear_ensembledock_csv_file_entry()
    clear_ensembledock_csv_file_entry()
    
    # Insert "ensembledock_autodock.csv"
    input_ensemble_csv_file_entry.insert(10,"ensembledock_autodock.csv")
    
    # Call clear_scores_all_csv_file_entry
    clear_scores_all_csv_file_entry()
    
    # Insert "scores_all_autodock.csv"
    input_score_csv_file_entry.insert(10,"scores_all_autodock.csv")
    
    # Call show_message_in_sandres()
    my_new_message_2_show = "SAnDReS generated ensembledock_autodock.csv and scores_all_autodock.csv files"
    show_message_in_sandres(my_new_message_2_show,"black","light grey")

def pre_merge_autodock_data_EPDB():
    """Function to call functions from merge_autodock_data() for docking with LGA"""
    
    # Get project directory # WFA 2018 04 02
    project_dir_string = str(strdir_entry.get())
    
    #spec_redock_file = "LGA/redock_autodock.csv"
    spec_epdb_file = "EPDB/epdb_autodock.csv"
    
    # Call mautodock.merge_redock_results()
    mautodock_epdb.merge_redock_results(spec_epdb_file,project_dir_string)
    
    # Call clear_ensembledock_csv_file_entry()
    clear_ensembledock_csv_file_entry()
    
    # Insert "ensembledock_autodock.csv"
    input_ensemble_csv_file_entry.insert(10,"ensembledock_autodock.csv")
    
    # Call clear_scores_all_csv_file_entry
    clear_scores_all_csv_file_entry()
    
    # Insert "scores_all_autodock.csv"
    input_score_csv_file_entry.insert(10,"scores_all_autodock.csv")
    
    # Call show_message_in_sandres()
    my_new_message_2_show = "SAnDReS generated ensembledock_autodock.csv and scores_all_autodock.csv files"
    show_message_in_sandres(my_new_message_2_show,"black","light grey")

def pre_merge_vina_data():
    """Function to call functions from merge_vina_data()"""
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Call mvina.merge_redock_results()
    mvina.merge_redock_results("redock_vina.csv",project_dir_string)
    
    # Call clear_ensembledock_csv_file_entry()
    clear_ensembledock_csv_file_entry()
    
    # Insert "ensembledock_vina.csv"
    input_ensemble_csv_file_entry.insert(10,"ensembledock_vina.csv")
    
    # Call clear_scores_all_csv_file_entry
    clear_scores_all_csv_file_entry()
    
    # Insert "scores_all_vina.csv"
    input_score_csv_file_entry.insert(10,"scores_all_vina.csv")
    
    # Call show_message_in_sandres()
    my_new_message_2_show = "SAnDReS generated ensembledock_vina.csv and scores_all_vina.csv files"
    show_message_in_sandres(my_new_message_2_show,"black","light grey")
    
def add_xtal_to_lig_out_pdbqt():
    """Function to include lig.pdbqt line into lig_out.pdbqt file"""
    
    # At first try to open lig_out.pdbqt to get last MODEL number
    # Try to open lig_out.pdbqt
    try:
        fo0 = open(sandres_root+"lig_out.pdbqt","r")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return
    
    # Looping through lig_out.pdbqt to get MODEL number
    for line in fo0:
        if "MODEL" in line:
            model_number0 = line[6:]
            model_number1 = model_number0.replace(" ","")
    
    # Some editing
    model_number2 = int(model_number1) + 1
    model_number = str(model_number2)
    
    # Close file
    fo0.close()
    
    # Try to re-open lig_out.pdbqt, now to add lig.pdbqt lines
    try:
        fo0 = open(sandres_root+"lig_out.pdbqt","a")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return
    
    # Try to open lig.pdbqt
    try:
        fo1 = open(sandres_root+"lig.pdbqt","r")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return
    
    # Add MODEL 0 line
    fo0.write("MODEL "+model_number+"\n")
    
    # Only to have this line, Vina will calculate potential later and assimilate will calculate RMSD (=0 for xtal)
    fo0.write("REMARK VINA RESULT:       0.0      0.0      0.000\n") 
    
    # Looping through lig.pdbqt
    print("\nAdding lig.pdbqt to lig_out.pdbqt...")
    for line in fo1:
        print(line)
        fo0.write(line)  # Add lig.pdbqt lines to lig_out.pdbqt
    
    # Add ENDMDL line
    fo0.write("ENDMDL")
    
    print("\nDone!")
    
    # Close files
    fo0.close()
    fo1.close()
    
def split_vina_pdbqt():
    """Function to split .pdbqt file"""
    
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Call add_xtal_to_lig_out_pdbqt
    add_xtal_to_lig_out_pdbqt()
    
    # Try to open lig_out.pdbqt
    try:
        fo = open(sandres_root+"lig_out.pdbqt","r")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return
    
    # Set up empty lists
    lines_out = []
    rmsd_vina = []
    Affinity = []
    gauss_1 = []
    gauss_2 = []
    repulsion = []
    hydrophobic = []
    Hydrogen = []
        
    # Looping through lig_out.pdbqt
    count_mdl = 0   # Set count of models to zero    
    for line in fo:
        if line[0:5] != "MODEL" and line[0:6] != "ENDMDL":
            lines_out.append(line)
        if line[0:6] == "ENDMDL":
            count_mdl += 1
            
            # Fix the number of characters with zeros
            my_str_3_char = str(count_mdl)
            if len(my_str_3_char)< 4:
                my_str_id = str((3-len(my_str_3_char) )*"0")+my_str_3_char
            
            # Write pose .pdbqt files
            pose = open(sandres_root+"lig_"+my_str_id+".pdbqt","w")
            print("\nWriting lig_"+my_str_id+".pdbqt file...",end="" )
            for line1 in lines_out:
                pose.write(line1)
            lines_out = []
            pose.close()    
            print("done.\n")
            
            # Read config.txt
            config_lines = []
            fo_config = open(sandres_root+"config.txt","r")
            for line_config in fo_config:
                config_lines.append(line_config)
            fo_config.close()
            
            # Write config_###.txt files
            print("\nWriting config_"+my_str_id+".txt file...",end="" )
            config = open(sandres_root+"config_"+my_str_id+".txt","w")
            for line_config in config_lines:
                if line_config[0:8] == "ligand =":
                    config.write("ligand = lig_"+my_str_id+".pdbqt\n")
                elif line_config[0:5] == "out =":
                    config.write("out = lig_out_"+my_str_id+".pdbqt\n")
                else:
                    config.write(line_config)
            config_lines = []
            config.close()    
            print("done.\n")
            
            # Run sandres_run_vina.py files
            print("\nRunning sandres_run_vina.py for lig_"+my_str_id+".pdbqt file.")
            run_vina_4_score_only(my_str_id)
            print("Done.\n")
            
            # Get energy terms generated by vina
            A,g1,g2,r,hy,H_atm = get_energy_terms_vina_log(my_str_id) 
            Affinity.append(A)
            gauss_1.append(g1)
            gauss_2.append(g2)
            repulsion.append(r)
            hydrophobic.append(hy)
            Hydrogen.append(H_atm)
            
            # Calculate RMSD
            # Call gen_vina_csv_4_pdbqt()
            print("\nCalculating docking RMSD for lig_"+my_str_id+".pdbqt file.")
            rmsd_mdl = gen_vina_csv_4_pdbqt(my_str_id)
            rmsd_vina.append(rmsd_mdl)
            print("done.\n")
    
    # Show vina results
    print("\n\nA total of ",count_mdl," poses were read from lig_out.pdbqt file.\n")
    print("Energy Terms Obtained from AutoDock Vina\n\n")
    print("\n\nModel\tAffinity\tGauss1\t\tGauss2\t\tRepulsion\tHydrophobic\tHydrogen\tRMSD")
    for i in range(len(rmsd_vina)):
        print(i+1,"\t",Affinity[i],"\t%.5f"%gauss_1[i],"\t%.5f"%gauss_2[i],"\t%.5f"%repulsion[i],\
        "\t%.5f"%hydrophobic[i],"\t%.5f"%Hydrogen[i],"\t%.3f"%rmsd_vina[i])
    
    # Open csv file
    vina_fo = open(dir_in0+"redock_vina.csv","w")
    
    print("\nWriting redock_vina.csv...",end="")
    
    # Looping through data
    line_out = "Model,Affinity,Gauss1,Gauss2,Repulsion,Hydrophobic,Hydrogen,RMSD\n"
    vina_fo.write(line_out)
    for i in range(len(rmsd_vina)):
        line_out = str(i+1)+","+str(Affinity[i])+","+str(gauss_1[i])+","+str(gauss_2[i])+","+\
                    str(repulsion[i])+","+str(hydrophobic[i])+","+str(Hydrogen[i])+","+str(rmsd_vina[i])+"\n"
        vina_fo.write(line_out)
    vina_fo.close()
    print("done.\n")
    
def pre_run_vina():
    """Function to call run_vina()"""
    
    # Import library
    from tkinter import messagebox
    
    # Call aux GUI
    result = messagebox.askyesno("SAnDReS","Do you want to run AutoDock Vina?")
        
    # If run is chosen
    if result:   
    
        # Call check_vina_lig_pdb()
        check_vina_lig_pdb()
                
        # Call check_vina_input()
        boolean_var = check_vina_input()

        # Only runs if all files are present (lig.pdbqt, receptor.pdbqt, and config.txt)
        if boolean_var:
            
            # Call show_message_in_sandres()
            show_message_in_sandres("SAnDReS is running AutoDock Vina...","green","light grey")
        
            # Call run_vina()
            run_vina()
        else:
            return
            
    else:
        return
    
def write_py_file_4_multiple_vina(string_in,dir_in):
    """Function to write a .py file for vina"""
        
    # Write a .py file
    fo = open(dir_in+"sandres_run_vina.py","w")
    
    fo.write("import sys, string, os\n")
    
    fo.write(string_in)
    
    fo.close()
    
def run_vina_4_score_only(file_number_in):
    """Function to run vina for score_only"""
    
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Get command line
    vina_in = "vina --config config_"+file_number_in+".txt --score_only --log log_score_"+file_number_in+".txt"+"\')\n"
    string_in = "os.system( \'\""+vina_in
            
    # Call write_py_file_4_multiple_vina()
    write_py_file_4_multiple_vina(string_in,sandres_root)
        
    # Call run_my_vina_exe()
    run_my_vina_exe()
        
    # Call copy_vina_score_outputs()
    print("\nCopying vina score results to "+dir_in0+" ...",end="")
    copy_vina_score_outputs(sandres_root,dir_in0,file_number_in)
    print("done.\n")
           
def run_vina():
    """Function to run vina"""
    
    # Get project directory
    project_dir_string0 = str(strdir_entry.get())
        
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Get command line
    vina_in0 = str(vina_command_entry.get())
    vina_in = vina_in0+"\')\n"
    string_in = "os.system( \'\""+vina_in
        
    # Call copy_vina_inputs()
    copy_vina_inputs(dir_in0,sandres_root)
    
    # Call write_py_file_4_vina()
    write_py_file_4_vina(string_in,sandres_root)
        
    # Call run_my_vina_exe()
    run_my_vina_exe()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS finished running AutoDock Vina!","black","light grey")
    
    # Call copy_vina_outputs()
    print("\nCopying vina results to "+dir_in0+" ...",end="")
    copy_vina_outputs(sandres_root,dir_in0)
    print("Done!\n")
    
    # Call gen_vina_csv_4_dataset()
    print("\nConverting vina results to CSV format...",end="")
    gen_vina_csv_4_dataset()
    print("Done!\n")
    
    # Call split_vina_pdbqt()
    split_vina_pdbqt()
        
def write_run_chrome(exe_in,site_in):
    """Function to write a python script to run chrome"""
            
    # Try to open sandres_run_chrome.py
    try:
        fo = open(sandres_root+"sandres_run_chrome.py","w")
    except IOError:
        print("\nSAnDReS Error! I can't open sandres_run_chrome.py file!")
        return
    
    # Write run_chrome.py
    fo.write("import sys, string, os\n")
    fo.write("os.system( '\""+exe_in+"\" "+site_in+"')\n")
    
def run_chrome():
    """Function to run run_chrome.py"""
    
    # Import libraries
    import sys, string, os
    
    # Run sandres_run_chrome.py
    os.system( '"start python sandres_run_chrome.py"')

def prep_run_chrome_vina_tutor1():
    """Function to prepare sandres to run chrome for vina tutorial 1"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://azevedolab.net/resources/Vina_2A4L_2017a.pdf"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()

def prep_run_chrome_gemdock_tutor1():
    """Function to prepare sandres to run chrome for gemdock tutorial 1"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://azevedolab.net/resources/GemDock_2A4L_2017a.pdf"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()

def prep_run_chrome_mvd_tutor1():
    """Function to prepare sandres to run chrome for mvd tutorial 1"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://azevedolab.net/resources/MVD_2A4L_2017a.pdf"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()

def prep_run_chrome_swissdock_tutor1():
    """Function to prepare sandres to run chrome for swissdock tutorial 1"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://azevedolab.net/resources/swissdock_2A4L_2017a.pdf"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()
    
def prep_run_chrome_vina_manual():
    """Function to prepare sandres to run chrome for vina manual"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://vina.scripps.edu/manual.html"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()

#########################################################################
# AUTODOCK 4								                            #
#########################################################################

def setup_dpf_GUI():
    """Function to call a GUI window to generate .dpf file"""
    
    # Set up global variables
    global search_algorithm_var, receptor_pdbqt_entry, lig_pdbqt_entry, autodock_seed_entry, ga_pop_size_entry,\
    ga_num_evals_entry, ga_num_generations_entry, ga_elitism_entry,ga_mutation_rate_entry, ga_crossover_rate_entry,\
    ga_number_runs_entry, ga_do_global_only_entry,\
    ls_sw_max_its_entry, ls_sw_max_succ_entry,ls_sw_max_fail_entry,ls_sw_rho_entry, ls_sw_lb_rho_entry,\
    ls_sw_search_freq_entry, ls_number_sims_entry,\
    sa_time_step_entry,sa_quaternion_step_entry, sa_torsion_step_entry, sa_initial_temperature_entry,\
    sa_temperature_red_cycles_entry, sa_accepted_cycles_entry,sa_rejected_cycles_entry, sa_simanneal_entry
    
    # Get new structure directory 
    string_strdir = str(strdir_entry.get())
    
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Set up Data for DPF') 

    top_txt.geometry("870x420+20+135")
    
    Label(top_txt, text="Parameters for DPF", font = "Arial" ).grid(row = 0,column = 0)
    
    # Widgets for search algorithm
    Label(top_txt, text="Search Algorithm:       " ).grid(row = 3,column = 0, stick = W)
    search_algorithm_var  = IntVar()
    
    # Set list for search algoriths 
    search_algorithm_list = ["LGA","GA ","LS ","SA "]
    search_algorithm_values = ["LGA","GA ","LS ","SA "]
    
    # Write search algorithm for AutoDock Run
    fo_autodock = open(sandres_root+"autodock_search_algorithm.txt","w")
    fo_autodock.write("LGA")
    fo_autodock.close()
    
    def my_sel1():
        """Function to show selection of of search algorithms"""
        selection = "Algorithm: " + str( search_algorithm_list[int(search_algorithm_var.get())])+"         "
        Label(top_txt, text=selection ).grid(row = 21,column = 0, stick = W)
        my_search_algorithm = str( search_algorithm_list[int(search_algorithm_var.get())])
        # Write search algorithm for AutoDock Run
        fo_autodock = open(sandres_root+"autodock_search_algorithm.txt","w")
        fo_autodock.write(str(my_search_algorithm))
        fo_autodock.close()
    
    # Looping through search algorithms
    for i in range(4):
        rad = Radiobutton(top_txt, text = search_algorithm_list[i], value = i, variable=search_algorithm_var,\
                           command = my_sel1)
        rad.grid(row = 3,column = i+2, stick = W)
        
    
    # Widget for receptor.pdbqt
    Label(top_txt, text="Receptor:" ).grid(row = 4,column = 0, stick = W, pady = 4)   
    receptor_pdbqt_entry = Entry(top_txt,width = 10)
    receptor_pdbqt_entry.grid(row = 4, column = 0,stick = E, pady = 4)
    receptor_pdbqt_entry.insert(10,"receptor.pdbqt")
    
    # Widget for lig.pdbqt
    Label(top_txt, text="Ligand:" ).grid(row = 5,column = 0, stick = W, pady = 4)   
    lig_pdbqt_entry = Entry(top_txt,width = 10)
    lig_pdbqt_entry.grid(row = 5, column = 0,stick = E, pady = 4)
    lig_pdbqt_entry.insert(10,"lig.pdbqt")
    
    # Widget for seed
    Label(top_txt, text="Seed:" ).grid(row = 6,column = 0, stick = W, pady = 4)   
    autodock_seed_entry = Entry(top_txt,width = 16)
    autodock_seed_entry.grid(row = 6, column = 0,stick = E, pady = 4)
    autodock_seed_entry.insert(16,"28641 1106107140")
        
    # Widgets for Genetic Algorithm Section
    Label(top_txt, text="Genetic Algorithm Section" ).grid(row = 7,column = 0, stick = W)
    
    # Widget for GA pop size
    Label(top_txt, text="GA pop size:" ).grid(row = 8,column = 0, stick = W, pady = 4)   
    ga_pop_size_entry = Entry(top_txt,width = 10)
    ga_pop_size_entry.grid(row = 8, column = 0,stick = E, pady = 4)
    ga_pop_size_entry.insert(10,"150")
    
    # Widget for GA number of evaluations
    Label(top_txt, text="GA num evals:" ).grid(row = 9,column = 0, stick = W, pady = 4)   
    ga_num_evals_entry = Entry(top_txt,width = 10)
    ga_num_evals_entry.grid(row = 9, column = 0,stick = E, pady = 4)
    ga_num_evals_entry.insert(10,"2500000")
    
    # Widget for GA number of generations
    Label(top_txt, text="GA num gens:" ).grid(row = 10,column = 0, stick = W, pady = 4)   
    ga_num_generations_entry = Entry(top_txt,width = 10)
    ga_num_generations_entry.grid(row = 10, column = 0,stick = E, pady = 4)
    ga_num_generations_entry.insert(10,"27000")
    
    # Widget for GA elitism
    Label(top_txt, text="GA elitism:" ).grid(row = 11,column = 0, stick = W, pady = 4)   
    ga_elitism_entry = Entry(top_txt,width = 10)
    ga_elitism_entry.grid(row = 11, column = 0,stick = E, pady = 4)
    ga_elitism_entry.insert(10,"1")
    
    # Widget for GA mutation rate
    Label(top_txt, text="GA mut rate:" ).grid(row = 12,column = 0, stick = W, pady = 4)   
    ga_mutation_rate_entry = Entry(top_txt,width = 10)
    ga_mutation_rate_entry.grid(row = 12, column = 0,stick = E, pady = 4)
    ga_mutation_rate_entry.insert(10,"0.02")
    
    # Widget for GA crossover rate
    Label(top_txt, text="GA co rate:" ).grid(row = 13,column = 0, stick = W, pady = 4)   
    ga_crossover_rate_entry = Entry(top_txt,width = 10)
    ga_crossover_rate_entry.grid(row = 13, column = 0,stick = E, pady = 4)
    ga_crossover_rate_entry.insert(10,"0.8")
    
    # Widget for GA number of runs
    Label(top_txt, text="GA num runs:" ).grid(row = 14,column = 0, stick = W, pady = 4)   
    ga_number_runs_entry = Entry(top_txt,width = 10)
    ga_number_runs_entry.grid(row = 14, column = 0,stick = E, pady = 4)
    ga_number_runs_entry.insert(10,"10")
    
    # Widget for GA global search
    Label(top_txt, text="GA Only runs:" ).grid(row = 15,column = 0, stick = W, pady = 4)   
    ga_do_global_only_entry = Entry(top_txt,width = 10)
    ga_do_global_only_entry.grid(row = 15, column = 0,stick = E, pady = 4)
    ga_do_global_only_entry.insert(10,"10")
    
    # Widgets for Local Search Section
    Label(top_txt, text="Local Search Section" ).grid(row = 7,column = 6, stick = W)
    
    # Widget for LS max iteractions of Solis & Wets 
    Label(top_txt, text="LS max iter:" ).grid(row = 8,column = 6, stick = W, pady = 4)   
    ls_sw_max_its_entry = Entry(top_txt,width = 10)
    ls_sw_max_its_entry.grid(row = 8, column = 7,stick = E, pady = 4)
    ls_sw_max_its_entry.insert(10,"300")
    
    # Widget for LS max consecutive successes before changing rho 
    Label(top_txt, text="LS max succ:" ).grid(row = 9,column = 6, stick = W, pady = 4)   
    ls_sw_max_succ_entry = Entry(top_txt,width = 10)
    ls_sw_max_succ_entry.grid(row = 9, column = 7,stick = E, pady = 4)
    ls_sw_max_succ_entry.insert(10,"4")
    
    # Widget for LS max consecutive failures before changing rho 
    Label(top_txt, text="LS max fail:" ).grid(row = 10,column = 6, stick = W, pady = 4)   
    ls_sw_max_fail_entry = Entry(top_txt,width = 10)
    ls_sw_max_fail_entry.grid(row = 10, column = 7,stick = E, pady = 4)
    ls_sw_max_fail_entry.insert(10,"4")
    
    # Widget for LS size of local search space to sample
    Label(top_txt, text="LS rho:" ).grid(row = 11,column = 6, stick = W, pady = 4)   
    ls_sw_rho_entry = Entry(top_txt,width = 10)
    ls_sw_rho_entry.grid(row = 11, column = 7,stick = E, pady = 4)
    ls_sw_rho_entry.insert(10,"1.0")
    
    # Widget for LS lower bound in rho
    Label(top_txt, text="LS Lower rho:" ).grid(row = 12,column = 6, stick = W, pady = 4)   
    ls_sw_lb_rho_entry = Entry(top_txt,width = 10)
    ls_sw_lb_rho_entry.grid(row = 12, column = 7,stick = E, pady = 4)
    ls_sw_lb_rho_entry.insert(10,"0.01")
    
    # Widget for LS probability of performing local search
    Label(top_txt, text="LS search freq:" ).grid(row = 13,column = 6, stick = W, pady = 4)   
    ls_sw_search_freq_entry = Entry(top_txt,width = 10)
    ls_sw_search_freq_entry.grid(row = 13, column = 7,stick = E, pady = 4)
    ls_sw_search_freq_entry.insert(10,"0.06")
    
    # Widget for LS number of simulations
    Label(top_txt, text="LS num simulations:" ).grid(row = 14,column = 6, stick = W, pady = 4)   
    ls_number_sims_entry = Entry(top_txt,width = 10)
    ls_number_sims_entry.grid(row = 14, column = 7,stick = E, pady = 4)
    ls_number_sims_entry.insert(10,"50")
    
    # Widgets for empty line
    Label(top_txt, text=15*" " ).grid(row = 7,column = 8, stick = W)
    
    # Widgets for Local Search Section
    Label(top_txt, text="Simulated Annealing Section" ).grid(row = 7,column = 9, stick = W)
    
    # Widget for SA time step 
    Label(top_txt, text="SA time step:" ).grid(row = 8,column = 9, stick = W, pady = 4)   
    sa_time_step_entry = Entry(top_txt,width = 10)
    sa_time_step_entry.grid(row = 8, column = 9,stick = E, pady = 4)
    sa_time_step_entry.insert(10,"0.2")
    
    # Widget for SA quaternion step 
    Label(top_txt, text="SA quaternion step:" ).grid(row = 9,column = 9, stick = W, pady = 4)   
    sa_quaternion_step_entry = Entry(top_txt,width = 8)
    sa_quaternion_step_entry.grid(row = 9, column = 9,stick = E, pady = 4)
    sa_quaternion_step_entry.insert(10,"5.0")
    
    # Widget for SA quaternion step 
    Label(top_txt, text="SA torsion step:" ).grid(row = 10,column = 9, stick = W, pady = 4)   
    sa_torsion_step_entry = Entry(top_txt,width = 8)
    sa_torsion_step_entry.grid(row = 10, column = 9,stick = E, pady = 4)
    sa_torsion_step_entry.insert(10,"5.0")
    
    # Widget for SA initial temperature
    Label(top_txt, text="SA initial temp:" ).grid(row = 11,column = 9, stick = W, pady = 4)   
    sa_initial_temperature_entry = Entry(top_txt,width = 6)
    sa_initial_temperature_entry.grid(row = 11, column = 9,stick = E, pady = 4)
    sa_initial_temperature_entry.insert(10,"100.0")
    
    # Widget for SA number of temperature reduction cycles
    Label(top_txt, text="SA num temp cycles:" ).grid(row = 12,column = 9, stick = W, pady = 4)   
    sa_temperature_red_cycles_entry = Entry(top_txt,width = 4)
    sa_temperature_red_cycles_entry.grid(row = 12, column = 9,stick = E, pady = 4)
    sa_temperature_red_cycles_entry.insert(10,"50")
    
    # Widget for SA maximum number of accepted steps per cycle
    Label(top_txt, text="SA num accepted stp:" ).grid(row = 13,column = 9, stick = W, pady = 4)   
    sa_accepted_cycles_entry = Entry(top_txt,width = 5)
    sa_accepted_cycles_entry.grid(row = 13, column = 9,stick = E, pady = 4)
    sa_accepted_cycles_entry.insert(10,"30000")
    
    # Widget for SA maximum number of rejected steps per cycle
    Label(top_txt, text="SA num rejected stp:" ).grid(row = 14,column = 9, stick = W, pady = 4)   
    sa_rejected_cycles_entry = Entry(top_txt,width = 5)
    sa_rejected_cycles_entry.grid(row = 14, column = 9,stick = E, pady = 4)
    sa_rejected_cycles_entry.insert(10,"30000")

    # Widget for SA maximum number of rejected steps per cycle
    Label(top_txt, text="SA num of cycles:" ).grid(row = 15,column = 9, stick = W, pady = 4)   
    sa_simanneal_entry = Entry(top_txt,width = 6)
    sa_simanneal_entry.grid(row = 15, column = 9,stick = E, pady = 4)
    sa_simanneal_entry.insert(10,"10")

    def pre_write_lga_dpf():
        """"Function to call write_lga_dpf and others"""
    
        # Try to open autodock_search_algorithm.txt
        try:
            fo_autodock = open(sandres_root+"autodock_search_algorithm.txt","r")
        except IOError:
            print("\nSAnDRES IOError! I can't find autodock_search_algorithm.txt")
            return
        for line in fo_autodock:
            my_aux = str(line)
            break
    
        fo_autodock.close()
    
        # Check which seach algorithm will be writen
        if my_aux == "LGA":
            print("\nWriting AutoDock 4. LGA search algorithm...",end="")
            # Call write_lga_dpf()
            write_lga_dpf("docking.dpf")
        elif my_aux == "GA ":
            print("\nWriting AutoDock 4. GA search algorithm...",end="")
            # Call write_ga_dpf()
            write_ga_dpf("docking.dpf")
        elif my_aux == "SA ":
            print("\nWriting AutoDock 4. SA search algorithm...",end="")
            # Call write_sa_dpf()
            write_sa_dpf("docking.dpf")
        elif my_aux == "LS ":
            print("\nWriting AutoDock 4. LS algorithm...",end="")
            # Call write_ls_dpf()
            write_ls_dpf("docking.dpf")
        
    # Button for Energy for Xtal
    Button(top_txt, text=" Energy for PDB  ", command=energy_4_xtal).grid(row = 21, column = 9, sticky = W) 
    
    # Button for Save DPF
    Button(top_txt, text="Save DPF", command=pre_write_lga_dpf).grid(row = 21, column = 9, sticky = E) 
    
    # Button for Edit DPF
    Button(top_txt, text="Open DPF", command=open_dpf).grid(row = 21, column = 10, sticky = E) 
    
    # Button to Close
    Button(top_txt, text=" Close ", bg = "red", command=top_txt.destroy).grid(row = 21, column = 11, sticky = E) 
        
        
def prep_run_chrome_sandres_diy_dd():
    """Function to prepare sandres to run chrome for sandres DIY Drug Designs"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://sandres.net/Drug-Design.php"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()
    
def prep_run_chrome_sandres_diy():
    """Function to prepare sandres to run chrome for sandres DIY"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://sandres.net/DIY-Projects.php"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()
    
def prep_run_chrome_sandres_tutorials():
    """Function to prepare sandres to run chrome for sandres tutorials"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://sandres.net/Tutorials.php"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()
    
def prep_run_chrome_sandres():
    """Function to prepare sandres to run chrome for sandres.net site"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://sandres.net/"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()
    
def prep_run_chrome_autodock_tutor1():
    """Function to prepare sandres to run chrome for autodock tutorial 1"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://azevedolab.net/resources/AutoDock4_2A4L_2017a.pdf"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()
    
def prep_run_chrome_autodock_manual():
    """Function to prepare sandres to run chrome for autodock 4.2.6 manual"""
    
    # Import library
    import csv
    
    # Read chrome_exe from sandres_par.csv
    try:
        fo = open(sandres_root+"sandres_par.csv","r")
        csv1 = csv.reader(fo)
    except IOError:
        print("\nSAnDReS Error! I can't find sandres_par.csv file.")
        return
    
    # Looping through csv1
    for line in csv1:
        if line[0] == "google_chrome":
            chrome_exe = line[1]
    
    fo.close()
    
    # Set up variable for site
    site_2_open = "http://autodock.scripps.edu/faqs-help/manual/autodock-4-2-user-guide/AutoDock4.2.6_UserGuide.pdf"
    
    # Call write_run_chrome()
    write_run_chrome(chrome_exe,site_2_open)
    
    # Call run_chrome()
    run_chrome()

def run_my_autodock_exe():
    """Function to run autodock4.exe -p docking.dpf -l docking.dlg"""
    
    # Import libraries
    import sys, string, os
    from tkinter import messagebox
    
    # Now run the script
    os.system( '"python sandres_run_autodock.py"' )

def write_py_file_4_autodock(string_in):
    """Function to write a .py file for autodock"""
        
    # Write a .py file
    fo = open("sandres_run_autodock.py","w")
    
    fo.write("import sys, string, os\n")
    
    fo.write(string_in)
    
    fo.close()

def copy_autodock_inputs(dir_source,dir_target):
    """Function to copy autodock inputs"""
    
    # Import library
    import shutil
    
    list1 = ["lig.pdbqt","receptor.pdbqt","autodock4.exe"]
    
    # Looping through files to be copied
    for line in list1:
        # Copy file
        shutil.copy2(dir_source+line,dir_target+line)

def energy_4_xtal():
    """Function to calculate energy for xtal position (no docking pose)"""
    
    # Import libraries
    import shutil
    import errno 
    import os
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
        
    # Call write_epdb_dpf()
    write_epdb_dpf("docking.dpf")
        
    # Call pre_run_autodock()
    pre_run_autodock()
                
    # Call gen_my_epdb_csv()
    gen_my_epdb_csv("docking.dlg","epdb_autodock.csv")
    
    # Set up list with the files to be copied
    list_to_be_copied = ["docking.gpf","docking.glg","docking.dpf","docking.dlg","receptor.A.map","receptor.C.map",
    "receptor.d.map","receptor.e.map","receptor.N.map","receptor.NA.map","receptor.OA.map","receptor.maps.fld","receptor.maps.xyz",
    "epdb_autodock.csv"]
    
    # Define new directory name # WFA 2018 01 09
    path2go = dir_in0+"/EPDB/"
    
    # Try makedirs 
    try:
        os.makedirs(path2go)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise 
            
    # Copy files in the list_to_be_copied 
    for line in list_to_be_copied:
        try:
            shutil.copy2(sandres_root+line,path2go+line)
        except IOError:
            print("SAnDReS IOError! I can't find "+line+" file.")
    
def write_epdb_dpf(file_in):
    """Function to write Enegy for xtal position file_in.dpf to run autodock4"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty lists
    ligand_types = []
    ligand_atoms = []
    sorted_ligand_types = []
        
    # Try to read lig.pdbqt
    try:
        fo = open(dir_in0+"lig.pdbqt","r")
        print("\nReading lig.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"lig.pdbqt file!")
        return
    
    # Looping through lig.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            ligand_types.append(aux2)
        elif line[0:7] == "TORSDOF":
            tor0 = str(line[7:])
            tor1 = tor0.replace("\n","")
            tor2 = tor1.replace(" ","")
    
    print("done.\n")
    
    fo.close()

    # Looping through ligand_types to unify list
    ligand_atoms.append(ligand_types[0])
    for line in ligand_types:
        if line not in ligand_atoms:
            ligand_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_ligand_types = sorted(ligand_atoms)
    
    print("\nList of ligand_types: ",sorted_ligand_types)
    
    # Try to open config.txt
    try:
        fo = open(dir_in0+"config.txt","r")
        print("\nReading config.txt...",end="")
    except IOError:
        print("\nI can't find config.txt file!")
        return
    
    print("done.\n")
    
    # Looping through config.txt
    for line in fo:
        if line[0:10] == "center_x =":
            print("center_x :",line[11:])
            center_x = str(line[11:])
            x0 = center_x.replace(" ","")
            x = x0.replace("\n","")
        elif line[0:10] == "center_y =":
            print("center_y :",line[11:])
            center_y = str(line[11:])
            y0 = center_y.replace(" ","")
            y = y0.replace("\n","")
        elif line[0:10] == "center_z =":
            print("center_z :",line[11:])
            center_z = str(line[11:])
            z0 = center_z.replace(" ","")
            z = z0.replace("\n","")
    fo.close()
    
    # Write docking.dpf
    print("\nWriting "+file_in+"...",end="")
    fo = open(file_in,"w")
    
    fo.write("## GENERIC SECTION \n")
    fo.write("autodock_parameter_version 4.2       # used by autodock to validate parameter set\n")
    fo.write("outlev adt                           # diagnostic output level\n")
        
    fo.write("\n## LIGAND-SPECIFIC SECTION \n")
    # Take care of ligand_types
    line_aux = "ligand_types "
    
    # Looping through sorted_ligand_types
    for line in sorted_ligand_types:
        line_aux +=line+" "
    line_aux += "            # ligand atom types\n"
    fo.write(line_aux)
    
    fo.write("fld receptor.maps.fld                    # grid_data_file\n")
    
    # Take care of maps
    line_aux = "map receptor."
    for line in sorted_ligand_types:
        if line != "H":
            line_aux += line
            line_aux +=".map                       # atom-specific affinity map\n"
            fo.write(line_aux)
            line_aux = "map receptor." 
    
    fo.write("elecmap receptor.e.map                   # electrostatic potential map\n")
    fo.write("dsolvmap receptor.d.map                  # desolvation potential map\n")
    fo.write("move lig.pdbqt                       # small molecule\n")
        
    fo.write("\n## EVALUATE LIGAND ENERGY in RECEPTOR SECTION\n")
    fo.write("epdb                                 # small molecule to be evaluated")
    
    fo.close()
    
    print("done.\n")
  
def write_ga_dpf(file_in):
    """Function to write GA file_in.dpf to run autodock4"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty lists
    ligand_types = []
    ligand_atoms = []
    sorted_ligand_types = []
        
    # Try to read lig.pdbqt
    try:
        fo = open(dir_in0+"lig.pdbqt","r")
        print("\nReading lig.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"lig.pdbqt file!")
        return
    
    # Looping through lig.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            ligand_types.append(aux2)
        elif line[0:7] == "TORSDOF":
            tor0 = str(line[7:])
            tor1 = tor0.replace("\n","")
            tor2 = tor1.replace(" ","")
    
    print("done.\n")
    
    fo.close()

    # Looping through ligand_types to unify list
    ligand_atoms.append(ligand_types[0])
    for line in ligand_types:
        if line not in ligand_atoms:
            ligand_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_ligand_types = sorted(ligand_atoms)
    
    print("\nList of ligand_types: ",sorted_ligand_types)
    
    # Try to open config.txt
    try:
        fo = open(dir_in0+"config.txt","r")
        print("\nReading config.txt...",end="")
    except IOError:
        print("\nI can't find config.txt file!")
        return
    
    print("done.\n")
    
    # Looping through config.txt
    for line in fo:
        if line[0:10] == "center_x =":
            print("center_x :",line[11:])
            center_x = str(line[11:])
            x0 = center_x.replace(" ","")
            x = x0.replace("\n","")
        elif line[0:10] == "center_y =":
            print("center_y :",line[11:])
            center_y = str(line[11:])
            y0 = center_y.replace(" ","")
            y = y0.replace("\n","")
        elif line[0:10] == "center_z =":
            print("center_z :",line[11:])
            center_z = str(line[11:])
            z0 = center_z.replace(" ","")
            z = z0.replace("\n","")
    fo.close()
    
    # Write docking.dpf
    print("\nWriting "+file_in+"...",end="")
    fo = open(file_in,"w")
    
    fo.write("## GENERIC SECTION \n")
    fo.write("autodock_parameter_version 4.2       # used by autodock to validate parameter set\n")
    fo.write("outlev adt                           # diagnostic output level\n")
    fo.write("intelec                              # calculate internal electrostatics\n")
    fo.write("seed "+str(autodock_seed_entry.get())+"                # seeds for random generator \n")
        
    fo.write("\n## LIGAND-SPECIFIC SECTION \n")
    # Take care of ligand_types
    line_aux = "ligand_types "
    
    # Looping through sorted_ligand_types
    for line in sorted_ligand_types:
        line_aux +=line+" "
    line_aux += "            # ligand atom types\n"
    fo.write(line_aux)
    
    fo.write("fld receptor.maps.fld                    # grid_data_file\n")
    
    # Take care of maps
    line_aux = "map receptor."
    for line in sorted_ligand_types:
        line_aux += line
        line_aux +=".map                       # atom-specific affinity map\n"
        fo.write(line_aux)
        line_aux = "map receptor." 
    
    fo.write("elecmap receptor.e.map                   # electrostatic potential map\n")
    fo.write("dsolvmap receptor.d.map                  # desolvation potential map\n")
    fo.write("move lig.pdbqt                       # small molecule\n")
    
    # Take care of about
    fo.write("about "+x+" "+y+" "+z+"                # small molecule center\n")
    
    fo.write("\n## INITIAL SEARCH STATE SECTION\n")
    
    fo.write("tran0 random                         # initial coordinates/A or random\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("dihe0 random                         # initial dihedrals (relative) or random\n")
    
    fo.write("\n## FREE ENERGY ENTROPY ADJUSTMENT SECTION\n")
    fo.write("torsdof "+tor2+"                            # torsional degrees of freedom\n")
    fo.write("rmstol 2.0                           # cluster_tolerance/A\n")
    fo.write("extnrg 1000.0                        # external grid energy\n")
    fo.write("e0max 0.0 10000                      # max initial energy; max number of retries\n")
    
    fo.write("\n## SEARCH-SPECIFIC SECTION\n")
    dpf_line = "ga_pop_size "+str(ga_pop_size_entry.get())+"                      # number of individuals in population\n"
    fo.write(dpf_line)
    
    dpf_line ="ga_num_evals "+str(ga_num_evals_entry.get())+"                 # maximum number of energy evaluations\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_num_generations "+str(ga_num_generations_entry.get())+"             # maximum number of generations\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_elitism "+str(ga_elitism_entry.get())+"                         # number of top individuals to survive to next generation\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_mutation_rate "+str(ga_mutation_rate_entry.get())+"                # rate of gene mutation\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_crossover_rate "+str(ga_crossover_rate_entry.get())+"                # rate of crossover\n"
    fo.write(dpf_line)
    
    fo.write("ga_window_size 10                    # \n")
    fo.write("ga_cauchy_alpha 0.0                  # Alpha parameter of Cauchy distribution\n")
    fo.write("ga_cauchy_beta 1.0                   # Beta parameter Cauchy distribution\n")
    fo.write("set_ga                               # set the above parameters for GA or LGA\n")
    fo.write("unbound_model bound                  # state of unbound ligand\n")
    
    fo.write("\n## PERFORM SEARCH SECTION\n")
    dpf_line = "do_global_only "+str(ga_do_global_only_entry.get())+"                    # how many dockings to run GA runs\n"
    fo.write(dpf_line)
    
    fo.write("\n## ANALYSIS SECTION\n")
    fo.write("analysis                             # perform a ranked cluster analysis")
        
    fo.close()
    print("done.\n")

def write_ls_dpf(file_in):
    """Function to write LS file_in.dpf to run autodock4"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty lists
    ligand_types = []
    ligand_atoms = []
    sorted_ligand_types = []
        
    # Try to read lig.pdbqt
    try:
        fo = open(dir_in0+"lig.pdbqt","r")
        print("\nReading lig.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"lig.pdbqt file!")
        return
    
    # Looping through lig.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            ligand_types.append(aux2)
        elif line[0:7] == "TORSDOF":
            tor0 = str(line[7:])
            tor1 = tor0.replace("\n","")
            tor2 = tor1.replace(" ","")
    
    print("done.\n")
    
    fo.close()

    # Looping through ligand_types to unify list
    ligand_atoms.append(ligand_types[0])
    for line in ligand_types:
        if line not in ligand_atoms:
            ligand_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_ligand_types = sorted(ligand_atoms)
    
    print("\nList of ligand_types: ",sorted_ligand_types)
    
    # Try to open config.txt
    try:
        fo = open(dir_in0+"config.txt","r")
        print("\nReading config.txt...",end="")
    except IOError:
        print("\nI can't find config.txt file!")
        return
    
    print("done.\n")
    
    # Looping through config.txt
    for line in fo:
        if line[0:10] == "center_x =":
            print("center_x :",line[11:])
            center_x = str(line[11:])
            x0 = center_x.replace(" ","")
            x = x0.replace("\n","")
        elif line[0:10] == "center_y =":
            print("center_y :",line[11:])
            center_y = str(line[11:])
            y0 = center_y.replace(" ","")
            y = y0.replace("\n","")
        elif line[0:10] == "center_z =":
            print("center_z :",line[11:])
            center_z = str(line[11:])
            z0 = center_z.replace(" ","")
            z = z0.replace("\n","")
    fo.close()
    
    # Write docking.dpf
    print("\nWriting "+file_in+"...",end="")
    fo = open(file_in,"w")
    
    fo.write("## GENERIC SECTION \n")
    fo.write("autodock_parameter_version 4.2       # used by autodock to validate parameter set\n")
    fo.write("outlev adt                           # diagnostic output level\n")
    fo.write("intelec                              # calculate internal electrostatics\n")
    fo.write("seed "+str(autodock_seed_entry.get())+"                # seeds for random generator \n")
    
    fo.write("\n## LIGAND-SPECIFIC SECTION \n")
    # Take care of ligand_types
    line_aux = "ligand_types "
    
    # Looping through sorted_ligand_types
    for line in sorted_ligand_types:
        line_aux +=line+" "
    line_aux += "            # ligand atom types\n"
    fo.write(line_aux)
    
    fo.write("fld receptor.maps.fld                    # grid_data_file\n")
    
    # Take care of maps
    line_aux = "map receptor."
    for line in sorted_ligand_types:
        line_aux += line
        line_aux +=".map                       # atom-specific affinity map\n"
        fo.write(line_aux)
        line_aux = "map receptor." 
    
    fo.write("elecmap receptor.e.map                   # electrostatic potential map\n")
    fo.write("dsolvmap receptor.d.map                  # desolvation potential map\n")
    fo.write("move lig.pdbqt                       # small molecule\n")
    
    # Take care of about
    fo.write("about "+x+" "+y+" "+z+"                # small molecule center\n")
        
    fo.write("\n## INITIAL SEARCH STATE SECTION\n")
    
    fo.write("tran0 random                         # initial coordinates/A or random\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("dihe0 random                         # initial dihedrals (relative) or random\n")
    
    fo.write("\n## FREE ENERGY ENTROPY ADJUSTMENT SECTION\n")
    fo.write("torsdof "+tor2+"                            # torsional degrees of freedom\n")
   
    fo.write("\n## LOCAL SEARCH PARAMETERS SECTION\n")
    dpf_line = "sw_max_its "+str(ls_sw_max_its_entry.get())+"                       # iterations of Solis & Wets local search\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_max_succ "+str(ls_sw_max_succ_entry.get())+"                        # consecutive successes before changing rho\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_max_fail "+str(ls_sw_max_fail_entry.get())+"                        # consecutive failures before changing rho\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_rho "+str(ls_sw_rho_entry.get())+"                           # size of local search space to sample\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_lb_rho "+str(ls_sw_lb_rho_entry.get())+"                       # lower bound on rho\n"
    fo.write(dpf_line)
    
    fo.write("ls_search_freq 1.0                   # probability of performing local search on individual\n")
    fo.write("set_psw1                             # set the above pseudo-Solis & Wets parameters\n")

    fo.write("\n## PERFORM SEARCH SECTION\n")
    dpf_line = "do_local_only "+str(ls_number_sims_entry.get())+"                     # Number of LS simulations\n"
    fo.write(dpf_line)
    
    fo.write("\n## ANALYSIS SECTION\n")
    fo.write("rmstol 0.5                           # cluster_tolerance/A \n")
    fo.write("analysis                             # perform a ranked cluster analysis")
        
    fo.close()
    print("done.\n")

def write_sa_dpf(file_in):
    """Function to write SA file_in.dpf to run autodock4"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty lists
    ligand_types = []
    ligand_atoms = []
    sorted_ligand_types = []
        
    # Try to read lig.pdbqt
    try:
        fo = open(dir_in0+"lig.pdbqt","r")
        print("\nReading lig.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"lig.pdbqt file!")
        return
    
    # Looping through lig.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            ligand_types.append(aux2)
        elif line[0:7] == "TORSDOF":
            tor0 = str(line[7:])
            tor1 = tor0.replace("\n","")
            tor2 = tor1.replace(" ","")
    
    print("done.\n")
    
    fo.close()

    # Looping through ligand_types to unify list
    ligand_atoms.append(ligand_types[0])
    for line in ligand_types:
        if line not in ligand_atoms:
            ligand_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_ligand_types = sorted(ligand_atoms)
    
    print("\nList of ligand_types: ",sorted_ligand_types)
    
    # Try to open config.txt
    try:
        fo = open(dir_in0+"config.txt","r")
        print("\nReading config.txt...",end="")
    except IOError:
        print("\nI can't find config.txt file!")
        return
    
    print("done.\n")
    
    # Looping through config.txt
    for line in fo:
        if line[0:10] == "center_x =":
            print("center_x :",line[11:])
            center_x = str(line[11:])
            x0 = center_x.replace(" ","")
            x = x0.replace("\n","")
        elif line[0:10] == "center_y =":
            print("center_y :",line[11:])
            center_y = str(line[11:])
            y0 = center_y.replace(" ","")
            y = y0.replace("\n","")
        elif line[0:10] == "center_z =":
            print("center_z :",line[11:])
            center_z = str(line[11:])
            z0 = center_z.replace(" ","")
            z = z0.replace("\n","")
    fo.close()
    
    # Write docking.dpf
    print("\nWriting "+file_in+"...",end="")
    fo = open(file_in,"w")
    
    fo.write("## GENERIC SECTION \n")
    fo.write("autodock_parameter_version 4.2       # used by autodock to validate parameter set\n")
    fo.write("outlev adt                           # diagnostic output level\n")
    fo.write("intelec                              # calculate internal electrostatics\n")
    fo.write("seed "+str(autodock_seed_entry.get())+"                # seeds for random generator \n")
        
    fo.write("\n## LIGAND-SPECIFIC SECTION \n")
    # Take care of ligand_types
    line_aux = "ligand_types "
    
    # Looping through sorted_ligand_types
    for line in sorted_ligand_types:
        line_aux +=line+" "
    line_aux += "            # ligand atom types\n"
    fo.write(line_aux)
    
    fo.write("fld receptor.maps.fld                    # grid_data_file\n")
    
    # Take care of maps
    line_aux = "map receptor."
    for line in sorted_ligand_types:
        line_aux += line
        line_aux +=".map                       # atom-specific affinity map\n"
        fo.write(line_aux)
        line_aux = "map receptor." 
    
    fo.write("elecmap receptor.e.map                   # electrostatic potential map\n")
    fo.write("dsolvmap receptor.d.map                  # desolvation potential map\n")
    fo.write("move lig.pdbqt                       # small molecule\n")
    
    # Take care of about
    fo.write("about "+x+" "+y+" "+z+"                # small molecule center\n")
    
    fo.write("\n## INITIAL SEARCH STATE SECTION\n")
    
    fo.write("tran0 random                         # initial coordinates/A or random\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("dihe0 random                         # initial dihedrals (relative) or random\n")
    
    fo.write("\n## SIMULATED ANNEALING SEARCH PARAMETERS SECTION\n")
    
    dpf_line = "tstep "+str(sa_time_step_entry.get())+"                            # quaternion stp/d translation stp/A \n"
    
    fo.write(dpf_line)
    
    dpf_line = "qstep "+str(sa_quaternion_step_entry.get())+"                            # quaternion step/deg\n"
    fo.write(dpf_line)
    
    dpf_line = "dstep "+str(sa_torsion_step_entry.get())+"                            # torsion step/deg\n"
    fo.write(dpf_line)
    
    dpf_line = "rt0 "+str(sa_initial_temperature_entry.get())+"                            # initial annealing temperature\n"
    fo.write(dpf_line)
    
    fo.write("linear_schedule                      # use linear, arithmetic temperature reduction \n")
    
    dpf_line = "cycles "+str(sa_temperature_red_cycles_entry.get())+"                            # number of temperature reduction cycles\n"
    fo.write(dpf_line)
    
    dpf_line = "accs "+str(sa_accepted_cycles_entry.get())+"                           # max num of accepted steps p/cycle\n"
    fo.write(dpf_line)
    
    dpf_line = "rejs "+str(sa_rejected_cycles_entry.get())+"                           # max num of rejected steps p/cycle\n"
    fo.write(dpf_line)
    
    fo.write("select m                             # state selection flag: (m)inimum or (l)ast state\n")
        
    fo.write("\n## PERFORM SEARCH SECTION\n")
    dpf_line = "simanneal "+str(sa_simanneal_entry.get())+"  \n"
    fo.write(dpf_line)
    
    fo.write("\n## ANALYSIS SECTION\n")
    fo.write("rmstol 0.5                           # cluster_tolerance/A \n")
    fo.write("analysis                             # perform a ranked cluster analysis")
        
    fo.close()
    print("done.\n")
    
def write_lga_dpf(file_in):
    """Function to write LGA file_in.dpf to run autodock4"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty lists
    ligand_types = []
    ligand_atoms = []
    sorted_ligand_types = []
        
    # Try to read lig.pdbqt
    try:
        fo = open(dir_in0+"lig.pdbqt","r")
        print("\nReading lig.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"lig.pdbqt file!")
        return
    
    # Looping through lig.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            ligand_types.append(aux2)
        elif line[0:7] == "TORSDOF":
            tor0 = str(line[7:])
            tor1 = tor0.replace("\n","")
            tor2 = tor1.replace(" ","")
    
    print("done.\n")
    
    fo.close()

    # Looping through ligand_types to unify list
    ligand_atoms.append(ligand_types[0])
    for line in ligand_types:
        if line not in ligand_atoms:
            ligand_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_ligand_types = sorted(ligand_atoms)
    
    print("\nList of ligand_types: ",sorted_ligand_types)
    
    # Try to open config.txt
    try:
        fo = open(dir_in0+"config.txt","r")
        print("\nReading config.txt...",end="")
    except IOError:
        print("\nI can't find config.txt file!")
        return
    
    print("done.\n")
    
    # Looping through config.txt
    for line in fo:
        if line[0:10] == "center_x =":
            print("center_x :",line[11:])
            center_x = str(line[11:])
            x0 = center_x.replace(" ","")
            x = x0.replace("\n","")
        elif line[0:10] == "center_y =":
            print("center_y :",line[11:])
            center_y = str(line[11:])
            y0 = center_y.replace(" ","")
            y = y0.replace("\n","")
        elif line[0:10] == "center_z =":
            print("center_z :",line[11:])
            center_z = str(line[11:])
            z0 = center_z.replace(" ","")
            z = z0.replace("\n","")
    fo.close()
    
    # Write docking.dpf
    print("\nWriting "+file_in+"...",end="")
    fo = open(file_in,"w")
    
    fo.write("## GENERIC SECTION \n")
    fo.write("autodock_parameter_version 4.2       # used by autodock to validate parameter set\n")
    fo.write("outlev adt                           # diagnostic output level\n")
    fo.write("intelec                              # calculate internal electrostatics\n")
    fo.write("seed "+str(autodock_seed_entry.get())+"                # seeds for random generator \n")
        
    fo.write("\n## LIGAND-SPECIFIC SECTION \n")
    # Take care of ligand_types
    line_aux = "ligand_types "
    
    # Looping through sorted_ligand_types
    for line in sorted_ligand_types:
        line_aux +=line+" "
    line_aux += "         # ligand atom types\n"
    fo.write(line_aux)
    
    fo.write("fld receptor.maps.fld                    # grid_data_file\n")
    
    # Take care of maps
    line_aux = "map receptor."
    for line in sorted_ligand_types:
        line_aux += line
        line_aux +=".map                       # atom-specific affinity map\n"
        fo.write(line_aux)
        line_aux = "map receptor." 
    
    fo.write("elecmap receptor.e.map                   # electrostatic potential map\n")
    fo.write("dsolvmap receptor.d.map                  # desolvation potential map\n")
    fo.write("move lig.pdbqt                       # small molecule\n")
    
    # Take care of about
    fo.write("about "+x+" "+y+" "+z+"                # small molecule center\n")
    
    fo.write("\n## INITIAL SEARCH STATE SECTION\n")
    
    fo.write("tran0 random                         # initial coordinates/A or random\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("quaternion0 random                   # initial orientation\n")
    fo.write("dihe0 random                         # initial dihedrals (relative) or random\n")
    
    fo.write("\n## FREE ENERGY ENTROPY ADJUSTMENT SECTION\n")
    fo.write("torsdof "+tor2+"                            # torsional degrees of freedom\n")
    fo.write("rmstol 2.0                           # cluster_tolerance/A\n")
    fo.write("extnrg 1000.0                        # external grid energy\n")
    fo.write("e0max 0.0 10000                      # max initial energy; max number of retries\n")
    
    fo.write("\n## SEARCH-SPECIFIC SECTION\n")
    dpf_line = "ga_pop_size "+str(ga_pop_size_entry.get())+"                      # number of individuals in population\n"
    fo.write(dpf_line)
    
    dpf_line ="ga_num_evals "+str(ga_num_evals_entry.get())+"                 # maximum number of energy evaluations\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_num_generations "+str(ga_num_generations_entry.get())+"             # maximum number of generations\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_elitism "+str(ga_elitism_entry.get())+"                         # number of top individuals to survive to next generation\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_mutation_rate "+str(ga_mutation_rate_entry.get())+"                # rate of gene mutation\n"
    fo.write(dpf_line)
    
    dpf_line = "ga_crossover_rate "+str(ga_crossover_rate_entry.get())+"                # rate of crossover\n"
    fo.write(dpf_line)
    
    fo.write("ga_window_size 10                    # \n")
    fo.write("ga_cauchy_alpha 0.0                  # Alpha parameter of Cauchy distribution\n")
    fo.write("ga_cauchy_beta 1.0                   # Beta parameter Cauchy distribution\n")
    fo.write("set_ga                               # set the above parameters for GA or LGA\n")
    
    fo.write("\n## LOCAL SEARCH PARAMETERS SECTION\n")
    dpf_line = "sw_max_its "+str(ls_sw_max_its_entry.get())+"                       # iterations of Solis & Wets local search\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_max_succ "+str(ls_sw_max_succ_entry.get())+"                        # consecutive successes before changing rho\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_max_fail "+str(ls_sw_max_fail_entry.get())+"                        # consecutive failures before changing rho\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_rho "+str(ls_sw_rho_entry.get())+"                           # size of local search space to sample\n"
    fo.write(dpf_line)
    
    dpf_line = "sw_lb_rho "+str(ls_sw_lb_rho_entry.get())+"                       # lower bound on rho\n"
    fo.write(dpf_line)
    
    dpf_line = "ls_search_freq "+str(ls_sw_search_freq_entry.get())+"                  # probability of performing local search on individual\n"
    fo.write(dpf_line)
    
    fo.write("set_psw1                             # set the above pseudo-Solis & Wets parameters\n")
    fo.write("unbound_model bound                  # state of unbound ligand\n")

    fo.write("\n## PERFORM SEARCH SECTION\n")
    dpf_line = "ga_run "+str(ga_number_runs_entry.get())+"                            # do this many hybrid GA-LS runs\n"
    fo.write(dpf_line)
    
    fo.write("\n## ANALYSIS SECTION\n")
    fo.write("analysis                             # perform a ranked cluster analysis")
        
    fo.close()
    print("done.\n")

def copy_autodock_outputs(dir_source,dir_target):
    """Function to copy autodock outputs"""
    
    # Import library
    import shutil
    
    list1 = ["docking.glg","docking.dlg"]
    
    # Looping through files to be copied
    for line in list1:
        # Copy file
        shutil.copy2(dir_source+line,dir_target+line)

def copy_dlg(file_in):
    """Function to copy docking.dlg file to project_dir"""
    
    # Import library
    import shutil
    
    # Get project directory
    project_dir_string0 = str(strdir_entry.get())
        
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Copy file
    print("\nCopying "+file_in+"...",end="")
    shutil.copy2(dir_in0+file_in,project_dir_string0+file_in)
    print("done.\n")

def gen_my_autodock_csv(file_in,file_out):
    """Function to generate csv file from autodock .dlg file"""
        
    # Read input file name  
    f1 = file_in
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Call read_RMSD()
    l1,l2 = read_RMSD(project_dir_string+f1)
    
    # Call energy_terms()
    l3,l4,l5,l6,l7,l8 = energy_terms(project_dir_string+f1)
    
    # Looping through list of models  
    for i in range(len(l1)):
        print(l1[i],l2[i],l3[int(l1[i])-1], l4[int(l1[i])-1], l5[int(l1[i])-1], l6[int(l1[i])-1],\
        l7[int(l1[i])-1],l8[int(l1[i])-1]  )   
        
    # Call make_csv()
    make_csv(l1,l2,l3,l4,l5,l6,l7,l8,project_dir_string+file_out)
    
def autodock_strmsd():
    """Function to run strmsd.in obtained from autodock results"""
    
    # Import libraries
    import shutil
    import errno 
    import os
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
                
    # Call prepare_input_4_strmsd
    prepare_input_4_strmsd()
    
    # Call run_sandres_in()
    run_sandres_in("strmsd.in") 
        
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished running strmsd.in!","black","light grey")
    
    # Show log file content on window_txt
    read_log_file("strmsd.log")
    
    # Set up list with the files to be copied1
    list_to_be_copied1 = ["strmsd.in","strmsd.log","strmsd.csv","redock_autodock.csv"]
    
    # Set up list with the files to be copied2
    list_to_be_copied2 = ["docking.gpf","docking.glg","docking.dpf","docking.dlg","receptor.A.map","receptor.C.map",
    "receptor.d.map","receptor.e.map","receptor.N.map","receptor.NA.map","receptor.OA.map","receptor.maps.fld","receptor.maps.xyz"]
    
    # Get the search algorithm used in the autodock run
    # Try to open autodock_search_algorithm.txt
    try:
        fo =  open(sandres_root+"autodock_search_algorithm.txt","r")
    except IOError:
        print("\a")
        print("\nSAnDReS IOError! I can't find autodock_search_algorithm.txt file.")
        return
    
    # Get the search algorithm
    for line in fo:
        my_s_m0 = str(line)
        break
    
    fo.close()
    
    # Some editing
    my_s_m1 = my_s_m0.replace(" ","")
    my_s_m = my_s_m1.upper() 
        
    # Define new directory name # WFA 2018 01 09
    path2go = dir_in0+"/"+my_s_m
    
    # Try makedirs 
    try:
        os.makedirs(path2go)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise 
            
    # Copy files in the list_to_be_copied1 # WFA 2018 01 09
    for line in list_to_be_copied1:
        try:
            shutil.copy2(project_dir_string+line,path2go+"/"+line)
        except IOError:
            print("SAnDReS IOError! I can't find "+line+" file.")
    
    # Move files in list_to_be_copied2  
    for line in list_to_be_copied2:
        try:
            shutil.copy2(sandres_root+line,path2go)
        except IOError:
            print("SAnDReS IOError! I can't find "+line+" file.")
        
def run_autodock():
    """Function to run autodock"""
    
    # Get project directory
    project_dir_string0 = str(strdir_entry.get())
        
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Get command line
    autodock_in0 = str(autodock_command_entry.get())
    autodock_in = autodock_in0+"\')\n"
    string_in = "os.system( \'\""+autodock_in
    
    # Call copy_autodock_inputs()
    copy_autodock_inputs(dir_in0,sandres_root)
                
    # Call write_py_file_4_autodock()
    write_py_file_4_autodock(string_in)
        
    # Call run_my_autodock_exe()
    run_my_autodock_exe()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS finished running AutoDock 4!","black","light grey")

    # Checking autogrid results
    print("\nChecking AutoDock results...",end="")
    
    # Try to open docking.dlg
    try:
        fo = open("docking.dlg","r")
    except IOError:
        print("\nI can't find docking.gdlg file.")
        return
        
    # Looping through docking.dlg file
    success = False
    for line in fo:
        if "autodock4: Successful Completion on" in line:
            print("done.\n")
            success = True
            print(line)
            
    # Show message if not success
    if not success:
        print("done.\n")
        print("\nNot successful completion for AutoDock. Please check docking.dlg file.")
    
    # Call copy_autodock_outputs()
    print("\nCopying autodock results to "+dir_in0+" ...",end="")
    copy_autodock_outputs(sandres_root,dir_in0)
    print("done.\n")   
    
    # Call copy_dlg()
    copy_dlg("docking.dlg")
        
    # Delete string
    input_csv_file_entry.delete(0,END)
        
    # Insert string
    input_csv_file_entry.insert(10,"redock_autodock.csv")
    
    # Call gen_my_autodock_csv()
    gen_my_autodock_csv("docking.dlg","redock_autodock.csv")
        
def check_autodock_inputs():
    """Function to check if lig.pdbqt, receptor.pdbqt, and docking.dpf files are in the running directory"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up list of files to checked
    list_of_files = ["lig.pdbqt","receptor.pdbqt","docking.dpf"]
    
    # Looping through list of files
    check_ok = True
    for line in list_of_files:
        print("\nChecking if ",line," is in the ",dir_in0," directory...", end="")
        try:
            fo = open(dir_in0+line,"r")
            print("done!\n")
        except IOError:
            my_message1 = "SAnDReS IOError!"
            my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
            show_warning_message_pop_up(my_message1,my_message2)
            check_ok = False
            return check_ok
    
    return check_ok

def check_autodock_lig_pdb():
    """Function to check lig.pdb before running autodock"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty list
    lig_in = []
    lig_out = []
    
    # Try to open lig,pdb
    try:
        fo = open(dir_in0+"lig.pdb","r")
        print("\nReading lig,pdb...",end="")
    except IOError:
        my_message1 = "SAnDReS IOError!"
        my_message2 = "SAnDReS didn't find "+str(line)+" file in the "+str(dir_in0)+" directory."
        show_warning_message_pop_up(my_message1,my_message2)
        return
    
    # Looping through lig.pdb
    low_occ = False
    for line in fo:
        if line[0:6] == "ATOM   " or line[0:6] == "HETATM":
            if float(line[56:60]) < 1.00:
                low_occ = True
        lig_in.append(line)
    
    fo.close()
    print("done.\n")
    
    # Looping through lig_in:
    print("\nChecking lig.pdb...",end="")
    former_line_12_16 = "    "
    for i in range(len(lig_in)-1):
        line1 = str(lig_in[i])
        line2 = str(lig_in[i+1])
        if line1[0:6] == "ATOM   " or line1[0:6] == "HETATM":
            if line2[0:6] == "ATOM   " or line2[0:6] == "HETATM":
                if float(line1[56:60]) > 0.50:
                    aux = line1[0:16]+" "+line1[17:]
                    lig_out.append(aux)
                elif line1[12:16] == line2[12:16]:
                    if float(line1[56:60]) >= float(line2[56:60]):
                        aux = line1[0:16]+" "+line1[17:]
                        lig_out.append(aux)
                    else:
                        aux = line2[0:16]+" "+line2[17:]
                        lig_out.append(aux)
    
    lig_out.append("END")
                        
    # If low_occ is found new lig.pdb is generated
    if low_occ:
        print("\nOccupancy factor < 1.00 identified in lig.pdb! Writing highest occupancy atoms...",end="")
        
        # Open new lig.pdb
        fo = open(dir_in0+"lig.pdb","w")
        
        # Looping through lig_out
        for line in lig_out:
            print(line)
            fo.write(line)
        
        print("done.")
    
        fo.close()
    else:
        print("done.")
        print("\nNo low occupancy atoms found in lig.pdb file.\n")
        
def copy_autogrid_inputs(dir_source,dir_target):
    """Function to copy autogrid inputs"""
    
    # Import library
    import shutil
    
    list1 = ["lig.pdbqt","receptor.pdbqt","docking.gpf","autogrid4.exe"]
    
    # Looping through files to be copied
    for line in list1:
        # Copy file
        shutil.copy2(dir_source+line,dir_target+line)

def write_py_file_4_autogrid(string_in,dir_in):
    """Function to write a .py file for autogrid"""
        
    # Write a .py file
    fo = open(dir_in+"sandres_run_autogrid.py","w")
    
    fo.write("import sys, string, os\n")
    
    fo.write(string_in)
    
    fo.close()
    
def run_my_autogrid_exe():
    """Function to run autogrid.exe -p docking.gpf -l docking.glg"""
    
    # Import libraries
    import sys, string, os
    from tkinter import messagebox
    
    # Now run the script
    os.system( '"python sandres_run_autogrid.py"' )
    
def run_autogrid():
    """Function to run autogrid -p docking.gpf -l docking.glg"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Get command line
    autogrid_in0 = str(autogrid_command_entry.get())
    autogrid_in = autogrid_in0+"\')\n"
    string_in = "os.system( \'\""+autogrid_in
    
    # Call copy_autogrid_inputs()
    copy_autogrid_inputs(dir_in0,sandres_root)
    
    # Call write_py_file_4_autogrid()
    write_py_file_4_autogrid(string_in,sandres_root)
    
    # Call run_my_autogrid_exe()
    run_my_autogrid_exe()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS finished running AutoGrid 4!","black","light grey")
    
    # Checking autogrid results
    print("\nChecking AutoGrid results...",end="")
    
    # Try to open docking.glg
    try:
        fo = open(sandres_root+"docking.glg","r")
    except IOError:
        print("\nI can't find docking.glg file.")
        return
    
    # Looping through docking.glg file
    success = False
    for line in fo:
        if "autogrid4: Successful Completion" in line:
            print("done.\n")
            success = True
            print(line)
            
    # Show message if not success
    if not success:
        print("done.\n")
        print("\nNot successful completion for AutoGrid. Please check docking.glg file.")
        
def pre_run_autogrid():
    """Function to call run_autogrid()"""
    
    # Import library
    from tkinter import messagebox
    
    # Call write_gpf()
    write_gpf("docking.gpf")
    
    # Call check_autodock_lig_pdb()
    check_autodock_lig_pdb()
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS is running AutoGrid 4...","green","light grey")
        
    # Call aux GUI
    result = messagebox.askyesno("SAnDReS","Do you want to run AutoGrid 4?")
        
    # If run is chosen
    if result:        
        # Call run_autogrid()
        run_autogrid()
        
def write_gpf(file_in):
    """Function to write file_in.gpf to run autogrid4"""
    
    # Get dataset dir
    dataset_in0 = str(autodock_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_autodock_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Set up empty lists
    receptor_types = []
    receptor_atoms = []
    sorted_receptor_types = []
    ligand_types = []
    ligand_atoms = []
    sorted_ligand_types = []
    
    # Try to read receptor.pdbqt
    try:
        fo = open(dir_in0+"receptor.pdbqt","r")
        print("\nReading receptor.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"receptor.pdbqt file!")
        return
    
    # Looping through receptor.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            receptor_types.append(aux2)
    
    print("done.\n")
    
    fo.close()
    
    # Looping through receptor_types to unify list
    receptor_atoms.append(receptor_types[0])
    for line in receptor_types:
        if line not in receptor_atoms:
            receptor_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_receptor_types = sorted(receptor_atoms)
    
    print("\nList of receptor_types: ",sorted_receptor_types)
    
    # Try to read lig.pdbqt
    try:
        fo = open(dir_in0+"lig.pdbqt","r")
        print("\nReading lig.pdbqt...",end="")
    except IOError:
        print("\nI can't find "+dir_in0+"lig.pdbqt file!")
        return
    
    # Looping through lig.pdbqt
    for line in fo:
        if line[0:6] == "ATOM  " or line[0:6] == "HETATM":
            aux0 = str(line[77:])
            aux1 = aux0.replace("\n","")
            aux2 = aux1.replace(" ","")
            ligand_types.append(aux2)
    
    print("done.\n")
    
    fo.close()

    # Looping through ligand_types to unify list
    ligand_atoms.append(ligand_types[0])
    for line in ligand_types:
        if line not in ligand_atoms:
            ligand_atoms.append(line)
    
    # Sort list in alphabetical order
    sorted_ligand_types = sorted(ligand_atoms)
    
    print("\nList of ligand_types: ",sorted_ligand_types)
    
    # Try to open config.txt
    try:
        fo = open(dir_in0+"config.txt","r")
        print("\nReading config.txt...",end="")
    except IOError:
        print("\nI can't find config.txt file!")
        return
    
    print("done.\n")
    
    # Looping through config.txt
    for line in fo:
        if line[0:10] == "center_x =":
            print("center_x :",line[11:])
            center_x = str(line[11:])
            x0 = center_x.replace(" ","")
            x = x0.replace("\n","")
        elif line[0:10] == "center_y =":
            print("center_y :",line[11:])
            center_y = str(line[11:])
            y0 = center_y.replace(" ","")
            y = y0.replace("\n","")
        elif line[0:10] == "center_z =":
            print("center_z :",line[11:])
            center_z = str(line[11:])
            z0 = center_z.replace(" ","")
            z = z0.replace("\n","")
    fo.close()
    
    # Write docking.gpf
    print("\nWriting "+file_in+"...",end="")
    fo = open(dir_in0+file_in,"w")
    
    fo.write("npts 40 40 40                        # num.grid points in xyz\n")
    fo.write("gridfld receptor.maps.fld                # grid_data_file\n")
    fo.write("spacing 0.375                        # spacing(A)\n")
    
    # Take care of receptor_types
    line_aux = "receptor_types "
    # Looping through sorted_receptor_types
    for line in sorted_receptor_types:
        line_aux +=line+" "
    line_aux += "       # receptor atom types\n"
    fo.write(line_aux)
    
    # Take care of ligand_types
    line_aux = "ligand_types "
    # Looping through sorted_ligand_types
    for line in sorted_ligand_types:
        line_aux +=line+" "
    line_aux += "            # ligand atom types\n"
    fo.write(line_aux)
    
    fo.write("receptor receptor.pdbqt                  # macromolecule\n")
    
    # Take care of gridcenter
    fo.write("gridcenter "+x+" "+y+" "+z+"           # xyz-coordinates or auto\n")
    fo.write("smooth 0.5                           # store minimum energy w/in rad(A)\n")
    
    # Take care of maps
    line_aux = "map receptor."
    for line in sorted_ligand_types:
        if line != "H":
            line_aux += line
            line_aux +=".map                       # atom-specific affinity map\n"
            fo.write(line_aux)
            line_aux = "map receptor." 
    
    fo.write("elecmap receptor.e.map                   # electrostatic potential map\n")
    fo.write("dsolvmap receptor.d.map                  # desolvation potential map\n")
    fo.write("dielectric -0.1465                   # <0, AD4 distance-dep.diel;>0, constant")
    
    fo.close()
    print("done.\n")
    
def pre_run_autodock():
    """Function to call run_autodock()"""
    
    # Import library
    from tkinter import messagebox
    
    # Call check_autodock_lig_pdb()
    check_autodock_lig_pdb()
        
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS is running AutoDock 4...","green","light grey")
        
    # Call aux GUI
    result = messagebox.askyesno("SAnDReS","Do you want to run AutoDock 4?")
        
    # If run is chosen
    if result:        
        # Call run_autodock()
        run_autodock()

def clear_autodock_command_entry():
    """Function to clear autodock_command_entry"""
        
    # Clear
    autodock_command_entry.delete(0,END)

def clear_autogrid_command_entry():
    """Function to clear autogrid_command_entry"""
        
    # Clear
    autogrid_command_entry.delete(0,END)
    
def next_run_autodock_pdb_entry():
    """Function to insert next pdb access code read from the chklig.in"""
    
    # Import library
    from tkinter import messagebox
    
    # Call aux GUI
    from tkinter import messagebox
    
    # Call read_pdbs_chklig()
    pdb_list = read_pdbs_chklig()
    
    # Get running run_autodock_pdb_entry
    running_pdb = str(run_autodock_pdb_entry.get())
    
    # Looping through pdb_list
    i = 0
    for line in pdb_list:
        if running_pdb == line:
            break
        i += 1
        
    # To finish after last pdb access code
    if i > (len(pdb_list)-2):
        my_message1 = "SAnDReS Warning! The Number of PDB files in chklig.in is "+str(len(pdb_list))
        my_message2 = "The Number of PDB files in chklig.in should be less than "+str(len(pdb_list))
        print(my_message1+"\n"+my_message2)
        messagebox.showerror(my_message1, my_message2)
        return
    else:
        # Clear run_autodock_pdb_entry
        run_autodock_pdb_entry.delete(0,END)
        # Insert next pdb access code in run_autodock_pdb_entry
        run_autodock_pdb_entry.insert(10,str(pdb_list[i+1]))

def clear_autodock_dataset_entry():
    """Function to clear autodock_dataset_entry"""
        
    # Clear
    autodock_dataset_entry.delete(0,END)
            
def run_mvd_moldock_GUI():
    """Function to call GUI to prepare input to run MVD from SAnDReS"""
    
    # Import library
    from tkinter import messagebox
        
    # Show warning message
    my_message1 = "SAnDReS Message"
    my_message2 = """To run Molegro Virtual Docker (MVD) from SAnDReS you need to 
    have MVD installed in your computer.
    Reference:
    Thomsen R, Christensen MH. MolDock: a new technique for 
    high-accuracy molecular docking. 
    J Med Chem. 2006;49:3315-21.
    """
    messagebox.showwarning(my_message1, my_message2)
    print("\n"+my_message1+"\n"+my_message2)
    
    # Defines global variables to allow access to variables from different functions
    global run_autodock_pdb_entry, autodock_dataset_entry, autodock_command_entry,autogrid_command_entry,\
    number_of_runs_entry,number_of_poses_entry,\
    mvd_random_seed_entry, mvd_radius_entry
    
    # Call read_dataset_dir()
    autodock_dir_in = read_dataset_dir()
    
    # Call read_pdbs_chklig()
    my_pdb_list = read_pdbs_chklig()
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Run Molegro Virtual Docker') 
    top_txt.geometry("880x360+125+157")
    
    # Show Label with information about this GUI
    Label(top_txt, text="Molegro Virtual Docker", font = "Arial" ).grid(row = 0,column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for PDB access code
    Label(top_txt, text="PDB Access Code:" ).grid(row = 3,column = 0, stick = W)   
    run_autodock_pdb_entry = Entry(top_txt,width = 65)
    run_autodock_pdb_entry.grid(row = 3, column = 0,stick = E)
    run_autodock_pdb_entry.insert(10,str(my_pdb_list[0]))
    
    # Widgets for buttons 
    Button(top_txt, text='Next ', command=next_run_autodock_pdb_entry).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for Dataset dir
    Label(top_txt, text="Dataset Directory:" ).grid(row = 4,column = 0, stick = W)   
    autodock_dataset_entry = Entry(top_txt,width = 65)
    autodock_dataset_entry.grid(row = 4, column = 0,stick = E)
    autodock_dataset_entry.insert(10,autodock_dir_in)
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autodock_dataset_entry).grid(row = 4, column = 1, sticky = W)
    
    # Show Label with information about this GUI
    Label(top_txt, text="Protocols", font = "Arial" ).grid(row = 6,column = 1, stick = W)
    
    # Widgets for Number of Runs
    Label(top_txt, text="Runs:" ).grid(row = 7,column = 1, stick = W)   
    number_of_runs_entry = Entry(top_txt,width = 3)
    number_of_runs_entry.grid(row = 7, column = 2,stick = W)
    number_of_runs_entry.insert(10,"10")
    
    # Widgets for Number of Poses/Runs
    Label(top_txt, text="Poses:" ).grid(row = 8,column = 1, stick = W)   
    number_of_poses_entry = Entry(top_txt,width = 3)
    number_of_poses_entry.grid(row = 8, column = 2,stick = W)
    number_of_poses_entry.insert(10,"5")
    
    # Widgets for MVD Random Seed
    Label(top_txt, text="Random Seed:" ).grid(row = 9,column = 1, stick = W)   
    mvd_random_seed_entry = Entry(top_txt,width = 10)
    mvd_random_seed_entry.grid(row = 9, column = 2,stick = W)
    mvd_random_seed_entry.insert(10,"3576336485")
    
    # Widgets for MVD radius
    Label(top_txt, text="Radius:" ).grid(row = 10,column = 1, stick = W)   
    mvd_radius_entry = Entry(top_txt,width = 3)
    mvd_radius_entry.grid(row = 10, column = 2,stick = W)
    mvd_radius_entry.insert(10,"15")
    
    # Protocol buttons    
    Button(top_txt, text='P01', command=pre_run_mvd_moldock_score_01).grid(row = 11, column = 2, sticky = E) 
    Button(top_txt, text="P02", command=pre_run_mvd_moldock_score_02).grid(row = 11, column = 3, sticky = E) 
    Button(top_txt, text='P03', command=pre_run_mvd_moldock_score_03).grid(row = 11, column = 4, sticky = E)  
    Button(top_txt, text='P04', command=pre_run_mvd_moldock_score_04).grid(row = 11, column = 5, sticky = E)  
    Button(top_txt, text='P05', command=pre_run_mvd_moldock_score_05).grid(row = 11, column = 6, sticky = E) 
    Button(top_txt, text="P06", command=pre_run_mvd_moldock_score_06).grid(row = 11, column = 7, sticky = E) 
    Button(top_txt, text='P07', command=pre_run_mvd_moldock_score_07).grid(row = 11, column = 8, sticky = E)  
    Button(top_txt, text='P08', command=pre_run_mvd_moldock_score_08).grid(row = 11, column = 9, sticky = E)  
    
    Button(top_txt, text='P09', command=pre_run_mvd_moldock_score_09).grid(row = 12, column = 2, sticky = E) 
    Button(top_txt, text="P10", command=pre_run_mvd_moldock_score_10).grid(row = 12, column = 3, sticky = E) 
    Button(top_txt, text='P11', command=pre_run_mvd_moldock_score_11).grid(row = 12, column = 4, sticky = E)  
    Button(top_txt, text='P12', command=pre_run_mvd_moldock_score_12).grid(row = 12, column = 5, sticky = E)  
    Button(top_txt, text='P13', command=pre_run_mvd_moldock_score_13).grid(row = 12, column = 6, sticky = E) 
    Button(top_txt, text="P14", command=pre_run_mvd_moldock_score_14).grid(row = 12, column = 7, sticky = E) 
    Button(top_txt, text='P15', command=pre_run_mvd_moldock_score_15).grid(row = 12, column = 8, sticky = E)  
    Button(top_txt, text='P16', command=pre_run_mvd_moldock_score_16).grid(row = 12, column = 9, sticky = E)  
    
    Button(top_txt, text='P17', command=pre_run_mvd_moldock_score_17).grid(row = 13, column = 2, sticky = E) 
    Button(top_txt, text="P18", command=pre_run_mvd_moldock_score_18).grid(row = 13, column = 3, sticky = E) 
    Button(top_txt, text='P19', command=pre_run_mvd_moldock_score_19).grid(row = 13, column = 4, sticky = E)  
    Button(top_txt, text='P20', command=pre_run_mvd_moldock_score_20).grid(row = 13, column = 5, sticky = E)  
    Button(top_txt, text='P21', command=pre_run_mvd_moldock_score_21).grid(row = 13, column = 6, sticky = E) 
    Button(top_txt, text="P22", command=pre_run_mvd_moldock_score_22).grid(row = 13, column = 7, sticky = E) 
    Button(top_txt, text='P23', command=pre_run_mvd_moldock_score_23).grid(row = 13, column = 8, sticky = E)  
    Button(top_txt, text='P24', command=pre_run_mvd_moldock_score_24).grid(row = 13, column = 9, sticky = E)  
    
    Button(top_txt, text='P25', command=pre_run_mvd_moldock_score_25).grid(row = 14, column = 2, sticky = E) 
    Button(top_txt, text="P26", command=pre_run_mvd_moldock_score_26).grid(row = 14, column = 3, sticky = E) 
    Button(top_txt, text='P27', command=pre_run_mvd_moldock_score_27).grid(row = 14, column = 4, sticky = E)  
    Button(top_txt, text='P28', command=pre_run_mvd_moldock_score_28).grid(row = 14, column = 5, sticky = E)  
    Button(top_txt, text='P29', command=pre_run_mvd_moldock_score_29).grid(row = 14, column = 6, sticky = E) 
    Button(top_txt, text="P30", command=pre_run_mvd_moldock_score_30).grid(row = 14, column = 7, sticky = E) 
    Button(top_txt, text='P31', command=pre_run_mvd_moldock_score_31).grid(row = 14, column = 8, sticky = E)  
    Button(top_txt, text='P32', command=pre_run_mvd_moldock_score_32).grid(row = 14, column = 9, sticky = E)  
    
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 15, column = 1, sticky = E)
                    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=170*" " ).grid(row = 5,column = 0, stick = W) 
    
def pre_run_mvd_moldock_score_01():
    """Function to run MVD with protocol 01"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("01")
    
def pre_run_mvd_moldock_score_02():
    """Function to run MVD with protocol 02"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("02")

def pre_run_mvd_moldock_score_03():
    """Function to run MVD with protocol 03"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("03")

def pre_run_mvd_moldock_score_04():
    """Function to run MVD with protocol 04"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("04")

def pre_run_mvd_moldock_score_05():
    """Function to run MVD with protocol 05"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("05")

def pre_run_mvd_moldock_score_06():
    """Function to run MVD with protocol 06"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("06")

def pre_run_mvd_moldock_score_07():
    """Function to run MVD with protocol 07"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("07")

def pre_run_mvd_moldock_score_08():
    """Function to run MVD with protocol 08"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("08")

def pre_run_mvd_moldock_score_09():
    """Function to run MVD with protocol 09"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("09")

def pre_run_mvd_moldock_score_10():
    """Function to run MVD with protocol 10"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("10")

def pre_run_mvd_moldock_score_11():
    """Function to run MVD with protocol 11"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("11")

def pre_run_mvd_moldock_score_12():
    """Function to run MVD with protocol 12"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("12")

def pre_run_mvd_moldock_score_13():
    """Function to run MVD with protocol 13"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("13")

def pre_run_mvd_moldock_score_14():
    """Function to run MVD with protocol 14"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("14")

def pre_run_mvd_moldock_score_15():
    """Function to run MVD with protocol 15"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("15")

def pre_run_mvd_moldock_score_16():
    """Function to run MVD with protocol 16"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("16")

def pre_run_mvd_moldock_score_17():
    """Function to run MVD with protocol 17"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("17")

def pre_run_mvd_moldock_score_18():
    """Function to run MVD with protocol 18"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("18")

def pre_run_mvd_moldock_score_19():
    """Function to run MVD with protocol 19"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("19")

def pre_run_mvd_moldock_score_20():
    """Function to run MVD with protocol 20"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("20")

def pre_run_mvd_moldock_score_21():
    """Function to run MVD with protocol 21"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("21")

def pre_run_mvd_moldock_score_22():
    """Function to run MVD with protocol 22"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("22")

def pre_run_mvd_moldock_score_23():
    """Function to run MVD with protocol 23"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("23")

def pre_run_mvd_moldock_score_24():
    """Function to run MVD with protocol 24"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("24")

def pre_run_mvd_moldock_score_25():
    """Function to run MVD with protocol 25"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("25")

def pre_run_mvd_moldock_score_26():
    """Function to run MVD with protocol 26"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("26")

def pre_run_mvd_moldock_score_27():
    """Function to run MVD with protocol 27"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("27")

def pre_run_mvd_moldock_score_28():
    """Function to run MVD with protocol 28"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("28")

def pre_run_mvd_moldock_score_29():
    """Function to run MVD with protocol 29"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("29")

def pre_run_mvd_moldock_score_30():
    """Function to run MVD with protocol 30"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("30")

def pre_run_mvd_moldock_score_31():
    """Function to run MVD with protocol 31"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("31")

def pre_run_mvd_moldock_score_32():
    """Function to run MVD with protocol 32"""
    
    # Call run_mvd_moldock_score()
    run_mvd_moldock_score("32")

def run_mvd_moldock_score(p_in):
    """Function to run MVD with protocol 1 with MolDsck Score"""
    
    # Import libraries
    import shutil
    import sys, string, os
    import errno
    import csv
    import time
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Get dir information # WFA 2018 01 09    
    dir_in0 = str(autodock_dataset_entry.get())
    pdb_in0 = str(run_autodock_pdb_entry.get())
    path0 = dir_in0+pdb_in0+"/P"+p_in+"/"
    
    # Try makedirs for mvd path # WFA 2018 01 09
    mvd_path = sandres_root+"mvd/"
    try:
        os.makedirs(mvd_path)
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise 
        
    # Get project directory
    project_dir_string = str(strdir_entry.get())
        
    # Try to backup # WFA 2018 01 09
    try:
        shutil.move(path0+"/mvd/",path0+"/backup_"+my_local_time+"/")
    except:
        print()
    
    # Open script
    try:
        f_script = open(sandres_root+"inputs/script"+p_in+".mvdscript","r")
    except IOError:
        print("\nSAnDRES IOError! I can't find script"+p_in+".mvdscript file!")
        return
    
    print("\nWriting script.mvdscript...",end="")
    
    # Open script.mvdscript
    fo = open(mvd_path+"script.mvdscript","w")

    fo.write("// Created by SAnDReS \n")
    
    # Looping through f_script # WFA 2018 01 09
    for line in f_script:
        print(line)
        line_aux = str(line)
        if "runs=" in line_aux:
            line_out0 = line_aux.replace("runs=","runs="+str(number_of_runs_entry.get()))
            line_out1 = line_out0.replace("MaxPoses=","MaxPoses="+str(number_of_poses_entry.get()))
        elif "keepmaxposes=" in line_aux:
            line_out1 = line_aux.replace("keepmaxposes=","keepmaxposes="+str(number_of_poses_entry.get()))
        elif "LOAD " in line_aux:
            line_out1 = "LOAD \"system.mvdml\" \n"
        elif "Structure file:" in line_aux:
            line_out1 = "// Structure file: system.mvdml\n"
        elif "SEARCHSPACE" in line_aux:
            line_out1 = "SEARCHSPACE radius="+str(mvd_radius_entry.get())+";center=ligand[0]\n"
        elif "RANDOM" in line_aux:
            line_out1 = "RANDOM "+str(mvd_random_seed_entry.get())+" \n"
        else:
            line_out1  = line_aux
        
        fo.write(line_out1)
        
    f_script.close()
    fo.close()
    
    print("Done.")
        
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS is running MVD (MolDock Score) (Protocol "+p_in+")...","green","light grey")
    
    
    # Write Python script
    #path1 = path0.replace("\\","\\\\")
    fo_py = open(mvd_path+"script.py","w")
    fo_py.write("def run_mvd_script():\n")
    fo_py.write("    \"\"\"Function to run mvd\"\"\"\n")
    fo_py.write("    import sys, string, os\n")
    fo_py.write("    os.system( \'\""+mvd_path+"script.mvdscript\"\')\n")
    fo_py.write("def main():\n")
    fo_py.write("    run_mvd_script()\n")
    fo_py.write("main()")
    fo_py.close()
    
    
    # Copy system.mvdml # WFA 2018 01 09
    shutil.copy2(path0+"system.mvdml",mvd_path+"system.mvdml")
    
    # Run mvd script    WFA 2018 01 10
    os.system('"mvd\\script.mvdscript"') # WFA 2018 01 09. It should be "\\" for windows
    

    print("Done.\n")
    
    
    # Move mvd_path to path0
    shutil.move(mvd_path,path0)
    
    # Call gen_mvd_csv_4_dataset() # WFA 2018 01 09
    gen_mvd_csv_4_dataset("mvd/DockingResults.mvdresults","redock01.csv",path0)
    
    # Copy redock01.csv to project_directory
    shutil.copy2(path0+"redock01.csv",project_dir_string+"redock01.csv")
    
    # Call strmsd()
    strmsd()
    
    # Copy strmsd.csv, strmsd.log, and strmsd.in to path0
    shutil.copy2(project_dir_string+"strmsd.csv",path0+"strmsd.csv")
    shutil.copy2(project_dir_string+"strmsd.log",path0+"strmsd.log")
    shutil.copy2(project_dir_string+"strmsd.in",path0+"strmsd.in")
    
    # Cpy strmsd###.csv to path0
    for i in range(45):
        try:
            # Fix the number of characters with zeros
            my_str_3_char = str(i)
            if len(my_str_3_char)< 4:
                my_str_id = str((3-len(my_str_3_char) )*"0")+my_str_3_char
                shutil.copy2(project_dir_string+"strmsd"+my_str_id+".csv",path0+"strmsd"+my_str_id+".csv")
        except:
            print()
    
    # Call aux GUI
    from tkinter import messagebox
    result = messagebox.askyesno("SAnDReS","Do you want to prepare files to generate scatter plots?")
        
    # If run is chosen
    if result:        
        # Call edit_scatter_pltcsv1()
        edit_scatter_pltcsv1()
        
        # Call  plot_pltcsv_GUI()
        plot_pltcsv_GUI()
        
def run_autodock_GUI():
    """Function to call GUI to prepare input to run AutoDock 4 from SAnDReS"""
    
    # Import library
    from tkinter import messagebox
        
    # Show warning message
    my_message1 = "SAnDReS Message"
    my_message2 = """To run AutoDock 4 from SAnDReS you need to have lig.pdbqt and 
    receptor.pdbqt files for each structure to be submitted to dock. 
    These files can be generated by AutoDockTools.
    Reference:
    Morris, G.M.; Huey, R.; Lindstrom, W.; Sanner, M.F.; Belew, 
    R.K.; Goodsell, D.S.; Olson, A.J. AutoDock4 and 
    AutoDockTools4: Automated Docking With Selective 
    Receptor Flexibility. J. Comput.Chem.,  2009; 30(16), 
    2785-91."""
    messagebox.showwarning(my_message1, my_message2)
    print("\n"+my_message1+"\n"+my_message2)
    
    # Defines global variables to allow access to variables from different functions
    global run_autodock_pdb_entry, autodock_dataset_entry, autodock_command_entry,autogrid_command_entry
    
    # Call read_dataset_dir()
    autodock_dir_in = read_dataset_dir()
    
    # Call read_pdbs_chklig()
    my_pdb_list = read_pdbs_chklig()
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Run AutoDock 4') 
    top_txt.geometry("870x280+125+157")
    
    # Show Label with information about this GUI
    Label(top_txt, text="AutoDock 4", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for PDB access code
    Label(top_txt, text="PDB Access Code:" ).grid(row = 3,column = 0, stick = W)   
    run_autodock_pdb_entry = Entry(top_txt,width = 86)
    run_autodock_pdb_entry.grid(row = 3, column = 0,stick = E)
    run_autodock_pdb_entry.insert(10,str(my_pdb_list[0]))
    
    # Widgets for buttons 
    Button(top_txt, text='Next ', command=next_run_autodock_pdb_entry).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for Dataset dir
    Label(top_txt, text="Dataset Directory:" ).grid(row = 4,column = 0, stick = W)   
    autodock_dataset_entry = Entry(top_txt,width = 86)
    autodock_dataset_entry.grid(row = 4, column = 0,stick = E)
    autodock_dataset_entry.insert(10,autodock_dir_in)
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autodock_dataset_entry).grid(row = 4, column = 1, sticky = W)
    
    # Widgets for AutoGrid 4 command
    Label(top_txt, text="AutoGrid Command:" ).grid(row = 5,column = 0, stick = W)   
    autogrid_command_entry = Entry(top_txt,width = 86)
    autogrid_command_entry.grid(row = 5, column = 0,stick = E)
    autogrid_command_entry.insert(10,"autogrid4 -p docking.gpf -l docking.glg")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autogrid_command_entry).grid(row = 5, column = 1, sticky = W)
    
    # Widgets for AutoDock 4 command
    Label(top_txt, text="AutoDock Command:" ).grid(row = 6,column = 0, stick = W)   
    autodock_command_entry = Entry(top_txt,width = 86)
    autodock_command_entry.grid(row = 6, column = 0,stick = E)
    autodock_command_entry.insert(10,"autodock4 -p docking.dpf -l docking.dlg")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autodock_command_entry).grid(row = 6, column = 1, sticky = W)
    
    # Last buttons    
    Button(top_txt, text='     AutoGrid     ', command=pre_run_autogrid).grid(row = 8, column = 0, sticky = E) 
    Button(top_txt, text="Set Up DPF", command=setup_dpf_GUI).grid(row = 8, column = 1, sticky = E) 
    Button(top_txt, text='  AutoDock ', command=pre_run_autodock).grid(row = 8, column = 2, sticky = E)  
    Button(top_txt, text='Analysis', command=autodock_strmsd).grid(row = 8, column = 3, sticky = E)  
    
    Button(top_txt, text="Prepare to Plot", command=edit_scatter_pltcsv1).grid(row = 9, column = 0, sticky = E)    
    Button(top_txt, text='      Plot      ', command=plot_pltcsv_GUI).grid(row = 9, column = 1, sticky = E) 
    Button(top_txt, text='  Tutorial 1  ', command=prep_run_chrome_autodock_tutor1).grid(row=9,column=2, sticky = E) 
    Button(top_txt, text='  More   ',command=prep_run_chrome_sandres_tutorials).grid(row=9,column=3,sticky= E)
    
    Button(top_txt, text='       Manual      ',command=prep_run_chrome_autodock_manual).grid(row=10,column=0,sticky= E)
    Button(top_txt, text='      Help     ',command=about_docking).grid(row=10,column=1,sticky= E)
    Button(top_txt, text=' SAnDReS  ',command=prep_run_chrome_sandres).grid(row=10,column=1,sticky= E)
    Button(top_txt, text='DIY Projects',command=prep_run_chrome_sandres_diy).grid(row=10,column=2,sticky= E)
    Button(top_txt, text='   Close  ', bg = "red", command=top_txt.destroy).grid(row = 10, column = 3, sticky = E)
                
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=220*" " ).grid(row = 7,column = 0, stick = W) 

def backup_plots():
    """Function to backup last generated plots to Dataset PDB directory"""
    
    # Import libraries
    from tkinter import messagebox
    import csv
    import shutil
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get dataset
    dataset2get = str(vina_dataset_entry.get())
        
    # Get PDB
    pdbdir2get = str(run_vina_pdb_entry.get())
    
    # Try to open files2plot.in
    try:
        fo0 = open(project_dir_string+"files2plot.in","r")
    except IOError:
        print("SAnDReS IO Error! I can't find ",project_dir_string+"files2plot.in") 
        print("Please update project directory as your needs!")
        messagebox.showerror("SAnDReS IO Error!", "I can't find file "+project_dir_string+"files2plot.in"+\
                             " \nPlease check directory name!")
        return
    
    # Looping through files2plot.in
    for line in fo0:
        
        # Get CSv file to copy
        aux = line[:len(line)-4]
        
        # Open file
        fo1 = open(project_dir_string+aux+".in","r")
        csv1 = csv.reader(fo1)
        
        # Looping through csv1 file
        for line1 in csv1:
            
            # Check PLTCSV string
            if "PLTCSV" in line1:
                fig_filename0 = line1[1]
                fig_filename = fig_filename0.replace(".csv","."+line1[12])
                print("\nCopying "+line1[1]+" file...")
                # Copy files # WFA 2018 01 09
                try:
                    shutil.copy2(project_dir_string+line1[1],dataset2get+\
                        pdbdir2get+"/"+line1[1])
                    shutil.copy2(project_dir_string+fig_filename,dataset2get+\
                        pdbdir2get+"/"+fig_filename)
                except IOError:
                    print("SAnDReS IOError!")
                            
        # Close file
        fo1.close()

    # Close file
    fo0.close()
def run_vina_GUI():
    """Function to call GUI to prepare input to run AutoDock Vina from SAnDReS"""
    
    # Import library
    from tkinter import messagebox
        
    # Show warning message
    my_message1 = "SAnDReS Message"
    my_message2 = """To run Vina from SAnDReS you need to have lig.pdbqt and receptor.pdbqt files for each structure to be submitted to dock. 
These files can be generated by AutoDockTools.

Reference:
Morris, G.M.; Huey, R.; Lindstrom, W.; Sanner, M.F.; Belew, 
R.K.; Goodsell, D.S.; Olson, A.J. AutoDock4 and 
AutoDockTools4: Automated Docking With Selective 
Receptor Flexibility. J. Comput.Chem.,  2009; 30(16), 
2785-91."""
    
    # Show message
    messagebox.showwarning(my_message1, my_message2)
    print("\n"+my_message1+"\n"+my_message2)
    
    # Defines global variables to allow access to variables from different functions
    global run_vina_pdb_entry, vina_dataset_entry, vina_command_entry
    
    # Call read_dataset_dir()
    vina_dir_in = read_dataset_dir()
    
    # Call read_pdbs_chklig()
    my_pdb_list = read_pdbs_chklig()
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS: Run AutoDock Vina') 
    top_txt.geometry("870x240+125+157")
    
    # Show Label with information about this GUI
    Label(top_txt, text="AutoDock Vina", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for PDB access code
    Label(top_txt, text="PDB Access Code:" ).grid(row = 3,column = 0, stick = W)   
    run_vina_pdb_entry = Entry(top_txt,width = 86)
    run_vina_pdb_entry.grid(row = 3, column = 0,stick = E)
    run_vina_pdb_entry.insert(10,str(my_pdb_list[0]))
    
    # Widgets for buttons 
    Button(top_txt, text='Next ', command=next_run_vina_pdb_entry).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for Dataset dir
    Label(top_txt, text="Dataset Directory:" ).grid(row = 4,column = 0, stick = W)   
    vina_dataset_entry = Entry(top_txt,width = 86)
    vina_dataset_entry.grid(row = 4, column = 0,stick = E)
    vina_dataset_entry.insert(10,vina_dir_in)
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_vina_dataset_entry).grid(row = 4, column = 1, sticky = W)
    
    # Widgets for Vina command
    Label(top_txt, text="Vina Command:" ).grid(row = 5,column = 0, stick = W)   
    vina_command_entry = Entry(top_txt,width = 86)
    vina_command_entry.grid(row = 5, column = 0,stick = E)
    vina_command_entry.insert(10,"vina.exe --config config.txt --log log.txt")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_vina_command_entry).grid(row = 5, column = 1, sticky = W)
    
    # Last buttons
    Button(top_txt, text='Edit config.txt',command=edit_vina_config_txt).grid(row = 8, column = 0,sticky = E) 
    Button(top_txt, text='    Run Vina  ', command=pre_run_vina).grid(row = 8, column = 1, sticky = E)  
    Button(top_txt, text='  Analysis  ', command=vina_strmsd).grid(row = 8, column = 2, sticky = E)
    Button(top_txt, text="Prepare 2 Plot", command=edit_scatter_pltcsv1).grid(row = 8, column = 3, sticky = E)   
    
    Button(top_txt, text='      Plot CSV    ', command=plot_pltcsv_GUI).grid(row = 9, column = 0, sticky = E) 
    Button(top_txt, text='Back Up Plot',command=backup_plots).grid(row =9, column = 1, sticky = E)
    Button(top_txt, text='     More    ',command=prep_run_chrome_sandres_tutorials).grid(row=9,column=2,sticky= E)
    Button(top_txt, text='  Vina Manual ',command=prep_run_chrome_vina_manual).grid(row =9, column = 3, sticky = E) 
    
    Button(top_txt, text=' Drug Design  ',command=prep_run_chrome_sandres_diy_dd).grid(row=10,column=0,sticky= E)
    Button(top_txt, text=' DIY Projects',command=prep_run_chrome_sandres_diy).grid(row=10,column=1,sticky= E)
    Button(top_txt, text='     Site      ',command=prep_run_chrome_sandres).grid(row=10,column=2,sticky= E)
    Button(top_txt, text='        Close       ', bg = "red", command=top_txt.destroy).grid(row = 10, column = 3, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=210*" " ).grid(row = 6,column = 0, stick = W) 
    
def vina2sandres_GUI():
    """Function to call GUI to prepare input to convert AutoDock-Vina to SAnDReS"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, autodock_dir_entry, ref_lig_entry, autodock_pdbqt_entry, autodock_csv_entry, top_strdir_entry,\
    ligand_pdbqt_entry 
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x180+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt, text="AutoDock Vina (Convert from AutoDock Vina to SAnDReS)", font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for reference ligand .pdbqt file
    Label(top_txt, text="Reference Ligand (.pdbqt):" ).grid(row = 3,column = 0, stick = W)   
    ligand_pdbqt_entry = Entry(top_txt,width = 86)
    ligand_pdbqt_entry.grid(row = 3, column = 0,stick = E)
    ligand_pdbqt_entry.insert(10,"lig.pdbqt")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_ligand_pdbqt).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for Autodock .pdbqt file
    Label(top_txt, text="Vina File (.pdbqt):" ).grid(row = 4,column = 0, stick = W)   
    autodock_pdbqt_entry = Entry(top_txt,width = 86)
    autodock_pdbqt_entry.grid(row = 4, column = 0,stick = E)
    autodock_pdbqt_entry.insert(10,"lig_out.pdbqt")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_pdbqt_results).grid(row = 4, column = 1, sticky = W)
    
    # Widgets for csv file
    Label(top_txt, text="SAnDReS CSV File:" ).grid(row = 5,column = 0, stick = W)   
    autodock_csv_entry = Entry(top_txt,width = 86)
    autodock_csv_entry.grid(row = 5, column = 0,stick = E)
    autodock_csv_entry.insert(10,"redock01.csv")
    
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_autodock_csv).grid(row = 5, column = 1, sticky = W)
    
    # Last buttons
    Button(top_txt, text='Generate CSV File', command=gen_vina_csv  ).grid(row = 8, column = 1, sticky = W)  
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 8, column = 2, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=220*" " ).grid(row = 6,column = 0, stick = W) 
    
def read_PDBQT(file_in):
    """Function to read .pdbqtfile"""
    
    # Import libraries
    import csv
    import sys
    
    # Set up empty lists
    list_model = []
    list_rmsd = []
    list_energy = []
    
    # Try to open pdbqt file
    try:
        fo = open(file_in,"r")
    except IOError:
        sys.exit("I can't find file "+file_in)
    
    # Looping through file
    i = 1
    for line in fo:
        if line[0:19] == "REMARK VINA RESULT:":
            list_model.append(str(i))
            list_energy.append(str(line[19:29]))
            list_rmsd.append(str(line[30:40]))
            i+=1
   
    # Close file
    fo.close()
    
    # Notice this rmsd_list is not taken for reference (crystal position) is taken for best pose (MODEL 1)
    # It will not be considered in the redock1.csv file
    return list_model,list_rmsd,list_energy
    
def read_RMSD(file_in):
    """Function to read RMSD"""
    
    # Import libraries
    import csv
    import sys
    
    # Set up empty lists
    list_model = []
    list_rmsd = []
    
    # Try to open dgl file
    try:
        fo = open(file_in,"r")
    except IOError:
        sys.exit("I can't find file "+file_in)
    
    # Looping through file
    rmsd_table = False
    rmsd_header = False
    for line in fo:
        if "RMSD TABLE" in line:
            rmsd_table = True
        if rmsd_header and "__" not in line:
            list_model.append(line[13:19])
            rmsd_aux = (line[43:59]).replace(" ","")
            list_rmsd.append(rmsd_aux)
        if rmsd_table and "_____|______|______|___________|_________|_________________|___________" in line \
            and rmsd_table:
            rmsd_header = True
        if "_______________________________________________________________________" in line:
            rmsd_table = False
            rmsd_header = False
    
    # Close file
    fo.close()
    
    return list_model,list_rmsd
    
def gen_my_epdb_csv(file_in,file_out):
    """Function to generate csv file from autodock epdb .dlg file"""
        
    # Read input file name  
    f1 = file_in
    
    # Get directory where the files are
    my_new_dir_string = sandres_root
    
    # Call read_RMSD()
    l1 = ["1"]
    l2 = ["0.0"]
            
    # Call energy_terms()
    l3,l4,l5,l6,l7,l8 = epdb_terms(my_new_dir_string+f1)

    # Looping through list of models WFA 2017 10 18 
    # for i in range(len(l1)):
        
    #    print(l1[i],l2[i],l3[int(l1[i])-1], l4[int(l1[i])-1], l5[int(l1[i])-1], l6[int(l1[i])-1],\
    #    l7[int(l1[i])-1],l8[int(l1[i])-1]  )   
    
    # Call make_csv()
    make_csv(l1,l2,l3,l4,l5,l6,l7,l8,my_new_dir_string+file_out)
    
def epdb_terms(file_in):
    """Function to get energy terms for autodock epdb"""
    
    # Import libraries
    import csv
    import sys
    
    # Set up empty lists
    free_energy = []
    final_intermol = []
    vdw_plus = []
    elect_term = []
    final_internal = []
    torsion = []
    
    # Try to open dgl file
    try:
        fo = open(file_in,"r")
    except IOError:
        sys.exit("I can't find file "+file_in)
    
    # looping through file
    epdb_flag = False
    for line in fo:
        if "epdb: USER" in line:
            epdb_flag = True
        if "epdb: USER    Estimated Free Energy of Binding    =" in line and epdb_flag:
            # WFA 2017 10 18
            try:
                free_energy.append(float(line[51:60]))
            except:
                print()
                free_energy.append(float(line[51:63]))
                
        elif "epdb: USER    (1) Final Intermolecular Energy     =" in line and epdb_flag:
            # WFA 2017 10 18
            try:
                final_intermol.append(float(line[51:60]))
            except:
                final_intermol.append(float(line[51:63]))
                
        elif "epdb: USER        vdW + Hbond + desolv Energy     =" in line and epdb_flag:
            # WFA 2017 10 18   
            try:
                vdw_plus.append( float(line[51:60])  )
            except:
                vdw_plus.append( float(line[51:63])  )
                
        elif "epdb: USER        Electrostatic Energy            =" in line and epdb_flag:
            # WFA 2017 10 18
            try:
                elect_term.append( float(line[51:60])  )
            except:
                elect_term.append( float(line[51:63])  )  
                
        elif "epdb: USER    (2) Final Total Internal Energy     =" in line and epdb_flag:
            # WFA 2017 10 18
            try:
                final_internal.append( float(line[51:60]) )
            except:
                final_internal.append( float(line[51:63]) )
                
        elif "epdb: USER    (3) Torsional Free Energy           =" in line and epdb_flag:
            # WFA 2017 10 18  
            try:
                torsion.append( float(line[51:60]) )
            except:
                torsion.append( float(line[51:63]) )
                
            
    # Close file
    fo.close()
    
    return free_energy,final_intermol, vdw_plus,elect_term,final_internal,torsion
        
def energy_terms(file_in):
    """Function to get energy terms"""
    
    # Import libraries
    import csv
    import sys
    
    # Set up empty lists
    free_energy = []
    final_intermol = []
    vdw_plus = []
    elect_term = []
    final_internal = []
    torsion = []
    
    # Try to open dgl file
    try:
        fo = open(file_in,"r")
    except IOError:
        sys.exit("I can't find file "+file_in)
    
    # looping through file
    docked = False
    for line in fo:
        if "kcal/mol" in line:
            l_i = line.index("kcal/mol")
        if "DOCKED: MODEL   " in line:
            docked = True
        if "DOCKED: USER    Estimated Free Energy of Binding    =" in line and docked:
            free_energy.append(float(line[54:l_i]))
        elif "DOCKED: USER    (1) Final Intermolecular Energy     =" in line and docked:
            final_intermol.append(float(line[54:l_i]))
        elif "DOCKED: USER        vdW + Hbond + desolv Energy     =" in line and docked:
            vdw_plus.append( float(line[54:l_i])  )
        elif "DOCKED: USER        Electrostatic Energy            =" in line and docked:
            elect_term.append( float(line[54:l_i])  )
        elif "DOCKED: USER    (2) Final Total Internal Energy     =" in line and docked:
            final_internal.append( float(line[54:l_i]) )
        elif "DOCKED: USER    (3) Torsional Free Energy           =" in line and docked:
            torsion.append( float(line[54:l_i]) )
            
    # Close file
    fo.close()
    
    return free_energy,final_intermol, vdw_plus,elect_term,final_internal,torsion

def make_csv(i1,i2,i3,i4,i5,i6,i7,i8,file_in):
    """Function to make a CSV file"""
    
    # Import libraries
    import csv
    import time
    import shutil
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    print(my_local_time)
    
    # Make backup of old redock01.csv 
    try:
        shutil.copy2(project_dir_string+"redock01.csv",project_dir_string+\
                     "redock01_"+my_local_time+".csv")
    except:
        print("No redock01.csv file in the project directory.")
        
    # Open csv file
    csv1 = open(file_in,"w")
    
    # Write header
    csv1.write("Model,RMSD,FreeEnergy,FinalIntermolecularEnergy,vdW+Hbond+desolvEnergy,"+\
                "ElectrostaticEnergy,FinalTotalInternalEnergy,TorsionalFreeEnergy\n")
    
    # Looping through to write data
    for i in range(len(i1)):
        line = str(i1[i])+","+str(i2[i] )+","+str(i3[int(i1[i])-1])+","+str(i4[int(i1[i])-1])+","+str(i5[int(i1[i])-1])+","+str(i6[int(i1[i])-1])+","+str(i7[int(i1[i])-1])+","+str(i8[int(i1[i])-1])
        
        csv1.write(line+"\n")
    
    # Close file
    csv1.close()
    
def make_csv_vina(i1,i2,i3,file_in):
    """Function to make a CSV file from pdbqt data"""
    
    # Import libraries
    import csv
    import time
    import shutil
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Make backup of old redock01.csv 
    try:
        shutil.copy2(project_dir_string+"redock01.csv",project_dir_string+\
                     "redock01_"+my_local_time+".csv")
    except:
        print()
    
    # Opencsv file
    csv1 = open(file_in,"w")
    
    # Write header
    csv1.write("Model,RMSD,FreeEnergy(kcal/mol)\n")
    
    # Looping through to write data
    for i in range(len(i1)):
        aux1 = "%.3f"%float(i2[i])
        aux2 = "%.3f"%float(i3[i])
        line = str(i1[i])+","+str(aux1)+","+str(aux2)
        
        csv1.write(line+"\n")
    
    # Close file
    csv1.close()

def read_xyz_pdbqt1(file_in):
    """Function to read x,y,z from pdbqt files"""
    
    # Import library
    import numpy as np
    
    # Set up empty lists
    x,y,z,lines = [],[],[],[]
    
    # Open pdbqt file
    fo = open(file_in,"r")
    
    # Looping through data to get non-hydrogen atom coordinates
    for line in fo:
        if line[0:6] == "HETATM" and line[13:14] != "H":
            x.append(float(line[30:38]))
            y.append(float(line[38:46]))
            z.append(float(line[46:54]))
            lines.append(line)
    
    # Make them arrays
    xa = np.array(x)
    ya = np.array(y)
    za = np.array(z)
    
    # Close file
    fo.close()
    
    return xa,ya,za,lines

def get_n_models(file_in):
    """Function to get the number of models"""
    
    # open pdbqt file
    fo = open(file_in,"r")
    
    # Set up n_models
    n_models =  0
    
    # Looping throgh pdbqt file
    for line in fo:
        if "MODEL" in line:
            n_models += 1
    
    # Close file
    fo.close()

    return n_models

def calc_rmsd_pdbqt(n_models,x1,y1,z1,x2,y2,z2,lines1,lines2):
    """Function to calculate RMSD for pdbqt files"""
    
    # Import library
    import numpy as np
    
    # Get number of atoms
    num_lines1 = len(x1)
    num_lines2 = len(x2)
 
    # Set up a zero array
    rmsd = np.zeros(n_models)
    
    # Looping through models (poses)
    k = 0
    while k < n_models:
        sum_d2 = 0
        # Looping through modes
        for i in range(num_lines1):
            d2 = (x1[i]-x2[i+k*num_lines1] )**2 + (y1[i] - y2[i+k*num_lines1])**2 + (z1[i] - z2[i+k*num_lines1])**2
            sum_d2 += d2
        rmsd[k] = np.sqrt(sum_d2/num_lines1)
        k+=1
    
    return rmsd

def gen_swissdock_csv():
    """Function to generate csv file from a swissdock csv file"""
    
    # Import library
    import csv
    
    # Get file and directory names
    file_in = swissdock_pdb_entry.get()
    file_out = sandres_csv_entry.get()
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Call read_swissdock_mol2()
    x,y,z,list_atm_mol2 = read_swissdock_mol2()
    
    # Get the number on non-hydrogen atoms
    number_of_atoms_in_mol2 = len(list_atm_mol2)    # List of non-hydrogen atoms (list_atm_mol2)
    
    # Call read_swissdock_data()
    read_swissdock_data(number_of_atoms_in_mol2)
    
    # Try to open swissdock csv
    try:
        fo1 = open(project_dir_string+file_in,"r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("\nI can't find "+project_dir_string+file_in+" file!")
        return
    
    fo1.close()
    
def gen_vina_csv_4_pdbqt(mdl_number):
    """Function to generate csv file from AutoDock Vina .pdbqt file in pdb dir"""
            
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Read input file name (reference ligand)  
    f1 = "lig.pdbqt"
    
    # Read input file name (poses)
    f2 = "lig_"+mdl_number+".pdbqt"
    
    # Get new project directory
    #project_dir_string = str(strdir_entry.get())
    
    # Call read_xyz_pdbqt1() for reference ligand
    x1,y1,z1,lines1 = read_xyz_pdbqt1(dir_in0+f1)
    
    # Call read_xyz_pdbqt1() for poses
    x2,y2,z2,lines2 = read_xyz_pdbqt1(dir_in0+f2)
    
    n_models = 1
    
    # Call calc_rmsd_pdbqt()
    l2 = calc_rmsd_pdbqt(n_models,x1,y1,z1,x2,y2,z2,lines1,lines2)
    
    # Call read_PDBQT()
    l1,_,l3 = read_PDBQT(dir_in0+f2)
    
    # Notice this rmsd list (_) is not taken for reference (crystal position) is taken for best pose (MODEL 1)
    # It will not be considered in the redock1.csv file
    # l2 is taken from calc_rmsd_pdbqt()
     
    # Looping through list of models  
    print("\nResults taken from AutoDock-Vina")
    print("Model\tRMSD(A)\tBinding Energy(kcal/mol)")
    for i in range(len(l1)):
       print(mdl_number,"\t\t%6.3f"%l2[i],"\t",l3[i])  
       return l2[i] # Return RMSD
            
def gen_vina_csv_4_dataset():
    """Function to generate csv file from AutoDock Vina .pdbqt file in Dataset dir"""
            
    # Get dataset dir
    dataset_in0 = str(vina_dataset_entry.get())
    
    # Get pdb # WFA 2018 01 09
    pdb_in0 = str(run_vina_pdb_entry.get())+"/"
    
    # Get complete dir
    dir_in0 = dataset_in0+pdb_in0
    
    # Read input file name (reference ligand)  
    #f1 = ligand_pdbqt_entry.get()
    f1 = "lig.pdbqt"
    
    # Read input file name (poses)
    #f2 = autodock_pdbqt_entry.get()
    f2 = "lig_out.pdbqt"
    
    # Get new project directory
    #project_dir_string = str(strdir_entry.get())
    
    # Call read_xyz_pdbqt1() for reference ligand
    x1,y1,z1,lines1 = read_xyz_pdbqt1(dir_in0+f1)
    
    # Call read_xyz_pdbqt1() for poses
    x2,y2,z2,lines2 = read_xyz_pdbqt1(dir_in0+f2)
    
    # Call get_n_models()
    n_models = get_n_models(dir_in0+f2)
    
    # Call calc_rmsd_pdbqt()
    l2 = calc_rmsd_pdbqt(n_models,x1,y1,z1,x2,y2,z2,lines1,lines2)
    
    # Call read_PDBQT()
    l1,_,l3 = read_PDBQT(dir_in0+f2)
    
    # Notice this rmsd list (_) is not taken for reference (crystal position) is taken for best pose (MODEL 1)
    # It will not be considered in the redock1.csv file
    # l2 is taken from calc_rmsd_pdbqt()
     
    # Looping through list of models  
    print("\nResults taken from AutoDock-Vina")
    print("Model\tRMSD(A)\tBinding Energy(kcal/mol)")
    for i in range(len(l1)):
        print(l1[i],"\t\t%6.3f"%l2[i],"\t",l3[i])   
    
    # Call make_csv_vina()
    make_csv_vina(l1,l2,l3,dir_in0+"redock01.csv")
      
def gen_vina_csv():
    """Function to generate csv file from AutoDock Vina .pdbqt file"""
    
    # Defines global variables to allow access to variables from different functions
    global autodock_pdbqt_entry,ligand_pdbqt_entry
        
    # Read input file name (reference ligand)  
    f1 = ligand_pdbqt_entry.get()
    
    # Read input file name (poses)
    f2 = autodock_pdbqt_entry.get()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Call read_xyz_pdbqt1() for reference ligand
    x1,y1,z1,lines1 = read_xyz_pdbqt1(project_dir_string+f1)
    
    # Call read_xyz_pdbqt1() for poses
    x2,y2,z2,lines2 = read_xyz_pdbqt1(project_dir_string+f2)
    
    # Call get_n_models()
    n_models = get_n_models(project_dir_string+f2)
    
    # Call calc_rmsd_pdbqt()
    l2 = calc_rmsd_pdbqt(n_models,x1,y1,z1,x2,y2,z2,lines1,lines2)
    
    # Call read_PDBQT()
    l1,_,l3 = read_PDBQT(project_dir_string+f2)
    
    # Notice this rmsd list (_) is not taken for reference (crystal position) is taken for best pose (MODEL 1)
    # It will not be considered in the redock1.csv file
    # l2 is taken from calc_rmsd_pdbqt()
     
    # Looping through list of models  
    print("\nResults taken from AutoDock-Vina")
    print("Model\tRMSD(A)\tBinding Energy(kcal/mol)")
    for i in range(len(l1)):
        print(l1[i],"\t\t%6.3f"%l2[i],"\t",l3[i])   
    
    # Call make_csv_vina()
    make_csv_vina(l1,l2,l3,project_dir_string+"redock01.csv")
      
def gen_autodock_csv():
    """Function to generate csv file from autodock .dlg file"""
    
    # Defines global variables to allow access to variables from different functions
    global autodock_dlg_entry
    
    # Read input file name  
    f1 = autodock_dlg_entry.get()
    
    # Get new project directory
    project_dir_string = str(strdir_entry.get())
    
    # Call read_RMSD()
    l1,l2 = read_RMSD(project_dir_string+f1)
    
    # Call energy_terms()
    l3,l4,l5,l6,l7,l8 = energy_terms(project_dir_string+f1)
    
    # Looping through list of models  
    for i in range(len(l1)):
        print(l1[i],l2[i],l3[int(l1[i])-1], l4[int(l1[i])-1], l5[int(l1[i])-1], l6[int(l1[i])-1],\
        l7[int(l1[i])-1],l8[int(l1[i])-1]  )   
    
    # Call make_csv()
    make_csv(l1,l2,l3,l4,l5,l6,l7,l8,project_dir_string+"redock01.csv")
        
def mvd2sandres_GUI():
    """Function to call GUI to prepare input to convert MVD to SAnDReS"""
    
    # Import library
    from tkinter import messagebox
    
    # Defines global variables to allow access to variables from different functions
    global top_txt, mvd_dir_entry, ref_lig_entry,mvdresults_entry, mvd_csv2_entry, top_strdir_entry 
          
    # Creates child window 
    top_txt = Toplevel() 
    top_txt.title('SAnDReS') 
    top_txt.geometry("870x150+20+435")
    
    # Show Label with information about this GUI
    Label(top_txt,text="Molegro Virtual Docker (MVD) (Convert from MVD to SAnDReS)",font = "Arial" ).grid(row = 0,\
        column = 0, stick = W)
    
    # Show Empty Label 
    Label(top_txt, text=" ", font = "Arial" ).grid(row = 1,\
        column = 0, stick = W)
     
    # Widgets for MVD csv file
    Label(top_txt, text="MVD Results (.mvdresuls):" ).grid(row = 3,column = 0, stick = W)   
    mvdresults_entry = Entry(top_txt,width = 81)
    mvdresults_entry.grid(row = 3, column = 0,stick = E)
    mvdresults_entry.insert(10,"DockingResults.mvdresults")
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_mvd_results).grid(row = 3, column = 1, sticky = W)
    
    # Widgets for csv file
    Label(top_txt, text="SAnDReS CSV File:" ).grid(row = 4,column = 0, stick = W)   
    mvd_csv2_entry = Entry(top_txt,width = 87)
    mvd_csv2_entry.grid(row = 4, column = 0,stick = E)
    mvd_csv2_entry.insert(10,"redock01.csv")
    # Widgets for buttons 
    Button(top_txt, text='Clear', command=clear_mvd_csv).grid(row = 4, column = 1, sticky = W)
    
    # Last buttons
    Button(top_txt, text='Generate CSV File', command=gen_mvd_csv  ).grid(row = 7, column = 1, sticky = W)  
    Button(top_txt, text='Close', bg = "red", command=top_txt.destroy).grid(row = 7, column = 2, sticky = E)
    
    # Widget for empty label to be included after widgets for txt
    Label(top_txt, text=210*" " ).grid(row = 5,column = 0, stick = W) 

def get_exe(dir_in):
    """Function to copy executables to Dataset directories"""
    
    # Import library
    import shutil
                
    # Set list to be copied
    list_to_be_copied = ["autodock4.exe","autogrid4.exe","vina.exe"]
                
    # Looping through list to be copied to project directory
    for my_file_to_be_copied in list_to_be_copied:
        sandres_line ="Copying "+my_file_to_be_copied+" to "+dir_in+" \n"
        print(sandres_line)
        window_txt.insert(END,sandres_line) # WFA 2018 01 09
        shutil.copy2(sandres_root+"Third_Party_Programs/"+my_file_to_be_copied,\
                         dir_in)
    
def write_binding_file(dir_in,pdb_in,lig_in,my_lines):
    """Function to get atomic coordinates for ligands"""
    
    # Set up directory # WFA 2018 01 09
    dir1 = dir_in+pdb_in+"/"
    
    # Try to open file
    try:
        fo1 = open(dir1+lig_in+".pdb","w")
    except IOError:
        print("\n Problem in finding directory!"+dir1)
        return
    
    # Looping through my_lines
    for line in my_lines:
        fo1.write(line)
    
    # This is the END
    fo1.write("END")
    fo1.close()
    
    # Call get_exe()
    get_exe(dir1)
    
    return

def write_lig_file(dir_in,pdb_in,my_lines):
    """Function to get atomic coordinates for ligands to be used to run autodock-vina"""
    
    # Set up directory # WFA 2018 01 09
    dir1 = dir_in+pdb_in+"/"
    
    # Try to open file
    try:
        fo1 = open(dir1+"lig.pdb","w")
    except IOError:
        print("\n Problem in finding directory!"+dir1)
        return
    
    # Looping through my_lines
    for line in my_lines:
        fo1.write(line)
    
    # This is the END
    fo1.write("END")
    fo1.close()
    
    return

def write_config_file(dir_in,pdb_in,x,y,z):
    """Function to write config.txt to run autodock-vina"""
    
    # Set up directory # WFA 2018 01 09
    dir1 = dir_in+pdb_in+"/"
    
    # Try to open file
    try:
        fo1 = open(dir1+"config.txt","w")
    except IOError:
        print("\n Problem in finding directory!"+dir1)
        return
        
    # Geometric center
    xc = "%.2f"%x
    yc = "%.2f"%y
    zc = "%.2f"%z
    
    # WFA 2018 02 14
    # Call read_preferences
    _,_,_,_,_,autodock_vina_random_seed_in = read_preferences()
    
    # Write config.txt
    fo1.write("receptor = receptor.pdbqt\n")
    fo1.write("ligand = lig.pdbqt\n")
    fo1.write("center_x = "+str(xc)+"\n")
    fo1.write("center_y = "+str(yc)+"\n")
    fo1.write("center_z = "+str(zc)+"\n")
    fo1.write("size_x = 15.0\n")
    fo1.write("size_y = 15.0\n")
    fo1.write("size_z = 15.0\n")
    fo1.write("seed = "+str(autodock_vina_random_seed_in)+"\n")
    fo1.write("num_modes = 20\n")
    fo1.write("energy_range = 20\n")
    fo1.write("out = lig_out.pdbqt\n")
    
    # Close file
    fo1.close()
    
    return
               
def calc_geometric_center(x,y,z):
    """Function to calculate geometric center for x,y,z arrays"""
    
    # Import library
    import numpy as np
    
    # Sum arrays
    sum_x = np.sum(x)
    sum_y = np.sum(y)
    sum_z = np.sum(z)
    
    # Calculate geometric center if len(x)>0
    if len(x) > 0:
        # Calculate center coordinates
        x_GC = sum_x/len(x)
        y_GC = sum_y/len(y)
        z_GC = sum_z/len(z)
        return x_GC,y_GC,z_GC
    else:
        print("\nArray x is empty. Please check")
        return None,None,None

def calc_dist(x,y,z,x_GC,y_GC,z_GC):
    """Function to calculate Euclidian distance between two points"""
    
    # Import library
    import numpy as np
    
    dist =  np.sqrt( (x-x_GC)**2 + (y-y_GC)**2  + (z-z_GC)**2 )
    
    return dist

def pre_binding_site():
    """Function to call binding_site()"""
    
    # Call show_message_in_sandres()
    show_message_in_sandres("SAnDReS is generating binding sites!","green","light grey")
    
    # Call aux GUI
    from tkinter import messagebox
    result = messagebox.askyesno("SAnDReS","Do you want to generate binding sites?")
        
    # If run is chosen
    if result:        
        # Call binding_site()
        binding_site()
    
def binding_site():
    """Function to read fndwat.in and create binding site and ligands for structures"""
    
    # Import library
    import csv
    
    # Get project directory
    project_dir_string = str(strdir_entry.get())
    
    # Try to open fndwat.in
    try:
        fo1 = open(project_dir_string+"fndwat.in","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("SAnDReS IOError! I can't find file fndwat.in!")
        return
    
    # Get fndwat dir
    for line in csv1:
        fndwat_dir = line[1]
        print(line[1])
        break
    
    fo1.close()
        
    # Try to open chklig.in
    try:
        fo1 = open(project_dir_string+"chklig.in","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("SAnDReS IOError! I can't find file fndwat.in!")
        return
    
    # Looping through csv1
    print("\nGenerating geometric centers for each structure...")
    for line in csv1:
        if line[0] == "CHKLIG":
            pdb_file0 = line[1]
            pdb_file1 = pdb_file0.replace(" ","")
            pdb_file2 = project_dir_string+pdb_file1+".pdb"
            fo2 = open(pdb_file2,"r")
            my_lig_lines = []
            x_lig = []
            y_lig = []
            z_lig = []
            
            # Looping through fo2
            for pdb_line in fo2:
                if pdb_line[0:6] == "HETATM" and pdb_line[17:20] == line[2] and pdb_line[21:22] == line[3]\
                and int(pdb_line[22:26]) == int(line[4]):
                    my_lig_lines.append(pdb_line)
                    x_lig.append(float(pdb_line[30:38]))
                    y_lig.append(float(pdb_line[38:46]))
                    z_lig.append(float(pdb_line[46:54]))
            write_binding_file(fndwat_dir,pdb_file1,line[2],my_lig_lines)
            write_lig_file(fndwat_dir,pdb_file1,my_lig_lines)       # Write lig.pdb file
            fo2.close()
            
            # Call calc_geometric_center()
            x_lig_GC,y_lig_GC,z_lig_GC = calc_geometric_center(x_lig,y_lig,z_lig)   
            
            # Write config.txt file to run autodock vina
            write_config_file(fndwat_dir,pdb_file1,x_lig_GC,y_lig_GC,z_lig_GC)
            
            fo2 = open(pdb_file2,"r")
            
            # Looping through fo2
            my_atom_lines = []
            for pdb_line in fo2:
                if pdb_line[0:6] == "HETATM" and pdb_line[17:20] == line[2] and pdb_line[21:22] == line[3] \
                and int(pdb_line[22:26]) == int(line[4]):
                    print(".",end="")
                elif pdb_line[0:6] == "ATOM  " or pdb_line[0:6] == "HETATM":
                    dist1 =  calc_dist(float(pdb_line[30:38]),float(pdb_line[38:46]),float(pdb_line[46:54]),\
                                       x_lig_GC,y_lig_GC,z_lig_GC )
                    if dist1 <= 15.0:
                        my_atom_lines.append(pdb_line)
            write_binding_file(fndwat_dir,pdb_file1,"binding_site"+line[1],my_atom_lines)  # Write binding_site_
            
            fo2.close()
            
            # Looping through fo2 to get receptor.pdb
            fo2 = open(pdb_file2,"r")
            my_atom_lines = []
            for pdb_line in fo2:
                if pdb_line[0:6] == "HETATM" and pdb_line[17:20] == "HOH":
                    my_atom_lines.append(pdb_line)
                elif pdb_line[0:6] == "ATOM  ":
                    my_atom_lines.append(pdb_line)
            write_binding_file(fndwat_dir,pdb_file1,"receptor",my_atom_lines)   # Write receptor.pdb
            fo2.close()
        
    # Call show_message_in_sandres()
    show_message_in_sandres("Done! SAnDReS finished generating binding sites!","black","light grey")
    print("\a")    
        
def Asimov():
    """Function to show Asimov's quotes"""
    
    # Import library
    import random
    
    # Source: http://www.quotationof.com/isaac-asimov.html
    
    quotes = ["The saddest aspect of life right now is that science gathers knowledge faster than society gathers wisdom. - Isaac Asimov.",
"Never let your sense of morals prevent you from doing what is right. - Isaac Asimov, Foundation.",
"In life, unlike chess, the game continues after checkmate. - Isaac Asimov.",
"It is change, continuing change, inevitable change, that is the dominant factor in society today. No sensible decision can be made any longer without taking into account not only the world as it is, but the world as it will be.  - Isaac Asimov.",
"A subtle thought that is in error may yet give rise to fruitful inquiry that can establish truths of great value.  - Isaac Asimov.",
"It pays to be obvious, especially if you have a reputation for subtlety.  - Isaac Asimov.",
"The true delight is in the finding out rather than in the knowing.  - Isaac Asimov.",
"Science fiction writers foresee the inevitable, and although problems and catastrophes may be inevitable, solutions are not.  - Isaac Asimov.",
"Writing, to me, is simply thinking through my fingers.  - Isaac Asimov.",
"I don't believe in personal immortality; the only way I expect to have some version of such a thing is through my books. - Isaac Asimov.",
"I write for the same reason I breathe - because if I didn't, I would die. - Isaac Asimov.",
"It is not only the living who are killed in war.- Isaac Asimov.",
"Meanwhile, fears of universal disaster sank to an all time low over the world. - Isaac Asimov.",
"Dalton's records, carefully preserved for a century, were destroyed during the World War II bombing of Manchester. It is not only the living who are killed in war. - Isaac Asimov.",
"From my close observation of writers... they fall into two groups: 1) those who bleed copiously and visibly at any bad review, and 2) those who bleed copiously and secretly at any bad review. - Isaac Asimov.",
"He had read much, if one considers his long life; but his contemplation was much more than his reading. He was wont to say that if he had read as much as other men he should have known no more than other men. - Isaac Asimov.",
"People who think they know everything are a great annoyance to those of us who do. - Isaac Asimov.",
"Violence is the last refuge of the incompetent. - Isaac Asimov.",
"The most exciting phrase to hear in science, the one that heralds new discoveries, is not 'Eureka!' but 'That's funny...' - Isaac Asimov.",
"Life is pleasant. Death is peaceful. It's the transition that's troublesome. - Isaac Asimov.",
"I don't believe in an afterlife, so I don't have to spend my whole life fearing hell, or fearing heaven even more. For whatever the tortures of hell, I think the boredom of heaven would be even worse. - Isaac Asimov.",
"Creationists make it sound as though a 'theory' is something you dreamt up after being drunk all night. - Isaac Asimov.",
"Self-education is, I firmly believe, the only kind of education there is. - Isaac Asimov.",
"I do not fear computers. I fear the lack of them. - Isaac Asimov.",
"Individual science fiction stories may seem as trivial as ever to the blinder critics and philosophers of today - but the core of science fiction, its essence has become crucial to our salvation if we are to be saved at all. - Isaac Asimov.",
"No sensible decision can be made any longer without taking into account not only the world as it is, but the world as it will be. - Isaac Asimov.",
"And above all things, never think that you're not good enough yourself. A man should never think that. My belief is that in life people will take you at your own reckoning. - Isaac Asimov.",
"Part of the inhumanity of the computer is that, once it is competently programmed and working smoothly, it is completely honest. - Isaac Asimov.",
"If knowledge can create problems, it is not through ignorance that we can solve them. - Isaac Asimov.",
"Humanity has the stars in its future, and that future is too important to be lost under the burden of juvenile folly and ignorant superstition. - Isaac Asimov.",
"It takes more than capital to swing business. You've got to have the A. I. D. degree to get by - Advertising, Initiative, and Dynamics. - Isaac Asimov.",
"I am not a speed reader. I am a speed understander. - Isaac Asimov.",
"To insult someone we call him 'bestial. For deliberate cruelty and nature, 'human' might be the greater insult. - Isaac Asimov.",
"There is a single light of science, and to brighten it anywhere is to brighten it everywhere. - Isaac Asimov.",
"All sorts of computer errors are now turning up. You'd be surprised to know the number of doctors who claim they are treating pregnant men. - Isaac Asimov.",
"Suppose that we are wise enough to learn and know - and yet not wise enough to control our learning and knowledge, so that we use it to destroy ourselves? Even if that is so, knowledge remains better than ignorance. - Isaac Asimov.",
"When I read about the way in which library funds are being cut and cut, I can only think that American society has found one more way to destroy itself. - Isaac Asimov.",
"If my doctor told me I had only six minutes to live, I wouldn't brood. I'd type a little faster. - Isaac Asimov.",
"Start by doing what's necessary; then do what's possible; and suddenly you are doing the impossible. - Isaac Asimov.",
"For it is in giving that we receive. - Isaac Asimov.",
"Where there is charity and wisdom, there is neither fear nor ignorance. - Isaac Asimov."]

    r1 = random.randint(0,len(quotes))
    
    print("\n"+quotes[r1])

def About():
    """Function to show information about SAnDReS"""
    
    # Import library
    import time
    
    # String for local time
    my_local_date = str(time.strftime("%Y %m %d"))
    my_local_time = str(time.strftime("%Hh%Mmin%Ss"))
    
    print("\nLoading SAnDReS files...")
    print("\nToday's date: ",my_local_date)
    print("Local time: ",my_local_time)
    
    Asimov()
    
    # Call call_main_sandres()
    call_main_sandres()
        
    return

def call_main_sandres():
    """Function to call main sandres"""
        
    # Run script sandres_main_2018.py
    import sandres_main_2018 as sandres
        
    # Call main method
    sandres.main()
    
    my_opening_message = """
    Statistical Analysis of Docking Results and Scoring functions
    SAnDReS 1.1.0
    Written by Walter F. de Azevedo Jr. 
    with help from
    Gabriela Bitencourt-Ferreira, Amauri Duarte da Silva,
    Mariana M. Xavier, Gabriela Sehnem Heck, 
    Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
    Val de Oliveira Pintro, and Nathalia L. Carvalho.
    
    Please acknowledge the use of the SAnDReS software that results
    in any published scientific paper by citing the following reference:
    
    Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro, V.O.; Carvalho, N.L.; Azevedo, W.F.Jr.
    SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results and Development of Scoring
    Functions. Comb.  Chem.  High Throughput Screen, 2016, 19(10): 801-812.
    DOI: 10.2174/1386207319666160927111347 
    """
    
    print(my_opening_message)

# Main GUI program

# Import libraries
from tkinter import *
from tkinter import filedialog
    
# Call insert_showinfo_in() # Here on January 30th 2017 (check this function)
insert_showinfo_in()

# Try to call About()
try:
    About()
except:
    fo = open(sandres_root+"inputs\strdir.in","w")
    fo.write("STRDIR,"+sandres_root)
    fo.close()
    print("\n\nI can't find Project Directory! Please use 'Find' button to browse for a new Project Directory!")
    print("\a")
    input("\nPress Enter to continue ")
    print("\nSAnDReS is comming...")

mycolor = '#%02x%02x%02x' % (240, 240, 240)  # set your favourite rgb color for background
root = Tk()
root.title("Statistical Analysis of Docking Results and Scoring functions") 
root.geometry("870x340+20+40")  # Layout for Prompt cf commands: Window: length = 106, height = 20
                                #                                Positioning: left = 70, top: 410
root.configure(bg=mycolor)      # This method sets the color for background
menu = Menu(root)

root.config(menu=menu)

logo1 = PhotoImage(file="sandres_logo1.gif")
Label(root, image = logo1 ).grid(row = 0, column = 0, stick = E) 
logo2 = PhotoImage(file="sandres_110.gif")
Label(root, image = logo2 ).grid(row = 0, column = 0, stick = W) 

show_message_in_sandres("SAnDReS ready to go!","black","light grey")

# Widgets for project directory
Label(root, text = 70*" "+"Project Directory:" ).grid(row = 2,column = 0, stick = W, pady = 4 )  
strdir_entry = Entry(root,width = 75) 
strdir_entry.grid(row = 2,column = 0, stick = E, pady = 4)
Button(root, text='Find ', command=dir_chooser).grid(row = 2, column = 1, sticky = W)
Button(root, text='Update', command=update_strdir).grid(row = 2, column = 1, stick = E)
my_strdir_main_GUI = read_strdir() 
strdir_entry.insert(10,my_strdir_main_GUI)

# Widgets to read input file
Label(root, text = 70*" "+"Input File Name:" ).grid(row = 4,column = 0, stick = W)   
inputfile_entry = Entry(root,width = 75)
inputfile_entry.grid(row = 4, column = 0,stick = E)
Button(root, text='Clear', command=clear_inputfile_entry).grid(row = 4, column = 1, sticky = W)
Button(root, text=' Run it ', bg = "light green", command=run_input_file).grid(row = 4, column = 1, sticky = E)
inputfile_entry.insert(10,"showinfo.in")

# Widgets to read csv file name
Label(root, text = 63*" "+"Re-Docking CSV File:" ).grid(row = 5,column = 0, stick = W)   
input_csv_file_entry = Entry(root,width = 75)
input_csv_file_entry.grid(row = 5, column = 0,stick = E)
Button(root, text='Clear', command=clear_input_csv_file_entry).grid(row = 5, column = 1, sticky = W)
Button(root, text='Import', command=edit_redock_file).grid(row = 5, column = 1, sticky = E)
input_csv_file_entry.insert(10,"redock01.csv")
my_file_main_GUI = input_csv_file_entry.get() 

# Widgets to read ensemble-docking csv file name
Label(root, text = 51*" "+"Ensemble-Docking CSV File:" ).grid(row = 6,column = 0, stick = W)   
input_ensemble_csv_file_entry = Entry(root,width = 75)
input_ensemble_csv_file_entry.grid(row = 6, column = 0,stick = E)
Button(root, text='Clear', command=clear_ensembledock_csv_file_entry).grid(row = 6, column = 1, sticky = W)
Button(root, text='Import', command=edit_ensembledock_file).grid(row = 6, column = 1, sticky = E)
input_ensemble_csv_file_entry.insert(10,"ensembledock.csv")
my_ensemble_file_main_GUI = input_ensemble_csv_file_entry.get() 

# Widgets to read scoring function csv file name
Label(root, text = 53*" "+"Scoring Function CSV File:" ).grid(row = 7,column = 0, stick = W)   
input_score_csv_file_entry = Entry(root,width = 75)
input_score_csv_file_entry.grid(row = 7, column = 0,stick = E)
Button(root, text='Clear', command=clear_scores_all_csv_file_entry).grid(row = 7, column = 1, sticky = W)
Button(root, text='Import', command=edit_score_file).grid(row = 7, column = 1, sticky = E)
input_score_csv_file_entry.insert(10,"scores_all.csv")
my_score_file_main_GUI = input_score_csv_file_entry.get() 

# Widgets to read window_txt and show file
scrollbar = Scrollbar(root)
scrollbar.grid(row=8, column = 2, sticky=W)
window_txt = Text(root, width = 106, height = 8, font = "Courier 10", yscrollcommand=scrollbar.set)        
window_txt.grid(row = 8, column = 0, columnspan = 2, sticky = W)
scrollbar.config(command=window_txt.yview) 

my_opening_message = """
Statistical Analysis of Docking Results and Scoring functions
SAnDReS 1.1.0
Written by Walter F. de Azevedo Jr. 
with help from
Gabriela Bitencourt-Ferreira, Amauri Duarte da Silva,
Mariana M. Xavier, Gabriela Sehnem Heck, 
Mauricio B. de Avila, Nayara M. Bernhardt Levin, 
Val de Oliveira Pintro, and Nathalia L. Carvalho.
                          """
                          
window_txt.insert(0.0,my_opening_message) 

Button(root, text=' Clear ', command=clear_sandres_info_file_txt).grid(row=9, column=1, sticky=W, pady=4)
Button(root, text='  Exit   ', bg = "red", command=exit_function).grid(row=9, column=1, sticky=E, pady=4) 

# File Menu
filemenu = Menu(menu)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="Copy tutorial001 to Project Directory", command=copy_tutorial_001)
filemenu.add_separator()
filemenu.add_command(label="Preferences", command=sandres_par_GUI)
filemenu.add_separator()
filemenu.add_command(label="Import "+my_file_main_GUI+" File", command=edit_specific_file)
filemenu.add_command(label="Import chklig.in File", command=edit_input_file_chklig)
filemenu.add_command(label="Import pltcsv0.in File", command=edit_input_file_pltcsv0)
filemenu.add_command(label="Import pltcsv0A.in File", command=edit_input_file_pltcsv0A)
filemenu.add_command(label="Import pltcsv1.in File", command=edit_input_file_pltcsv1)
filemenu.add_command(label="Import pltcsv1A.in File", command=edit_input_file_pltcsv1A)
filemenu.add_command(label="Import pltcsv2.in File", command=edit_input_file_pltcsv2)
filemenu.add_command(label="Import pltcsv2A.in File", command=edit_input_file_pltcsv2A)
filemenu.add_command(label="Import pltcsv3.in File", command=edit_input_file_pltcsv3)
filemenu.add_command(label="Import pltcsv3A.in File", command=edit_input_file_pltcsv3A)
filemenu.add_command(label="Import pltcsv4.in File", command=edit_input_file_pltcsv4)
filemenu.add_command(label="Import pltcsv4A.in File", command=edit_input_file_pltcsv4A)
filemenu.add_separator()
filemenu.add_command(label="Exit", command=exit_function)

# Download Menu
downloadmenu = Menu(menu)
menu.add_cascade(label="Download", menu = downloadmenu)
downloadmenu.add_command(label="Input PDB Access Codes", command = getPDB)
downloadmenu.add_separator()
downloadmenu.add_command(label="Structures (PDB Format)", command= getstr_PDB)
downloadmenu.add_separator()
downloadmenu.add_command(label="Binding Affinity (CSV Format)", command = getstr_download_GUI)

# Pre-dock Menu
predockmenu = Menu(menu)
menu.add_cascade(label="Pre-Docking", menu=predockmenu)
predockmenu.add_command(label="Check Structures with Binding Affinity Information", command = chkstr_GUI)
predockmenu.add_separator()
predockmenu.add_command(label="Update Binding Infornation in chklig.in", command = update_chklig_in)
predockmenu.add_command(label="Check Ligands", command = chklig)
predockmenu.add_separator()
predockmenu.add_command(label="Filter Dataset",command = edit_filter_dataset) 
predockmenu.add_separator()
predockmenu.add_command(label="Statistical Analysis of Crystallographic Structures", command = ststru)
predockmenu.add_command(label="Show Statistical Analysis of Crystallographic Structures", command = show_ststru)
predockmenu.add_separator()
predockmenu.add_command(label="Bio-matrix for Crystallographic Structures", command = biomat)
predockmenu.add_separator()
predockmenu.add_command(label="Generate Data Set with Crystallographic Structures", command = fndwat)
predockmenu.add_command(label="Update Ligand Information (chklig.in)", command = update_chklig)
predockmenu.add_command(label="Generate Binding Site for Crystallographic Structures", command = pre_binding_site)
predockmenu.add_separator()
predockmenu.add_command(label="Create Dataset for Active Ligands in chklig.in", command = extract_sdf)
predockmenu.add_separator()
predockmenu.add_command(label="Filter PDB Files By Enzyme Classification (EC)", command = filter_PDB_by_EC)
predockmenu.add_separator()
predockmenu.add_command(label="Prepare Files to Generate Plots", command = histogram_pltcsv0)
predockmenu.add_separator()
predockmenu.add_command(label="Plot", command = plot_pltcsv0A_GUI)
predockmenu.add_command(label="Histogram Plot", command = plot_pltcsv0_GUI)
predockmenu.add_separator()
predockmenu.add_command(label="Plot Intermolecular Interactions", command = pre_intermol_GUI)
    
# Docking Hub Menu
redockmenu = Menu(menu)
menu.add_cascade(label="Docking Hub", menu = redockmenu)
redockmenu.add_command(label="Docking Simulations", command = docking_simulations_GUI)
redockmenu.add_separator()
redockmenu.add_command(label="Import Docking Results", command = import_docking_results_GUI)
redockmenu.add_command(label="Merge AutoDock4 Results (GA)", command =  pre_merge_autodock_data_GA)
redockmenu.add_command(label="Merge AutoDock4 Results (LGA)", command =  pre_merge_autodock_data_LGA)
redockmenu.add_command(label="Merge AutoDock4 Results (EPDB)", command =  pre_merge_autodock_data_EPDB)
redockmenu.add_command(label="Merge Vina Results", command =  pre_merge_vina_data)
redockmenu.add_separator()
redockmenu.add_command(label="Statistical Analysis of Scoring Functions vs RMSD", command = strmsd)
redockmenu.add_command(label="Show Statistical Analysis of Scoring Functions vs RMSD", command = show_strmsd)
redockmenu.add_separator()
redockmenu.add_command(label="Prepare Files to Plot Re-dock Results (Scatter Plot)", command = edit_scatter_pltcsv1)
redockmenu.add_command(label="Prepare Files to Plot Re-dock Results (Scatter Plot) with Correlation and p-value",\
                        command = edit_scatter_pltcsv1A)
redockmenu.add_separator()
redockmenu.add_command(label="Plot Re-dock Results (Scatter Plot)", command = plot_pltcsv_GUI)
    
# Ensemble-Docking Menu
ensembledockingmenu = Menu(menu)
menu.add_cascade(label="Ensemble Docking", menu = ensembledockingmenu)
ensembledockingmenu.add_command(label="Check Ligands in "+my_ensemble_file_main_GUI+" File",\
                            command = check_ensembledock_csv_file)
ensembledockingmenu.add_separator()
ensembledockingmenu.add_command(\
                            label="Generate Input for Statistical Analysis of Ensemble-Docking Results",\
                            command = dummy_stensembledock) # Call gen_stensembledock
ensembledockingmenu.add_command(\
                            label="Statistical Analysis of Ensemble-Docking Results and Scoring Functions",\
                            command = stensembledock)
ensembledockingmenu.add_command(label=\
                            "Show Statistical Analysis of Ensemble-Docking Results and Scoring Functions",\
                            command = show_stensembledock)
ensembledockingmenu.add_separator()
ensembledockingmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot)", command = edit_scatter_pltcsv3)
ensembledockingmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot) with Correlation and p-value",\
                            command = edit_scatter_pltcsv3A)
ensembledockingmenu.add_separator()
ensembledockingmenu.add_command(label="Plot Re-dock Results (Scatter Plot)", command = plot_pltcsv_GUI)

# Structural Parameters Menu
structuralparmenu = Menu(menu)
menu.add_cascade(label="Structural Parameters", menu = structuralparmenu)
structuralparmenu.add_command(label="Check Ligands in "+my_ensemble_file_main_GUI+" File",\
                              command = check_ensembledock_csv_file)
structuralparmenu.add_separator()
structuralparmenu.add_command(label="Generate Input for Statistical Analysis of Docking Results",\
                              command = dummy_stdock) # call gen_stdock()
structuralparmenu.add_command(label="Statistical Analysis of Docking Results (Short)", command = stdock1)
structuralparmenu.add_command(label="Statistical Analysis of Docking Results (Long)", command = stdock2)
structuralparmenu.add_command(label="Show Statistical Analysis of Docking Results", command = show_stdock)
structuralparmenu.add_separator()
structuralparmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot)", command = edit_scatter_pltcsv2)
structuralparmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot) with Correlation and p-value",\
                              command = edit_scatter_pltcsv2A)
structuralparmenu.add_separator()
structuralparmenu.add_command(label="Plot Re-dock Results (Scatter Plot)", command = plot_pltcsv_GUI)

# Scoring Function Menu
scorefunctionmenu = Menu(menu)
menu.add_cascade(label="Scoring Functions", menu = scorefunctionmenu)
scorefunctionmenu.add_command(label="Add Experimental Binding Affinity",\
                              command = prep_read_binding_data)
scorefunctionmenu.add_command(label="Add Calculated Binding Affinity", command = add_calc_binding_GUI) 
scorefunctionmenu.add_separator()
scorefunctionmenu.add_command(label="Check Ligands in "+my_score_file_main_GUI+" File",\
                              command = check_score_csv_file)
scorefunctionmenu.add_separator()
scorefunctionmenu.add_command(label="Generate Input for Statistical Analysis of Scoring Functions",\
                              command = dummy_stscor)  # Call gen_stscor
scorefunctionmenu.add_command(label="Statistical Analysis of Experimental Binding Affinity and Scoring \
Functions", command = stscor)
scorefunctionmenu.add_command(label="Show Statistical Analysis of Experimental Binding Affinity and Scoring \
Functions", command = show_stscor)
scorefunctionmenu.add_separator()
scorefunctionmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot)", command = edit_scatter_pltcsv4)
scorefunctionmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot) with Correlation and p-value",\
                              command = edit_scatter_pltcsv4A)
scorefunctionmenu.add_separator()
scorefunctionmenu.add_command(label="Plot Re-dock Results (Scatter Plot)", command = plot_pltcsv_GUI)

# Machine Learning Box Menu
build_scorefunctionmenu = Menu(menu)
menu.add_cascade(label="Machine Learning Box", menu = build_scorefunctionmenu)
build_scorefunctionmenu.add_command(label="Generate CSV Files for Polynomial Scoring Functions",\
                              command = gen_newcsv)
build_scorefunctionmenu.add_separator()
build_scorefunctionmenu.add_command(label="Machine Learning Method (Polscore)", command = reg_methods_GUI) 
build_scorefunctionmenu.add_separator()
build_scorefunctionmenu.add_command(label="Machine Learning Method (Scoring Function Space)", command = reg_brute_force_GUI) 
build_scorefunctionmenu.add_separator()
build_scorefunctionmenu.add_command(label="Sort Scoring Functions", command = sort_polscore)
build_scorefunctionmenu.add_command(label="Update "+my_score_file_main_GUI+" File",\
                              command = update_score_csv_file_GUI)
build_scorefunctionmenu.add_separator()
build_scorefunctionmenu.add_command(label="Generate Input for Statistical Analysis of Scoring Functions",\
                              command = gen_stscor)
build_scorefunctionmenu.add_command(\
label="Statistical Analysis of Experimental Binding Affinity and Scoring \
Functions", command = stscor)
build_scorefunctionmenu.add_command(label="Show Statistical Analysis of Experimental Binding Affinity and \
Scoring Functions", command = show_stscor)
build_scorefunctionmenu.add_separator()
build_scorefunctionmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot)", command = edit_scatter_pltcsv4)
build_scorefunctionmenu.add_command(label="Prepare Files to Plot Results (Scatter Plot) with Correlation and p-value",command = edit_scatter_pltcsv4A)
build_scorefunctionmenu.add_separator()
build_scorefunctionmenu.add_command(label="Plot Re-dock Results (Scatter Plot)", command = plot_pltcsv_GUI)

# Decoy Menu
decoymenu = Menu(menu)
menu.add_cascade(label="Decoys", menu =decoymenu)
decoymenu.add_command(label="Prepare Dataset with Decoys and Actives",\
                              command = prep_dataset)
decoymenu.add_command(label="Insert Polynomial Equation to Decoy Dataset ",\
                        command = update_decoy_csv_file_GUI)
decoymenu.add_command(label="Plot Receiver Operating Characteristic (ROC) Curves ",command = par_2_ROC)

# Help menu
helpmenu = Menu(menu)
helpmenu.add_command(label="Docking School:")
helpmenu.add_command(label="Using AutoDock 4", command = prep_run_chrome_autodock_tutor1)
helpmenu.add_command(label="Using AutoDock Vina", command = prep_run_chrome_vina_tutor1)
helpmenu.add_command(label="Using GemDock", command = prep_run_chrome_gemdock_tutor1)
helpmenu.add_command(label="Using Molegro Virtual Docker", command = prep_run_chrome_mvd_tutor1)
helpmenu.add_command(label="Using SwissDock", command = prep_run_chrome_swissdock_tutor1)
helpmenu.add_separator()
helpmenu.add_command(label="License", command = about_license)
menu.add_cascade(label="Help", menu = helpmenu)
helpmenu.add_command(label="Overview", command = about_overview)
helpmenu.add_command(label="Version", command = about_version)
helpmenu.add_command(label="SAnDReS Paper", command = about_sandres_paper)
helpmenu.add_separator()
helpmenu.add_command(label="Help for:")
helpmenu.add_command(label="File", command = about_file)
helpmenu.add_command(label="Download from PDB", command = about_download)
helpmenu.add_command(label="Pre-Docking", command = about_predocking)
helpmenu.add_command(label="Docking Hub", command = about_docking)
helpmenu.add_command(label="Ensemble Docking", command = about_ensemble_docking)
helpmenu.add_command(label="Structural Parameters", command = about_docking_results)
helpmenu.add_command(label="Scoring Functions", command = about_scoring_functions)
helpmenu.add_command(label="Machine Learning Box", command = about_machine_learning_box)
helpmenu.add_command(label="Decoys", command = about_decoys)
 
mainloop()