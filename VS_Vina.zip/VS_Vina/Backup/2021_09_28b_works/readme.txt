Suppose you are in a directory containing your receptor receptor.pdbqt and a set of ligands named ligand_01.pdbqt, ligand_02.pdbqt, etc.

You can create a configuration file conf.txt, such as

receptor = receptor.pdbqt

center_x =  2
center_y =  6
center_z = -7

size_x = 25
size_y = 25
size_z = 25

num_modes = 9
and dock all ligands with this shell script. 
