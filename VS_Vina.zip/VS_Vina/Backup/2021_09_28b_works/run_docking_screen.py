# Import package
from tools import docking_screen as dock_s

# Main function
def main():

    # Set up arguments
    program_root = "/home/walter/Dev/sandres2/"
    vs_dir = "/home/walter/Dev/VS_Vina/Test_10_with_Python/"
    config_in = "config.txt"

    # Instantiate an object of VirtualScreening() class
    vs = dock_s.VirtualScreening(program_root,vs_dir,config_in)

    # Invoke simulation() method
    vs.simulation()

main()