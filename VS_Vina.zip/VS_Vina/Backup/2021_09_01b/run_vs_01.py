# Import package
import os

# Set up parameters
program_root = "/home/walter/Dev/sandres2/"
vs_dir = "/home/walter/Dev/VS_Vina/Test_04_with_Python/"
config_in = "config.txt"
count_pdb = 1

# Get the number of molecules for virtual screening
ligs = os.listdir(vs_dir+"mols/")
n_ligs = len(ligs)
print("Number of molecules for VS: ",n_ligs)

# Looping through molecules
for i in range(n_ligs):

    # Try to make dir
    try:
        # Make dir
        os.mkdir(vs_dir+"mols/lig_"+str(count_pdb))
    except:
        pass

    # Run AutoDock Vina
    # ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt --log ${b}/results.log
    os.system(program_root+\
        "misc/linux_third_party_software/vina/./vina --config "+\
        vs_dir+config_in+" --ligand "+\
        vs_dir+"mols/lig_"+str(count_pdb)+".pdbqt --out "+\
        vs_dir+"mols/lig_"+str(count_pdb)+"/poses.pdbqt"+" --log "+\
        vs_dir+"mols/lig_"+str(count_pdb)+"/results.log")

    # Update count_pdb
    count_pdb += 1