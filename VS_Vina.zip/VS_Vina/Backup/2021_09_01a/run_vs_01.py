# Import package
import os

program_root = "/home/walter/Dev/sandres2/"
vs_dir = "/home/walter/Dev/VS_Vina/Test_03_with_Python/"
config_in = "config.txt"
count_pdb = 1

# Run AutoDock Vina for energy calculation
# ./vina --receptor receptor.pdbqt --ligand lig.pdbqt --score_only --log log.txt
# ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt --log ${b}/results.log
#os.system(self.program_root+\
#    "misc/linux_third_party_software/vina/./vina --receptor "+\
#    pdb_dir+self.receptor_in+" --ligand "+\
#    pdb_dir+"pose_"+a_str+".pdbqt --score_only --log "+pdb_dir+\
#    "result_"+a_str+".log")

# Try to make dir
try:
    # Make dir
    os.mkdir(vs_dir+"lig_"+str(count_pdb))
except:
    pass

# Run AutoDock Vina
# ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt --log ${b}/results.log
os.system(program_root+\
    "misc/linux_third_party_software/vina/./vina --config "+\
    vs_dir+config_in+" --ligand "+\
    vs_dir+"lig_"+str(count_pdb)+".pdbqt --out "+\
    vs_dir+"lig_"+str(count_pdb)+"/poses.pdbqt"+" --log "+\
    vs_dir+"lig_"+str(count_pdb)+"/results.log")