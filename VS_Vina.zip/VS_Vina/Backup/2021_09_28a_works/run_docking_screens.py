# Import package
import os

class VirtualScreening(object):
    """Class to carry out virtual screening with AutoDock Vina"""

    # Define constructor method
    def __init__(self,program_root,vs_dir,config_in):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.vs_dir = vs_dir
        self.config_in = config_in

    # Define simulation() method
    def simulation(self):
        """Virtual screening with AutoDock Vina"""

        # Set up empty string
        config_lines = ""

        # Try to open config.txt
        try:

            # Open a file
            file2open = self.vs_dir+self.config_in
            config_lines = ""
            fo_config = open(file2open,"r")
            fo_lines = fo_config.readlines()

            # Looping through fo_lines
            for line in fo_lines:
                if "receptor" in str(line):
                    config_lines += "receptor = "+self.vs_dir+"receptor.pdbqt\n"
                else:
                    line_out = str(line)
                    config_lines += line_out

            # Close file
            fo_config.close()

            # Open new file
            fo_config = open(file2open,"w")

            # Write lines
            fo_config.write(config_lines)

            # Close file
            fo_config.close()

        # Handle IOError exception
        except IOError:
            print("\nI can't find "+file2open+" file!")

        # Get the number of molecules for virtual screening
        ligs = os.listdir(self.vs_dir+"mols/")
        n_ligs = len(ligs)
        print("Number of molecules for VS: ",n_ligs)

        # Looping through molecules
        for lig in ligs:

            print("\nRunning for ligand: ",lig)

            # Set up ligand root
            i_p = lig.index(".")
            lig_root = lig[:i_p]

            # Try to make dir
            try:
                # Make dir
                os.mkdir(self.vs_dir+"mols/"+lig_root)
            except:
                pass

            # Run AutoDock Vina
            # ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt
            #--log ${b}/results.log
            os.system(self.program_root+\
                "misc/linux_third_party_software/vina/./vina --config "+\
                self.vs_dir+self.config_in+" --ligand "+\
                self.vs_dir+"mols/"+lig+" --out "+\
                self.vs_dir+"mols/"+lig_root+"/poses.pdbqt"+" --log "+\
                self.vs_dir+"mols/"+lig_root+"/results.log")

# Main function
def main():

    # Set up arguments
    program_root = "/home/walter/Dev/sandres2/"
    vs_dir = "/home/walter/Dev/VS_Vina/Test_09_with_Python/"
    config_in = "config.txt"

    # Instantiate an object of VirtualScreening() class
    vs = VirtualScreening(program_root,vs_dir,config_in)

    # Invoke simulation() method
    vs.simulation()

main()