#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define ElasticNetCV() class
class ElasticNetCV(object):
    """Class to carry out ElasticNet regression with cross-validation

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : ndarray of shape (n_samples, n_features). Training data.
                                If using GCV, will be cast to float64 if necessary.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_targets)
                                Target values. Will be cast to X’s dtype if necessary.

    Outputs
       rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or ndarray of shape (n_targets,). Independent term in decision function.
                                Set to 0.0 if fit_intercept = False.
       model.coef_              : ndarray of shape (n_features) or (n_targets, n_features). Weight vector(s).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_ElasticNet() method
    def ml_scikit_ElasticNetCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ElasticNet
        It uses Kfold class to build a n fold cross-validation loop and test
        the generalization ability of a regression model available in
        the ValidationLoop() class. It is not used the ElasticNetCV available
        in the Scikit-Learn
        """

        # Import packages
        from sklearn.linear_model import ElasticNet # Not ElasticNetCV from scikit-learn
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.ElasticNet.html
        #
        # string_reg_method = ElasticNet
        #
        # alpha: float, default=1.0
        # Constant that multiplies the penalty terms. Defaults to 1.0. See the
        # notes for the exact mathematical meaning of this parameter. alpha = 0
        # is equivalent to an ordinary least square, solved by the
        # LinearRegression object. For numerical reasons, using alpha = 0 with
        # the Lasso object is not advised. Given this, you should use
        # the LinearRegression object.
        #
        # l1_ratio: float, default=0.5
        # The ElasticNet mixing parameter, with 0 <= l1_ratio <= 1.
        # For l1_ratio = 0 the penalty is an L2 penalty.
        # For l1_ratio = 1 it is an L1 penalty. For 0 < l1_ratio < 1,
        # the penalty is a combination of L1 and L2.
        #
        # fit_intercept: bool, default=True
        # Whether the intercept should be estimated or not. If False, the data
        # is assumed to be already centered.
        #
        # precompute: bool or array-like of shape (n_features, n_features),
        # default=False
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # The Gram matrix can also be passed as argument. For sparse input this
        # option is always False to preserve sparsity.
        #
        # max_iter: int, default=1000
        # The maximum number of iterations.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # tol: float, default=1e-4
        # The tolerance for the optimization: if the updates are smaller than
        # tol, the optimization code checks the dual gap for optimality and
        # continues until it is smaller than tol.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit as
        # initialization, otherwise, just erase the previous solution.
        #
        # positive: bool, default=False
        # When set to True, forces the coefficients to be positive.
        #
        # random_state: int, RandomState instance, default=None
        # The seed of the pseudo random number generator that selects a random
        # feature to update. Used when selection == ‘random’.
        # Pass an int for reproducible output across multiple function calls.
        #
        # selection: {‘cyclic’, ‘random’}, default=’cyclic’
        # If set to ‘random’, a random coefficient is updated every iteration
        # rather than looping over features sequentially by default.
        # This (setting to ‘random’) often leads to significantly faster
        # convergence especially when tol is higher than 1e-4.
        #
        # Show message
        print("\nElasticNet Regression with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0].strip() == "ElasticNetCV":

                # For alpha_in
                alpha_in = float(line[1].strip())

                # For l1_ratio_in
                l1_ratio_in = float(line[2].strip())

                # For fit_in
                if line[3].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For precompute_in
                if line[4].strip() == "True":
                    precompute_in = True
                else:
                    precompute_in = False

                # For max_iter_in
                max_iter_in = int(line[5].strip())

                # For copy_X_in
                if line[6].strip() == "True":
                    copy_X_in = True
                else:
                    copy_X_in = False

                # For tol_in
                tol_in = float(line[7].strip())

                # For warm_start_in
                if line[8].strip() == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For positive_in
                if line[9].strip() == "True":
                    positive_in = True
                else:
                    positive_in = False

                # For random_state_in
                if line[10].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[10].strip())

                # For selection_in
                list_selection = ["cyclic","random"]
                if line[11].strip() in list_selection:
                    selection_in = line[11].strip()
                else:
                    selection_in = "cyclic"
                    print("Unrecognizable input!")

                # For rand_in (for MDM file)
                rand_in = int(line[12].strip())

                # For cv_in
                cv_in = int(line[13].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Alpha: ",alpha_in)
        print("l1_ratio: ",l1_ratio_in)
        print("Fit intercept? ",line[3])
        print("Precompute: ",line[4])
        print("Maximum number of iterations: ",max_iter_in)
        print("If True, X will be copied; else, it may be overwritten: ",
        line[6])
        print("Tolerance for the optimization: ",tol_in)
        print("When set to True, reuse the solution of the previous call: ",
        line[8])
        print("Forces the coefficients to be positive: ",line[9])
        print("Seed of the pseudo random number generator: ",line[10])
        print("Selection: ",selection_in)

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of ElasticNet() class
        model = ElasticNet(
                alpha = alpha_in,               # alpha: float, default=1.0
                l1_ratio = l1_ratio_in,         # l1_ratio: float, default=0.5
                fit_intercept = fit_in,         # fit_intercept: bool, default=True
                precompute = precompute_in,     # precompute: bool or array-like of shape (n_features, n_features), default=False
                max_iter = max_iter_in,         # max_iter: int, default=1000
                copy_X = copy_X_in,             # copy_X: bool, default=True
                tol = tol_in,                   # tol: float, default=1e-4
                warm_start = warm_start_in,     # warm_start: bool, default=False
                positive = positive_in,         # positive: bool, default=False
                random_state = random_state_in, # random_state: int, RandomState instance, default=None
                selection = selection_in        # selection: {‘cyclic’, ‘random’}, default=’cyclic’
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_