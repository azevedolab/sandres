#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define KernelRidgeCV() class
class KernelRidgeCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_KernelRidgeCV() method
    def ml_scikit_KernelRidgeCV(self):
        """
        Method to generate a multiple regression model using
        KernelRidgeCV
        """

        # Import packages
        from sklearn.kernel_ridge import KernelRidge
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.kernel_ridge.KernelRidge.html
        #
        # Additional material related to scikit-learn
        # https://www.educative.io/blog/scikit-learn-cheat-sheet-classification-regression-methods
        #
        # string_reg_method = KernelRidgeCV
        #
        #
        # alpha: float or array-like of shape (n_targets,), default=1.0
        # Regularization strength; must be a positive float. Regularization
        # improves the conditioning of the problem and reduces the variance of
        # the estimates. Larger values specify stronger regularization. Alpha
        # corresponds to 1 / (2C) in other linear models such as
        # LogisticRegression or LinearSVC. If an array is passed, penalties are
        # assumed to be specific to the targets. Hence they must correspond in
        # number. See Ridge regression and classification for formula.
        #
        # kernel: string or callable, default=”linear”
        # Kernel mapping used internally. This parameter is directly passed to
        # pairwise_kernel. If kernel is a string, it must be one of the metrics
        # in pairwise.PAIRWISE_KERNEL_FUNCTIONS. If kernel is “precomputed”,
        # X is assumed to be a kernel matrix. Alternatively, if kernel is a
        # callable function, it is called on each pair of instances (rows) and
        # the resulting value recorded. The callable should take two rows from
        # X as input and return the corresponding kernel value as a single
        # number. This means that callables from sklearn.metrics.pairwise are
        # not allowed, as they operate on matrices, not single samples. Use the
        # string identifying the kernel instead.
        #
        # gamma: float, default=None
        # Gamma parameter for the RBF, laplacian, polynomial, exponential
        # chi2 and sigmoid kernels. Interpretation of the default value is
        # left to the kernel; see the documentation for
        # sklearn.metrics.pairwise. Ignored by other kernels.
        #
        # degree: float, default=3.0
        # Degree of the polynomial kernel. Ignored by other kernels.
        #
        # coef0: float, default=1.0
        # Zero coefficient for polynomial and sigmoid kernels. Ignored by other kernels.
        #
        # kernel_params: mapping of string to any, default=None
        # Additional parameters (keyword arguments) for kernel function passed as callable object.

        # Show message
        print("\nKernel Ridge Regression (KRR)")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "KernelRidgeCV":

                # For alpha_in
                try:
                    alpha_in = float(line[1].strip())
                    if alpha_in < 0.0: # It has to be > 0.0
                        print("\nAlpha should be a positive float!")
                        alpha_in = 1.0

                # Handle exceptions (it accepts arrays)
                except:
                    alpha_in = np.array(line[1].strip())

                # For kernel_in (worked for:linear,poly,polynomial,rbf,
                # laplacian,sigmoid, and cosine)
                # Original list: "precomputed","linear","additive_chi2","chi2",
                # "poly","polynomial","rbf","laplacian","sigmoid","cosine"
                list_kernel = ["linear","poly","polynomial","rbf","laplacian",
                "sigmoid","cosine"]
                if line[2].strip() in list_kernel:
                    kernel_in = line[2].strip()
                else:
                    kernel_in = "linear"
                    print("Unrecognizable input!")

                # For gamma_in
                if line[3].strip() == "None":
                    gamma_in = None
                else:
                    gamma_in = float(line[3].strip())

                # For degree_in
                degree_in = float(line[4].strip())

                # For coef0_in
                coef0_in = float(line[5].strip())

                # For kernel_params_in
                if line[6].strip() == "None":
                    kernel_params_in = None
                else:
                    kernel_params_in = line[6].strip()

                # For cv_in
                cv_in = int(line[7].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Regularization strength: ",line[1])
        print("Kernel mapping used internally: ",line[2])
        line_out3 = "Gamma parameter for the RBF, laplacian, polynomial, "
        line_out3 += "exponential chi2 and sigmoid kernels: "
        print(line_out3,line[3])
        print("Degree of the polynomial kernel: ", line[4])
        print("Zero coefficient for polynomial and sigmoid kernels: ",line[5])
        print("Additional parameters for kernel function: ",line[6])
        print("Kfold class to build a N-fold cross-validation loop. N: ",
        line[7])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of KernelRidge class
        ############################################################################
        model = KernelRidge(
            alpha=alpha_in,                     # alpha: float or array-like of shape (n_targets,), default=1.0
            kernel=kernel_in,                   # kernel: string or callable, default=”linear”
            gamma=gamma_in,                     # gamma: float, default=None
            degree=degree_in,                   # degree: float, default=3.0
            coef0=coef0_in,                     # coef0: float, default=1.0
            kernel_params=kernel_params_in      # kernel_params: mapping of string to any, default=None
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model