#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define SVRCV() class
class SVRCV(object):
    """Class to carry out support cector regression
    Epsilon-Support Vector Regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : {array-like, sparse matrix}, shape (n_samples, n_features)
                                Training vectors, where n_samples is the number of samples and n_features is the number of features.
                                For kernel=”precomputed”, the expected shape of X is (n_samples, n_samples).
        y                       : array-like, shape (n_samples,). Target values (class labels in classification, real numbers in regression)

    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : array, shape = [1]. Constants in decision function.
       model.coef_              : array, shape = [1, n_features]. Weights assigned to the features (coefficients in the primal problem).
                                This is only available in the case of a linear kernel.
                                coef_ is readonly property derived from dual_coef_ and support_vectors_.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_SVRCV() method
    def ml_scikit_SVRCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.SVRCV
        """

        # Import packages
        from sklearn.svm import SVR
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVR.html
        #
        # string_reg_method = SVRCV
        #
        #
        # kernel: string, optional (default=’rbf’)
        # Specifies the kernel type to be used in the algorithm. It must be one
        # of ‘linear’, ‘poly’, ‘rbf’, ‘sigmoid’,
        # ‘precomputed’ or a callable. If none is given, ‘rbf’ will be used.
        # If a callable is given it is used to precompute the kernel matrix.
        #
        # degree: int, optional (default=3)
        # Degree of the polynomial kernel function (‘poly’). Ignored by all
        # other kernels.
        #
        # gamma: {‘scale’, ‘auto’} or float, optional (default=’scale’)
        # Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’.
        # if gamma='scale' (default) is passed then it uses
        # 1 / (n_features * X.var()) as value of gamma,
        # if ‘auto’, uses 1 / n_features.
        #
        # coef0: float, optional (default=0.0)
        # Independent term in kernel function. It is only significant in ‘poly’
        # and ‘sigmoid’.
        #
        # tol: float, optional (default=1e-3)
        # Tolerance for stopping criterion.
        #
        # C: float, optional (default=1.0)
        # Regularization parameter. The strength of the regularization is
        # inversely proportional to C.
        # Must be strictly positive. The penalty is a squared l2 penalty.
        #
        # epsilon: float, optional (default=0.1)
        # Epsilon in the epsilon-SVRCV model. It specifies the epsilon-tube within
        # which no penalty is associated in the
        # training loss function with points predicted within a distance epsilon
        # from the actual value.
        #
        # shrinking: boolean, optional (default=True)
        # Whether to use the shrinking heuristic.
        #
        # cache_size: float, optional
        # Specify the size of the kernel cache (in MB).
        #
        # verbose: bool, default: False
        # Enable verbose output. Note that this setting takes advantage of a
        # per-process runtime setting in libsvm that,
        # if enabled, may not work properly in a multithreaded context.
        #
        # max_iter: int, optional (default=-1)
        # Hard limit on iterations within solver, or -1 for no limit.

        # Show message
        print("\nEpsilon-Support Vector Regression with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "SVRCV":

                # For kernel_in
                list_kernel = ["linear","poly","rbf","sigmoid","precomputed"]
                if line[1].strip() in list_kernel:
                    kernel_in = line[1].strip()
                else:
                    kernel_in = "rbf"
                    print("Unrecognizable input!")

                # For degree_in
                degree_in = int(line[2].strip())

                # For gamma_in
                list_gamma = ["scale","auto"]
                if line[3].strip() in list_gamma:
                    gamma_in = line[3].strip()
                else:
                    try:
                        gamma_in = float(line[3].strip())
                    # Handle exception
                    except:
                        gamma_in = "scale"
                        print("Unrecognizable input!")

                # For coef0_in
                coef0_in = float(line[4].strip())

                # For tol_in
                tol_in = float(line[5].strip())

                # For C_in
                C_in = float(line[6].strip())

                # For epsilon_in
                epsilon_in = float(line[7].strip())

                # For shrinking_in
                if line[8].strip() == "True":
                    shrinking_in = True
                else:
                    shrinking_in = False

                # For cache_size_in
                cache_size_in = float(line[9].strip())

                # For ver_in
                if line[10].strip() == "True":
                    ver_in = True
                else:
                    ver_in = False

                # For max_iter_in
                max_iter_in = int(line[11].strip())

                # For rand_in (for MDM file)
                rand_in = int(line[12].strip())

                # For cv_in
                cv_in = int(line[13].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Kernel type to be used in the algorithm: {}".format(kernel_in))
        print("Degree of the polynomial kernel function: {}".format(degree_in))
        print("Gamma: {}".format(gamma_in))
        print("Independent term in kernel function: {:.5e}".format(coef0_in))
        print("Tolerance for stopping criterion: {:.5e}".format(tol_in))
        print("Regularization parameter (C): {:.5e}".format(C_in))
        print("Epsilon in the epsilon-SVR model: {:.5e}".format(epsilon_in))
        print("Whether to use the shrinking heuristic: {}".format(shrinking_in))
        print("Cache size (MB): {:.5}".format(cache_size_in))
        print("Enable verbose output: ",line[10])
        print("Hard limit on iterations within solver: {}".format(max_iter_in))
        print("Kfold class to build a N-fold cross-validation loop. N : ",
        line[13])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of SVR class
        model = SVR(
                kernel=kernel_in,           # kernel: string, optional (default=’rbf’)
                degree=degree_in,           # degree: int, optional (default=3)
                gamma=gamma_in,             # gamma: {‘scale’, ‘auto’} or float, optional (default=’scale’)
                coef0=coef0_in,             # coef0: float, optional (default=0.0)
                tol=tol_in,                 # tol: float, optional (default=1e-3)
                C=C_in,                     # C: float, optional (default=1.0)
                epsilon=epsilon_in,         # epsilon: float, optional (default=0.1)
                shrinking=shrinking_in,     # shrinking: boolean, optional (default=True)
                cache_size=cache_size_in,   # cache_size: float, optional
                verbose=ver_in,             # verbose: bool, default: False
                max_iter=max_iter_in        # max_iter: int, optional (default=-1)
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Generate string with regression equation
        columns = len(self.X[0])
        self.reg_model = str("y = {:.5f}".format(float(model.intercept_)))
        for i in range(columns):
                aux_strg=str(" + {:.5}".format(model.coef_[0][i]))+"x"+str(i+1)
                self.reg_model += aux_strg

        # Get multiple model
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[0][i])

        # Set up array with coefficients
        self.b = np.array(alphas)

        # Return model and parameters
        return rand_in,self.b,self.reg_model,model,model.intercept_,model.coef_