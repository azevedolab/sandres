#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define LinearRegressionCV() class
class LinearRegressionCV(object):
    """Class to carry out linear regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : {array-like, sparse matrix} of shape (n_samples, n_features)
                                Training data
        y                       : array-like of shape (n_samples,) or (n_samples, n_targets)
                                Target values. Will be cast to X’s dtype if necessary
    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : float or array of shape of (n_targets,). Independent term in the linear model.
                                Set to 0.0 if fit_intercept = False.
       model.coef_              : array of shape (n_features, ) or (n_targets, n_features)
                                Estimated coefficients for the linear regression problem.
                                If multiple targets are passed during the fit (y 2D), this is a 2D array of shape (n_targets, n_features),
                                while if only one target is passed, this is a 1D array of length n_features.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_LinearRegressionCV() method
    def ml_scikit_LinearRegressionCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LinearRegression
        """

        # Import packages
        from sklearn.linear_model import LinearRegression
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html
        #
        # string_reg_method = LinearRegressionCV
        #
        #
        # fit_in = fit_intercept: bool, optional, default True
        # Whether to calculate the intercept for this model. If set to False, no
        # intercept will be used in calculations (i.e. data
        # is expected to be centered).
        #
        # norm_in = normalize: bool, optional, default False
        # This parameter is ignored when fit_intercept is set to False. If True,
        # the regressors X will be normalized
        # before regression by subtracting the mean and dividing by the l2-norm.
        # If you wish to standardize, please
        # use sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # copy_in = copy_X: bool, optional, default True
        # If True, X will be copied; else, it may be overwritten.
        #
        # job_in = n_jobs: int or None, optional (default=None)
        # The number of jobs to use for the computation. This will only provide
        # speedup for n_targets > 1 and sufficient large
        # problems. None means 1 unless in a joblib.parallel_backend context.
        # -1 means using all processors.
        #
        # positive: bool, default=False
        # When set to True, forces the coefficients to be positive.
        # This option is only supported for dense arrays.

        # Show message
        print("\nLinear Regression with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "LinearRegressionCV":

                # For fit_in
                if line[1].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For copy_in
                if line[2].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For job_in
                if line[3].strip() == "None":
                    job_in = None
                else:
                    job_in = int(line[3].strip())

                # For positive_in
                if line[4].strip() == "True":
                    positive_in = True
                else:
                    positive_in = False

                # For rand_in
                rand_in = int(line[5].strip())

                # For cv_in
                cv_in = int(line[6])

                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Fit intercept? "+line[1])
        print("Copy x array? "+line[2])
        print("Number of jobs to use for the computation : {}".format(job_in))
        print("When set to True, forces the coefficients to be positive: ",
        line[4])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[6])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of LinearRegression class
        model = LinearRegression(
                fit_intercept = fit_in, # fit_in = fit_intercept: bool, optional, default True
                copy_X = copy_in,       # copy_in = copy_X: bool, optional, default True
                n_jobs = job_in,        # job_in = n_jobs: int or None, optional (default=None)
                positive = positive_in  # positive: bool, default=False
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_