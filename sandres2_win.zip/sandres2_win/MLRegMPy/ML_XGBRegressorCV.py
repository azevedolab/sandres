#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define XGBRegressorCV() class
class XGBRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_XGBRegressorCV() method
    def ml_scikit_XGBRegressorCV(self):
        """
        Method to generate a multiple regression model using
        XGBRegressorCV
        """

        # Import packages
        from xgboost import XGBRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://xgboost.readthedocs.io/en/latest/parameter.html#general-parameters
        # and
        # https://xgboost.readthedocs.io/en/latest/python/python_api.html
        #
        # Additional material related to XGBoost in scikit-learn
        # https://xgboost.readthedocs.io/en/latest/tutorials/model.html
        # https://www.datacamp.com/community/tutorials/xgboost-in-python
        # https://towardsdatascience.com/getting-started-with-xgboost-in-scikit-learn-f69f5f470a97
        # https://www.educative.io/blog/scikit-learn-cheat-sheet-classification-regression-methods
        #
        # string_reg_method = XGBRegressorCV
        #
        #
        # General Parameters
        # booster: {"gbtree","gblinear","dart"}, default="gbtree"
        # Which booster to use. Can be gbtree, gblinear or dart;
        # gbtree and dart use tree based models while gblinear uses linear
        # functions.
        #
        # verbosity: int,  default=1
        # Verbosity of printing messages. Valid values are 0 (silent),
        # 1 (warning), 2 (info), 3 (debug). Sometimes XGBoost tries to change
        # configurations based on heuristics, which is displayed as warning
        # message. If there’s unexpected behaviour, please try to increase
        # value of verbosity.
        #
        # validate_parameters: bool, default=True
        # When set to True, XGBoost will perform validation of input parameters
        # to check whether a parameter is used or not. The feature is still
        # experimental. It’s expected to have some false positives.
        #
        # disable_default_eval_metric: bool, default=False
        # Flag to disable default metric. Set to 1 or True to disable.
        #
        # Parameters for Tree Booster
        #
        # eta: float, default=0.3, alias: learning_rate
        # Step size shrinkage used in update to prevents overfitting. After each
        # boosting step, we can directly get the weights of new features, and
        # eta shrinks the feature weights to make the boosting process more
        # conservative.
        # range: [0,1]
        #
        # gamma: float, default=0.0, alias: min_split_loss
        # Minimum loss reduction required to make a further partition on a
        # leaf node of the tree. The larger gamma is, the more conservative
        # the algorithm will be.
        # range: [0,∞]
        #
        # max_depth: int, default=6
        # Maximum depth of a tree. Increasing this value will make the model
        # more complex and more likely to overfit. 0 is only accepted in
        # lossguided growing policy when tree_method is set as hist or gpu_hist
        # and it indicates no limit on depth. Beware that XGBoost aggressively
        # consumes memory when training a deep tree.
        # range: [0,∞] (0 is only accepted in lossguided growing policy when
        # tree_method is set as hist or gpu_hist)
        #
        # min_child_weight: float, default=1.0
        # Minimum sum of instance weight (hessian) needed in a child. If the
        # tree partition step results in a leaf node with the sum of instance
        # weight less than min_child_weight, then the building process
        # will give up further partitioning. In linear regression task, this
        # simply corresponds to minimum number of instances needed to be in each
        # node. The larger min_child_weight is, the more conservative
        # the algorithm will be.
        # range: [0,∞]
        #
        # subsample: float, default=1.0
        # Subsample ratio of the training instances. Setting it to 0.5 means
        # that XGBoost would randomly sample half of the training data prior to
        # growing trees. and this will prevent overfitting. Subsampling
        # will occur once in every boosting iteration.
        # range: (0,1]
        #
        # sampling_method: {"uniform","gradient_based"}, default="uniform"
        # The method to use to sample the training instances.
        # "uniform": each training instance has an equal probability of being
        # selected. Typically set subsample >= 0.5 for good results.
        # "gradient_based": the selection probability for each training instance
        # is proportional to the regularized absolute value of gradients
        # (more specifically, ). subsample may be set to as low as 0.1 without
        # loss of model accuracy. Note that this sampling method is only supported
        # when tree_method is set to gpu_hist; other tree methods only support
        # uniform sampling.
        #
        # colsample_bytree, colsample_bylevel, colsample_bynode: float,
        # default=1.0
        # This is a family of parameters for subsampling of columns.
        # All colsample_by* parameters have a range of (0, 1], the default value
        # of 1, and specify the fraction of columns to be subsampled.
        # colsample_bytree is the subsample ratio of columns when constructing
        # each tree. Subsampling occurs once for every tree constructed.
        # colsample_bylevel is the subsample ratio of columns for each level.
        # Subsampling occurs once for every new depth level reached in a tree.
        # Columns are subsampled from the set of columns chosen for the current
        # tree.
        # colsample_bynode is the subsample ratio of columns for each node
        # (split). Subsampling occurs once every time a new split is evaluated.
        # Columns are subsampled from the set of columns chosen for the current
        # level.
        #
        # reg_lambda_in: float, default=1.0, alias: lambda
        # L2 regularization term on weights. Increasing this value will make
        # model more conservative.
        #
        # alpha: float, default=0.0, alias: reg_alpha
        # L1 regularization term on weights. Increasing this value will make
        # model more conservative.
        #
        # tree_method: {"auto","exact","approx","hist","gpu_hist"},
        # default= "auto"
        # The tree construction algorithm used in XGBoost. See description in
        # the reference paper and XGBoost Tree Methods.
        # XGBoost supports approx, hist and gpu_hist for distributed training.
        # Experimental support for external memory is available for approx and
        # gpu_hist.
        # Choices: auto, exact, approx, hist, gpu_hist, this is a combination of
        # commonly used updaters. For other updaters like refresh, set the
        # parameter updater directly.
        # "auto": Use heuristic to choose the fastest method.
        # For small dataset, exact greedy (exact) will be used.
        # For larger dataset, approximate algorithm (approx) will be chosen.
        # It’s recommended to try hist and gpu_hist for higher performance with
        # large dataset. (gpu_hist)has support for external memory.
        # Because old behavior is always use exact greedy in single machine,
        # user will get a message when approximate algorithm is chosen to notify
        # this choice.
        # "exact": Exact greedy algorithm. Enumerates all split candidates.
        # "approx": Approximate greedy algorithm using quantile sketch and
        # gradient histogram.
        # "hist": Faster histogram optimized approximate greedy algorithm.
        # "gpu_hist": GPU implementation of hist algorithm.
        #
        # scale_pos_weight: float, default=1.0
        # Control the balance of positive and negative weights, useful for
        # unbalanced classes. A typical value to consider:
        # sum(negative instances) / sum(positive instances). See Parameters
        # Tuning for more discussion. Also, see Higgs Kaggle competition demo
        # for examples: R, py1, py2, py3.
        #
        # refresh_leaf: int, default=1
        # This is a parameter of the refresh updater. When this flag is 1,
        # tree leafs as well as tree nodes’ stats are updated. When it is 0,
        # only node stats are updated.
        #
        # process_type: {"default","update"}, default="default"
        # A type of boosting process to run.
        # Choices: default, update
        # "default": The normal boosting process which creates new trees.
        # "update": Starts from an existing model and only updates its trees. In
        # each boosting iteration, a tree from the initial model is taken, a
        # specified sequence of updaters is run for that tree, and a modified
        # tree is added to the new model. The new model would have either the
        # same or smaller number of trees, depending on the number of boosting
        # iterations performed. Currently, the following built-in updaters
        # could be meaningfully used with this process type: refresh, prune.
        # With process_type=update, one cannot use updaters that create
        # new trees.
        #
        # predictor: {"auto","cpu_predictor","gpu_predictor"}, default="auto"
        # The type of predictor algorithm to use. Provides the same results but
        # allows the use of GPU or CPU.
        # "auto": Configure predictor based on heuristics.
        # "cpu_predictor": Multicore CPU prediction algorithm.
        # "gpu_predictor": Prediction using GPU. Used when tree_method is
        # gpu_hist. When predictor is set to default value auto, the gpu_hist
        # tree method is able to provide GPU based prediction without copying
        # training data to GPU memory. If gpu_predictor is explicitly specified,
        # then all data is copied into GPU, only recommended for performing
        # prediction tasks.
        #
        # Learning Task Parameters
        # objective: {"reg:squarederror",
        # "reg:squaredlogerror",
        # "reg:logistic",
        # "reg:pseudohubererror",
        # "binary:logistic",
        # "binary:logitraw",
        # "binary:hinge",
        # "count:poisson",
        # "survival:cox",
        # "survival:aft",
        # "aft_loss_distribution",
        # "multi:softmax",
        # "multi:softprob",
        # "rank:pairwise",
        # "rank:ndcg",
        # "rank:map",
        # "reg:gamma",
        # "reg:tweedie"},  default="reg:squarederror"
        # Specify the learning task and the corresponding learning objective
        # "reg:squarederror": regression with squared loss.
        # "reg:squaredlogerror": regression with squared log loss. All input
        # labels are required to be greater than -1.
        # Also, see metric rmsle for possible issue with this objective.
        # "reg:logistic": logistic regression
        # "reg:pseudohubererror": regression with Pseudo Huber loss, a twice
        # differentiable alternative to absolute loss.
        # "binary:logistic": logistic regression for binary classification,
        # output probability.
        # "binary:logitraw": logistic regression for binary classification,
        # output score before logistic transformation.
        # "binary:hinge": hinge loss for binary classification. This makes
        # predictions of 0 or 1, rather than producing probabilities.
        # "count:poisson": poisson regression for count data, output mean of Poisson distribution
        # max_delta_step is set to 0.7 by default in Poisson regression
        # (used to safeguard optimization).
        # "survival:cox": Cox regression for right censored survival time data
        # (negative values are considered right censored). Note that predictions
        # are returned on the hazard ratio scale (i.e.,
        # as HR = exp(marginal_prediction) in the proportional hazard
        # function h(t) = h0(t) * HR).
        # "survival:aft": Accelerated failure time model for censored survival
        # time data. See Survival Analysis with Accelerated Failure Time for
        # details.
        # "aft_loss_distribution": Probability Density Function used by
        # survival:aft objective and aft-nloglik metric.
        # "multi:softmax": set XGBoost to do multiclass classification using the
        # softmax objective, you also need to set num_class(number of classes)
        # "multi:softprob": same as softmax, but output a vector of
        # ndata * nclass, which can be further reshaped to ndata * nclass
        # matrix. The result contains predicted probability of each data point
        # belonging to each class.
        # "rank:pairwise": Use LambdaMART to perform pairwise ranking where the
        # pairwise loss is minimized.
        # "rank:ndcg": Use LambdaMART to perform list-wise ranking where
        # Normalized Discounted Cumulative Gain (NDCG) is maximized.
        # "rank:map": Use LambdaMART to perform list-wise ranking where Mean
        # Average Precision (MAP) is maximized.
        # "reg:gamma": gamma regression with log-link. Output is a mean of gamma
        # distribution. It might be useful, e.g., for modeling insurance claims
        # severity, or for any outcome that might be gamma-distributed.
        # "reg:tweedie": Tweedie regression with log-link. It might be useful,
        # e.g., for modeling total loss in insurance, or for any outcome that
        # might be Tweedie-distributed.
        #
        # n_estimators: int, default = 100
        # Number of gradient boosted trees. Equivalent to number of boosting rounds.

        # Show message
        print("\nExtreme Gradient Boosting (XGBoost) Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "XGBRegressorCV":

                # For booster_in
                list_booster = ["gbtree","gblinear","dart"]
                if line[1] in list_booster:
                    booster_in = line[1]
                else:
                    print("\nIOError! Undefined string ",line[1])
                    return

                # For verbosity_in
                verbosity_in = int(line[2])

                # For validate_parameters_in
                if line[3] == "True":
                    validate_parameters_in = True
                else:
                    validate_parameters_in = False

                # For disable_default_eval_metric_in
                if line[4] == "True":
                    disable_default_eval_metric_in = True
                else:
                    disable_default_eval_metric_in = False

                # For eta_in
                eta_in = float(line[5])

                # For gamma_in
                gamma_in = float(line[6])

                # For max_depth_in
                max_depth_in = int(line[7])

                # For min_child_weight_in
                min_child_weight_in = float(line[8])

                # For subsample_in
                subsample_in = float(line[9])

                # sampling_method_in
                list_sampling_method = ["uniform","gradient_based"]
                if line[10] in list_sampling_method:
                    sampling_method_in = line[10]
                else:
                    print("\nIOError! Undefined string ",line[10])
                    return

                # For colsample_bytree_in, colsample_bylevel_in,
                # colsample_bynode_in
                colsample_bytree_in = float(line[11])
                colsample_bylevel_in = float(line[12])
                colsample_bynode_in = float(line[13])

                # For reg_lambda_in
                reg_lambda_in = float(line[14])

                # For alpha_in
                alpha_in = float(line[15])

                # For tree_method_in
                list_tree_method = ["auto","exact","approx","hist","gpu_hist"]
                if line[16] in list_tree_method:
                    tree_method_in = line[16]
                else:
                    print("\nIOError! Undefined string ",line[16])
                    return

                # For scale_pos_weight_in
                scale_pos_weight_in = float(line[17])

                # For refresh_leaf_in
                refresh_leaf_in = int(line[18])

                # For process_type_in
                list_process_type = ["default","update"]
                if line[19] in list_process_type:
                    process_type_in = line[19]
                else:
                    print("\nIOError! Undefined string ",line[19])
                    return

                # For predictor_in
                list_predictor = ["auto","cpu_predictor","gpu_predictor"]
                if line[20] in list_predictor:
                    predictor_in = line[20]
                else:
                    print("\nIOError! Undefined string ",line[20])
                    return

                # For objective_in
                list_objective = ["reg:squarederror","reg:squaredlogerror",
                "reg:logistic","reg:pseudohubererror","binary:logistic",
                "binary:logitraw","binary:hinge","count:poisson","survival:cox",
                "survival:aft","aft_loss_distribution","multi:softmax",
                "multi:softprob","rank:pairwise","rank:ndcg","rank:map",
                "reg:gamma","reg:tweedie"]
                if line[21] in list_objective:
                    objective_in = line[21]
                else:
                    print("\nIOError! Undefined string ",line[21])
                    return

                # For n_estimators_in
                n_estimators_in = int(line[22])

                # For cv_in (set value to 5)
                cv_in = int(line[23])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Type of booster: ",line[1])
        print("Verbosity of printing messages: ",line[2])
        print("Validation parameter: ",line[3])
        print("Flag to disable default metric: ",line[4])
        print("Step size shrinkage used in update to prevents overfitting: ",
        line[5])
        line_out_6 = "Minimum loss reduction required to make a further "
        line_out_6 += "partition on a leaf node of the tree: "
        print(line_out_6,line[6])
        print("Maximum depth of a tree: ",line[7])
        print("Minimum sum of instance weight (hessian) needed in a child: ",
        line[8])
        print("Subsample ratio of the training instance: ",line[9])
        print("Method to use to sample the training instances: ",line[10])
        print("L2 regularization term on weights (lambda): ",line[14])
        print("L1 regularization term on weights (alpha): ",line[15])
        print("The tree construction algorithm used in XGBoost: ",line[16])
        print("Balance of positive and negative weights: ",line[17])
        print("Refresh updater: ",line[18])
        print("Type of boosting process to run: ",line[19])
        print("The type of predictor algorithm to use: ",line[20])
        print("Learning objective: ",line[21])
        print("Number of gradient boosted trees: ",line[22])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of XGBRegressor class
        ############################################################################
        model = XGBRegressor(
            booster=booster_in,                 # booster: {"gbtree","gblinear","dart"}, default="gbtree"
            verbosity=verbosity_in,             # verbosity: int,  default=1
            validate_parameters=validate_parameters_in,     # validate_parameters: bool, default=True
            disable_default_eval_metric=disable_default_eval_metric_in,     # disable_default_eval_metric: bool
            eta=eta_in,                         # eta: float, default=0.3, alias: learning_rate
            gamma=gamma_in,                     # gamma: float, default=0.0, alias: min_split_loss
            max_depth=max_depth_in,             # max_depth: int, default=6
            min_child_weight=min_child_weight_in,   # min_child_weight: float, default=1.0
            subsample=subsample_in,             # subsample: float, default=1.0
            sampling_method=sampling_method_in, # sampling_method: {"uniform","gradient_based"}, default="uniform"
            colsample_bytree=colsample_bytree_in,   # colsample_bytree: float, default=1.0
            colsample_bylevel=colsample_bylevel_in, # colsample_bylevel: float, default=1.0
            colsample_bynode=colsample_bynode_in,   # colsample_bynode: float, default=1.0
            reg_lambda=reg_lambda_in,           # reg_lambda_in: float, default=1.0, alias: lambda
            alpha=alpha_in,                     # alpha: float, default=0.0, alias: reg_alpha
            tree_method=tree_method_in,         # tree_method: {"auto","exact","approx","hist","gpu_hist"}
            scale_pos_weight=scale_pos_weight_in,   # scale_pos_weight: float, default=1.0
            refresh_leaf=refresh_leaf_in,       # refresh_leaf: int,  default=1
            process_type=process_type_in,       # process_type: {"default","update"}, default="default"
            predictor=predictor_in,             # predictor: {"auto","cpu_predictor","gpu_predictor"}
            objective=objective_in,             # objective: {"reg:squarederror",..},  default="reg:squarederror"
            n_estimators=n_estimators_in        # n_estimators: int, default = 100
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model