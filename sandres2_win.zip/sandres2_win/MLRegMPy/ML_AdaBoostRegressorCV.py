#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
# Define AdaBoostRegressorCV() class
class AdaBoostRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_AdaBoostRegressorCV() method
    def ml_scikit_AdaBoostRegressorCV(self):
        """
        Method to generate a multiple regression model using
        AdaBoostRegressor
        """

        # Import packages
        from sklearn.ensemble import AdaBoostRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.AdaBoostRegressor.html
        #
        # string_reg_method = AdaBoostRegressor
        #
        #
        # base_estimator: object, default=None
        # The base estimator from which the boosted ensemble is built. If None,
        # then the base estimator is DecisionTreeRegressor initialized
        # with max_depth=3.
        #
        # n_estimators: int, default=50
        # The maximum number of estimators at which boosting is terminated.
        # In case of perfect fit, the learning procedure is stopped early.
        #
        # learning_rate: float, default=1.
        # Weight applied to each classifier at each boosting iteration.
        # A higher learning rate increases the contribution of each classifier.
        # There is a trade-off between the learning_rate and n_estimators
        # parameters.
        #
        # loss: {"linear","square","exponential"}, default="linear"
        # The loss function to use when updating the weights after each boosting
        # iteration.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls the random seed given at each base_estimator at each boosting
        # iteration. Thus, it is only used when base_estimator exposes a
        # random_state. In addition, it controls the bootstrap of the weights
        # used to train the base_estimator at each boosting iteration.
        # Pass an int for reproducible output across multiple function calls.

        # Show message
        print("\nAdaBoost Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "AdaBoostRegressorCV":

                # For base_estimator_in
                if line[1].strip() == "None":
                    base_estimator_in = None
                else:
                    base_estimator_in = None

                # For n_estimators_in
                n_estimators_in = int(line[2].strip())

                # For learning_rate_in
                learning_rate_in = float(line[3].strip())

                # For loss_in
                list_loss = ["linear","square","exponential"]
                if line[4].strip() in list_loss:
                    loss_in = line[4].strip()
                else:
                    print("\nIOError! Undefined string ",line[4].strip())
                    return

                # For random_state_in
                if line[5].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[5].strip())

                # For cv_in (set value to 5) (for cross-validation)
                cv_in = int(line[6].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("The base estimator from which the boosted ensemble is built: ",
        line[1])
        print("The maximum number of estimators: ",line[2])
        print("Weight applied to each classifier at each boosting iteration:",
        line[3])
        print("The loss function to use when updating the weights: ",line[4])
        print("Controls the random seed given at each base_estimator: ",line[5])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of AdaBoostRegressor class
        ############################################################################
        model = AdaBoostRegressor(
            base_estimator=base_estimator_in,   # base_estimator: object, default=None
            n_estimators=n_estimators_in,       # n_estimators: int, default=50
            learning_rate=learning_rate_in,     # learning_rate: float, default=1.
            loss=loss_in,                       # loss: {"linear","square","exponential"}, default=’linear’
            random_state=random_state_in        # random_state: int, RandomState instance or None, default=None
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model
        return model