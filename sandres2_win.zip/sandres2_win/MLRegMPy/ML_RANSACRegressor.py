#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define RANSACRegressor() class
class RANSACRegressor(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_RANSACRegressor() method
    def ml_scikit_RANSACRegressor(self):
        """
        Method to generate a multiple regression model using
        RANSACRegressor
        """

        # Import packages
        from sklearn.linear_model import RANSACRegressor
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.RANSACRegressor.html
        #
        # string_reg_method = RANSACRegressor
        #
        #
        # base_estimator: object, default=None
        # Base estimator object which implements the following methods:
        # fit(X, y): Fit model to given training data and target values.
        # score(X, y): Returns the mean accuracy on the given test data,
        #  which is used for the stop criterion defined by stop_score.
        #  Additionally, the score is used to decide which of two equally large
        #  consensus sets is chosen as the better one.
        # predict(X): Returns predicted values using the linear model,
        #  which is used to compute residual error using loss function.
        # If base_estimator is None, then LinearRegression is used for target
        # values of dtype float.
        # Note that the current implementation only supports regression
        # estimators.
        #
        # min_samples: int (>= 1) or float ([0, 1]), default=None
        # Minimum number of samples chosen randomly from original data.
        # Treated as an absolute number of samples for min_samples >= 1,
        # treated as a relative number ceil(min_samples * X.shape[0])
        # for min_samples < 1. This is typically chosen as the minimal
        # number of samples necessary to estimate the given base_estimator.
        # By default a sklearn.linear_model.LinearRegression() estimator is
        # assumed and min_samples is chosen as X.shape[1] + 1.
        #
        # residual_threshold: float, default=None
        # Maximum residual for a data sample to be classified as an inlier.
        # By default the threshold is chosen as the
        # MAD (median absolute deviation) of the target values y.
        #
        # is_data_valid: callable, default=None
        # This function is called with the randomly selected data before the
        # model is fitted to it: is_data_valid(X, y).
        # If its return value is False the current randomly chosen
        # sub-sample is skipped.
        #
        # is_model_valid: callable, default=None
        # This function is called with the estimated model and the randomly
        # selected data: is_model_valid(model, X, y). If its return value is
        # False the current randomly chosen sub-sample is skipped. Rejecting
        # samples with this function is computationally costlier than
        # with is_data_valid. is_model_valid should therefore only be used if
        # the estimated model is needed for making the rejection decision.
        #
        # max_trials: int, default=100
        # Maximum number of iterations for random sample selection.
        #
        # max_skips: int, default=np.inf
        # Maximum number of iterations that can be skipped due to finding zero
        # inliers or invalid data defined by is_data_valid or invalid models
        # defined by is_model_valid.
        # New in version 0.19.
        #
        # stop_n_inliers: int, default=np.inf
        # Stop iteration if at least this number of inliers are found.
        #
        # stop_score: float, default=np.inf
        # Stop iteration if score is greater equal than this threshold.
        #
        # stop_probability: float in range [0, 1], default=0.99
        # RANSAC iteration stops if at least one outlier-free set of the
        # training data is sampled in RANSAC. This requires to generate at
        # least N samples (iterations):
        # N >= log(1 - probability) / log(1 - e**m)
        # where the probability (confidence) is typically set to high value
        # such as 0.99 (the default) and e is the current fraction of
        # inliers w.r.t. the total number of samples.
        #
        # loss: string, callable, default=’absolute_loss’
        # String inputs, “absolute_loss” and “squared_loss” are supported which
        # find the absolute loss and squared loss per sample respectively.
        # If loss is a callable, then it should be a function that takes two
        # arrays as inputs, the true and predicted value and returns a
        # 1-D array with the i-th value of the array corresponding to the
        # loss on X[i].
        # If the loss on a sample is greater than the residual_threshold,
        # then this sample is classified as an outlier.
        # New in version 0.18.
        #
        # random_state: int, RandomState instance, default=None
        # The generator used to initialize the centers. Pass an int for
        # reproducible output across multiple function calls. See Glossary.

        # Show message
        print("\nRANSAC (RANdom SAmple Consensus) Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "RANSACRegressor":

                # For base_estimator_in
                if line[1].strip() == "None":
                    base_estimator_in = None
                else:
                    base_estimator_in = line[1].strip()

                # For min_samples_in
                if line[2].strip() == "None":
                    min_samples_in = None
                elif "." in str(line[2].strip()):
                    min_samples_in = float(line[2].strip())
                else:
                    min_samples_in = int(line[2].strip())

                # For residual_threshold_in
                if line[3].strip() == "None":
                    residual_threshold_in = None
                else:
                    residual_threshold_in = float(line[3].strip())

                # For is_data_valid_in
                if line[4].strip() == "None":
                    is_data_valid_in = None
                else:
                    is_data_valid_in = line[4].strip()

                # For is_model_valid_in
                if line[5].strip() == "None":
                    is_model_valid_in = None
                else:
                    is_model_valid_in = line[5].strip()

                # For max_trials_in
                max_trials_in = int(line[6].strip())

                # For max_skips_in
                if "np.inf" in line[7].strip():
                    max_skips_in = np.inf
                else:
                    max_skips_in = int(line[7].strip())

                # For stop_n_inliers_in
                if "np.inf" in line[8].strip():
                    stop_n_inliers_in = np.inf
                else:
                    stop_n_inliers_in = int(line[8].strip())

                # For stop_score_in
                if "np.inf" in line[9].strip():
                    stop_score_in = np.inf
                else:
                    stop_score_in = float(line[9].strip())

                # For stop_probability_in
                stop_probability_in = float(line[10].strip())

                # For loss_in
                list_loss = ["squared_error","absolute_error"]
                if line[11].strip() in list_loss:
                    loss_in = line[11].strip()
                else:
                    loss_in = "absolute_error"
                    print("Unrecognizable input!")

                # For random_state_in
                if line[12].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[12].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Base estimator object: ",line[1])
        print("Minimum number of samples chosen from original data: ",line[2])
        print("Maximum residual for a data sample to be classified as an inlie:",
        line[3])
        print("This function is called with the selected data: ",line[4])
        print("This function is called with the estimated model: ",line[5])
        print("Maximum number of iterations for random sample selection: ",
        line[6])
        print("Maximum number of iterations that can be skipped : ",line[7])
        print("Stop iteration if at least this number of inliers are found: ",
        line[8])
        print("Stop iteration if score is greater equal than this threshold",
        line[9])
        print("Stop probability: ",line[10])
        print("String input: ",line[11])
        print("The generator used to initialize the centers: ",line[12])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of RANSACRegressor class
        ############################################################################
        model = RANSACRegressor(
            base_estimator=base_estimator_in,   # base_estimatorobject, default=None
            min_samples = min_samples_in,       # min_samples: int (>= 1) or float ([0, 1]), default=None
            residual_threshold=residual_threshold_in,   # residual_threshold: float, default=None
            is_data_valid=is_data_valid_in,     # is_data_valid: callable, default=None
            is_model_valid=is_model_valid_in,   # is_model_valid: callable, default=None
            max_trials=max_trials_in,           # max_trials: int, default=100
            max_skips=max_skips_in,             # max_skipsint, default=np.inf
            stop_n_inliers=stop_n_inliers_in,   # stop_n_inliers: int, default=np.inf
            stop_score=stop_score_in,           # stop_score: float, default=np.inf
            stop_probability=stop_probability_in,   # stop_probability: float in range [0, 1], default=0.99
            loss=loss_in,                       # loss: string, callable, default=’absolute_loss’
            random_state=random_state_in        # random_state: int, RandomState instance or None, default=None
            )
        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return model