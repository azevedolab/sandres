#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define LassoLarsCV() class
class LassoLarsCV(object):
    """Class to carry out LassoLarsCV regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : array-like of shape (n_samples, n_features). Training data.
        y                       : array-like of shape (n_samples,) or (n_samples, n_targets)
                                Target values.

    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : float or array-like of shape (n_targets,) Independent term in decision function.
       model.coef_              : array-like of shape (n_features,) or (n_targets, n_features)
                                Parameter vector (w in the formulation formula).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_LassoLarsCV() method
    def ml_scikit_LassoLarsCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLarsCV
        """

        # Import packages
        from sklearn.linear_model import LassoLars  # Not LassoLarsCV from scikit-learn
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LassoLars.html
        #
        # string_reg_method = LassoLarsCV
        #
        # alpha: float, default=1.0
        # Constant that multiplies the penalty term. Defaults to 1.0. alpha = 0
        # is equivalent to an ordinary least square, solved by LinearRegression.
        # For numerical reasons, using alpha = 0 with the LassoLars object is
        # not advised and you should prefer the LinearRegression object.
        #
        # fit_intercept: bool, default=True
        # whether to calculate the intercept for this model. If set to false, no
        # intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # verbose: bool or int, default=False
        # Sets the verbosity amount
        #
        # precompute: bool, ‘auto’ or array-like, default=’auto’
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # If set to 'auto' let us decide. The Gram matrix can also be passed as
        # argument.
        #
        # max_iter:int, default=500
        # Maximum number of iterations to perform.
        #
        # eps: float, optional
        # The machine-precision regularization in the computation of the
        # Cholesky diagonal factors. Increase this for very ill-conditioned
        # systems.
        # Unlike the tol parameter in some iterative optimization-based
        # algorithms, this parameter does not control the tolerance of the
        # optimization.
        # By default, np.finfo(np.float).eps is used.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # fit_path: bool, default=True
        # If True the full path is stored in the coef_path_ attribute. If you
        # compute the solution for a large problem or many targets, setting
        # fit_path to False will lead to a speedup, especially with a small
        # alpha.
        #
        # positive: bool, default=False
        # Restrict coefficients to be >= 0. Be aware that you might want to
        # remove fit_intercept which is set True by default.
        # Under the positive restriction the model coefficients will not
        # converge to the ordinary-least-squares solution for small values of
        # alpha.
        # Only coefficients up to the smallest alpha value
        # (alphas_[alphas_ > 0.].min()
        # when fit_path=True) reached by the stepwise Lars-Lasso algorithm are
        # typically in congruence with the solution of the coordinate descent
        # Lasso estimator.
        #
        # jitter: float, default=None
        # Upper bound on a uniform noise parameter to be added to the y values,
        # to satisfy the model’s assumption of one-at-a-time computations.
        # Might help with stability.
        #
        # random_state: int, RandomState instance or None, default=None
        # Determines random number generation for jittering. Pass an int for
        # reproducible output across multiple function calls. See Glossary.
        # Ignored if jitter is None.

        # Show message
        print("\nRegression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "LassoLarsCV":

                # For alpha_in
                alpha_in = float(line[1].strip())

                # For fit_in
                if line[2].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For ver_in
                if line[3].strip() == "True":
                    ver_in = True
                elif line[3].strip() == "False":
                    ver_in = False
                else:
                    ver_in = int(line[3].strip())

                # For pre_in
                if line[4].strip() == "True":
                    pre_in = True
                elif line[4].strip() == "False":
                    pre_in = False
                else:
                    pre_in = line[4].strip()

                # For max_in
                max_in = int(line[5].strip())

                # For eps_in
                eps_in = float(line[6].strip())

                # For copy_in
                if line[7].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For fit_path_in
                if line[8].strip() == "True":
                    fit_path_in = True
                else:
                    fit_path_in = False

                # For pos_in
                if line[9].strip() == "True":
                    pos_in = True
                else:
                    pos_in = False

                # For jitter_in
                if line[10].strip() == "None":
                    jitter_in = None
                else:
                    jitter_in = float(line[10].strip())

                # For rand_in
                if line[11].strip() == "None":
                    rand_in = None
                else:
                    rand_in = int(line[11].strip())

                # For cv_in
                cv_in = int(line[12].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Alpha: ",line[1])
        print("Fit intercept? "+line[2])
        print("Sets the verbosity amount: ",line[3])
        print("Pre compute? "+line[4])
        print("Maximum number of iterations: {}".format(max_in))
        print("The machine-precision regularization (eps): {}".format(eps_in))
        print("Copy x array? "+line[7])
        print("If True the full path is stored in the coef_path_ attribute: ",
        line[8])
        print("Force the coefficients to be positive? "+line[9])
        m10 = "Upper bound on a uniform noise parameter to be added to the "
        m10 += "y values: "+str(line[10])
        print(m10)
        print("Determines random number generation for jittering: ",line[11])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[12])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of LassoLars class
        model = LassoLars(
                alpha = alpha_in,           # alpha: float, default=1.0
                fit_intercept = fit_in,     # fit_intercept: bool, default=True
                verbose=ver_in,             # verbose: bool or int, default=False
                precompute = pre_in,        # precompute: bool, ‘auto’ or array-like, default=’auto’
                max_iter = max_in,          # max_iter:int, default=500
                eps = eps_in,               # eps: float, optional
                copy_X = copy_in,           # copy_X: bool, default=True
                fit_path = fit_path_in,     # fit_path: bool, default=True
                positive = pos_in,          # positive: bool, default=False
                jitter = jitter_in,         # jitter: float, default=None
                random_state = rand_in      # random_state: int, RandomState instance or None, default=None
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Check whether rand_in == None for MDM
        if str(rand_in) == "None":
            rand_in = 1123581321

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_