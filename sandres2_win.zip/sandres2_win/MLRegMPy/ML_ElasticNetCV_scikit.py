#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define ElasticNetCV() class
class ElasticNetCV(object):
    """Class to carry out ElasticNet regression with cross-validation

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : ndarray of shape (n_samples, n_features). Training data.
                                If using GCV, will be cast to float64 if necessary.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_targets)
                                Target values. Will be cast to X’s dtype if necessary.

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or ndarray of shape (n_targets,). Independent term in decision function.
                                Set to 0.0 if fit_intercept = False.
       model.coef_              : ndarray of shape (n_features) or (n_targets, n_features). Weight vector(s).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_ElasticNet() method
    def ml_scikit_ElasticNetCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ElasticNetCV
        """

        # Import packages
        from sklearn.linear_model import ElasticNetCV # Not ElasticNetCV from scikit-learn
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.ElasticNetCV.html
        #
        # string_reg_method = ElasticNet
        #
        # l1_ratio: float or list of float, default=0.5
        # Float between 0 and 1 passed to ElasticNet (scaling between l1 and l2
        # penalties). For l1_ratio = 0 the penalty is an L2 penalty.
        # For l1_ratio = 1 it is an L1 penalty. For 0 < l1_ratio < 1, the
        # penalty is a combination of L1 and L2 This parameter can be a list,
        # in which case the different values are tested by cross-validation and
        # the one giving the best prediction score is used. Note that a good
        # choice of list of values for l1_ratio is often to put more values
        # close to 1 (i.e. Lasso) and less close to 0 (i.e. Ridge), as
        # in [.1, .5, .7, .9, .95, .99, 1].
        #
        # eps: float, default=1e-3 Length of the path. eps=1e-3 means that
        # alpha_min / alpha_max = 1e-3.
        #
        # n_alphas: int, default=100. Number of alphas along the regularization
        #  path, used for each l1_ratio.
        #
        # alphas: ndarray, default=None. List of alphas where to compute the
        # models. If None alphas are set automatically.
        #
        # fit_intercept: bool, default=True
        # Whether to calculate the intercept for this model. If set to false,
        # no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # precompute: ‘auto’, bool or array-like of
        # shape (n_features, n_features), default=’auto’
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # If set to 'auto' let us decide. The Gram matrix can also be passed as
        # argument.
        #
        # max_iter: int, default=1000
        # The maximum number of iterations.
        #
        # tol: float, default=1e-4
        # The tolerance for the optimization: if the updates are smaller than
        # tol, the optimization code checks the dual gap for optimality and
        # continues until it is smaller than tol.
        #
        # cv: int, cross-validation generator or iterable, default=None
        # Determines the cross-validation splitting strategy. Possible inputs for cv are:
        # None, to use the default 5-fold cross-validation,
        # int, to specify the number of folds.
        # CV splitter,
        # An iterable yielding (train, test) splits as arrays of indices.
        # For int/None inputs, KFold is used.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # verbose: bool or int, default=0
        # Amount of verbosity.
        #
        # n_jobs: int, default=None
        # Number of CPUs to use during the cross validation.
        # None means 1 unless in a joblib.parallel_backend context. -1 means
        # using all processors.
        #
        # positive: bool, default=False
        # When set to True, forces the coefficients to be positive.
        #
        # random_state: int, RandomState instance, default=None
        # The seed of the pseudo random number generator that selects a random
        # feature to update. Used when selection == ‘random’.
        # Pass an int for reproducible output across multiple function calls.
        #
        # selection: {‘cyclic’, ‘random’}, default=’cyclic’
        # If set to ‘random’, a random coefficient is updated every iteration
        # rather than looping over features sequentially by default. This
        # (setting to ‘random’) often leads to significantly faster convergence
        # especially when tol is higher than 1e-4.
        #
        # Show message
        print("\nElasticNet Regression with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "ElasticNetCV":

                # For l1_ratio_in
                l1_ratio_in = float(line[1])

                # For eps_in
                eps_in = float(line[2])

                # For n_alphas_in
                n_alphas_in = int(line[3])

                # For alphas
                if line[4] == "None":
                    alphas_in = None
                else:
                    alphas_in = line[4]

                # For fit_in
                if line[5] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For precompute_in
                precompute_in = line[6]

                # For max_iter_in
                max_iter_in = int(line[7])

                # For tol_in
                tol_in = float(line[8])

                # For cv_in
                if line[9] == "None":
                    cv_in = None
                else:
                    cv_in = int(line[9])

                # For copy_X_in
                if line[10] == "True":
                    copy_X_in = True
                else:
                    copy_X_in = False

                # For verbose_in
                if line[11] == "True":
                    verbose_in = True
                elif line[11] == "False":
                    verbose_in = False
                else:
                    verbose_in = int(line[11])

                # For n_jobs_in
                n_jobs_in = int(line[12])

                # For positive_in
                if line[13] == "True":
                    positive_in = True
                else:
                    positive_in = False

                # For random_state_in
                if line[14] == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[14])

                # For selection_in
                list_selection = ["cyclic","random"]
                if line[15] in list_selection:
                    selection_in = line[15]
                else:
                    print("\nIOError! Undefined string ",line[15])
                    return

                # For self.rand_in (for MDM file)
                self.rand_in = int(line[16])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("l1_ratio: ",l1_ratio_in)
        print("eps: ",eps_in)
        print("n_alphas: ",n_alphas_in)
        print("alphas: ",alphas_in)
        print("Fit intercept? ",line[5])
        print("Precompute: ",line[6])
        print("Maximum number of iterations: ",max_iter_in)
        print("Tolerance for the optimization: ",tol_in)
        print("Cross-validation splitting strategy: ",line[9])
        print("If True, X will be copied; else, it may be overwritten: ",
        line[10])
        print("Amount of verbosity: ",line[11])
        print("Number of CPUs to use during the cross validation: ",n_jobs_in)
        print("Forces the coefficients to be positive: ",line[13])
        print("Seed of the pseudo random number generator: ",line[14])
        print("Selection: ",selection_in)

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of ElasticNetCV() class
        model = ElasticNetCV(
                l1_ratio = l1_ratio_in,         # l1_ratio: float or list of float, default=0.5
                eps = eps_in,                   # eps: float, default=1e-3
                n_alphas = n_alphas_in,         # n_alphas: int, default=100
                alphas = alphas_in,             # alphas: ndarray, default=None
                fit_intercept = fit_in,         # fit_intercept: bool, default=True
                precompute = precompute_in,     # precompute: ‘auto’, bool or array-like of shape (n_features, n_features), default=’auto’
                max_iter = max_iter_in,         # max_iter: int, default=1000
                tol = tol_in,                   # tol: float, default=1e-4
                cv = cv_in,                     # cv: int, cross-validation generator or iterable, default=None
                copy_X = copy_X_in,             # copy_X: bool, default=True
                verbose = verbose_in,           # verbose: bool or int, default=0
                n_jobs = n_jobs_in,             # n_jobs: int, default=None
                positive = positive_in,         # positive: bool, default=False
                random_state = random_state_in, # random_state: int, RandomState instance, default=None
                selection = selection_in        # selection: {‘cyclic’, ‘random’}, default=’cyclic’
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_