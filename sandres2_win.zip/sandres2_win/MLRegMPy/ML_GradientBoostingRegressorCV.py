#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define GradientBoostingRegressorCV() class
class GradientBoostingRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_GradientBoostingRegressorCV() method
    def ml_scikit_GradientBoostingRegressorCV(self):
        """
        Method to generate a multiple regression model using
        GradientBoostingRegressorCV
        """

        # Import packages
        from sklearn.ensemble import GradientBoostingRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.GradientBoostingRegressor.html
        #
        # string_reg_method = GradientBoostingRegressorCV
        #
        #
        # loss: {"ls","lad","huber","quantile"}, default=’ls’
        # Loss function to be optimized. ‘ls’ refers to least squares
        # regression. ‘lad’ (least absolute deviation) is a highly robust loss
        # function solely based on order information of the input variables.
        # ‘huber’ is a combination of the two. ‘quantile’ allows quantile
        # regression (use alpha to specify the quantile).
        #
        # learning_rate: float, default=0.1
        # Learning rate shrinks the contribution of each tree by learning_rate.
        # There is a trade-off between learning_rate and n_estimators.
        #
        # n_estimators: int, default=100
        # The number of boosting stages to perform. Gradient boosting is fairly
        # robust to over-fitting so a large number usually results in better
        # performance.
        #
        # subsample: float, default=1.0
        # The fraction of samples to be used for fitting the individual base
        # learners. If smaller than 1.0 this results in Stochastic Gradient
        # Boosting. subsample interacts with the parameter n_estimators.
        # Choosing subsample < 1.0 leads to a reduction of variance and an
        # increase in bias.
        #
        # min_samples_split: int or float, default=2
        # The minimum number of samples required to split an internal node:
        # If int, then consider min_samples_split as the minimum number.
        # If float, then min_samples_split is a fraction and
        # ceil(min_samples_split * n_samples) are the minimum number of samples
        # for each split.
        #
        # min_samples_leaf: int or float, default=1
        # The minimum number of samples required to be at a leaf node. A split
        # point at any depth will only be considered if it leaves at least
        # min_samples_leaf training samples in each of the left and right
        # branches. This may have the effect of smoothing the model, especially
        # in regression.
        # If int, then consider min_samples_leaf as the minimum number.
        # If float, then min_samples_leaf is a fraction and
        # ceil(min_samples_leaf * n_samples) are the minimum number of samples
        # for each node.
        #
        # min_weight_fraction_leaf: float, default=0.0
        # The minimum weighted fraction of the sum total of weights
        # (of all the input samples) required to be at a leaf node.
        # Samples have equal weight when sample_weight is not provided.
        #
        # max_depth: int, default=3
        # Maximum depth of the individual regression estimators. The maximum
        # depth limits the number of nodes in the tree. Tune this parameter
        # for best performance; the best value depends on the interaction of
        # the input variables.
        #
        # min_impurity_decrease: float, default=0.0
        # A node will be split if this split induces a decrease of the impurity
        # greater than or equal to this value.
        # The weighted impurity decrease equation is the following:
        # N_t / N * (impurity - N_t_R / N_t * right_impurity
        #            - N_t_L / N_t * left_impurity)
        # where N is the total number of samples, N_t is the number of samples
        # at the current node, N_t_L is the number of samples in the left child,
        # and N_t_R is the number of samples in the right child.
        # N, N_t, N_t_R and N_t_L all refer to the weighted sum, if
        # sample_weight is passed.
        #
        # init: estimator or ‘zero’, default=None
        # An estimator object that is used to compute the initial predictions.
        # init has to provide fit and predict. If ‘zero’, the initial raw
        # predictions are set to zero. By default a DummyEstimator is used,
        # predicting either the average target value (for loss=’ls’), or a
        # quantile for the other losses.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls the random seed given to each Tree estimator at each boosting
        # iteration. In addition, it controls the random permutation of the
        # features at each split (see Notes for more details). It also controls
        # the random spliting of the training data to obtain a validation set
        # if n_iter_no_change is not None. Pass an int for reproducible output
        # across multiple function calls.
        #
        # max_features: {"auto","sqrt","log2"}, int or float, default=None
        # The number of features to consider when looking for the best split:
        # If int, then consider max_features features at each split.
        # If float, then max_features is a fraction and
        # int(max_features * n_features) features are considered at each split.
        # If “auto”, then max_features=n_features.
        # If “sqrt”, then max_features=sqrt(n_features).
        # If “log2”, then max_features=log2(n_features).
        # If None, then max_features=n_features.
        # Choosing max_features < n_features leads to a reduction of variance
        # and an increase in bias.
        # Note: the search for a split does not stop until at least one valid
        # partition of the node samples is found, even if it requires
        # to effectively inspect more than max_features features.
        #
        # alpha: float, default=0.9
        # The alpha-quantile of the huber loss function and the quantile loss
        # function. Only if loss='huber' or loss='quantile'.
        #
        # verbose: int, default=0
        # Enable verbose output. If 1 then it prints progress and performance
        # once in a while (the more trees the lower the frequency). If greater
        # than 1 then it prints progress and performance for every tree.
        #
        # max_leaf_nodes: int, default=None
        # Grow trees with max_leaf_nodes in best-first fashion. Best nodes are
        # defined as relative reduction in impurity. If None then unlimited
        # number of leaf nodes.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit and
        # add more estimators to the ensemble, otherwise, just erase the
        # previous solution.
        #
        # validation_fraction: float, default=0.1
        # The proportion of training data to set aside as validation set for
        # early stopping. Must be between 0 and 1. Only used if n_iter_no_change
        # is set to an integer.
        #
        # n_iter_no_change: int, default=None
        # n_iter_no_change is used to decide if early stopping will be used to
        # terminate training when validation score is not improving. By default
        # it is set to None to disable early stopping. If set to a number, it
        # will set aside validation_fraction size of the training data as
        # validation and terminate training when validation score is not
        # improving in all of the previous n_iter_no_change numbers of
        # iterations.
        #
        # tol: float, default=1e-4
        # Tolerance for the early stopping. When the loss is not improving by
        # at least tol for n_iter_no_change iterations (if set to a number),
        # the training stops.
        #
        # ccp_alpha: non-negative float, default=0.0
        # Complexity parameter used for Minimal Cost-Complexity Pruning.
        # The subtree with the largest cost complexity that is smaller than
        # ccp_alpha will be chosen. By default, no pruning is performed.

        # Show message
        print("\nGradient Boosting Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "GradientBoostingRegressorCV":

                # For loss_in
                list_loss = ["squared_error","absolute_error","huber",
                            "quantile"]
                if line[1].strip() in list_loss:
                    loss_in = line[1].strip()
                else:
                    loss_in = "squared_error"
                    print("Unrecognizable input!")

                # For learning_rate_in
                learning_rate_in = float(line[2].strip())

                # For n_estimators_in
                n_estimators_in = int(line[3].strip())

                # For subsample_in
                subsample_in = float(line[4].strip())

                # For criterion_in
                list_criteria = ["friedman_mse","squared_error"]
                if line[5].strip() in list_criteria:
                    criterion_in = line[5].strip()
                else:
                    criterion_in = "friedman_mse"
                    print("Unrecognizable input!")

                # For min_samples_split_in
                if "." in line[6].strip():
                    min_samples_split_in = float(line[6].strip())
                else:
                    min_samples_split_in = int(line[6].strip())

                # For min_samples_leaf_in
                if "." in line[7].strip():
                    min_samples_leaf_in = float(line[7].strip())
                else:
                    min_samples_leaf_in = int(line[7].strip())

                # For min_weight_fraction_leaf_in
                min_weight_fraction_leaf_in = float(line[8].strip())

                # For max_depth_in
                max_depth_in = int(line[9].strip())

                # For min_impurity_decrease_in
                min_impurity_decrease_in = float(line[10].strip())

                # For init_in
                if line[11].strip() == "None":
                    init_in = None
                else:
                    init_in = line[11].strip()

                # For random_state_in
                if line[12].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[12].strip())

                # For max_features_in
                list_max_features = ["auto","sqrt","log2"]
                if line[13].strip() == "None":
                    max_features_in = None
                elif line[13].strip() in list_max_features:
                    max_features_in = line[13].strip()
                elif "." in line[13].strip():
                    max_features_in = float(line[13].strip())
                else:
                    max_features_in = int(line[13].strip())

                # For alpha_in
                alpha_in = float(line[14].strip())

                # For verbose_in
                verbose_in = int(line[15].strip())

                # For max_leaf_nodes_in
                if line[16].strip() == "None":
                    max_leaf_nodes_in = None
                else:
                    max_leaf_nodes_in = int(line[16].strip())

                # For warm_start_in
                if line[17].strip() == "False":
                    warm_start_in = False
                else:
                    warm_start_in = True

                # For validation_fraction_in
                validation_fraction_in = float(line[18].strip())

                # For n_iter_no_change_in
                if line[19].strip() == "None":
                    n_iter_no_change_in = None
                else:
                    n_iter_no_change_in = int(Line[19].strip())

                # For tol_in
                tol_in = float(line[20].strip())

                # For ccp_alpha_in
                ccp_alpha_in = float(line[21].strip())

                # For cv_in
                cv_in = int(line[22].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Loss function to be optimized: ",line[1])
        print("Learning rate: ",line[2])
        print("The number of boosting stages to perform: ",line[3])
        print("Fraction of samples to be used for fitting: ",line[4])
        print("Function to measure the quality of a split: ",line[5])
        print("Minimum number of samples required to split an internal node: ",
        line[6])
        print("Minimum number of samples required to be at a leaf node: ",
        line[7])
        print("Minimum weighted fraction of the sum total of weights: ",line[8])
        print("Maximum depth of the individual regression estimators",line[9])
        print("Minimum impurity decrease: ",line[10])
        print("Estimator object that is used to compute the initial predictions",
        line[11])
        print("Random seed: ",line[12])
        print("Number of features to consider when looking for the best split: ",
        line[13])
        print("Alpha-quantile of the huber loss function and the quantile: ",
        line[14])
        print("Verbose output: ",line[15])
        print("Maximum leaf nodes: ",line[16])
        print("Warm start: ",line[17])
        print("Validation fraction: ",line[18])
        print("Number of iterations with no change: ",line[19])
        print("Tolerance for the early stopping: ",line[20])
        print("Complexity parameter: ",line[21])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[22])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of GradientBoostingRegressor class
        ############################################################################
        model = GradientBoostingRegressor(
            loss=loss_in,                       # loss: {‘squared_error’, ‘absolute_error’, ‘huber’, ‘quantile’}, default=’squared_error’
            learning_rate=learning_rate_in,     # learning_rate: float, default=0.1
            n_estimators=n_estimators_in,       # n_estimators: int, default=100
            subsample=subsample_in,             # subsample: float, default=1.0
            criterion=criterion_in,             # criterion: {‘friedman_mse’, ‘squared_error’, ‘mse’, ‘mae’}, default=’friedman_mse’
            min_samples_split=min_samples_split_in,     # min_samples_split: int or float, default=2
            min_samples_leaf=min_samples_leaf_in,       # min_samples_leaf: int or float, default=1
            min_weight_fraction_leaf=min_weight_fraction_leaf_in,   # min_weight_fraction_leaf: float, default=0.0
            max_depth=max_depth_in,             # max_depth: int, default=3
            min_impurity_decrease=min_impurity_decrease_in,     # min_impurity_decrease: float, default=0.0
            init=init_in,                       # init: estimator or ‘zero’, default=None
            random_state=random_state_in,       # random_state: int, RandomState instance or None, default=None
            max_features=max_features_in,       # max_features: {‘auto’,‘sqrt’,‘log2’}, int or float, default=None
            alpha=alpha_in,                     # alpha: float, default=0.9
            verbose=verbose_in,                 # verbose: int, default=0
            max_leaf_nodes=max_leaf_nodes_in,   # max_leaf_nodes: int, default=None
            warm_start=warm_start_in,           # warm_start: bool, default=False
            validation_fraction=validation_fraction_in,     # validation_fraction: float, default=0.1
            n_iter_no_change=n_iter_no_change_in,       # n_iter_no_change: int, default=None
            tol=tol_in,                         # tol: float, default=1e-4
            ccp_alpha=ccp_alpha_in              # ccp_alpha: non-negative float, default=0.0
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model