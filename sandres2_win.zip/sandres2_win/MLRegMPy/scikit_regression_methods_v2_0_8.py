#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
###############################################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
###############################################################################################################
#
# Import packages
import os
import sys
import shutil
from scipy import c_, ones, dot, stats
from scipy.linalg import inv 
from numpy import sqrt, diagonal, average
import numpy as np        

# Define Multvar_reg_modeling() class
class Multvar_reg_modeling(object):
    """
    This class carries out regression analysis using scikit-learn methods.
    
    Inputs
         program_root           : Program directory
         dir_in                 : Project directory
         ml_parameters          : Machine-learning parameter file
         num_indep_var          : Number of independent variables
         y                      : Dependent variable
         y_varnm                : String with the variable label for y
         x                      : Independent variables, note that a constant is added by default
         x_varnm                : String or list of variable labels for the independent variables
         selected_method_in     : String with the regression method

    Outputs
        self.nobs               : Number of observations
        self.b                  : np.array with regression coefficients except for methods in self.list_methods
        self.corr_p             : Pearson correlation coefficient
        self.R2                 : R-square
        self.pvalue_p           : p-value for Pearson correlation coefficient
        self.R2adj              : Adjusted R-square
        self.sd                 : Standard deviation
        self.corr_s             : Spearman rank correlation coefficient
        self.pvalue_s           : p-value for Spearman correlation coefficient
        self.f_stat             : F-stat
        self.se1                : Coefficient of standard errors
        self.Q                  : self.corr_p/self.sd 
        self.y_pred             : Predicted y
    """
    
    # Define constructor method
    def __init__(self,program_root,dir_in,ml_parameters,num_indep_var,y,x,y_varnm = 'y',x_varnm = '',selected_method_in="LinearRegression"):
        """Initializing the Multvar_reg_modeling class """
        
        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.ml_parameters = ml_parameters
        self.num_indep_var = num_indep_var
        self.y = y
        self.x = c_[ones(x.shape[0]),x]
        self.y_varnm = y_varnm
        self.selected_method_in = selected_method_in 
        if not isinstance(x_varnm,list): 
            self.x_varnm = ['const'] + list(x_varnm)
        else:
            self.x_varnm = ['const'] + x_varnm

        # length of vector y
        self.num_elements = len(self.y)

        # Check whether the specified path is an existing directory or not
        self.path4models = self.dir_in+"models/"
        isdir = os.path.isdir(self.path4models)
        if isdir:
            print("\nI've found ",self.path4models," directory!")
        else:
            # Create the directory self.dir_in+"models/"
            os.mkdir(self.path4models)
            print("\n",self.path4models," directory has been created!")
            
        # Set up a list of methods to have a different approach to
        # statistical analysis. These are methods that do not return
        # attributes coef_ and intercept_
        self.list_methods = ["AdaBoostRegressor",
        "AdaBoostRegressorCV",
        "BaggingRegressor",
        "BaggingRegressorCV",
        "DecisionTreeRegressor",
        "DecisionTreeRegressorCV",
        "ExtraTreeRegressor",
        "ExtraTreeRegressorCV",
        "ExtraTreesRegressor",
        "ExtraTreesRegressorCV",
        "GaussianProcessRegressor",
        "GaussianProcessRegressorCV",
        "GradientBoostingRegressor",
        "GradientBoostingRegressorCV",
        "KernelRidge",
        "KernelRidgeCV",
        "KNeighborsRegressor",
        "KNeighborsRegressorCV",
        "MLPRegressor",
        "MLPRegressorCV",
        "RandomForestRegressor",
        "RandomForestRegressorCV",
        "RANSACRegressor",
        "RANSACRegressorCV",
        "Stacking",
        "StackingCV",
        "VotingRegressor",
        "VotingRegressorCV",
        "XGBRegressor",
        "XGBRegressorCV"]
        
        # Estimate model using machine learning methods
        self.basic_statistical_analysis()
    
    # Define calc_ESS() method
    def calc_ESS(self):
        """Method to calculate Explained Sum of Squares (ESS)"""
        
        # Get number of data points
        n = len(self.y_in)
        
        # Set up array with zeros
        aux = np.zeros(n,dtype=float)
        
        # Calculate mean self.y_in
        mean_y_in = np.mean(self.y_in)
        
        # Looping through data points (self.y_in) and self.y_pred
        for i in range(n):
                aux[i] = (self.y_pred[i] - mean_y_in)**2
        
        # Calculates Explained Sum of Squares (ESS)
        self.ess = np.sum(aux)
    
    # Define calc_RSS() method
    def calc_RSS(self):
        """Method to calculate Residual Sum of Squares (RSS)"""
        
        # Get number of data points
        n = len(self.y_in)
        
        # Set up array with zeros
        aux = np.zeros(n,dtype=float)
        
        # Looping through data points (self.y_in) and self.y_pred
        for i in range(n):
                aux[i] = (self.y_in[i] - self.y_pred[i])**2
        
        # Calculates Residual Sum of Squares (RSS)
        self.rss = np.sum(aux)
    
    # Define stat_analysis_of_reg_models(self)
    def stat_analysis_of_reg_models(self):
        """Method to carry out statistical analysis of regression models"""
        
        # Import packages
        from scipy.stats import spearmanr, pearsonr
        from sklearn.metrics import mean_squared_error
        
        # Set up empty list   
        data_list = []
        
        # Looping through self.y_in to get elements for list
        for i in range(len(self.y_in)):
            aux = float(self.y_in[i][0])
            data_list.append(aux)
        
        # Import warnings filter
        from warnings import simplefilter

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)
        
        # Get Spearman's rank and Pearson correlation coefficient and p-value         
        self.corr_s,self.pvalue_s = spearmanr(data_list,self.y_pred)
        self.corr_p,self.pvalue_p = pearsonr(data_list,self.y_pred)
        
        # To avoid "nan"
        if str(self.corr_s) == "nan":
            self.corr_s,self.pvalue_s = 0.0,1.0
            
        # Invoke calc_RSS
        self.calc_RSS()
        
        # Invoke calc_ess
        self.calc_ESS()
                        
        # Basic statistics 
        n = len(self.y_in)                                                      # Number of data points
        p = self.num_indep_var                                                  # Number of explanatory variables
        self.r2S = self.corr_p*self.corr_p                                      # R-square
        self.s_dev = np.sqrt(self.rss/(n-p-1))                                  # Standard deviation
        self.rmse_model = np.sqrt(mean_squared_error(self.y_pred, data_list))   # RMSE
        self.f_stat = (self.ess/p)*( (n-p-1)/self.rss )                         # Calculate F-stat                
                
        # Show statistical analysis
        print("\nStatistical Analysis of Regression Model")
        print("Method: Multiple Linear Regression ("+self.reg_method+")")
        print("N = ",n)
        print("Regression model: ",self.reg_model)
        for i in range(len(self.se)):
                print("Standard error in "+u"\u03b2(",i,") : {:.6f} "
                .format(2*self.se[i]))
        print("Spearman's rank correlation coefficient : {:.6f}"
        .format(self.corr_s),
        "p-value: ",
        np.format_float_scientific(self.pvalue_s,precision=4,exp_digits=3))
        print("Pearson's correlation coefficient (r): {:.6f}"
        .format(self.corr_p),"p-value: ",
        np.format_float_scientific(self.pvalue_p,precision=4,exp_digits=3))
        print("r"+u"\u00b2"+": {:.6f}".format(self.r2S))
        print('RMSE: {:.6f}'.format(self.rmse_model))
        print("Standard deviation (s): {:.6f}".format(self.s_dev))
        print("Residual sum of squares (RSS): {:.6f}".format(self.rss))
        print("F-stat: {:.6f}".format(self.f_stat))
            
    # Define calc_SE_M() method
    def calc_SE_M(self):
        """Method to calculate standard error (SE) Equations 
        taken from http://zip2002.psy.unipd.it/index.php?page=sbcs"""
        
        # Get number of rows and columns
        n = len(self.x_in)
        row = n        
        column = len(self.x_in[0])

        # Set up matrices and vectors
        # a = np.array([[0]*column]*row,float)      # A matrix row x column
        x = np.array([[0]*(column+1)]*row,float)    # A matrix row x column
        beta = np.zeros(column+1,float)             # A vector with column elements
        self.se = np.zeros(column+1,float)          # A vector with column+1 elements

        # Beta coefficients
        for i in range(column):
                beta[i] = self.b[i]
        
        # Looping x_in to build x matrix
        for i in range(n):
                x[i][0] = 1.0
                for j in range(column):
                        x[i][j+1] = self.x_in[i][j]
                
        # Calculate transposes
        xt = np.transpose(x)
        yt = np.transpose(self.y_in)
        
        # Calculate [xt]*[x]
        xtx = np.dot(xt,x)
        
        # Calculate inverse of xtx
        #from numpy.linalg import inv
        xtx_inv = inv(xtx) 
        
        # Calculate ms_res
        aux1 = np.dot(yt,self.y_in)
        aux2 = np.dot(beta,xt)
        aux3 = np.dot(aux2,self.y_in)
        epe = aux1 - aux3
        ms_res = epe/(n-column-1)
        
        # looping through standard errors
        for i in range(column+1):
                if ms_res*xtx_inv[i][i]  >= 0:
                        self.se[i] = np.sqrt( ms_res*xtx_inv[i][i] )
                else:
                        self.se[i] = np.sqrt( np.abs( ms_res*xtx_inv[i][i] ) )
    
    # Define gen_modelMultD2() method
    def gen_modelMultD2(self):
        """Method to generate model (y_pred)"""
        
        # Set up empty list
        self.y_pred = []
        
        # Get number of colums
        columns =  len(self.b) - 1  
    
        # Looping through data to generate y_pred 
        for i in range(len(self.x_in)):
            aux1 = self.b[0]
            for j in range(columns):
                aux1 += self.b[j+1]*self.x_in[i][j]
            self.y_pred.append(aux1)
            aux1 = 0
    
    # Define prep_y1() method        
    def prep_y1(self):
        """Method to prepare y for scikit"""
        
        # Import package
        from sklearn.utils.validation import column_or_1d
        
        # Set up empty list
        self.y_in = []
        
        # Looping through self.y
        for line in self.y:
            aux_list = []
            aux_list.append(line)
            self.y_in.append(aux_list)
        
        # Convert to 1d vector
        self._y_in = column_or_1d(self.y_in, warn = False)
    
    # Define prep_x1() method 
    def prep_x1(self):
        """Method to prepare x for scikit"""
        
        # Set up empty list
        self.x_in = []
        
        # Looping through self.x
        for line in self.x:
            aux_list = []
            for aux1 in line[1:]:
                aux_list.append(aux1)
            self.x_in.append(aux_list)
        
        # Convert to array
        self._x_in = np.array(self.x_in)

    # Define backup_a_file() method 
    def backup_a_file(self,file2backup,label_4_reg_method,file_ext):
        """Method to back up a file, if it exists"""
        
        # Invoke set_local_time() method
        self.set_local_time()
        
        # Check whether the specified path/file is an existing directory/file
        # or not
        isfile = os.path.isfile(file2backup)
        print("\nCheck whether the specified path/file ",file2backup,
        "is an  existing directory/file or not: ",isfile)
        if isfile:
            print("\nI've found ",file2backup," directory/file!")
            origin = file2backup
            target = self.path4models+"model_"+label_4_reg_method
            target += "_"+self.my_local_time+file_ext
            shutil.copyfile(origin,target)
        
    # Define dump_json_model()
    def dump_json_model(self,regressor_coef_,regressor_intercept_):
        """Method to generate JSON output which could be shared.
        JSON (JavaScript Object Notation)
        """
        
        # Import packages
        import json
        import sklearn
        
        # Set up variables
        label_4_reg_method = self.reg_method[21:].replace(" with ","")
        file_ext = ".json"
        model_file = self.path4models+"model_"+label_4_reg_method+file_ext
        
        # Invoke backup_a_file() method
        self.backup_a_file(model_file,label_4_reg_method,file_ext)  
        
        # Set up parameters to be saved
        model_param = {}
        model_param["Regression method: "] = self.reg_method
        model_param["Scikit-learn version: "] = sklearn.__version__
        model_param['Date: '] = self.my_local_time
        model_param['Coefficient(s): '] = list(regressor_coef_)
        model_param['Intercept(s): '] = regressor_intercept_.tolist()
        json_txt = json.dumps(model_param, indent=4)
                
        # Open json file
        with open(model_file, "w") as file:
            file.write(json_txt)
        
        # Show message
        print("\nRegression model written in ",model_file)
    
    # Define read_json_model()
    def read_json_model(self):
        """Method to generate joblig output which could be shared"""
        
        # Import package
        import json
        
        # Set up label for regression method
        label_4_reg_method = self.reg_method[21:].replace(" with ","")
        file_ext = ".json"
        model_file = self.path4models+"model_"+label_4_reg_method+file_ext
        
        # Read json file
        with open(model_file, 'r') as file:
            json_model=json.load(file)
        
        # Show results
        print("\nModel read from json file: ",model_file)
        print(json_model)
    
    # Define dump_joblib_model()
    def dump_joblib_model(self,model4joblib):
        """Method to generate joblib output which could be shared"""
        
        # Import package
        from joblib import dump, load
        
        # Check self.reg_method        
        if  "ensembl." in self.reg_method:
            
            # Set up label for regression method ("sklearn.ensembl.AdaBoostRegressorCV")
            label_4_reg_method = self.reg_method[16:].replace(" with ","")
        
        elif  "kernel_ridge." in self.reg_method:
                                        
            # Set up label for regression method ("sklearn.kernel_ridge.KernelRidge")
            label_4_reg_method = self.reg_method[21:].replace(" with ","")
        
        elif  "gaussian_process." in self.reg_method:
                                        
            # Set up label for regression method ("sklearn.gaussian_process.GaussianProcessRegressor")
            label_4_reg_method = self.reg_method[25:].replace(" with ","")
        
        elif "sklearn.tree." in self.reg_method:
                                        
            # Set up label for regression method ("sklearn.tree.DecisionTreeRegressor")
            label_4_reg_method = self.reg_method[13:].replace(" with ","")
        
        elif "sklearn.neighbors." in self.reg_method:
                                        
            # Set up label for regression method ("sklearn.neighbors.KNeighborsRegressor")
            label_4_reg_method = self.reg_method[18:].replace(" with ","")
        
        else:
            
            # Set up label for regression method ("sklearn.linear_model.ARDRegression"  )
            label_4_reg_method = self.reg_method[21:].replace(" with ","")
                    
        # Set up variables
        file_ext = ".joblib"
        model_file = self.path4models+"model_"+label_4_reg_method+file_ext
        
        # Invoke backup_a_file() method
        self.backup_a_file(model_file,label_4_reg_method,file_ext) 
        
        # Assign model file name to model_out_file
        self.model_out_file = model_file
                
        # Dump model
        dump(model4joblib, self.model_out_file)
        
        # Show message
        print("\nRegression model written in ",self.model_out_file)
    
    # Define read_joblib_regression_model()
    def read_joblib_regression_model(self,model_in):
        """Method to read joblib output which could be shared"""
        
        # Import package
        from joblib import dump, load
        
        # Load model
        joblib_model = load(model_in) 
        
        # Invoke fit method
        joblib_model.fit(self._x_in, self._y_in)
                
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(joblib_model.intercept_,joblib_model.coef_)
    
    # Define read_joblib_MLPRegressor_model()
    def read_joblib_MLPRegressor_model(self,model_in,x,y,num_indep_var):
        """Method to read joblib MLPRegressor/Stacking output which could be shared"""

        # Import packages
        from joblib import dump, load
        from scipy.stats import spearmanr, pearsonr
        from sklearn.metrics import mean_squared_error

        # Load model
        joblib_model = load(model_in)
        
        # Generate prediction (self.y_pred)
        self.y_pred = joblib_model.predict(x)

        # Get Spearman's rank and Pearson correlation coefficient and p-value
        self.corr_s,self.pvalue_s = spearmanr(y,self.y_pred)
        self.corr_p,self.pvalue_p = pearsonr(y,self.y_pred)
        
        # Invoke calc_RSS
        self.calc_RSS()
        
        # Invoke calc_ess
        self.calc_ESS()

        # Basic statistics
        n = len(y)                                                      # Number of data points
        p = num_indep_var                                               # Number of explanatory variables
        self.r2S = self.corr_p*self.corr_p                              # R-squares
        self.s_dev = np.sqrt(self.rss/(n-p-1))                          # Standard deviation
        self.rmse_model = np.sqrt(mean_squared_error(self.y_pred, y))   # RMSE
        self.f_stat = (self.ess/p)*( (n-p-1)/self.rss )                 # Calculate F-stat

        # Show statistical analysis
        print("\nStatistical Analysis of Regression Model")
        print("Spearman's rank correlation coefficient : {:.6f}".format(self.corr_s),
        "p-value: ",np.format_float_scientific(self.pvalue_s,precision=4,exp_digits=3))
        print("Pearson's correlation coefficient (r): {:.6f}".format(self.corr_p),"p-value: ",
        np.format_float_scientific(self.pvalue_p,precision=4,exp_digits=3))
        print("r"+u"\u00b2"+": {:.6f}".format(self.r2S))
        print('RMSE: {:.6f}'.format(self.rmse_model))
        print("Standard deviation (s): {:.6f}".format(self.s_dev))
        print("Residual sum of squares (RSS): {:.6f}".format(self.rss))
        print("F-stat: {:.6}".format(self.f_stat))
    
    # Define set_local_time() method
    def set_local_time(self):
        """Method to set up local time"""
        
        # Import package
        import time
        
        # Assign local time to self.my_local_time variable
        self.my_local_time = str(time.strftime("%Y_%m_%d_%Hh%Mmin%Ss"))
        
        # Set up month_list
        month_list = ["January","February","March","April","May","June",
        "July","August","September","October","November","December"]
        
        # Set up self.date_var
        self.date_var = month_list[int(time.strftime("%m"))-1] +" "+ str(time.strftime("%d"))+", "+str(time.strftime("%Y"))+". "
        self.date_var += str(time.strftime("%Hh%Mmin%Ss"))
                
    # Define dump_xml() method
    def dump_xml(self):
        """Method to write Molegro Data Modeller XML file (.mdm extension) """
        
        # Invoke set_local_time() method
        self.set_local_time()
        
        # Set up variables
        label_4_reg_method = self.reg_method[21:].replace(" with ","")
        file_ext = ".mdm"
        model_file = self.path4models+"model_"+label_4_reg_method+file_ext
        
        # Invoke backup_a_file() method
        self.backup_a_file(model_file,label_4_reg_method,file_ext)  
                
        # Assign model file name to model_out_file
        self.model_out_file = model_file
                
        # Set up empty string
        coef_string = ""
        
        # Looping through self.b
        for coef_float in self.b[1:]:
            coef_string += str(coef_float)+","
        coef_string += str(self.b[0])
        
        # Read features.csv
        try:
            file2open = self.path4models+"features.csv"
            fo1_des = open(file2open,"r")
            descriptors_used = fo1_des.readline()
        except IOError:
            print("IOError! I can't find "+file2open+" file")
            return
            
        # Close file
        fo1_des.close()
        
        # Open new xml file and model data (MDM style)
        xml1 = open(self.model_out_file,"w")
        xml1.write('<?xml version="1.0\" encoding="ISO 8859-1"?>\n')
        xml1.write('<!DOCTYPE SAnDReS-MVDML>\n')
        xml1.write('<Object version="4" type="MDM.Model.Workspace" name="SAnDReS" datestring="'+self.date_var+' '+'" >\n')
        xml1.write('<DatasetList count="0" basetype="MDM.Model.Dataset" />\n')
        xml1.write('<ModelList count="1" basetype="MDM.Model.Model" >\n')
        xml1.write('<MDM-Algorithms-Regression-MLR randomSeed="'+str(self.rand_in)+'" coefficients="')
        xml1.write(coef_string+'" ')
        xml1.write('name="'+self.reg_method[21:]+' ('+str(len(self.b)-1)+'D)" descriptorsUsed="'+descriptors_used+'" targetVariable="Experimental" />\n')
        xml1.write('</ModelList>\n')
        xml1.write('</Object>\n')
        print("\nRegression model written in ",self.model_out_file)
        
        # Close file
        xml1.close()
            
    # Define gen_regression_model_string()
    def gen_regression_model_string(self,model_intercept,model_coef):
        """Method to generate regression model string"""
        
        # Generate string with regression equation (regression constant)
        columns = len(self.x_in[0])
        self.reg_model = str("y = {:.10}".format(float(model_intercept)))
                        
        # Looping through model.coef_() (regression weights)
        for i in range(columns):
            if i == 0:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2081'
            elif i == 1:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2082'
            elif i == 2:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2083'
            elif i == 3:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2084'
            elif i == 4:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2085'
            elif i == 5:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2086'
            elif i == 6:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2087'
            elif i == 7:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2088'
            elif i == 8:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+u'\u2089'
            else:
                aux_string = str(  "+{:.10f}".format((float(model_coef[i]))))+"x"+str(i+1)
            self.reg_model += aux_string
        
        # Get model intercept
        betas = []
        betas.append(float(model_intercept))
        
        # Looping through model_coef
        for i in range(columns):
            betas.append(model_coef[i])
        
        # Set up array with coefficients
        self.b = np.array(betas)
    
    ############################################################################
    #  Regression Methods from Scikit-Learn                                    #
    #  The scikit-learn version is 0.23.2.                                     #
    #  https://scikit-learn.org/stable/supervised_learning.html                #
    ############################################################################
    #
    # Define scikit_AdaBoostRegressor() method
    def scikit_AdaBoostRegressor(self):
        """
        Method to generate a multiple regression model using
        AdaBoostRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_AdaBoostRegressor as regr_class
                
        # Instantiate an object of AdaBoostRegressor() class
        regr_obj = regr_class.AdaBoostRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_AdaBoostRegressor() method
        model = regr_obj.ml_scikit_AdaBoostRegressor()
                
        # Set up string with regression method AdaBoostRegressor
        self.reg_method = "sklearn.ensembl.AdaBoostRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_AdaBoostRegressorCV() method
    def scikit_AdaBoostRegressorCV(self):
        """
        Method to generate a multiple regression model using
        AdaBoostRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_AdaBoostRegressorCV as regr_class
                
        # Instantiate an object of AdaBoostRegressorCV() class
        regr_obj = regr_class.AdaBoostRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_AdaBoostRegressorCV() method
        model = regr_obj.ml_scikit_AdaBoostRegressorCV()
                
        # Set up string with regression method AdaBoostRegressor
        self.reg_method = "sklearn.ensembl.AdaBoostRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_ARDRegression() method
    def scikit_ARDRegression(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ARDRegression
        (Automatic Relevance Determination Regression)
        """
        
        # Import regression class
        from MLRegMPy import ML_ARDRegression as regr_class
        
        # Instantiate an object of ARDRegression() class
        regr_obj = regr_class.ARDRegression(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ARDRegression() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_ARDRegression()
       
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.ARDRegression"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_ARDRegressionCV() method
    def scikit_ARDRegressionCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ARDRegression
        (Automatic Relevance Determination Regression)
        """
        
        # Import regression class
        from MLRegMPy import ML_ARDRegressionCV as regr_class
        
        # Instantiate an object of ARDRegressionCV() class
        regr_obj = regr_class.ARDRegressionCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ARDRegressionCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_ARDRegressionCV()
       
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.ARDRegressionCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
            
    # Define scikit_BaggingRegressor() method
    def scikit_BaggingRegressor(self):
        """
        Method to generate a multiple regression model using
        BaggingRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_BaggingRegressor as regr_class
                
        # Instantiate an object of BaggingRegressor() class
        regr_obj = regr_class.BaggingRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_BaggingRegressor() method
        model = regr_obj.ml_scikit_BaggingRegressor()
                
        # Set up string with regression method BaggingRegressor
        self.reg_method = "sklearn.ensembl.BaggingRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
            
    # Define scikit_BaggingRegressorCV() method
    def scikit_BaggingRegressorCV(self):
        """
        Method to generate a multiple regression model using
        BaggingRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_BaggingRegressorCV as regr_class
                
        # Instantiate an object of BaggingRegressor() class
        regr_obj = regr_class.BaggingRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_BaggingRegressor() method
        model = regr_obj.ml_scikit_BaggingRegressorCV()
                
        # Set up string with regression method BaggingRegressor
        self.reg_method = "sklearn.ensembl.BaggingRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_BayesianRidge() method
    def scikit_BayesianRidge(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.BayesianRidge
        """
        
        # Import regression class
        from MLRegMPy import ML_BayesianRidge as regr_class
        
        # Instantiate an object of BayesianRidge() class
        regr_obj = regr_class.BayesianRidge(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_BayesianRidge() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_BayesianRidge()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.BayesianRidge" 
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml() 

    # Define scikit_BayesianRidgeCV() method
    def scikit_BayesianRidgeCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.BayesianRidge
        """
        
        # Import regression class
        from MLRegMPy import ML_BayesianRidgeCV as regr_class
        
        # Instantiate an object of BayesianRidgeCV() class
        regr_obj = regr_class.BayesianRidgeCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_BayesianRidge() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_BayesianRidgeCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.BayesianRidgeCV" 
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
            
    # Define scikit_DecisionTreeRegressor() method
    def scikit_DecisionTreeRegressor(self):
        """
        Method to generate a multiple regression model using
        DecisionTreeRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_DecisionTreeRegressor as regr_class
                
        # Instantiate an object of DecisionTreeRegressor() class
        regr_obj = regr_class.DecisionTreeRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_DecisionTreeRegressor() method
        model = regr_obj.ml_scikit_DecisionTreeRegressor()
                
        # Set up string with regression method DecisionTreeRegressor
        self.reg_method = "sklearn.tree.DecisionTreeRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
            
    # Define scikit_DecisionTreeRegressorCV() method
    def scikit_DecisionTreeRegressorCV(self):
        """
        Method to generate a multiple regression model using
        DecisionTreeRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_DecisionTreeRegressorCV as regr_class
                
        # Instantiate an object of DecisionTreeRegressorCV() class
        regr_obj = regr_class.DecisionTreeRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_DecisionTreeRegressorCV() method
        model = regr_obj.ml_scikit_DecisionTreeRegressorCV()
                
        # Set up string with regression method DecisionTreeRegressor
        self.reg_method = "sklearn.tree.DecisionTreeRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_ElasticNet() method
    def scikit_ElasticNet(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ElasticNet
        """
    
        # Import regression class
        from MLRegMPy import ML_ElasticNet as regr_class
        
        # Instantiate an object of ElasticNet() class
        regr_obj = regr_class.ElasticNet(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ElasticNet() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_ElasticNet()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.ElasticNet"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_ElasticNetCV() method
    def scikit_ElasticNetCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ElasticNetCV
        """
    
        # Import regression class
        from MLRegMPy import ML_ElasticNetCV as regr_class
        
        # Instantiate an object of ElasticNetCV() class
        regr_obj = regr_class.ElasticNetCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ElasticNetCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_ElasticNetCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.ElaticNetCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
            
    # Define scikit_ExtraTreeRegressor() method
    def scikit_ExtraTreeRegressor(self):
        """
        Method to generate a multiple regression model using
        ExtraTreeRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_ExtraTreeRegressor as regr_class
                
        # Instantiate an object of ExtraTreeRegressor() class
        regr_obj = regr_class.ExtraTreeRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ExtraTreeRegressor() method
        model = regr_obj.ml_scikit_ExtraTreeRegressor()
                
        # Set up string with regression method ExtraTreeRegressor
        self.reg_method = "sklearn.tree.ExtraTreeRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
    # Define scikit_ExtraTreeRegressorCV() method
    def scikit_ExtraTreeRegressorCV(self):
        """
        Method to generate a multiple regression model using
        ExtraTreeRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_ExtraTreeRegressorCV as regr_class
                
        # Instantiate an object of ExtraTreeRegressorCV() class
        regr_obj = regr_class.ExtraTreeRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ExtraTreeRegressorCV() method
        model = regr_obj.ml_scikit_ExtraTreeRegressorCV()
                
        # Set up string with regression method ExtraTreeRegressor
        self.reg_method = "sklearn.tree.ExtraTreeRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
    
    # Define scikit_ExtraTreesRegressor() method
    def scikit_ExtraTreesRegressor(self):
        """
        Method to generate a multiple regression model using
        ExtraTreesRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_ExtraTreesRegressor as regr_class
                
        # Instantiate an object of ExtraTreesRegressor() class
        regr_obj = regr_class.ExtraTreesRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ExtraTreesRegressor() method
        model = regr_obj.ml_scikit_ExtraTreesRegressor()
                
        # Set up string with regression method ExtraTreesRegressor
        self.reg_method = "sklearn.ensembl.ExtraTreesRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    
    # Define scikit_ExtraTreesRegressorCV() method
    def scikit_ExtraTreesRegressorCV(self):
        """
        Method to generate a multiple regression model using
        ExtraTreesRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_ExtraTreesRegressorCV as regr_class
                
        # Instantiate an object of ExtraTreesRegressorCV() class
        regr_obj = regr_class.ExtraTreesRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_ExtraTreesRegressorCV() method
        model = regr_obj.ml_scikit_ExtraTreesRegressorCV()
                
        # Set up string with regression method ExtraTreesRegressorCV
        self.reg_method = "sklearn.ensembl.ExtraTreesRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
            
    # Define scikit_GaussianProcessRegressor() method
    def scikit_GaussianProcessRegressor(self):
        """
        Method to generate a multiple regression model using
        GaussianProcessRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_GaussianProcessRegressor as regr_class
                
        # Instantiate an object of GaussianProcessRegressor() class
        regr_obj = regr_class.GaussianProcessRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_GaussianProcessRegressor() method
        model = regr_obj.ml_scikit_GaussianProcessRegressor()
                
        # Set up string with regression method GaussianProcessRegressor
        self.reg_method = "sklearn.gaussian_process.GaussianProcessRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_GaussianProcessRegressorCV() method
    def scikit_GaussianProcessRegressorCV(self):
        """
        Method to generate a multiple regression model using
        GaussianProcessRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_GaussianProcessRegressorCV as regr_class
                
        # Instantiate an object of GaussianProcessRegressorCV() class
        regr_obj = regr_class.GaussianProcessRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_GaussianProcessRegressorCV() method
        model = regr_obj.ml_scikit_GaussianProcessRegressorCV()
                
        # Set up string with regression method GaussianProcessRegressor
        self.reg_method = "sklearn.gaussian_process.GaussianProcessRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_GradientBoostingRegressor() method
    def scikit_GradientBoostingRegressor(self):
        """
        Method to generate a multiple regression model using
        GradientBoostingRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_GradientBoostingRegressor as regr_class
                
        # Instantiate an object of GradientBoostingRegressor() class
        regr_obj = regr_class.GradientBoostingRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_GradientBoostingRegressor() method
        model = regr_obj.ml_scikit_GradientBoostingRegressor()
                
        # Set up string with regression method GradientBoostingRegressor
        self.reg_method = "sklearn.ensembl.GradientBoostingRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
    
    # Define scikit_GradientBoostingRegressorCV() method
    def scikit_GradientBoostingRegressorCV(self):
        """
        Method to generate a multiple regression model using
        GradientBoostingRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_GradientBoostingRegressorCV as regr_class
                
        # Instantiate an object of GradientBoostingRegressorCV() class
        regr_obj = regr_class.GradientBoostingRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_GradientBoostingRegressorCV() method
        model = regr_obj.ml_scikit_GradientBoostingRegressorCV()
                
        # Set up string with regression method GradientBoostingRegressor
        self.reg_method = "sklearn.ensembl.GradientBoostingRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
    
    # Define scikit_HuberRegressor() method
    def scikit_HuberRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.HuberRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_HuberRegressor as regr_class
        
        # Instantiate an object of HuberRegressor() class
        regr_obj = regr_class.HuberRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_HuberRegressor() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_HuberRegressor()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.HuberRegressor"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
        
    # Define scikit_HuberRegressorCV() method
    def scikit_HuberRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.HuberRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_HuberRegressorCV as regr_class
        
        # Instantiate an object of HuberRegressorCV() class
        regr_obj = regr_class.HuberRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_HuberRegressorCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_HuberRegressorCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.HuberRegressorCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_KernelRidge() method
    def scikit_KernelRidge(self):
        """
        Method to generate a multiple regression model using
        KernelRidge
        """
        
        # Import regression class
        from MLRegMPy import ML_KernelRidge as regr_class
                
        # Instantiate an object of KernelRidge() class
        regr_obj = regr_class.KernelRidge(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_KernelRidge() method
        model = regr_obj.ml_scikit_KernelRidge()
                
        # Set up string with regression method KernelRidge
        self.reg_method = "sklearn.kernel_ridge.KernelRidge"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
    
    # Define scikit_KernelRidgeCV() method
    def scikit_KernelRidgeCV(self):
        """
        Method to generate a multiple regression model using
        KernelRidgeCV
        """
        
        # Import regression class
        from MLRegMPy import ML_KernelRidgeCV as regr_class
                
        # Instantiate an object of KernelRidgeCV() class
        regr_obj = regr_class.KernelRidgeCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_KernelRidgeCV() method
        model = regr_obj.ml_scikit_KernelRidgeCV()
                
        # Set up string with regression method KernelRidge
        self.reg_method = "sklearn.kernel_ridge.KernelRidgeCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_KNeighborsRegressor() method
    def scikit_KNeighborsRegressor(self):
        """
        Method to generate a multiple regression model using
        KNeighborsRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_KNeighborsRegressor as regr_class
                
        # Instantiate an object of KNeighborsRegressor() class
        regr_obj = regr_class.KNeighborsRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_KNeighborsRegressor() method
        model = regr_obj.ml_scikit_KNeighborsRegressor()
                
        # Set up string with regression method KNeighborsRegressor
        self.reg_method = "sklearn.neighbors.KNeighborsRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_KNeighborsRegressorCV() method
    def scikit_KNeighborsRegressorCV(self):
        """
        Method to generate a multiple regression model using
        KNeighborsRegressorCV
        """
        
        # Import regression class
        from MLRegMPy import ML_KNeighborsRegressorCV as regr_class
                
        # Instantiate an object of KNeighborsRegressorCV() class
        regr_obj = regr_class.KNeighborsRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_KNeighborsRegressorCV() method
        model = regr_obj.ml_scikit_KNeighborsRegressorCV()
                
        # Set up string with regression method KNeighborsRegressor
        self.reg_method = "sklearn.neighbors.KNeighborsRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_Lars() method
    def scikit_Lars(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.Lars
        Least Angle Regression model a.k.a. LAR
        """
        
        # Import regression class
        from MLRegMPy import ML_Lars as regr_class
        
        # Instantiate an object of Lars() class
        regr_obj = regr_class.Lars(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_Lars() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_Lars()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Lars"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_LarsCV() method
    def scikit_LarsCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.Lars
        Least Angle Regression model a.k.a. LAR
        """
        
        # Import regression class
        from MLRegMPy import ML_LarsCV as regr_class
        
        # Instantiate an object of LarsCV() class
        regr_obj = regr_class.LarsCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LarsCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LarsCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LarsCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_Lasso() method
    def scikit_Lasso(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.Lasso
        """
        
        # Import regression class
        from MLRegMPy import ML_Lasso as regr_class
        
        # Instantiate an object of Lasso() class
        regr_obj = regr_class.Lasso(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_Lasso() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_Lasso()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Lasso"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
        
    # Define scikit_LassoCV() method
    def scikit_LassoCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoCV
        """
        
        # Import regression class
        from MLRegMPy import ML_LassoCV as regr_class
        
        # Instantiate an object of LassoCV() class
        regr_obj = regr_class.LassoCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LassoCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LassoCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LassoCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_LassoLars() method
    def scikit_LassoLars(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLars
        """
        
        # Import regression class
        from MLRegMPy import ML_LassoLars as regr_class
        
        # Instantiate an object of LassoLars() class
        regr_obj = regr_class.LassoLars(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LassoLars() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LassoLars()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LassoLars"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml() 
    
    # Define scikit_LassoLarsCV() method
    def scikit_LassoLarsCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLarsCV
        """
        
        # Import regression class
        from MLRegMPy import ML_LassoLarsCV as regr_class
        
        # Instantiate an object of LassoLarsCV() class
        regr_obj = regr_class.LassoLarsCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LassoLarsCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LassoLarsCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LassoLarsCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml() 

    # Define scikit_LassoLarsIC() method
    def scikit_LassoLarsIC(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLarsIC
        """
        
        # Import regression class
        from MLRegMPy import ML_LassoLarsIC as regr_class
        
        # Instantiate an object of LassoLarsIC() class
        regr_obj = regr_class.LassoLarsIC(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LassoLarsIC() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LassoLarsIC()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LassoLarsIC"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml() 

    # Define scikit_LassoLarsICCV() method
    def scikit_LassoLarsICCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLarsIC
        """
        
        # Import regression class
        from MLRegMPy import ML_LassoLarsICCV as regr_class
        
        # Instantiate an object of LassoLarsICCV() class
        regr_obj = regr_class.LassoLarsICCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LassoLarsIC() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LassoLarsICCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LassoLarsICCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml() 

    # Define scikit_LinearRegression() method
    def scikit_LinearRegression(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LinearRegression
        """
        
        # Import regression class
        from MLRegMPy import ML_LinearRegression as regr_class
                
        # Instantiate an object of LinearRegression() class
        regr_obj = regr_class.LinearRegression(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LinearRegression() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LinearRegression()

        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model_intercept_,model_coef_)

        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LinearRegression" 
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.fit(self._x_in, self._y_in).coef_,
        model.fit(self._x_in, self._y_in).intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_LinearRegressionCV() method
    def scikit_LinearRegressionCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LinearRegression
        """
        
        # Import regression class
        from MLRegMPy import ML_LinearRegressionCV as regr_class
                
        # Instantiate an object of LinearRegressionCV() class
        regr_obj = regr_class.LinearRegressionCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LinearRegressionCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LinearRegressionCV()

        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model_intercept_,model_coef_)

        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LinearRegressionCV" 
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.fit(self._x_in, self._y_in).coef_,
        model.fit(self._x_in, self._y_in).intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_LinearSVR() method  
    def scikit_LinearSVR(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.LinearSVR
        """
        
        # Import regression class
        from MLRegMPy import ML_LinearSVR as regr_class
        
        # Instantiate an object of LinearSVR() class
        regr_obj = regr_class.LinearSVR(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LinearSVR() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LinearSVR()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LinearSVR"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_LinearSVRCV() method  
    def scikit_LinearSVRCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.LinearSVR
        """
        
        # Import regression class
        from MLRegMPy import ML_LinearSVRCV as regr_class
        
        # Instantiate an object of LinearSVRCV() class
        regr_obj = regr_class.LinearSVRCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_LinearSVRCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_LinearSVRCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.LinearSVRCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_MLPRegressor() method
    def scikit_MLPRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.neural_network.MLPRegressor
        Multi-layer Perceptron Regressor
        """
        
        # Import regression class
        from MLRegMPy import ML_MLPRegressor as regr_class
        
        # Import packages
        from joblib import dump, load
        from sklearn.metrics import mean_squared_error
        from scipy.stats import spearmanr, pearsonr
        
        # Instantiate an object of MLPRegressor() class
        regr_obj = regr_class.MLPRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_MLPRegressor() method
        model = regr_obj.ml_scikit_MLPRegressor()
                
        # Set up string with regression method neural_network
        self.reg_method = "sklearn.neural_netrk.MLPRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                        
    # Define scikit_MLPRegressorCV() method
    def scikit_MLPRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.neural_network.MLPRegressor
        Multi-layer Perceptron Regressor
        """
        
        # Import regression class
        from MLRegMPy import ML_MLPRegressorCV as regr_class
        
        # Import packages
        from joblib import dump, load
        from sklearn.metrics import mean_squared_error
        from scipy.stats import spearmanr, pearsonr
        
        # Instantiate an object of MLPRegressorCV() class
        regr_obj = regr_class.MLPRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_MLPRegressorCV() method
        model = regr_obj.ml_scikit_MLPRegressorCV()
                
        # Set up string with regression method neural_network
        self.reg_method = "sklearn.neural_netrk.MLPRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                        
    # Define scikit_NuSVR() method  
    def scikit_NuSVR(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.NuSVR
        """
        
        # Import regression class
        from MLRegMPy import ML_NuSVR as regr_class
        
        # Instantiate an object of NuSVR() class
        regr_obj = regr_class.NuSVR(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_NuSVR() method
        self.rand_in,self.b,self.reg_model,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_NuSVR()
        
        # Set up string with regression method
        self.reg_method = "sklearn.svm_regmodel.NuSVR"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                            
        # Invoke dump_xml() method
        self.dump_xml()
                                                                
    # Define scikit_NuSVRCV() method  
    def scikit_NuSVRCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.NuSVR
        """
        
        # Import regression class
        from MLRegMPy import ML_NuSVRCV as regr_class
        
        # Instantiate an object of NuSVRCV() class
        regr_obj = regr_class.NuSVRCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_NuSVRCV() method
        self.rand_in,self.b,self.reg_model,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_NuSVRCV()
        
        # Set up string with regression method
        self.reg_method = "sklearn.svm_regmodel.NuSVRCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                            
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_OrthogonalMatchingPursuit() method  
    def scikit_OrthogonalMatchingPursuit(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.OrthogonalMatchingPursuit
        """
        
        # Import regression class
        from MLRegMPy import ML_OrthogonalMatchingPursuit as regr_class
        
        # Instantiate an object of OrthogonalMatchingPursuit() class
        regr_obj = regr_class.OrthogonalMatchingPursuit(self.program_root,
        self.ml_parameters,self._x_in,self._y_in,self.num_indep_var)
        
        # Invoke ml_scikit_OrthogonalMatchingPursuit() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_OrthogonalMatchingPursuit()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.OrthogonalMatchingPursuit"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
                                                                         
    # Define scikit_OrthogonalMatchingPursuitCV() method  
    def scikit_OrthogonalMatchingPursuitCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.OrthogonalMatchingPursuit
        """
        
        # Import regression class
        from MLRegMPy import ML_OrthogonalMatchingPursuitCV as regr_class
        
        # Instantiate an object of OrthogonalMatchingPursuitCV() class
        regr_obj = regr_class.OrthogonalMatchingPursuitCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in,self.num_indep_var)
        
        # Invoke ml_scikit_OrthogonalMatchingPursuitCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_OrthogonalMatchingPursuitCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.OrthogonalMatchingPursuitCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
                                                                         
    # Define scikit_PassiveAggressiveRegressor() method
    def scikit_PassiveAggressiveRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.PassiveAggressiveRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_PassiveAggressiveRegressor as regr_class
        
        # Instantiate an object of PassiveAggressiveRegressor() class
        regr_obj = regr_class.PassiveAggressiveRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_PassiveAggressiveRegressor() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_PassiveAggressiveRegressor()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.PassiveAggressiveRegressor"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
                                                                                 
    # Define scikit_PassiveAggressiveRegressorCV() method
    def scikit_PassiveAggressiveRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.PassiveAggressiveRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_PassiveAggressiveRegressorCV as regr_class
        
        # Instantiate an object of PassiveAggressiveRegressorCV() class
        regr_obj = regr_class.PassiveAggressiveRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_PassiveAggressiveRegressorCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_PassiveAggressiveRegressorCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.PassiveAggressiveRegressorCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
        
    # Define scikit_RandomForestRegressor() method
    def scikit_RandomForestRegressor(self):
        """
        Method to generate a multiple regression model using
        RandomForestRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_RandomForestRegressor as regr_class
                
        # Instantiate an object of RandomForestRegressor() class
        regr_obj = regr_class.RandomForestRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_RandomForestRegressor() method
        model = regr_obj.ml_scikit_RandomForestRegressor()
                
        # Set up string with regression method RandomForestRegressor
        self.reg_method = "sklearn.ensembl.RandomForestRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
    # Define scikit_RandomForestRegressorCV() method
    def scikit_RandomForestRegressorCV(self):
        """
        Method to generate a multiple regression model using
        RandomForestRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_RandomForestRegressorCV as regr_class
                
        # Instantiate an object of RandomForestRegressorCV() class
        regr_obj = regr_class.RandomForestRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_RandomForestRegressorCV() method
        model = regr_obj.ml_scikit_RandomForestRegressorCV()
                
        # Set up string with regression method RandomForestRegressor
        self.reg_method = "sklearn.ensembl.RandomForestRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_RANSACRegressor() method
    def scikit_RANSACRegressor(self):
        """
        Method to generate a multiple regression model using
        RANSACRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_RANSACRegressor as regr_class
                
        # Instantiate an object of RANSACRegressor() class
        regr_obj = regr_class.RANSACRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_RANSACRegressor() method
        model = regr_obj.ml_scikit_RANSACRegressor()
                
        # Set up string with regression method 
        self.reg_method = "sklearn.linear_model.RANSACRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_RANSACRegressorCV() method
    def scikit_RANSACRegressorCV(self):
        """
        Method to generate a multiple regression model using
        RANSACRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_RANSACRegressorCV as regr_class
                
        # Instantiate an object of RANSACRegressorCV() class
        regr_obj = regr_class.RANSACRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_RANSACRegressorCV() method
        model = regr_obj.ml_scikit_RANSACRegressorCV()
                
        # Set up string with regression method 
        self.reg_method = "sklearn.linear_model.RANSACRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_Ridge() method  
    def scikit_Ridge(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.Ridge
        """
        
        # Import regression class
        from MLRegMPy import ML_Ridge as regr_class
        
        # Instantiate an object of Ridge() class
        regr_obj = regr_class.Ridge(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_RidgeCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_Ridge()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.Ridge"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
       
    # Define scikit_RidgeCV() method  
    def scikit_RidgeCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.RidgeCV
        """
        
        # Import regression class
        from MLRegMPy import ML_RidgeCV as regr_class
        
        # Instantiate an object of RidgeCV() class
        regr_obj = regr_class.RidgeCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_RidgeCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_RidgeCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.RidgeCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
                            
    # Define scikit_SGDRegressor() method
    def scikit_SGDRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.SGDRegressor
        Note: SGDRegressor is well suited for regression problems with a large number of training samples (> 10.000), 
        for other problems we recommend Ridge, Lasso, or ElasticNet.
        """
        
        # Import regression class
        from MLRegMPy import ML_SGDRegressor as regr_class
        
        # Instantiate an object of SGDRegressor() class
        regr_obj = regr_class.SGDRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_SGDRegressor() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_SGDRegressor()

        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.SGDRegressor"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_SGDRegressorCV() method
    def scikit_SGDRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.SGDRegressor
        Note: SGDRegressor is well suited for regression problems with a large number of training samples (> 10.000), 
        for other problems we recommend Ridge, Lasso, or ElasticNet.
        """
        
        # Import regression class
        from MLRegMPy import ML_SGDRegressorCV as regr_class
        
        # Instantiate an object of SGDRegressorCV() class
        regr_obj = regr_class.SGDRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_SGDRegressorCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_SGDRegressorCV()

        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.SGDRegressorCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_Stacking() method
    def scikit_Stacking(self):
        """
        Method to generate a multiple regression model using
        an approach that combines predictors using stacking
        """
        
        # Import regression class
        from MLRegMPy import ML_Stacking as regr_class
                
        # Instantiate an object of Stacking() class
        regr_obj = regr_class.Stacking(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_Stacking() method
        model = regr_obj.ml_scikit_Stacking()
                
        # Set up string with regression method neural_network
        self.reg_method = "sklearn.ensembl.StackingRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
    
    # Define scikit_StackingCV() method
    def scikit_StackingCV(self):
        """
        Method to generate a multiple regression model using
        an approach that combines predictors using stacking
        """
        
        # Import regression class
        from MLRegMPy import ML_StackingCV as regr_class
                
        # Instantiate an object of StackingCV() class
        regr_obj = regr_class.StackingCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_StackingCV() method
        model = regr_obj.ml_scikit_StackingCV()
                
        # Set up string with regression method neural_network
        self.reg_method = "sklearn.ensembl.StackingRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
    
    # Define scikit_SVR() method  
    def scikit_SVR(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.SVR
        """
        
        # Import regression class
        from MLRegMPy import ML_SVR as regr_class
                
        # Instantiate an object of SVR() class
        regr_obj = regr_class.SVR(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_SVR() method
        self.rand_in,self.b,self.reg_model,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_SVR()
                      
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.SVR"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                            
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_SVRCV() method  
    def scikit_SVRCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.SVR
        """
        
        # Import regression class
        from MLRegMPy import ML_SVRCV as regr_class
                
        # Instantiate an object of SVRCV() class
        regr_obj = regr_class.SVRCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_SVRCV() method
        self.rand_in,self.b,self.reg_model,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_SVRCV()
                      
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.SVRCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                            
        # Invoke dump_xml() method
        self.dump_xml()

    # Define scikit_TheilSenRegressor() method
    def scikit_TheilSenRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TheilSenRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_TheilSenRegressor as regr_class
        
        # Instantiate an object of TheilSenRegressor() class
        regr_obj = regr_class.TheilSenRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_TheilSenRegressor() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_TheilSenRegressor()

        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.TheilSenRegressor"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_TheilSenRegressorCV() method
    def scikit_TheilSenRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TheilSenRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_TheilSenRegressorCV as regr_class
        
        # Instantiate an object of TheilSenRegressorCV() class
        regr_obj = regr_class.TheilSenRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_TheilSenRegressorCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_TheilSenRegressorCV()

        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
                                
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.TheilSenRegressorCV"  
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
    
    # Define scikit_TweedieRegressor() method
    def scikit_TweedieRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TweedieRegressor
        """
    
        # Import regression class
        from MLRegMPy import ML_TweedieRegressor as regr_class
        
        # Instantiate an object of TweedieRegressor() class
        regr_obj = regr_class.TweedieRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_TweedieRegressor() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_TweedieRegressor()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.TweedieRegressor"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
 
    # Define scikit_TweedieRegressorCV() method
    def scikit_TweedieRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TweedieRegressor
        """
    
        # Import regression class
        from MLRegMPy import ML_TweedieRegressorCV as regr_class
        
        # Instantiate an object of TweedieRegressorCV() class
        regr_obj = regr_class.TweedieRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_TweedieRegressorCV() method
        self.rand_in,model,model_intercept_,model_coef_ = regr_obj.ml_scikit_TweedieRegressorCV()
        
        # Invoke gen_regression_model_string() method
        self.gen_regression_model_string(model.intercept_,model.coef_)
        
        # Set up string with regression method
        self.reg_method = "sklearn.linear_model.TweedieRegressorCV"
        
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
        # Invoke dump_json_model() method
        self.dump_json_model(model.coef_,model.intercept_)
                    
        # Invoke dump_xml() method
        self.dump_xml()
 
    # Define scikit_VotingRegressor() method
    def scikit_VotingRegressor(self):
        """
        Method to generate a multiple regression model using
        VotingRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_VotingRegressor as regr_class
                
        # Instantiate an object of VotingRegressor() class
        regr_obj = regr_class.VotingRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_VotingRegressor() method
        model = regr_obj.ml_scikit_VotingRegressor()
                
        # Set up string with regression method VotingRegressor
        self.reg_method = "sklearn.ensembl.VotingRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)

    # Define scikit_VotingRegressorCV() method
    def scikit_VotingRegressorCV(self):
        """
        Method to generate a multiple regression model using
        VotingRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_VotingRegressorCV as regr_class
                
        # Instantiate an object of VotingRegressorCV() class
        regr_obj = regr_class.VotingRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_VotingRegressorCV() method
        model = regr_obj.ml_scikit_VotingRegressorCV()
                
        # Set up string with regression method VotingRegressor
        self.reg_method = "sklearn.ensembl.VotingRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
        
    # Define scikit_XGBRegressor() method
    def scikit_XGBRegressor(self):
        """
        Method to generate a multiple regression model using
        XGBRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_XGBRegressor as regr_class
                
        # Instantiate an object of XGBRegressor() class
        regr_obj = regr_class.XGBRegressor(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_XGBRegressor() method
        model = regr_obj.ml_scikit_XGBRegressor()
                
        # Set up string with regression method XGBRegressor
        self.reg_method = "sklearn.ensembl.XGBRegressor"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
                        
    # Define scikit_XGBRegressorCV() method
    def scikit_XGBRegressorCV(self):
        """
        Method to generate a multiple regression model using
        XGBRegressor
        """
        
        # Import regression class
        from MLRegMPy import ML_XGBRegressorCV as regr_class
                
        # Instantiate an object of XGBRegressorCV() class
        regr_obj = regr_class.XGBRegressorCV(self.program_root,
        self.ml_parameters,self._x_in,self._y_in)
        
        # Invoke ml_scikit_XGBRegressorCV() method
        model = regr_obj.ml_scikit_XGBRegressorCV()
                
        # Set up string with regression method XGBRegressor
        self.reg_method = "sklearn.ensembl.XGBRegressorCV"
                
        # Invoke dump_joblib_model() method
        self.dump_joblib_model(model)
      
    # Define basic_statistical_analysis() method
    def basic_statistical_analysis(self):
        """Method to carry out basic statistical calculation"""
                
        # Prepare arrays for scikit
        self.prep_y1()
        self.prep_x1()
        
        # Select regression method
        if self.selected_method_in == "AdaBoostRegressor":
            self.scikit_AdaBoostRegressor()
        elif self.selected_method_in == "AdaBoostRegressorCV":
            self.scikit_AdaBoostRegressorCV()
        elif self.selected_method_in == "ARDRegression":
            self.scikit_ARDRegression()
        elif self.selected_method_in == "ARDRegressionCV":
            self.scikit_ARDRegressionCV()
        elif self.selected_method_in == "BaggingRegressor":
            self.scikit_BaggingRegressor()
        elif self.selected_method_in == "BaggingRegressorCV":
            self.scikit_BaggingRegressorCV()
        elif self.selected_method_in == "BayesianRidge":
            self.scikit_BayesianRidge()
        elif self.selected_method_in == "BayesianRidgeCV":
            self.scikit_BayesianRidgeCV()
        elif self.selected_method_in == "DecisionTreeRegressor":
            self.scikit_DecisionTreeRegressor()
        elif self.selected_method_in == "DecisionTreeRegressorCV":
            self.scikit_DecisionTreeRegressorCV()
        elif self.selected_method_in == "ElasticNet":
            self.scikit_ElasticNet()
        elif self.selected_method_in == "ElasticNetCV":
            self.scikit_ElasticNetCV()
        elif self.selected_method_in == "ExtraTreeRegressor":
            self.scikit_ExtraTreeRegressor()
        elif self.selected_method_in == "ExtraTreeRegressorCV":
            self.scikit_ExtraTreeRegressorCV()
        elif self.selected_method_in == "ExtraTreesRegressor":
            self.scikit_ExtraTreesRegressor()
        elif self.selected_method_in == "ExtraTreesRegressorCV":
            self.scikit_ExtraTreesRegressorCV()
        elif self.selected_method_in == "GaussianProcessRegressor":
            self.scikit_GaussianProcessRegressor()
        elif self.selected_method_in == "GaussianProcessRegressorCV":
            self.scikit_GaussianProcessRegressorCV()
        elif self.selected_method_in == "GradientBoostingRegressor":
            self.scikit_GradientBoostingRegressor()
        elif self.selected_method_in == "GradientBoostingRegressorCV":
            self.scikit_GradientBoostingRegressorCV()
        elif self.selected_method_in == "HuberRegressor":
            self.scikit_HuberRegressor()
        elif self.selected_method_in == "HuberRegressorCV":
            self.scikit_HuberRegressorCV()
        elif self.selected_method_in == "KernelRidge":
            self.scikit_KernelRidge()
        elif self.selected_method_in == "KernelRidgeCV":
            self.scikit_KernelRidgeCV()
        elif self.selected_method_in == "KNeighborsRegressor":
            self.scikit_KNeighborsRegressor()
        elif self.selected_method_in == "KNeighborsRegressorCV":
            self.scikit_KNeighborsRegressorCV()
        elif self.selected_method_in == "Lars":
            self.scikit_Lars()
        elif self.selected_method_in == "LarsCV":
            self.scikit_LarsCV()
        elif self.selected_method_in == "Lasso":
            self.scikit_Lasso()
        elif self.selected_method_in == "LassoCV":
            self.scikit_LassoCV()
        elif self.selected_method_in == "LassoLars":
            self.scikit_LassoLars()
        elif self.selected_method_in == "LassoLarsCV":
            self.scikit_LassoLarsCV()
        elif self.selected_method_in == "LassoLarsIC":
            self.scikit_LassoLarsIC()
        elif self.selected_method_in == "LassoLarsICCV":
            self.scikit_LassoLarsICCV()
        elif self.selected_method_in == "LinearRegression":
            self.scikit_LinearRegression()
        elif self.selected_method_in == "LinearRegressionCV":
            self.scikit_LinearRegressionCV()
        elif self.selected_method_in == "LinearSVR":
            self.scikit_LinearSVR()
        elif self.selected_method_in == "LinearSVRCV":
            self.scikit_LinearSVRCV()
        elif self.selected_method_in == "MLPRegressor":
            self.scikit_MLPRegressor()
        elif self.selected_method_in == "MLPRegressorCV":
            self.scikit_MLPRegressorCV()
        elif self.selected_method_in == "NuSVR":
            self.scikit_NuSVR()
        elif self.selected_method_in == "NuSVRCV":
            self.scikit_NuSVRCV()
        elif self.selected_method_in == "OrthogonalMatchingPursuit":
            self.scikit_OrthogonalMatchingPursuit()
        elif self.selected_method_in == "OrthogonalMatchingPursuitCV":
            self.scikit_OrthogonalMatchingPursuitCV()
        elif self.selected_method_in == "PassiveAggressiveRegressor":
            self.scikit_PassiveAggressiveRegressor()
        elif self.selected_method_in == "PassiveAggressiveRegressorCV":
            self.scikit_PassiveAggressiveRegressorCV()
        elif self.selected_method_in == "RandomForestRegressor":
            self.scikit_RandomForestRegressor()
        elif self.selected_method_in == "RandomForestRegressorCV":
            self.scikit_RandomForestRegressorCV()
        elif self.selected_method_in == "RANSACRegressor":
            self.scikit_RANSACRegressor()
        elif self.selected_method_in == "RANSACRegressorCV":
            self.scikit_RANSACRegressorCV()
        elif self.selected_method_in == "Ridge":
            self.scikit_Ridge()
        elif self.selected_method_in == "RidgeCV":
            self.scikit_RidgeCV()
        elif self.selected_method_in == "SGDRegressor":
            self.scikit_SGDRegressor()
        elif self.selected_method_in == "SGDRegressorCV":
            self.scikit_SGDRegressorCV()
        elif self.selected_method_in == "Stacking":
            self.scikit_Stacking()
        elif self.selected_method_in == "StackingCV":
            self.scikit_StackingCV()
        elif self.selected_method_in == "SVR":
            self.scikit_SVR()
        elif self.selected_method_in == "SVRCV":
            self.scikit_SVRCV()
        elif self.selected_method_in == "TheilSenRegressor":
            self.scikit_TheilSenRegressor()
        elif self.selected_method_in == "TheilSenRegressorCV":
            self.scikit_TheilSenRegressorCV()
        elif self.selected_method_in == "TweedieRegressor":
            self.scikit_TweedieRegressor()
        elif self.selected_method_in == "TweedieRegressorCV":
            self.scikit_TweedieRegressorCV()
        elif self.selected_method_in == "VotingRegressor":
            self.scikit_VotingRegressor()
        elif self.selected_method_in == "VotingRegressorCV":
            self.scikit_VotingRegressorCV()
        elif self.selected_method_in == "XGBRegressor":
            self.scikit_XGBRegressor()
        elif self.selected_method_in == "XGBRegressorCV":
            self.scikit_XGBRegressorCV()
        else:
            sys.exit("\nError! No such regression method!")  
        
        # Carry out statistical analysis for all methods but those in 
        # self.list_methods
        if self.selected_method_in not in self.list_methods:
            
            # Invoke gen_modelMultD() method
            self.gen_modelMultD2()
        
            # Invoke calc_SE_M() method
            self.calc_SE_M()
        
            # Invoke stat_analysis_of_reg_models() method
            self.stat_analysis_of_reg_models()
        
            # Calculate self.inv_xx
            self.inv_xx = inv(dot(self.x.T,self.x))
        
            # Calculate statistical formulas
            self.nobs = self.y.shape[0]                         # Number of observations
            self.ncoef = self.x.shape[1]                        # Number of coefficients
            self.df_e = self.nobs - self.ncoef                  # Degrees of freedom, error 
            self.df_r = self.ncoef - 1                          # Degrees of freedom, regression 
        
            # Try to calculate
            try:
                self.e = self.y - dot(self.x,self.b)            # Residuals
            except:
                self.e = 1.0
    
            self.sse = dot(self.e,self.e)/self.df_e             # SSE
            self.se1 = sqrt(diagonal(self.sse*self.inv_xx))     # Coefficient of standard errors
            self.t = self.b / self.se1                          # Coefficient of  t-statistics
            self.p = (1-stats.t.cdf(abs(self.t), self.df_e))*2  # Coefficient of  p-values

            # Loop to calculate RSS (Residual Sum of Squares) and TSS (Total Sum of Squares)
            self.rss1 = 0
            self.tss = 0
            self.aver_y = average(self.y)
            for i in range(len(self.y)):
                try:
                    self.rss1 += (self.e[i])**2
                except:
                    self.rss1 += 1.0
                self.tss += (self.y[i] - self.aver_y)**2 
        
            self.R2 = 1 - self.rss1/self.tss                                    # model R-squared
            self.R2adj = 1-(1-self.r2S)*((self.nobs-1)/(self.nobs-self.ncoef))  # adjusted R-square
            self.F = (self.r2S/self.df_r) / ((1-self.r2S)/self.df_e)            # model F-statistic
            self.Fpv = 1-stats.f.cdf(self.F, self.df_r, self.df_e)              # F-statistic p-value
            self.sd = self.s_dev                                                # standard deviation
            self.Q = self.corr_p/self.sd 
    
    # Define summary() method
    def summary(self):
        """ Method for returning statistical analysis of regression models"""
        
        # Test if self.selected_method_in is in self.list_methods
        if self.selected_method_in in self.list_methods:
            
            # Invoke read_joblib_MLPRegressor_model() method
            self.read_joblib_MLPRegressor_model(self.model_out_file,self._x_in,self._y_in,self.num_indep_var)
                        
            # Calculate statistical parameters
            self.nobs = self.y.shape[0]                                         # Number of observations
            self.ncoef = self.x.shape[1]                                        # Number of coefficients
            # Try to calculate
            try:
                self.e = self.y - dot(self.x,self.b)                            # Residuals
            except:
                self.e = 1.0
            self.df_e = self.nobs - self.ncoef                                  # Degrees of freedom, error 
            self.sse = dot(self.e,self.e)/self.df_e                             # SSE
            self.inv_xx = inv(dot(self._x_in.T,self._x_in))                     # Calculate self.inv_xx
            self.se1 = sqrt(diagonal(self.sse*self.inv_xx))                     # Coefficient of standard errors
            self.R2adj = 1-(1-self.r2S)*((self.nobs-1)/(self.nobs-self.ncoef))  # adjusted R-square
            self.b = np.zeros(self.num_indep_var+1)                             # Zeros array only to keep the 
                                                                                # same structure for MLPRegressor
                                                                                # model is in loblib file
            self.R2 = self.r2S                                                  # adjusted R-square
            self.sd = self.s_dev                                                # standard deviation
            self.Q = self.corr_p/self.sd 
        
        # To avoid error messages
        if str(self.corr_s) == "nan":
            self.corr_s,self.pvalue_s = 0.0,1.0

        # Return statistical analysis parameters
        return self.nobs,self.b,self.corr_p,self.R2,self.pvalue_p,self.R2adj,self.sd,self.corr_s,\
            self.pvalue_s,self.f_stat,self.se1,self.Q, self.y_pred