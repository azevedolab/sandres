#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define NuSVR() class
class NuSVR(object):
    """Class to carry out  Nu support vector regression
    Nu Support Vector Regression (NuSVR)

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : {array-like, sparse matrix}, shape (n_samples, n_features). Training vectors,
                                where n_samples is the number of samples and n_features is the number of features.
                                For kernel=”precomputed”, the expected shape of X is (n_samples, n_samples).
                                Training vector, where n_samples in the number of samples and n_features is the number of features.
        y                       : array-like, shape (n_samples,)
                                Target values (class labels in classification, real numbers in regression)

    Outputs
       self.rand_in             : Random seed
       self.b:                  : array with coefficients
       self.reg_model           : String with regression model "y = ..."
       model                    : Regression model
       model.intercept_         : array, shape = [1]. Constants in decision function.
       model.coef_              : array, shape = [1, n_features]
                                Weights assigned to the features (coefficients in the primal problem).
                                This is only available in the case of a linear kernel.
                                coef_ is readonly property derived from dual_coef_ and support_vectors_.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_NuSVR() method
    def ml_scikit_NuSVR(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.NuSVR
        """

        # Import packages
        from sklearn.svm import NuSVR
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.svm.NuSVR.html
        #
        # string_reg_method = NuSVR (Nu Support Vector Regression)
        #
        #
        # nu: float, optional
        # An upper bound on the fraction of training errors and a lower bound of
        # the fraction of support vectors.
        # Should be in the interval (0, 1]. By default 0.5 will be taken.
        #
        # C: float, optional (default=1.0)
        # Penalty parameter C of the error term.
        #
        # kernel: string, optional (default=’rbf’)
        # Specifies the kernel type to be used in the algorithm. It must be one
        # of ‘linear’, ‘poly’, ‘rbf’, ‘sigmoid’, ‘precomputed’ or a callable.
        # If none is given, ‘rbf’ will be used.
        # If a callable is given it is used to precompute the kernel matrix.
        #
        # degree: int, optional (default=3)
        # Degree of the polynomial kernel function (‘poly’). Ignored by all
        # other kernels.
        #
        # gamma: {‘scale’, ‘auto’} or float, optional (default=’scale’)
        # Kernel coefficient for ‘rbf’, ‘poly’ and ‘sigmoid’.
        # if gamma='scale' (default) is passed then
        # it uses 1 / (n_features * X.var()) as value of gamma,
        # if ‘auto’, uses 1 / n_features.
        #
        # coef0: float, optional (default=0.0)
        # Independent term in kernel function. It is only significant in ‘poly’
        # and ‘sigmoid’.
        #
        # shrinking: boolean, optional (default=True)
        # Whether to use the shrinking heuristic.
        #
        # tol: float, optional (default=1e-3)
        # Tolerance for stopping criterion.
        #
        # cache_size: float, optional
        # Specify the size of the kernel cache (in MB).
        #
        # verbose: bool, default: False
        # Enable verbose output. Note that this setting takes advantage of a
        # per-process runtime setting in libsvm that,
        # if enabled, may not work properly in a multithreaded context.
        #
        # max_iter: int, optional (default=-1)
        # Hard limit on iterations within solver, or -1 for no limit.

        # Show message
        print("\nNu Support Vector Regression (NuSVR)")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "NuSVR":
                # For nu_in
                nu_in = float(line[1])

                # For C_in
                C_in = float(line[2])

                # For kernel_in
                kernel_in = line[3]

                # For degree_in
                degree_in = int(line[4])

                # For gamma_in
                try:
                    gamma_in = float(line[5])
                except:
                    gamma_in = line[5]

                # For coef0_in
                coef0_in = float(line[6])

                # For shrinking_in
                if line[7] == "True":
                    shrinking_in = True
                else:
                    shrinking_in = False

                # For tol_in
                tol_in = float(line[8])

                # For cache_size_in
                cache_size_in = float(line[9])

                # For ver_in
                if line[10] == "True":
                    ver_in = True
                else:
                    ver_in = False

                # For max_iter_in
                max_iter_in = int(line[11])

                # For cv_in
                cv_in = int(line[12])

                # For self.rand_in (not used for NuSVR but for MDM file)
                self.rand_in = int(line[13])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Kernel type to be used in the algorithm: {}".format(kernel_in))
        print("Degree of the polynomial kernel function: {}".format(degree_in))
        print("Gamma = {}".format(gamma_in))
        print("Independent term in kernel function: {:.5e}".format(coef0_in))
        print("Tolerance for stopping criterion: {:.5e}".format(tol_in))
        print("Regularization parameter (C): {:.5e}".format(C_in))
        print("Whether to use the shrinking heuristic: {}".format(shrinking_in))
        print("Cache size (MB): {:.5e}".format(cache_size_in))
        print("Hard limit on iterations: {}".format(max_iter_in))

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of NuSVR class
        model = NuSVR(
                nu=nu_in,                   # nu: float, optional
                C=C_in,                     # C: float, optional (default=1.0)
                kernel=kernel_in,           # kernel: string, optional (default=’rbf’)
                degree=degree_in,           # degree: int, optional (default=3)
                gamma=gamma_in,             # gamma: {‘scale’, ‘auto’} or float, optional (default=’scale’)
                coef0=coef0_in,             # coef0: float, optional (default=0.0)
                shrinking=shrinking_in,     # shrinking: boolean, optional (default=True)
                tol=tol_in,                 # tol: float, optional (default=1e-3)
                cache_size=cache_size_in,   # cache_size: float, optional
                verbose=ver_in,             # verbose: bool, default: False
                max_iter=max_iter_in        # max_iter: int, optional (default=-1)
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Generate string with regression equation
        columns = len(self.X[0])
        self.reg_model = str("y = {:.5f}".format(float(model.intercept_)))
        for i in range(columns):
                aux_string = str(" + {:.5}".format(model.coef_[0][i]))+"x"+str(i+1)
                self.reg_model += aux_string

        # Get Multiple model
        alphas = []
        alphas.append(float(model.intercept_))
        for i in range(columns):
            alphas.append(model.coef_[0][i])

        # Set up array with coefficients
        self.b = np.array(alphas)

        # Return model and parameters
        return self.rand_in,self.b,self.reg_model,model,model.intercept_,model.coef_