#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define TweedieRegressorCV() class
class TweedieRegressorCV(object):
    """Class to carry out ElasticNet regression with cross-validation

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : {array-like}, shape (n_samples, n_features). Training data.
        y                       : array-like, shape (n_samples,) or (n_samples, n_targets)
                                Target values

    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : Independent term in decision function. Set to 0.0 if fit_intercept = False.
       model.coef_              : Coefficients of the regression model (mean of distribution)
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_TweedieRegressorCV() method
    def ml_scikit_TweedieRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TweedieRegressorCV
        """

        # Import packages
        from sklearn.linear_model import TweedieRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.TweedieRegressor.html
        #
        # string_reg_method = TweedieRegressorCV
        #
        #
        # power: float, default=0.0
        # The power determines the underlying target distribution according to
        # the following table:
        # Power Distribution
        # 0     Normal
        # 1     Poisson
        # (1,2) Compound Poisson Gamma
        # 2     Gamma
        # 3     Inverse Gaussian
        # For 0 < power < 1, no distribution exists.
        #
        # alpha: float, default=1.0
        # Constant that multiplies the penalty term and thus determines the
        # regularization strength. alpha = 0 is equivalent to unpenalized GLMs.
        # In this case, the design matrix X must have full column rank
        # (no collinearities).
        #
        # fit_intercept: bool, default=True
        # Specifies if a constant (a.k.a. bias or intercept) should be added to
        # the linear predictor (X @ coef + intercept).
        #
        # link: {"auto","identity","log"}, default="auto"
        # The link function of the GLM, i.e. mapping from linear
        # predictor X @ coeff + intercept to prediction y_pred.
        # Option "auto" sets the link depending on the chosen family as follows:
        # "identity" for Normal distribution
        # "log" for Poisson, Gamma and Inverse Gaussian distributions
        #
        # max_iter: int, default=100
        # The maximal number of iterations for the solver.
        #
        # tol: float, default=1e-4
        # Stopping criterion. For the lbfgs solver, the iteration will stop
        # when max{|g_j|, j = 1, ..., d} <= tol where g_j is the j-th component
        # of the gradient (derivative) of the objective function.
        #
        # warm_start: bool, default=False
        # If set to True, reuse the solution of the previous call to fit as
        # initialization for coef_ and intercept_ .
        #
        # verbose: int, default=0
        # For the lbfgs solver set verbose to any positive number for verbosity.

        # Show messages
        print("\nTweedie Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "TweedieRegressorCV":

                # For power_in
                power_in = float(line[1].strip())

                # For alpha_in
                alpha_in = float(line[2].strip())

                # For fit_intercept_in
                if line[3].strip() == "True":
                    fit_intercept_in = True
                else:
                    fit_intercept_in = False


                # Link_in
                list_link = ["auto","identity","log"]
                if line[4].strip() in list_link:
                    link_in = line[4].strip()
                else:
                    link_in = "auto"
                    print("Unrecognizable input!")

                # For max_iter_in
                max_iter_in = int(line[5].strip())

                # For tol_in
                tol_in = float(line[6].strip())

                # For warm_start_in
                if line[7].strip() == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For verbose_in
                verbose_in = int(line[8].strip())

                # For rand_in
                if line[9].strip() == "None":
                    rand_in = None
                else:
                    rand_in = int(line[9].strip())

                # For cv_in
                cv_in = int(line[10].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("This power determines the underlying target distribution: ",
        line[1])
        print("Constant that multiplies the penalty term: ",line[2])
        print("Specifies if a constant should be added to the linear predictor: ",
        line[3])
        print("Link function of the Generalized Linear Model (GLM): ",line[4])
        print("Maximum number of iterations: ",line[5])
        print("Stopping criterion: ",line[6])
        print("If set to True, reuse the solution of the previous call: ",
        line[7])
        print("Verbose: ",line[8])
        print("Kfold class to build a N-fold cross-validation loop. N :",
        line[10])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of TweedieRegressor() class
        model = TweedieRegressor(
                power=power_in,             # power: float, default=0.0
                alpha=alpha_in,             # alpha: float, default=1.0
                fit_intercept=fit_intercept_in,     # fit_intercept: bool, default=True
                link=link_in,               # link: {"auto","identity","log"}, default="auto"
                max_iter=max_iter_in,       # max_iter: int, default=100
                tol=tol_in,                 # tol: float, default=1e-4
                warm_start=warm_start_in,   # warm_start: bool, default=False
                verbose=verbose_in          # verbose: int, default=0
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_