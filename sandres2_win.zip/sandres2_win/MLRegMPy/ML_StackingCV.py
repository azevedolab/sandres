#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define StackingCV() class
class StackingCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_StackingCV() method
    def ml_scikit_StackingCV(self):
        """
        Method to generate a multiple regression model using
        an approach that combines predictors using stacking
        """

        # Import packages
        from sklearn.ensemble import StackingRegressor
        from sklearn.ensemble import RandomForestRegressor
        from sklearn.experimental import enable_hist_gradient_boosting
        from sklearn.ensemble import HistGradientBoostingRegressor
        from sklearn.linear_model import LassoCV
        from sklearn.linear_model import RidgeCV
        from sklearn.model_selection import cross_validate, cross_val_predict
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.StackingCV.html#sklearn.neural_network.Stacking
        #
        # string_reg_method = StackingCV
        #

        # Show message
        print("\nStacking Regression with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "StackingCV":

                # For hidden_layer_size_in
                hidden_layer_size_in = int(line[1])

                # For activation_in
                activation_in = line[2]

                # For solver_in
                solver_in = line[3]

                # For alpha_in
                alpha_in = float(line[4])

                # For batch_size_in
                try:
                    batch_size_in = int(line[5])
                except:
                    batch_size_in = "auto"

                # For learning_rate_in
                learning_rate_in = line[6]

                # For learning_rate_init_in
                learning_rate_init_in = float(line[7])

                # For power_t_in
                power_t_in = float(line[8])

                # For max_in
                max_in = int(line[9])

                # For shuffle_in
                if line[10] == "True":
                    shuffle_in = True
                else:
                    shuffle_in = False

                # For self.rand_in
                try:
                    self.rand_in = int(line[11])
                except:
                    self.rand_in = None

                # For tol_in
                tol_in = float(line[12])

                # For ver_in
                if line[13] == "True":
                    ver_in = True
                else:
                    ver_in = False

                # For warm_start_in
                if line[14] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For momentum_in
                momentum_in = float(line[15])

                # For nesterovs_momentum_in
                if line[16] == "True":
                    nesterovs_momentum_in = True
                else:
                    nesterovs_momentum_in = False

                # For early_stopping_in
                if line[17] == "True":
                    early_stopping_in = True
                else:
                    early_stopping_in = False

                # For validation_fraction_in
                validation_fraction_in = float(line[18])

                # For beta_1_in
                beta_1_in = float(line[19])

                # For beta_2_in
                beta_2_in = float(line[20])

                # For epsilon_in
                epsilon_in = float(line[21])

                # For n_iter_no_change_in
                n_iter_no_change_in = int(line[22])

                # For max_fun_in
                max_fun_in = int(line[23])

                # For cv_in (set value to 5)
                cv_in = int(line[24])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Number of hidden layers: {}".format(hidden_layer_size_in))
        print("Activation function for the hidden layer: ",line[2])
        print("The solver for weight optimization: ",line[3])
        print("L2 penalty (regularization term) parameter: {:.5e}".format(alpha_in))
        print("Size of minibatches for stochastic optimizers: ",line[5])
        print("Learning rate schedule for weight updates: ",line[6])
        print("The initial learning rate used: {:.5e}".format(learning_rate_init_in))
        print("The exponent for inverse scaling learning rate: {:.5e}".format(power_t_in))
        print("Maximum number of iterations: {}".format(max_in))
        print("Whether to shuffle samples in each iteration: ",line[10])
        print("Random state: ",line[11])
        print("Tolerance for the optimization: {:.5e}".format(tol_in))
        print("Warm start? ",line[14])
        print("Momentum for gradient descent update: {:.5e}".format(momentum_in))
        print("Whether to use Nesterov’s momentum: ",line[16])
        print("Whether to use early stopping to terminate training when validation score is not improving: ",line[17])
        print("The proportion of training data to set aside as validation set for early stopping: ",line[18])
        print("Exponential decay rate for estimates of first moment vector in adam, should be in [0, 1): ",line[19])
        print("Exponential decay rate for estimates of second moment vector in adam, should be in [0, 1): ",line[20])
        print("Value for numerical stability in adam: ",line[21])
        print("Maximum number of epochs to not meet tol improvement: ",line[22])
        print("Maximum number of function calls (solver=’lbfgs’): ",line[23])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Define the regressors
        estimators = [
            ('Random Forest', RandomForestRegressor(random_state=42)),
            ('Lasso', LassoCV()),
            ('Gradient Boosting', HistGradientBoostingRegressor(random_state=0))
        ]
        model = StackingRegressor(
            estimators=estimators, final_estimator=RidgeCV()
        )

        # dummy variable only to have something to zip
        dummy = np.zeros(len(self.y))

        # Find the best method for regression
        for _, (name, est) in zip(dummy, estimators + [('Stacking Regressor',
                                                    model)]):

            score = cross_validate(est, self.X, self.y,
                                scoring=['r2', 'neg_mean_absolute_error'],
                                n_jobs=-1, verbose=0)


            y_pred = cross_val_predict(est, self.X, self.y, n_jobs=-1, verbose=0)

        ############################################################################

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model