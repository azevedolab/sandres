################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import os
import sys
from tools import tkinter_tools as tk_tools

# Set up program root directory
program_root = os.getcwd()+"/"

# Set the directory where Python scripts are
sys.path.append(program_root)

# Instantiate an object of GUI() class
gui1 = tk_tools.GUI(program_root)

# Invoke a open_main_gui() method
gui1.open_main_gui()