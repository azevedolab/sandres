# Class to download structural and binding data.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
from tkinter import *
from tools import string_tools as string_t
from tools import download_str as get_str
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs

# Instantiate an object of the Palavra class
a1 = string_t.Palavra("","pdb_codes.csv")

# Invoke ascii_art() method
_,pdb_ascii_art,_,_,_,_,_ = a1.ascii_art()

# Define PDBData() class
class PDBData(object):
    """Class to download structural and binding data"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Set up PDB message
        self.ref_pdb = "\nWhen using PDB data for machine learning modeling, "
        self.ref_pdb += "please cite: Veit-Acosta M, de Azevedo Junior WF. "
        self.ref_pdb += "The Impact of Crystallographic Data for the "
        self.ref_pdb += "Development of Machine Learning Models to Predict "
        self.ref_pdb += "Protein-Ligand Binding Affinity. Curr Med Chem. 2021; "
        self.ref_pdb += "28(34):7006-7022. "
        self.ref_pdb += "doi: 10.2174/0929867328666210210121320. "
        self.ref_pdb += "PMID: 33568025."
        self.pdb_short_msg = pdb_ascii_art+self.ref_pdb

    # Define pdb_GUI() method
    def pdb_GUI(self):
        """GUI to download PDB files"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Instantiate an object of the Palavra class
        p1 = string_t.Palavra(project_dir_string,"pdb_codes.csv")

        # Call count_codes() method
        number_of_pdbs = int(p1.count_codes())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_short_msg() method
        msg_out = "Number of structures in the pdb_codes.csv file: {:8d}".\
        format(number_of_pdbs)
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Define update_pdb_codes() function
        def update_pdb_codes(file_bind_in):
            """Function to read bind_####.csv file and update PDB access codes
            in the pdb_codes.csv file"""

            # Set up file_2_open
            file_2_open = project_dir_string+file_bind_in

            # Set up empty string
            pdb_string = ""

            # Try to open bind_####.csv file
            try:
                fo_bind_in = open(file_2_open,"r")
                csv_bind_in = csv.reader(fo_bind_in)

            # Handle exception
            except IOError:

                # Show message
                msg_out = "IOError! I can't find "+file_2_open+" file."
                msg1.show_botton_msg(msg_out,"red","light grey")
                print(msg_out)
                return

            # Read first line of bind_####.csv file (header)
            for line in csv_bind_in:
                break

            # Read the PDB access codes from bind_####.csv file
            for line in csv_bind_in:
                pdb_string += str(line[0]).replace(" ","")+","

            # Open pdb_codes.csv
            fo_pdb_codes = open(project_dir_string+"pdb_codes.csv","w")

            # Write an updated list of PDB access codes
            fo_pdb_codes.write(pdb_string[:len(pdb_string)-1])

            # Close files
            fo_bind_in.close()
            fo_pdb_codes.close()

        # Define function to download all structures from the PDB
        def pdb_xtal_all():
            """Function to download all structures showing a progress bar"""

            # Invoke progress_bar_pdb()
            self.progress_bar_pdb("Download All Structures")

        # Define function to download structures with Ki data from the PDB
        def pdb_xtal_binding_ki():
            """Function to download structures with Ki data
            showing a progress bar"""

            # Call update_pdb_codes() function
            update_pdb_codes("bind_Ki.csv")

            # Invoke progress_bar_pdb()
            self.progress_bar_pdb("Download Structures with Ki Data")

        # Define function to download structures with Kd data from the PDB
        def pdb_xtal_binding_kd():
            """Function to download structures with Kd data
            showing a progress bar"""

            # Call update_pdb_codes() function
            update_pdb_codes("bind_Kd.csv")

            # Invoke progress_bar_pdb()
            self.progress_bar_pdb("Download Structures with Kd Data")

        # Define function to download structures with IC50 data from the PDB
        def pdb_xtal_binding_ic50():
            """Function to download structures with IC50 data
            showing a progress bar"""

            # Call update_pdb_codes() function
            update_pdb_codes("bind_IC50.csv")

            # Invoke progress_bar_pdb()
            self.progress_bar_pdb("Download Structures with IC50 Data")

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('Protein Data Bank')
        top_txt.geometry(top_txt_geom)

        # Widgets for project directory
        Label(top_txt,
            text = "Download Structures from the PDB:" ).grid(row = 0,
            column = 0, stick = W, padx = 0)

        # Widget for downloading all PDB files (with progress bar)
        Button(top_txt,text='All',\
            command=pdb_xtal_all).grid(row=0,column=1,sticky = W)

        # Widget for downloading PDB files with Ki data (with progress bar)
        Button(top_txt,text='with Ki data',\
            command=pdb_xtal_binding_ki).grid(row=0,column=2,sticky = W)

        # Widget for downloading PDB files with Kd data (with progress bar)
        Button(top_txt,text='with Kd data',\
            command=pdb_xtal_binding_kd).grid(row=0,column=3,sticky = W)

        # Widget for downloading PDB files with IC50 data (with progress bar)
        Button(top_txt,text='with IC50 data',\
            command=pdb_xtal_binding_ic50).grid(row=0,column=4,sticky = W)

        # Show Empty Label
        Label(top_txt, text=14*" ",font="Arial").grid(row=2,column=5,stick = W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
        command=top_txt.destroy).grid(row = 3, column = 11,sticky = E)

    # Define progress_bar_pdb() method
    def progress_bar_pdb(self,progress_bar_pdb_title):
        """Method to download PDB files"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Instantiate an object of the Palavra class
        p1 = string_t.Palavra(project_dir_string,"pdb_codes.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Call count_codes() method
        number_of_pdbs = p1.count_codes()

        # Call read_program() method
        #url_in,_,_ = self.pr1.read_program()

        # Try to open strpdb.in file
        input2open = self.program_root+"misc/inputs/strpdb.in"
        try:
            fo_strpdb = open(input2open,"r")
            csv_strpdb = csv.reader(fo_strpdb)

            # Looping through csv_strpdb
            for line in csv_strpdb:
                if line[0] == "pdburl":
                    url_in = line[1]

            # Close file
            fo_strpdb.close()

        # Handle IOError exception
        except:
            print("\nIOError! I can't find "+input2open+" file!")
            return

        # Call backup_file() method
        p1.backup_file("xtal.log")

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160)(52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_3,self.win_y_offset_type_3)

        # Create xtal.log
        fo_xtal = open(project_dir_string+"xtal.log","w")

        # Try to open pdb_codes.csv file
        try:
            my_fo = open(project_dir_string+"pdb_codes.csv","r")
        except IOError:
            print("IOError! I can't find ",project_dir_string+
            "pdb_codes.csv")
            print("New pdb_codes.csv file will be generated!")
            return

        # Set up full name for pdb directory, where PDB files will be
        my_dir = project_dir_string+"pdb/"

        # Call checking_dir() method
        p1.checking_dir(my_dir)

        # Set up empty list
        x_resol_list = []

        # Define download_data() function
        def download_data():

            # Invoke show_short_msg() method
            msg1.show_short_msg(self.pdb_short_msg+
            "\nDownloading structures from "+url_in+"...\n")

            # Looping through my_fo
            for line1 in my_fo:
                pdb = ""
                count_ = 0
                i = 1

                # Set up the PDB string (PDB access code with 4 characters)
                for line2 in line1:
                    if line2 != ",":
                        pdb += line2
                        count_ += 1
                    if count_ == 4:

                        # Instantiate an object of the PDB() class
                        pdb2download = get_str.PDB(my_dir,pdb,url_in)

                        # Show message
                        msg_out = pdb+".pdb file downloaded from "+url_in
                        #msg1.show_botton_msg(msg_out,"black","light grey")

                        # Write message
                        fo_xtal.write(msg_out+"\n")

                        # Try to download
                        try:
                            # Call get_structure() method
                            pdb2download.get_structure()

                            # Instantiate an object of Messages() class
                            msg2 = tk_msg.Messages(self.strdir_entry,self.root)

                            # Invoke show_botton_msg() method
                            msg_out ="Successfully downloaded "
                            msg_out += "PDB: "+str(pdb)
                            msg2.show_botton_msg(msg_out,"black","light grey")
                            print(msg_out)

                        # Handle exception
                        except:

                            # Instantiate an object of Messages() class
                            msg3 = tk_msg.Messages(self.strdir_entry,self.root)

                            # Invoke show_botton_msg() method
                            msg_out = "Warning! SAnDReS couldn't download PDB "
                            msg_out += "file for structure: "+str(pdb)+"!"
                            msg3.show_botton_msg(msg_out,"grey","white")
                            print(msg_out)
                            pass

                        # To handle exceptions related to the Done button
                        try:
                            if count_ != 0:
                                pr_bar_01["value"] = i*100/number_of_pdbs
                            else:
                                pr_bar_01["value"] = i*100
                            root.update()
                        except:
                            return

                        # Set up initial conditions
                        count_ = 0
                        pdb = ""

                        # Add 1 to i
                        i += 1

                        # Call short_read_xtal() method
                        x_resol = pdb2download.short_read_xtal()

                        try:
                            # Append values to lists
                            x_resol_list.append(float(x_resol))
                        except:
                            x_resol_list.append("None")

            # Try to show message
            try:
                # Show message
                msg_out = "SAnDReS finished the \"Add Structures (PDB)\" "
                msg_out += "request! "
                #msg_out += "Number of structures: "+str(str(i-1))
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)
            except:
                # Show message
                msg_out = "SAnDReS finished the \"Add Structures (PDB)\" "
                msg_out += "request! "
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            # Write summary
            fo_xtal.write(msg_out+"\n")

            # Close file
            fo_xtal.close()

            # Show log file content on window_txt
            msg1.read_log_file("xtal.log")

        # Set up progress bar (pr_bar_01)
        # Create child window
        root = tk.Tk()
        root.title(progress_bar_pdb_title)
        root.geometry(top_txt_geom) # 870x52+0+540('870x50+0+430') length = 790
        pr_bar_01 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_01.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=download_data)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()