#!/usr/bin/env python3
#
# Class to convert MVD (Thomsen & Christensen, 2006) CSV file to SAnDReS format.
#
# Thomsen R, Christensen MH. MolDock: a new technique for high-accuracy
# molecular docking. J Med Chem. 2006 Jun 1;49(11):3315-21.
# doi: 10.1021/jm051197e. PMID: 16722650.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# July 14, 2022                                                                #
################################################################################
#
# Import packages
import csv
import numpy as np
from tools import backup_all

# Define MVD() class
class MVD(object):
    """Class to handle Molegro Virtual Docker results and convert it to
    SAnDReS readble CSV format"""

    # Define constructor method
    def __init__(self,program_root,dir_in,mvd_in,binding_affinity_file,
            sandres_out):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.mvd_in = mvd_in
        self.binding_affinity_file = binding_affinity_file
        self.sandres_out = sandres_out

        # Define array and empty lists
        self.column_ind = np.zeros(100,int)
        self.lines_out = []
        self.labels = []
        self.features_in = []

    # Define prep_mvd() method
    def prep_mvd(self):
        """Method prepare a MVD CSV file"""

        # Try to backup a file
        # Invoke backup_all.make()
        backup_all.make(self.mvd_in,self.dir_in,self.dir_in+"backup/")

        # Set up an empty string
        aux_lines_out = ""

        # Try to open a file
        file2open = self.dir_in+self.mvd_in
        try:
            fo_mvd = open(file2open,"r")
            csv_mvd = csv.reader(fo_mvd)

            # Looping through csv_mvd for the header
            for line in csv_mvd:
                # Some editing
                s_o = "E-Intra (tors, ligand atoms)"
                s_n = "E-Intra (tors-ligand atoms)"
                aux = str(line).replace(s_o,s_n)
                aux = aux.replace("[","")
                aux = aux.replace("]","")
                aux = aux.replace("'","")
                aux = aux.replace("\"","")
                aux_lines_out += aux+"\n"

                break

            # Looping through the remaining lines
            for line in csv_mvd:
                aux0 = str(line[0].strip())
                aux = str(line[1:]).replace("[","")
                aux = aux.replace("]","")
                aux = aux.replace("'","")
                aux = aux.replace("\"","")

                aux_lines_out += aux0+","+aux+"\n"

            # Close file
            fo_mvd.close()

            # Create a file
            file2create = self.dir_in+self.mvd_in
            fo_mvd = open(file2create,"w")

            # Write data
            fo_mvd.write(aux_lines_out)

            # Close file
            fo_mvd.close()

        # Handle IOError
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")

    # Define read_par() method
    def read_par(self):
        """Method to the parameters necessary to convert from MVD to SAnDReS"""

        # Try to open a file
        file2open = self.program_root+"misc/data/molegro_par.csv"
        try:
            fo_par = open(file2open,"r")
            csv_mvd = csv.reader(fo_par)

            # Set up an empty string
            aux_line = ""

            # Looping through csv_mvd
            for line in csv_mvd:
                if line[0].strip() == "features_in":
                    if "Intra (tors," in line[1].strip():
                        self.features_in.append("E-Intra (tors, ligand atoms)")
                    else:
                        self.features_in.append(line[1])
                elif line[0].strip() == "bind_in":
                    self.bind_in = line[1].strip()
                elif line[0].strip() == "chain_in":
                    self.chain_in = line[1].strip()
                elif line[0].strip() == "number_in":
                    self.number_in = line[1].strip()
                elif line[0].strip() == "resolution_in":
                    self.resolution_in = line[1].strip()
                elif line[0].strip() == "occupation_in":
                    self.occupation_in = line[1].strip()

            # Close file
            fo_par.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file")
            return

    # Define read_mvd() method
    def read_mvd(self):
        """Method read a MVD output CSV file"""

        # Try to open a file
        file2open = self.dir_in+self.mvd_in
        try:
            fo_mvd = open(file2open,"r")
            csv_mvd = csv.reader(fo_mvd)

            # Looping through csv_mvd for the header
            for line in csv_mvd:
                i = 0
                j = 0
                for line1 in line:
                    if line1.strip() in self.features_in:
                        print("I found header ",line1," in column number: ",i)
                        self.labels.append(line1.strip())
                        self.column_ind[j] = i
                        j += 1

                    i += 1
                break

            # Looping through the remaining lines
            for line in csv_mvd:
                self.lines_out.append(line)

            # Close file
            fo_mvd.close()

        # Handle IOError
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")

    # Define write_csv() method
    def write_csv(self):
        """Method to write a CSV file"""

        # Set up an empty list
        pdb_list = []

        # Set up an alphanumeric list
        alp = ["0","1","2","3","4","5","6","7","8","9",
                     "A","B","C","D","E","F","G","H","I","J",
                     "K","L","M","N","O","P","Q","R","S","T",
                     "U","V","W","X","Y","Z"]

        # Try to backup a file
        # Invoke backup_all.make()
        backup_all.make(self.sandres_out,self.dir_in,self.dir_in+"backup/")

        # Set up an empty string
        data_out = ""

        # Set up empty list
        self.features_out = []

        # Set up headers
        headers = "PDB,Ligand,Chain,Number,Resolution(A),"
        headers += "Ligand Occupation Factor,"
        headers += self.bind_in+"(M),log("+self.bind_in+"),p"+self.bind_in
        for line in self.labels[1:]:
            if "E-Intra (tors, ligand atoms)" in str(line):
                headers += ",E-Intra (tors-ligand atoms)"
                self.features_out.append("E-Intra (tors-ligand atoms)")
            else:
                headers += ","+str(line).replace(" ","")
                self.features_out.append(str(line).replace(" ",""))

        # Add headers
        data_out += headers+"\n"

        # Set up lines
        for line in self.lines_out:
            # Generate a dummy random PDB access code
            i1 = np.random.randint(0,36)
            i2 = np.random.randint(0,36)
            i3 = np.random.randint(0,36)
            i4 = np.random.randint(0,36)
            pdb_in = str(alp[i1])+str(alp[i2])+str(alp[i3])+str(alp[i4])
            while pdb_in in pdb_list:
                # Generate a dummy random PDB access code
                i1 = np.random.randint(0,36)
                i2 = np.random.randint(0,36)
                i3 = np.random.randint(0,36)
                i4 = np.random.randint(0,36)
                pdb_in = srt(alp[i1])+srt(alp[i2])+srt(alp[i3])+srt(alp[i4])

            # Append to list
            pdb_list.append(pdb_in)

            # Some editing
            aux_line = pdb_in
            lig_line = str(line[self.column_ind[0]])
            ind1 = lig_line.index("]")

            # Get experimental data for a ligand
            # Invoke get_binding() method
            binding_exp = self.get_binding(lig_line[ind1+1:].strip())
            log_binding_exp = np.log10(binding_exp)
            pk_binding_exp = -1*log_binding_exp

            aux_line += ","+lig_line[ind1+1:]
            aux_line += ","+self.chain_in+","+self.number_in
            aux_line += ","+self.resolution_in
            aux_line += ","+self.occupation_in
            aux_line += ","+str(binding_exp)
            aux_line += ","+str(log_binding_exp)
            aux_line += ","+str(pk_binding_exp)
            # Looping through self.features_in
            for i in range(1,len(self.features_in)):
                aux_line += ","+str(line[self.column_ind[i]])

            data_out += aux_line+"\n"

        # Open a new file
        file2create = self.dir_in+self.sandres_out
        fo_sandres = open(file2create,"w")

        # Write data
        fo_sandres.write(data_out)

        # Show message
        msg_out = "\nSuccessfully generated new SAnDReS CSV file: "
        msg_out += self.sandres_out+"\n"
        msg_out += "Number of molecules: "+str(len(self.lines_out))
        print(msg_out)

        # Close file
        fo_sandres.close()

    # Define generate_molegro_features() method
    def generate_molegro_features(self):
        """Method to generate molegro_features_in.csv file with all features"""

        # Assign "molegro_features_in.csv" to molegro_features_file
        molegro_features_file = "molegro_features_in.csv"

        # Set up empty string
        molegro_out = ""

        # Try to backup a file
        # Invoke backup_all.make()
        backup_all.make(molegro_features_file,self.program_root,
            self.dir_in+"backup/")

        # Assign the first feature
        molegro_out += self.features_out[0]

        # Looping through self.features_out
        for line in self.features_out[1:]:
            molegro_out += ","+line.strip()

        # Open a new file
        file2create = self.program_root+"misc/data/"+molegro_features_file
        fo_molegro = open(file2create,"w")

        # Write data
        fo_molegro.write(molegro_out)

        # Show message
        msg_out = "\nSuccessfully generated new file with Molegro features: "
        msg_out += molegro_features_file+"\n"
        print(msg_out)

        # Close file
        fo_molegro.close()

    # Define get_binding() method
    def get_binding(self,ligand_in):
        """Method to read ligand code and return binding affinity data in
        molar"""

        # Assign None to f_bind
        f_bind = None

        # Try to open a file
        try:
            file2open = self.dir_in+self.binding_affinity_file
            fo_bind = open(file2open,"r")
            csv_bind = csv.reader(fo_bind)

        # Handle IOError exception
        except:
            print("IOError! I can't find "+file2open+" file!")
            return

        # Looping through csv_bind for the first line
        for line in csv_bind:
            break

        # Looping through csv_bind for the remaining lines
        for line in csv_bind:
            if line[0].strip() == ligand_in:
                f_bind = float(line[1].strip())*1e-9 # Convert to Molar
                break

        # Close file
        fo_bind.close()

        # Return data
        return f_bind