# Class to read a SDF (structure-data file) downloaded from the
# BindingDB and extract binding data. This program also filters the SDF
# to unify the ligands and output only those for
# which binding affinity data is available.
#
# Inputs:
#       program_root: Program root
#       dir_in: Directory where BindingDB files are
#       tsv_in: TSV file downloaded from BindingDB
#       sdf_in: 3D SDF downloaded from BindingDB
#       vs_in: Virtual screening results generated with AutoDock Vina
#       option_in: String with the filtering option, it should be Clean or All
#       bind_in: String with the type of binding affinity data downloaded
#               from the BindingDB
#
# Outputs:
#       sdf_out: 3D SDF with filtered ligand data
#       csv_data: CSV file with BindingDB reactant set id and
#                   binding affinity data
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import os
import numpy as np

# Define Ligand() class
class Ligand(object):
    """Class to read a structure-data file (SDF) downloaded from BindingDB and
    handle ligands and binding affinity data"""

    # Define constructor method
    def __init__(self,program_root,dir_in,sdf_in,bind_in,tsv_in,
                csv_data,vs_in,option_in,sdf_out):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.sdf_in = sdf_in
        self.sdf_out = sdf_out
        self.bind_in = bind_in
        self.tsv_in = tsv_in
        self.csv_data = csv_data
        self.vs_in = vs_in
        self.option_in = option_in

        # Set up empty lists
        self.bindingdb_id_list = []
        self.updated_bindingdb_id_list = []

    # Define read_sdf() method
    def read_sdf(self):
        """Method to read SDF (structure-data file) downloaded from the
         BindingDB"""

        # Try to open SDF
        file2open = self.dir_in+self.sdf_in
        try:
            fo_sdf = open(file2open,"r")
            self.sdf_data1 = fo_sdf.readlines()

            # Close file
            fo_sdf.close()

        # Handle exception
        except IOError:
            print("\nI can't find "+file2open+" file!")
            return

    # Define get_id() method
    def get_id(self):
        """Method to read > <BindingDB Reactant_set_id>"""

        # Assign False to a boolean variable
        binding_id_flag = False

        # Assign zero to n_repeated
        n_repeated = 0

        # Looping through self.sdf_data1
        for line in self.sdf_data1:

            # Check the presence of "<BindingDB Reactant_set_id>"
            if "<BindingDB Reactant_set_id>" in str(line):

                # Assign True to a boolean variable
                binding_id_flag = True

            # Get id
            elif binding_id_flag:

                # Assign False to a boolean variable
                binding_id_flag = False

                # Some editing
                id = str(line)
                id = id.replace("\n","")
                id = id.replace(" ","")

                # Check if id is not in the self.bindingdb_id_list
                if id not in self.bindingdb_id_list:

                    # Append id to list
                    self.bindingdb_id_list.append(str(id))
                else:
                    n_repeated += 1

        # Show data
        self.n_ligands = len(self.bindingdb_id_list)
        n_total = self.n_ligands + n_repeated
        print("\nData read from: ",self.sdf_in)
        print("Number of ligands: "+str(n_total))
        print("Number of unique ligands: "+str(self.n_ligands))

        # Return self.bindingdb_id_list
        return self.bindingdb_id_list

    # Define show_list() method
    def show_list(self,list_in):
        """Method to show a list"""

        # Looping through self.monoID_list
        for line in list_in:
            print(line)

    # Define change_ligand_in() method
    def change_ligand_id(self):
        """Method to change ligand identification to
        BindingDB Reactant_set_id """

        # Set up empty strings
        lines_out = ""
        output_lines = ""

        # Assign True to a boolean variable
        first_line = True

        # Assign zero to i_lines
        i_lines = 0

        # Looping through self.bindingdb_id_list
        for id in self.bindingdb_id_list:

            # Add BindingDB Reactant_set_id to sdf
            lines_out += id+"\n"

            # Looping through self.sdf_data1
            for line in self.sdf_data1[i_lines:]:

                # Update i_lines
                i_lines += 1

                if first_line:

                    # Assign False to a boolean variable
                    first_line = False

                elif id in str(line):

                    # Assign True to a boolean variable
                    id_found = True

                    lines_out += line

                elif "$$$$" in str(line):

                    # Assign True to a boolean variable
                    first_line = True

                    lines_out += line

                    # Add to the right ligand
                    if id_found:

                        # Add lines
                        output_lines += lines_out
                        lines_out = ""

                        # Assign False to a boolean variable
                        id_found = False

                        break
                else:

                    lines_out += line

        # Open new sdfile
        file2create = self.dir_in+self.sdf_out
        fo_sdf = open(file2create,"w")

        # Write data
        fo_sdf.write(output_lines)

        # Close file
        fo_sdf.close()

        # Show data
        print("\nData written to : ",self.sdf_out)
        msg_out = "Number of ligands written to the structure-data file: "
        print(msg_out+str(self.n_ligands))

    # Define get_binding_affinity() method
    def get_binding_affinity(self):
        """Method to read binding affinity data from a TSV file"""

        # Set up empty string
        lines_out = "BindingDB reactant set id,"+self.bind_in+"(nM)\n"

        # Try to open a TSV file
        file2open = self.dir_in+self.tsv_in
        try:
            fo_tsv = open(file2open,"r")
            data_tsv = csv.reader(fo_tsv, delimiter="\t")

            # Looping through ligands for the first line
            for line in data_tsv:

                # Get the column number for the binding affinity
                for i in range(7,len(line)):
                    if self.bind_in in str(line[i]):
                        i_column = i
                        break
                break

            # Looping through ligands for the remaining lines
            for line in data_tsv:
                for id in self.bindingdb_id_list:
                    if str(id) == str(line[0]):
                        # Select All or Clean
                        if self.option_in.upper() == "ALL":
                            lines_out += id+","+str(line[i_column])+"\n"
                            self.updated_bindingdb_id_list.append(id)
                        else:
                            # Try to convert to float
                            try:
                                data_float = float(line[i_column])
                                lines_out += id+","+str(line[i_column])+"\n"
                                self.updated_bindingdb_id_list.append(id)
                            # Handle exception
                            except:
                                pass

        # Handle IOError
        except IOError:
            print("\nI can't find "+file2open+" file!")
            return

        # Open a new file
        file2create = self.dir_in+"affinity_BindingDB_"+self.bind_in+".csv"
        f_csv = open(file2create,"w")

        # Write binding affinity data
        f_csv.write(lines_out)

        # Close a file
        f_csv.close()

        # Show data
        self.n_updated_ligands = len(self.updated_bindingdb_id_list)
        msg_out1 = "\nBinding affinity data written to : "
        print(msg_out1,"binding_affinity_"+self.bind_in+".csv")
        msg_out2 ="Number of ligands written to the binding affinity CSV file: "
        print(msg_out2+str(self.n_updated_ligands))

        # Check whether is necessary to update the sdfile
        if self.n_updated_ligands < self.n_ligands:

            # Try to open SDF
            file2open2 = self.dir_in+self.sdf_out
            try:
                fo_sdf = open(file2open2,"r")
                self.sdf_data2 = fo_sdf.readlines()

                # Close file
                fo_sdf.close()

            # Handle exception
            except IOError:
                print("\nI can't find "+file2open2+" file!")
                return

            # Try to remove self.sdf_out
            file2remove = self.dir_in+self.sdf_out
            try:
                os.remove(file2remove)
            # Handle exception
            except OSError:
                print("\nI can't find "+file2remove+" file!")

            # Invoke update_sdf() method
            self.update_sdf(self.updated_bindingdb_id_list)

    # Define update_sdf() method
    def update_sdf(self,list_in):
        """Method to update ligands in a sdfile """

        # Set up empty strings
        lines_out = ""
        output_lines = ""

        # Assign zero to i_lines
        i_lines = 0

        # Set up an empty list
        check_list = []

        # Assign False to a boolean variable
        go_flag = False

        # Looping through list_in
        for id in list_in:

            print("Checking ligand "+id+"...")

            # Looping through self.sdf_data2
            for line in self.sdf_data2[i_lines:]:

                # Update i_lines
                i_lines += 1

                # Get the right the ligands
                if id in str(line):

                    # To avoid repeated ligands
                    if id not in check_list:
                        check_list.append(id)
                        lines_out += line

                        # Assign False to a boolean variable
                        go_flag = True

                # This is the end
                elif go_flag and "$$$$" in str(line):
                    lines_out += line
                    output_lines += lines_out
                    lines_out = ""

                    # Assign False to a boolean variable
                    go_flag = False

                    # Give me a break
                    break

                # Add line
                elif go_flag:
                    lines_out += line

        # Open a new sdf file
        f_sdf = open(self.dir_in+self.sdf_out,"w")

        # Add updated sdf
        f_sdf.write(output_lines)

        # Close file
        f_sdf.close()

        # Show message
        print("Done!\n\n")
        print("\nData written to : ",self.sdf_out)
        msg_out="Number of ligands written to the updated structure-data file: "
        print(msg_out,len(check_list))

    # Define add_binding() method
    def add_binding(self):
        """Method to read a CSV file and add binding affinity data read from the
        BindingDB"""

        # Set up an empty string
        lines_out = ""

        # Try to open VS results data file to get the header
        file2open0 = self.dir_in+self.vs_in
        try:
            fo_csv0 = open(file2open0,"r")
            csv_data0 = csv.reader(fo_csv0)

            # Looping through csv_data0 for the first line
            #for line in csv_data0:
            #    line_out = str(line)

                # Some editing 2
            #    line_out = line_out.replace("[","")
            #    line_out = line_out.replace("]","")
            #    line_out = line_out.replace("'","")

            #    lines_out += line_out+"\n"

            #    break

            # Close file
            #fo_csv0.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open0+" file!")
            return

        # Looping through csv_data0 for the first line
        for line in csv_data0:
            line_out = str(line)

            # Some editing 2
            line_out = line_out.replace(", ",",")
            line_out = line_out.replace("[","")
            line_out = line_out.replace("]","")
            line_out = line_out.replace("'","")

            try:
                line_out = line_out.replace(", ",",")
            except:
                pass

            try:
                line_out = line_out.replace(" ,",",")
            except:
                pass


            lines_out += line_out+"\n"

            break

        # Close file
        fo_csv0.close()

        # Assign zero to count_codes
        count_codes = 0

        # Try to open a CSV file
        file2open1 = self.dir_in+self.csv_data
        try:
            fo_csv1 = open(file2open1,"r")
            csv_data1 = csv.reader(fo_csv1)

            # Looping through csv_data1 for the first line
            for line in csv_data1:
                break

            # Looping through csv_data1 for the remaining lines
            for line1 in csv_data1:
                code1 = str(line1[0]).replace(" ","")
                bind = str(line1[1]).replace(" ","")
                bind_float = float(bind)*(1e-9)
                log_bind = np.log10(bind_float)
                p_bind = -1*log_bind

                # Try to open VS results data file
                file2open2 = self.dir_in+self.vs_in
                try:
                    fo_csv2 = open(file2open2,"r")
                    csv_data2 = csv.reader(fo_csv2)

                    # Looping through csv_data2 for the first file
                    for line2 in csv_data2:
                        break

                    # Looping through csv_data2 for the remaining lines
                    for line2 in csv_data2:
                        code2 = str(line2[2]).replace(" ","")

                        # Check whether the code is found
                        if code1 == code2:

                            # Update count_codes
                            count_codes += 1

                            # Some editing 1
                            line_out = str(line2[:6])+","
                            line_out += str(bind_float)+","
                            line_out += str(log_bind)+","
                            line_out += str(p_bind)+","
                            line_out += str(line2[9:])+"\n"

                            # Some editing 2
                            line_out = line_out.replace("[","")
                            line_out = line_out.replace("]","")
                            line_out = line_out.replace("'","")

                            # Add line
                            lines_out += line_out

                            # Close file
                            fo_csv2.close()
                            break

                # Handle IOError exception
                except IOError:
                    print("\nIOError! I can't find "+file2open2+"file!")
                    return

            # Close file
            fo_csv1.close()

            # Show data
            print("\nNumber of ligands: ",count_codes)

            # Create a new file
            file2create = file2open2
            f_out = open(file2create,"w")

            # Add data
            f_out.write(lines_out)

            # Close file
            f_out.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open1+"file!")
            return