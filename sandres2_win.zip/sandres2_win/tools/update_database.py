#!/usr/bin/env python3
#
#!/usr/bin/env python3
#
# Class to add binding affinity data and PDBQT files for ligands
# to the Ligand Databases
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import numpy as np
import shutil
from tools import backup_all
from tools import tkinter_messages as tk_msg

# Define LigandInfo() class
class LigandInfo(object):
    """Class to add data to Ligand Databases"""

    # Define constructor method
    def __init__(self,program_root,dir_in,root):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.root = root

    # Define some_string_editing() method
    def some_string_editing(self,string_in):
        """Method to carry out some string editing"""

        # Some editing
        string_out = str(string_in).replace("'","")
        string_out = string_out.replace("[","")
        string_out = string_out.replace("]","")
        string_out = string_out.replace(", ",",")
        string_out = string_out.replace(" ,",",")

        # Return edited string
        return string_out

    # Define read_pdbqt() method
    def read_pdbqt(self,pdb_in):
        """Method to read ligand PDBQT files"""

        # Try to open a PDBQT file
        pdbqt2open = self.ligand_dir+"pdbqt/"+pdb_in+"/lig.pdbqt"
        try:
            fo_pdbqt = open(pdbqt2open,"r")

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+pdbqt2open+" file!")
            return "ND"

        # Get pdbqt data
        pdbqt = fo_pdbqt.readlines()

        # Set up an empty list
        occ_factor = []

        # Looping through pdbqt
        for line in pdbqt:
            if line[:6] == "HETATM":
                occ_factor.append(float(line[54:60]))

        # Close file
        fo_pdbqt.close()

        # Convert to array
        occ_factor_array = np.array(occ_factor)

        # Get the mean value
        occupation = np.mean(occ_factor_array)

        # Return occ_factor
        return occupation

    # Define read_add_lig_par() method
    def read_add_lig_par(self):
        """Method to read add_lig_par.csv file"""

        # Read parameters
        # Try to open add_lig_par.csv
        file2open = self.program_root+"misc/data/add_lig_par.csv"
        try:
            fo_csv = open(file2open,"r")

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")

        # Get CSV data
        csv_in = csv.reader(fo_csv)

        # Looping through csv_in
        for line in csv_in:
            if line[0].strip() == "bind_in":
                self.bind_in = str(line[1].strip())
            elif line[0].strip() == "ligand_dir":
                self.ligand_dir = str(line[1].strip())
            elif line[0].strip() == "ligand_data":
                self.ligand_data = str(line[1].strip())

        # Close file
        fo_csv.close()

    # Define read_ligand_data() method
    def read_ligand_data(self):
        """Method to read data to be added to the Ligand Database"""

        # Read ligand data
        # Try to open ligand_data file
        file2open = self.ligand_dir+self.ligand_data
        try:
            fo_csv = open(file2open,"r")

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")

        # Get CSV data
        csv_in = csv.reader(fo_csv)

        # Set up an empty string
        self.data_out = ""

        # Looping through csv_in (first line)
        for line in csv_in:

            # Invoke some_string_editing() method
            line_out = self.some_string_editing(line)

            # Add header
            self.data_out += line_out+",log("+self.bind_in+"),p"+self.bind_in
            self.data_out += "\n"
            break

        # Looping through csv_in
        for line in csv_in:

            # Get PDB access code
            pdb_in = line[0]

            # Show message
            print("\nGetting data for structure ",pdb_in)

            # Invoke read_pdbqt() method
            occ_factor = self.read_pdbqt(pdb_in)

            # Add occ_factor to line
            line_out = str(line[:5])+","+str(occ_factor)+","+str(line[6])+","

            # Calculate log() and pK and add them to line
            log10_aff = np.log10(float(line[6]))
            pK_aff = -1*log10_aff
            line_out += str(log10_aff)+","+str(pK_aff)+"\n"

            # Invoke some_string_editing() method
            line_out = self.some_string_editing(line_out)

            # Add line_out to data_out
            self.data_out += line_out

            # Invoke copy_folder() method
            self.copy_folder(pdb_in)

        # Close file
        fo_csv.close()

        # Show data_out
        print("\nThe folowing lines will be added to the Ligand Database:")
        print(self.data_out)

    # Define write_new_data() method
    def write_new_data(self):
        """Method to write new ligand data to Ligand Database"""

        # Invoke backup_all.make()
        origin_dir = self.program_root+"misc/data/"
        target_dir = origin_dir
        origin_file = "bind_"+self.bind_in+".csv"
        backup_all.make(origin_file,origin_dir,target_dir)

        # Create a new Ligand Database
        database2create = origin_dir+origin_file
        fo_new_database = open(database2create,"w")

        # Write data
        fo_new_database.write(self.databaset_out)

        # Close file
        fo_new_database.close()

    # Define copy_folder() method
    def copy_folder(self,pdb_in):
        """Method to copy a folder with ligand data"""

        # Copy folder
        source = self.program_root+"Ligands/pdbqt/"+str(pdb_in)
        destination = self.program_root+"misc/data/pdbqt/"+self.bind_in+"/"
        destination += str(pdb_in)
        shutil.copytree(source,destination)

    # Define bundle() method
    def bundle(self):
        """Method to invoke methods to Ligand Database"""

        # Invoke read_add_lig_par() method
        self.read_add_lig_par()

        # Invoke read_ligand_data()
        self.read_ligand_data()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Add data to Ligand Database
        self.databaset_out = self.data_out

        # Try to open Ligand Database file
        origin_file = "bind_"+self.bind_in+".csv"
        database2open = self.program_root+"misc/data/"+origin_file
        try:
            fo_database = open(database2open,"r")

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+database2open+" file!")

        # Get CSV data
        database_csv_in = csv.reader(fo_database)

        # Looping through database_csv_in (first line)
        for line in database_csv_in:
            break

        # Looping through database_csv_in
        for line in database_csv_in:

            # Some editing
            line_out = str(line[0].strip())+","+str(line[1].strip())+","
            line_out += str(line[2].strip())+","+str(line[3].strip())+","
            line_out += str(line[4].strip())+","+str(line[5].strip())+","
            line_out += str(line[6].strip())+","+str(line[7].strip())+","
            line_out += str(line[8].strip())

            # Invoke some_string_editing() method
            line_out = self.some_string_editing(line_out)

            # Add edited line
            self.databaset_out += line_out+"\n"

        # Close file
        fo_database.close()

        # Try to add new ligands
        try:
            # Invoke write_new_data() method
            self.write_new_data()

            # Invoke show_botton_msg() method
            msg_out = "Done! Successfully updated Ligand Database!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        # Handle exception
        except:

            # Invoke show_botton_msg() method
            msg_out = "Error! I can't update Ligand Database!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
