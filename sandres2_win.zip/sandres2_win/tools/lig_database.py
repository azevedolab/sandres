# Class to recover data for ligand bound to a crystallographic structure with
# binding affinity data.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import package
import csv

# Define LIG() class
class LIG(object):
    """Class to recover data for ligand bound to a crystallographic structure
    with binding affinity data """

    # Define constructor method
    def __init__(self,program_root,bind_in,pdb):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.bind_in = bind_in
        self.pdb = pdb

    # Define read_data() method
    def read_data(self):
        """Method to read data for a given PDB"""

        # Try to open data for ligands
        try:
            fo_lig=open(self.program_root+"misc/data/bind_"+self.bind_in+".csv")
            csv_lig=csv.reader(fo_lig)
        except IOError:
            msg_out = "IOError! I can't find "+"bind_"+self.bind_in+".csv file!"
            print(msg_out)
            return None,None,None,None,None,None,None,None

        # Looping through csv_lig
        for line in csv_lig:
            if self.pdb == line[0]:
                break

        # Close file
        fo_lig.close()

        # Return data
        return line[1],line[2],line[3],line[4],line[5],line[6],line[7],line[8]







