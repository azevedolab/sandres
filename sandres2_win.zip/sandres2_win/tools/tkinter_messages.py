# Import package
from tkinter import *

# define Messages() class
class Messages(object):
    """Class to show messages"""

    # Define constructor method
    def __init__(self,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.strdir_entry = strdir_entry
        #self.window_txt = window_txt
        self.root = root

    # Define show_short_msg() method
    def show_short_msg(self,msg2show):
        """Method to show short message"""

        print(msg2show)

        # Import package
        # from tkinter import messagebox

        # Call clear_txt()
        #self.clear_txt()

        # Show message
        #self.window_txt.insert(END,my_short_msg)

    # Define show_botton_msg() method
    def show_botton_msg(self,input_2_show,color1,color2):
        """Method to show message on the botton bar"""

        #root = Tk()

        # Clear Label (it was 180) (80)
        Label(self.root, text = 90*" " ,fg = color1,bg=color2,
          font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)

        # The strip() method removes any leading (spaces at the beginning)
        # and trailing (spaces at the end) characters
        output_message1 = input_2_show.strip()

        # To handle different lengths (it was 50, 100)
        #len_string = len(output_message1)
        #if len_string < 40:
        #    number_spaces = 40 - len_string
        #    output_message2 = output_message1+number_spaces*" "
        #elif len_string < 90:
        #    output_message2 = output_message1+" "
        #else:
        #    output_message2 = output_message1[:90]

        # To handle different lengths (40 and 120 for windows)
        len_string = len(output_message1)
        if len_string < 40:
            number_spaces = 40 - len_string
            output_message2 = output_message1+number_spaces*" "
        elif len_string < 120:
            output_message2 = output_message1+" "
        else:
            output_message2 = output_message1[:200]


        # Creates Label (WFA 2021-10-14) (140)
        Label(self.root, text = 150*" " ,fg = color1,bg=color2,
            font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)

        # Creates Label
        Label(self.root, text = output_message2 ,fg = color1,bg=color2,
            font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)

        print("\n"+output_message1)

        #return

    # Define read_log_file() method
    def read_log_file(self,my_log_file):
        """Method to read log file"""

        # Import package
        from tkinter import messagebox

        # Call clear_txt()
        self.clear_txt()

        # Get new project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open  input file
        try:
            my_info_log_file = open(project_dir_string+my_log_file,"r")
        except IOError:
            print("IOError! I can't find ",project_dir_string+my_log_file)
            print("Please update project directory as your needs!")
            messagebox.showerror("IOError!", "I can't find file "+
                project_dir_string+my_log_file+" \nPlease check directory name!")
            return

        # Reads file content
        #self.window_txt.insert(END,my_info_log_file.read())

        # Close input file
        my_info_log_file.close()

    # Define clear_txt() method
    def clear_txt(self):
        """Nethod to clear txt content"""

        #self.window_txt.delete(0.0,END)
