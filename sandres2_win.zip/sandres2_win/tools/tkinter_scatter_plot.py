#!/usr/bin/env python3
#
# Class to create a scatter plot.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import numpy as np
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import bivariate_analysis_full as bi_analysis
from tools import plot_xy as p_xy

# Define Scatter2D() class
class Scatter2D(object):
    """Class to create a scatter plot"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Define ascii_art
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=2D-Plot
        self.art_2D_plot = """
██████╗ ██████╗       ██████╗ ██╗      ██████╗ ████████╗
╚════██╗██╔══██╗      ██╔══██╗██║     ██╔═══██╗╚══██╔══╝
 █████╔╝██║  ██║█████╗██████╔╝██║     ██║   ██║   ██║
██╔═══╝ ██║  ██║╚════╝██╔═══╝ ██║     ██║   ██║   ██║
███████╗██████╔╝      ██║     ███████╗╚██████╔╝   ██║
╚══════╝╚═════╝       ╚═╝     ╚══════╝ ╚═════╝    ╚═╝
 """

    # Define pre_2d_GUI() method
    def pre_2d_GUI(self):
        """Method to invoke plot_GUI() method """

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() message
        msg_out = "Ready to generate scatter plot using Matplotlib!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Call show_short_msg() method
        msg_out = self.art_2D_plot+"\nUsing Matplotlib available at "
        msg_out += "https://matplotlib.org/"
        msg1.show_short_msg(msg_out)

        # Invoke plot_view_GUI() method
        self.plot_view_GUI()

    # Define plot_GUI() method
    def plot_view_GUI(self):
        """Method to call plot_xy"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title("Matplotlib: Visualization with Python")
        top_txt.geometry(top_txt_geom)

        # Widgets for 3D View
        Button(top_txt,text=' 2D-View ',command=self.call_2d_view).grid(row=4,
        column = 1, sticky = W)

        # Widgets for Plot
        Button(top_txt,text=' Plot ',command=self.call_2d_plot).grid(row=4,
        column = 2, sticky = E)

        # Label (Insert space to get the right position of botton bar)
        Label(top_txt, text = (self.win_y_offset_type_2+5)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=5, column=4, sticky=W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
        command=top_txt.destroy).grid(row = 5, column = 5,sticky = E)

    # Define call_2d_plot() method
    def call_2d_plot(self):
        """Method to generate 2D plot"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Read plotting parameters
        # Try to open a file
        try:
            file2open = self.program_root+"misc/data/scatter_plot_par.csv"
            fo_plot_par = open(file2open,"r")
            csv_plot_par = csv.reader(fo_plot_par)

            # Looping through csv_plot_par
            for line in csv_plot_par:
                if "#" not in line:
                    if line[0] == "data_file":
                        data_file = line[1]
                    elif line[0] == "plot_file":
                        plot_file = line[1]
                    elif line[0] == "marker_in":
                        marker_in = line[1]
                    elif line[0] == "X_col":
                        X_col = int(line[1])
                    elif line[0] == "y_col":
                        y_col = int(line[1])
                    elif line[0] == "X_label":
                        X_label = line[1]
                    elif line[0] == "y_label":
                        y_label = line[1]
                    elif line[0] == "X_tick_size":
                        X_tick_size = int(line[1])
                    elif line[0] == "y_tick_size":
                        y_tick_size = int(line[1])
                    elif line[0] == "rot_X_tick":
                        rot_X_tick = int(line[1])
                    elif line[0] == "rot_y_tick":
                        rot_y_tick = int(line[1])
                    elif line[0] == "X_size":
                        X_size = int(line[1])
                    elif line[0] == "y_size":
                        y_size = int(line[1])
                    elif line[0] == "title_in":
                        title_in = line[1]
                    elif line[0] == "title_size":
                        title_size = int(line[1])
                    elif line[0] == "scatter_color":
                        scatter_color = line[1]
                    elif line[0] == "line_color":
                        line_color = line[1]
                    elif line[0] == "dpi_in":
                        dpi_in = int(line[1])
                    elif line[0] == "reg_line":
                        reg_line = line[1]
                    elif line[0] == "include_x_lim":
                        include_x_lim = line[1]
                    elif line[0] == "x_min_in":
                        x_min_in = float(line[1])
                    elif line[0] == "x_max_in":
                        x_max_in = float(line[1])
                    elif line[0] == "include_y_lim":
                        include_y_lim = line[1]
                    elif line[0] == "y_min_in":
                        y_min_in = float(line[1])
                    elif line[0] == "y_max_in":
                        y_max_in = float(line[1])
                    elif line[0] == "include_grid":
                        include_grid = line[1]
                    elif line[0] == "grid_color":
                        grid_color = line[1]
                    elif line[0] == "grid_linestyle":
                        grid_linestyle = line[1]
                    elif line[0] == "grid_linewidth":
                        grid_linewidth = float(line[1])
                    elif line[0] == "stats_calc":
                        stats_calc = line[1]
                    elif line[0] == "stats_calc_features":
                        stats_calc_features = int(line[1])
                    elif line[0] == "stats_calc_string":
                        stats_calc_string = line[1]

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Close file
        fo_plot_par.close()

        # Check stats_calc
        if stats_calc.upper() == "ON":

            # Open reference_file
            file2open = project_dir_string+data_file

            # Get numerical data
            array1 = np.genfromtxt(file2open,delimiter=",",skip_header=1)
            stats_calc_X = array1[:,X_col]
            stats_calc_y = array1[:,y_col]

            # Instantiate an object of Metrics() class
            stats_calc_1 = bi_analysis.Metrics(stats_calc_X,stats_calc_y,False,
            stats_calc_features)

            # Invoke bundle() method
            corr_p,pvalue_p,r2,corr_s,pvalue_s,mse,rmse_model,s_dev,rss,\
                f_stats,stats_results = stats_calc_1.bundle()

            # Open a new file
            plot_file_stats = plot_file.replace(".pdf","_")
            plot_file_stats += str(X_col)+"_"+str(y_col)+".csv"
            file2create = project_dir_string+"plots/"+plot_file_stats
            fo_stats_calc = open(file2create,"w")

            # Write results
            stats_calc_lines_out = "Method,r,p-value,r2,rho,"
            stats_calc_lines_out += "p-value,MSE,RMSE,SD,RSS,F-stat\n"
            stats_calc_lines_out += stats_calc_string+","+stats_results
            fo_stats_calc.write(stats_calc_lines_out)

            # Close file
            fo_stats_calc.close()

        # Instantiate an object of the ScatterPlot() class
        p1 = p_xy.ScatterPlot(project_dir_string)

        # Invoke read_csv() method
        p1.read_csv(data_file,X_col,y_col)

        # Set go_2dview
        go_2dview = "Off"

        # Invoke generate() method
        p1.generate(plot_file,marker_in,
                X_label,y_label,X_size,y_size,
                X_tick_size,y_tick_size,rot_X_tick,rot_y_tick,
                title_in,title_size,
                scatter_color,line_color,dpi_in,reg_line,
                include_x_lim,x_min_in,x_max_in,
                include_y_lim,y_min_in,y_max_in,
                include_grid,grid_color,grid_linestyle,grid_linewidth,
                go_2dview)

    # Define call_2d_view() method
    def call_2d_view(self):
        """Method to call view 2D plot"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Read plotting parameters
        # Try to open a file
        try:
            file2open = self.program_root+"misc/data/scatter_plot_par.csv"
            fo_plot_par = open(file2open,"r")
            csv_plot_par = csv.reader(fo_plot_par)

            # Looping through csv_plot_par
            for line in csv_plot_par:
                if "#" not in line:
                    if line[0] == "data_file":
                        data_file = line[1]
                    elif line[0] == "plot_file":
                        plot_file = line[1]
                    elif line[0] == "marker_in":
                        marker_in = line[1]
                    elif line[0] == "X_col":
                        X_col = int(line[1])
                    elif line[0] == "y_col":
                        y_col = int(line[1])
                    elif line[0] == "X_label":
                        X_label = line[1]
                    elif line[0] == "y_label":
                        y_label = line[1]
                    elif line[0] == "X_tick_size":
                        X_tick_size = int(line[1])
                    elif line[0] == "y_tick_size":
                        y_tick_size = int(line[1])
                    elif line[0] == "rot_X_tick":
                        rot_X_tick = int(line[1])
                    elif line[0] == "rot_y_tick":
                        rot_y_tick = int(line[1])
                    elif line[0] == "X_size":
                        X_size = int(line[1])
                    elif line[0] == "y_size":
                        y_size = int(line[1])
                    elif line[0] == "title_in":
                        title_in = line[1]
                    elif line[0] == "title_size":
                        title_size = int(line[1])
                    elif line[0] == "scatter_color":
                        scatter_color = line[1]
                    elif line[0] == "line_color":
                        line_color = line[1]
                    elif line[0] == "dpi_in":
                        dpi_in = int(line[1])
                    elif line[0] == "reg_line":
                        reg_line = line[1]
                    elif line[0] == "include_x_lim":
                        include_x_lim = line[1]
                    elif line[0] == "x_min_in":
                        x_min_in = float(line[1])
                    elif line[0] == "x_max_in":
                        x_max_in = float(line[1])
                    elif line[0] == "include_y_lim":
                        include_y_lim = line[1]
                    elif line[0] == "y_min_in":
                        y_min_in = float(line[1])
                    elif line[0] == "y_max_in":
                        y_max_in = float(line[1])
                    elif line[0] == "include_grid":
                        include_grid = line[1]
                    elif line[0] == "grid_color":
                        grid_color = line[1]
                    elif line[0] == "grid_linestyle":
                        grid_linestyle = line[1]
                    elif line[0] == "grid_linewidth":
                        grid_linewidth = float(line[1])
                    elif line[0] == "stats_calc":
                        stats_calc = line[1]
                    elif line[0] == "stats_calc_features":
                        stats_calc_features = int(line[1])
                    elif line[0] == "stats_calc_string":
                        stats_calc_string = line[1]

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Close file
        fo_plot_par.close()

        # Check stats_calc
        if stats_calc.upper() == "ON":

            # Open reference_file
            file2open = project_dir_string+data_file

            # Get numerical data
            array1 = np.genfromtxt(file2open,delimiter=",",skip_header=1)
            stats_calc_X = array1[:,X_col]
            stats_calc_y = array1[:,y_col]

            # Instantiate an object of Metrics() class
            stats_calc_1 = bi_analysis.Metrics(stats_calc_X,stats_calc_y,False,
            stats_calc_features)

            # Invoke bundle() method
            corr_p,pvalue_p,r2,corr_s,pvalue_s,mse,rmse_model,s_dev,rss,\
                f_stats,stats_results = stats_calc_1.bundle()

            # Open a new file
            plot_file_stats = plot_file.replace(".pdf","_")
            plot_file_stats += str(X_col)+"_"+str(y_col)+".csv"
            file2create = project_dir_string+"plots/"+plot_file_stats
            fo_stats_calc = open(file2create,"w")

            # Write results
            stats_calc_lines_out = "Features,r,p-value,r2,rho,"
            stats_calc_lines_out += "p-value,MSE,RMSE,SD,RSS,F-stat\n"
            stats_calc_lines_out += stats_calc_string+" vs "+y_label
            #stats_calc_lines_out += X_label+" vs "+y_label
            stats_calc_lines_out += ","+stats_results
            fo_stats_calc.write(stats_calc_lines_out)

            # Close file
            fo_stats_calc.close()

            # Show results
            print(stats_calc_lines_out)

        # Instantiate an object of the ScatterPlot() class
        p1 = p_xy.ScatterPlot(project_dir_string)

        # Invoke read_csv() method
        p1.read_csv(data_file,X_col,y_col)

        # Set go_2dview
        go_2dview = "On"


        # Invoke generate() method
        p1.generate(plot_file,marker_in,
                X_label,y_label,X_size,y_size,
                X_tick_size,y_tick_size,rot_X_tick,rot_y_tick,
                title_in,title_size,
                scatter_color,line_color,dpi_in,reg_line,
                include_x_lim,x_min_in,x_max_in,
                include_y_lim,y_min_in,y_max_in,
                include_grid,grid_color,grid_linestyle,grid_linewidth,
                go_2dview)
