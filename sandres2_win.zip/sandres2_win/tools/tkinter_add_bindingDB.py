#!/usr/bin/env python3
#
# Class to add binding affinity data downloaded from BindingDB.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
from tkinter import *
from tools import bindingDB as bindDB
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import binding_affinity as b_aff

# Define AddAffinityData() class
class AddAffinityData(object):
    """Class to add binding affinity data downloaded from BindingDB"""

    # Define constructor method
    def __init__(self,program_root,dir_in,vs_in,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.vs_in = vs_in
        self.root = root

        # Try to read the type of binding affinity data
        try:

            # Invoke read_it function
            self.bind_in = b_aff.read_it(self.dir_in)

        # Handle exception
        except:

            # Assing "Ki" to self.bind_in
            self.bind_in  = "Ki"

        # Define self.csv_data
        self.csv_data = "affinity_BindingDB_"+self.bind_in+".csv"

        # Set up message about the main reference for BindingDB
        self.bindingDB_ref = "\nWhen using BindingDB data, please cite: "
        self.bindingDB_ref = "Gilson MK, Liu T, Baitaluk M, Nicola G, Hwang L, "
        self.bindingDB_ref = "Chong J. BindingDB in 2015: A public database "
        self.bindingDB_ref = "for medicinal chemistry, computational chemistry "
        self.bindingDB_ref = "and systems pharmacology. "
        self.bindingDB_ref = "\nNucleic Acids Res. 2015; 44(D1):D1045-53."
        self.bindingDB_short_msg = self.bindingDB_ref

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define prep_GUI() method
    def prep_GUI(self):
        """Method to invoke sorting_GUI() method """

        # Invoke input_GUI() method
        self.input_GUI()

    # Define input_GUI() method
    def input_GUI(self):
        """Method to call bindingDB"""

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2+20,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title('BindingDB')
        top_txt.geometry(top_txt_geom)

        # Widget for BindingDB CSV
        Label(top_txt,text="BindingDB CSV:").grid(row=1,column=0,stick=W)
        self.bind_csv_entry = Entry(top_txt,width = 30)
        self.bind_csv_entry.grid(row = 1, column = 1,stick = E)
        self.bind_csv_entry.insert(0,self.csv_data)

        # Widget for VS CSV
        Label(top_txt,text="Target CSV:").grid(row=2,column=0,stick=W)
        self.vs_results_entry = Entry(top_txt,width = 30)
        self.vs_results_entry.grid(row = 2, column = 1,stick = E)
        self.vs_results_entry.insert(0,self.vs_in)

        # Widget for binding affinity type
        Label(top_txt,text="Binding Affinity:" ).grid(row = 3,column = 0,stick=W)
        self.bind_in_entry = Entry(top_txt,width = 30)
        self.bind_in_entry.grid(row = 3, column = 1,stick = E)
        self.bind_in_entry.insert(0,self.bind_in )

        # Label (Insert space to get the right position of botton bar) -25 -28 -31
        Label(top_txt, text = (self.win_y_offset_type_2-36)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Joblib
        Button(top_txt,text='  Add  ',command=self.do_it).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define do_it() method
    def do_it(self):
        """Method to add BindingDB data to a selected CSV files"""

        # Import library
        from tkinter import messagebox

        # Get binding affinity type
        chosen_bind_in = str(self.bind_in_entry.get())

        # Assign "" to chosen_sdf_in
        chosen_sdf_in = ""

        # Assign "" to sdf_out
        sdf_out = ""

        # Assign "" to chosen_tsv_in
        chosen_tsv_in = ""

        # Assign "" to chosen_option_in
        chosen_option_in = ""

        # Get vs_in
        chosen_vs_in = str(self.vs_results_entry.get())

        # Get chosen_csv_data (input 2 columns data)
        chosen_csv_data = str(self.bind_csv_entry.get())

        # Instantiate an object of Ligand() class
        b1 = bindDB.Ligand(self.program_root,self.dir_in,chosen_sdf_in,
                            chosen_bind_in,chosen_tsv_in,chosen_csv_data,
                            chosen_vs_in,chosen_option_in,sdf_out)

        # Invoke add_binding()
        b1.add_binding()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Invoke show_botton_msg() method
        msg_out = "Done! SAnDReS added BindingDB data "
        msg_out += "to VS results!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)