#!/usr/bin/env python3
#
# Class to download PDB files.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define PDB() class
class PDB(object):
    """Class to download PDB files"""

    # Define constructor method
    def __init__(self,dir_in,access_code,url_in):
        """Constructor method"""

        # Set up attributes
        self.access_code = access_code
        self.dir_in = dir_in
        self.url_in = url_in

    # Define method get structure
    def get_structure(self):
        """Method to download a PDB file from the Protein Data Bank"""
    
        # Import packages
        import urllib.request, urllib.parse, urllib.error
        import time
    
        # Sets up initial values for variable
        check_if_code_in = False
        file_2_download = self.access_code[0:4].replace(" ","")
        file_2_download = file_2_download+".pdb"
        
        # Check if file is already in the structure directory
        flag_4_file_present = self.pre_download(file_2_download)
        if flag_4_file_present:
            print("File "+file_2_download+" is in the directory "+
            self.dir_in+"!\nIgnoring download request!\n")
            check_if_code_in = True
            return
    
        # Set up url
        my_url = self.url_in+file_2_download
        
        # Try to download file    
        try: 
            file_object = urllib.request.urlopen(my_url)
            structure = file_object.read()
            file_object.close()
        
            file_object = urllib.request.urlopen(my_url)
            structure_line = file_object.readline()
            file_object.close()
        
        except:
            check_if_code_in = False
            my_iteraction = 1
            print("RCSB is complaining about 'High User Activity'.")
            print("I will try to wait longer for each file...")
            my_time_to_wait = my_iteraction*120
            print("Waiting for",my_time_to_wait," seconds...")
            time.sleep(my_time_to_wait)
            
            loop_flag = True
        
            # while loop to keep trying to download
            while loop_flag:
                try: 
                    file_object = urllib.request.urlopen(my_url)
                    structure = file_object.read()
                    file_object.close()
        
                    file_object = urllib.request.urlopen(my_url)
                    structure_line = file_object.readline()
                    file_object.close()
                    loop_flag = False
                    check_if_code_in = True
                except:
                    my_iteraction += 1
                    loop_flag = True
                    check_if_code_in = False
    
                if my_time_to_wait > 359:
                    print("It is taking too long!")
                    print("Try to split in diffent inputs getstr.in, with a smaller number of structures per input.\n")
                    break
            
        time.sleep(1)
    
        # Write file
        with open(self.dir_in+file_2_download,"wb") as my_file_4_download:
            my_file_4_download.write(structure)
            my_file_4_download.close()
            check_if_code_in = True

    # Define pre_download() method
    def pre_download(self,my_file_in):
        """Method to check if the file is already in the structure directory"""
        file_present = False
    
        # Try to open file
        try:
            my_fo = open(self.dir_in+my_file_in,"r")
            file_present  = True
            my_fo.close()
        except:
            file_present  = False
    
        # Return boolean variable
        return file_present
    
    # Define read_xtal() method
    def read_xtal(self,active):
        """Method to read crystallographic and ligand data in a PDB file"""
        
        # Set up pdb file
        pdb_file = self.dir_in+self.access_code+".pdb"
        
        # Try to open a pdb file
        try:
            fo_pdb = open(pdb_file,"r")
            pdb_lines = fo_pdb.readlines()
        except:
            print("\nIOError! I can't find "+pdb_file+"!")
            return None,None,None,None
        
        # Assign initial values to variables
        chain = "X"
        number = 0
        x_resol = None
        
        # Looping through pdb_lines:
        for line in pdb_lines:
            if "REMARK   2 RESOLUTION." in line:
                try:
                    i_tag = line.index("ANGSTROMS.")
                    x_resol = float(line[22:i_tag])
                except:
                    print("Problem reading resoluction!")
            elif "HETATM" in line:
                if active in line:
                    chain = line[21:22]
                    number = line[22:26]
                    break
        
        # Return crystallographic data (resolution, chain id, 
        # and lig number)
        return x_resol,chain,number
    
    # Define lig_occupation_factor() method
    def lig_occupation_factor(self,active):
        """Method to calculated mean occupation factor for ligand atoms"""
        
        # Import package
        import numpy as np
        
        # Set up pdb file
        pdb_file = self.dir_in+self.access_code+".pdb"
        
        # Try to open a pdb file
        try:
            fo_pdb = open(pdb_file,"r")
            pdb_lines = fo_pdb.readlines()
        except:
            print("\nIOError! I can't find "+pdb_file+"!")
            return None
        
        # Set up empty list
        list_occ_factor = []
        
        # Assign None to mean_occupation_factor
        mean_occupation_factor = None
        
        # Looping through pdb_lines:
        for line in pdb_lines:
            if line[:6] == "HETATM" and line[17:20] == active:
                occ_factor = float(line[56:60])
                list_occ_factor.append(occ_factor )
        
        # Convert list to array
        array_occ_factor = np.array(list_occ_factor)
        
        # To avoid np.mean() with empty array
        if len(array_occ_factor) > 1:
            
            # Try to calculate mean value
            try:
                # Calculate mean value
                mean_occupation_factor = np.mean(array_occ_factor)
            except:
                mean_occupation_factor = 1.0
        else:
            mean_occupation_factor = 1.0
        
        # Return mean value
        return mean_occupation_factor

    # Define short_read_xtal() method
    def short_read_xtal(self):
        """Method to read crystallographic resolution in a PDB file"""
        
        # Set up pdb file
        pdb_file = self.dir_in+self.access_code+".pdb"
        
        # Assign initial value
        x_resol = None
        
        # Try to open a pdb file
        try:
            fo_pdb = open(pdb_file,"r")
            pdb_lines = fo_pdb.readlines()
        except:
            print("\nIOError! I can't find "+pdb_file+"!")
            return None,None
        
        # Looping through pdb_lines:
        for line in pdb_lines:
            if "REMARK   2 RESOLUTION." in line:
                try:
                    i_tag = line.index("ANGSTROMS.")
                    x_resol = float(line[22:i_tag])
                except:
                    pass
        
        # Return crystallographic resolution in Angstrom
        return x_resol