#!/usr/bin/env python3
#
# Class to check whether lig.pdbqt and receptor.pdbqt files were created.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import os
import csv

# Define PDBQT class
class PDBQT(object):
    """Class to check whether lig.pdbqt and receptor.pdbqt were created"""

    # Define constructor method
    def __init__(self,program_root,dir_in):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in

    # Define check_pdbqt() method
    def check_pqbqt(self):
        """Method to check whether lig.pdbqt and receptor.pdbqt were created"""

        # Define dataset_dir variable
        dataset_dir = self.dir_in+"pdbqt"

        # Get the list of directories
        pdbqt_dirs = os.listdir(dataset_dir)

        # Assign an initial False to a boolean variable
        no_pdbqt = False

        # Set up empty lists
        no_lig_pdbqt_list = []
        no_receptor_pdbqt_list = []

        # Looping through directories
        for pdb in pdbqt_dirs:

            # Check whether lig.pdbqt is in the directory
            if not os.path.isfile(dataset_dir+"/"+pdb+"/lig.pdbqt"):
                print("No lig.pdbqt for "+pdb)
                no_lig_pdbqt_list.append(pdb)

                # Assign True to a boolean variable
                no_pdbqt = True

            # Check whether receptor.pdbqt is in the directory
            if not os.path.isfile(dataset_dir+"/"+pdb+"/receptor.pdbqt"):
                print("No receptor.pdbqt for "+pdb)
                no_receptor_pdbqt_list.append(pdb)

                # Assign True to a boolean variable
                no_pdbqt = True

        # Open file with PDB access codes for which there are no PDBQT files
        if no_pdbqt:

            # Assign True to a boolean variable
            missing_pdbqt = True

            # open a new file
            fo_no_pdbqt = open(self.dir_in+"missing_pdbqt.csv","w")

            # Write first header
            fo_no_pdbqt.write("PDB, Missing files\n")

            # Looping through pdbqt_dirs
            for pdb in pdbqt_dirs:

                # Assign pdb+"," to line_out
                line_out = pdb+","

                # Assign False to a boolean variable
                no_pdbqt = False

                # Check whether lig.pdbqt is missing
                if pdb in no_lig_pdbqt_list:
                    line_out += "lig.pdbqt"

                    # Assign True to a boolean variable
                    no_pdbqt = True

                # Check whether receptor.pdbqt is missing
                if pdb in no_receptor_pdbqt_list:
                    line_out += " receptor.pdbqt"

                    # Assign True to a boolean variable
                    no_pdbqt = True

                # Write line if pdbqt is missing
                if no_pdbqt:
                    fo_no_pdbqt.write(line_out+"\n")

            # Close file
            fo_no_pdbqt.close()

        else:

            # Assign True to boolean variable
            missing_pdbqt = False

        return missing_pdbqt
