#!/usr/bin/env python3
#
# Class to convert from Molegro Virtual Docker (Thomsen & Christensen, 2006)
# format to SAnDReS format.
#
# Thomsen R, Christensen MH. MolDock: a new technique for high-accuracy
# molecular docking. J Med Chem. 2006 Jun 1;49(11):3315-21.
# doi: 10.1021/jm051197e. PMID: 16722650.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import binding_affinity as b_aff
from tools import molegro2sandres as molegro2san

# Define MVDData() class
class MVDData(object):
    """Class to convert from Molegro format to SAnDReS format"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define my_GUI() method
    def my_GUI(self):
        """Method to call pre_convert"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2+20,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title('SAnDReS')
        top_txt.geometry(top_txt_geom)

        # Widget for Molegro CSV file
        Label(top_txt,text="Molegro File:").grid(row=1,column=0,stick=W)
        self.csv_in = Entry(top_txt,width = 25)
        self.csv_in.grid(row = 1, column = 1,stick = E)
        self.csv_in.insert(0,"vs2.csv")

        # Widget for binding affinity data
        Label(top_txt, text="Binding Affinity File:").grid(row = 2,column = 0,
            stick = W)
        self.binding_file = Entry(top_txt,width = 25)
        self.binding_file.grid(row = 2, column = 1,stick = E)
        self.binding_file.insert(0,"affinity_BindingDB_Ki.csv")

        # Widget for SAnDReS output file
        Label(top_txt, text="SAnDReS File:").grid(row = 3,column = 0, stick = W)
        self.sandres_file = Entry(top_txt,width = 25)
        self.sandres_file.grid(row = 3, column = 1,stick = E)
        self.sandres_file.insert(0,"bind_Ki.csv")

        # Label (Insert space to get the right position of botton bar) (21)
        Label(top_txt, text = (self.win_y_offset_type_2-30)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Convert
        Button(top_txt,text='Convert',command=self.go2run).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define go2run() method
    def go2run(self):
        """Method to handle format convertion"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Define parameters
        mvd_in = self.csv_in.get()
        binding_affinity_file = self.binding_file.get()
        sandres_out = self.sandres_file.get()

        # Instantiate an object of MVD() class
        m1 = molegro2san.MVD(self.program_root,project_dir_string,mvd_in,
            binding_affinity_file,sandres_out)

        # Invoke read_mvd() method
        m1.prep_mvd()

        # Invoke read_par() method
        m1.read_par()

        # Invoke read_mvd() method
        m1.read_mvd()

        # Invoke write_csv() method
        m1.write_csv()

        # Invoke generate_molegro_features() method
        m1.generate_molegro_features()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,self.root)

        # Invoke show_botton_msg() method
        msg_out = "Done! Molegro data converted to SAnDReS format!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)
