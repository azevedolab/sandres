# Import packages
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import contacts as con

# Define ContactMap() class
class ContactMap(object):
    """Class to create a dataset"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Define ascii_art
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=2D-Plot
        self.art_2D_plot = """
██████╗ ██████╗       ██████╗ ██╗      ██████╗ ████████╗
╚════██╗██╔══██╗      ██╔══██╗██║     ██╔═══██╗╚══██╔══╝
 █████╔╝██║  ██║█████╗██████╔╝██║     ██║   ██║   ██║
██╔═══╝ ██║  ██║╚════╝██╔═══╝ ██║     ██║   ██║   ██║
███████╗██████╔╝      ██║     ███████╗╚██████╔╝   ██║
╚══════╝╚═════╝       ╚═╝     ╚══════╝ ╚═════╝    ╚═╝
 """

    # Define pre_intermol_GUI() method
    def pre_intermol_GUI(self):
        """Method to invoke intermol_GUI() method """

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() message
        msg_out = "Ready to generate 2D-plots using Matplotlib!"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Call show_short_msg() method
        msg_out = self.art_2D_plot+"\nUsing Matplotlib available at "
        msg_out += "https://matplotlib.org/"
        msg1.show_short_msg(msg_out)

        # Invoke intermol_GUI() method
        self.intermol_GUI(4.0,300)

    # Define intermol_GUI() method
    def intermol_GUI(self,distance_in,nres_in):
        """Method to call intermol"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title("Matplotlib: Visualization with Python")
        top_txt.geometry(top_txt_geom)

        # Widget for distance cutoff
        Label(top_txt,text="Distance cutoff (A):").grid(row=1,column=0,stick=W)
        self.top_distance_cutoff_entry = Entry(top_txt,width = 4)
        self.top_distance_cutoff_entry.grid(row = 1, column = 1,stick = E)
        self.top_distance_cutoff_entry.insert(0,str(distance_in))

        # Widget for number of residues
        Label(top_txt, text="Number of residues:" ).grid(row = 2,column = 0, stick = W)
        self.top_nres_entry = Entry(top_txt,width = 5)
        self.top_nres_entry.grid(row = 2, column = 1,stick = E)
        self.top_nres_entry.insert(0,str(nres_in))

        # Label (Insert space to get the right position of botton bar)(-8)
        Label(top_txt, text = (self.win_y_offset_type_2+104)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Plot
        Button(top_txt,text=' Plot ',command=self.call_intermol).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define call_intermol() method
    def call_intermol(self):
        """Method to call intermol() what set free the button"""

        # Import library
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # # Invoke show_botton_msg() method
        msg_out = " Counting intermolecular contacts ..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Ask yes/no question
        result = messagebox.askyesno("","Do you want to generate intermolecular contact plot?")

        if result:

            # Assign data to variables
            dir_in = str(self.strdir_entry.get())
            par_file_in = "bar_plot_par.csv"
            nres = int(self.top_nres_entry.get())
            cut_off = float(self.top_distance_cutoff_entry.get())

            # Instantiate an object of InterMol() class
            map1 = con.InterMol(self.program_root,dir_in,par_file_in,nres,cut_off)

            # Invoke calculate() method
            map1.calculate()

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished \"Add 2D Plot\" request!"
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Invoke show_short_msg() method
            msg1.show_short_msg(self.art_2D_plot+"\nDone!\n")

        else:
            # Invoke show_botton_msg() method
            msg_out="No request for generating plot for intermolecular contacts!"
            msg1.show_botton_msg(msg_out,"black","light grey")