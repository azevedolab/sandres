# Class to assess intermolecular contacts and generate a 3D-plot.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import os
from tools import bar_plot3d as bar3d

# Define Inter3DMolContact() class
class Inter3DMolContact(object):
    """Class to assess intermolecular contacts and generate a 3D-plot"""

    # Define constructor method
    def __init__(self,program_root,dir_in):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in

        # Set up self.dataset_dir
        self.dataset_dir = self.dir_in+"pdbqt"

        # Get a list with directories
        self.list_dataset_dir = os.listdir(self.dataset_dir)

    # Define plot3d_data() method
    def plot3d_data(self,plot_boolean):
        """ Method to generate 3D bar plot"""

        # Instantiate an object of Plot3DBar() class
        map_all = bar3d.Plot3DBar(self.program_root,self.dir_in,
        "bar_3dplot_par.csv")

        # Invoke read_contacts() method
        map_all.read_contacts()

        # Invoke generate() method
        map_all.generate(plot_boolean)
