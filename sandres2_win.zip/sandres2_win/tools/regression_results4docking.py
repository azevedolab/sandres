# Class to carry out bivariate statistical analysis of the docking results
# obtained using AutoDock Vina (Trott & Olson, 2010; Eberhardt et al., 2021).
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import numpy as np
import csv
from tools import bivariate_analysis as bi_analysis
from MLRegMPy import backup

# Define DockingResults() class
class DockingResults(object):
    """Class to carry out bivariate statistical analysis of regression models
    applied to docking simulations using AutoDock Vina"""

    # Define constructor method
    def __init__(self,dir_in,sf_file_in,bind_in):
        """Constructor method"""

        # Define attributes
        self.dir_in = dir_in
        self.sf_file_in = sf_file_in
        self.bind_in = bind_in

        # Set up empty list
        self.methods = []

    # Define docking_accuracy() method
    def docking_accuracy(self,rmsd_array):
        """ Method to calculate docking accuracy as defined in Xavier et al 2016
            doi: 10.2174/138620731966616092711134"""

        # Calculate docking accuracy (DA1 and DA2) (Xavier et al 2016)
        # doi: 10.2174/138620731966616092711134
        n_all = np.count_nonzero(rmsd_array > 0.0)
        n_a = np.count_nonzero(rmsd_array < 2.0)
        n_b = np.count_nonzero(rmsd_array < 3.0)
        n_c = np.count_nonzero(rmsd_array < 4.0)
        if n_all != 0:
            f_a = n_a/n_all
            f_b = n_b/n_all
            f_c = n_c/n_all
            self.da1 = f_a + 0.5*(f_b - f_a)
            self.da2 = self.da1 + 0.25*(f_c - f_b)
        else:
            print("\nError! Number of poses is zero!")
            print("Please check dataset!")
            return

        # Docking accuracy data
        self.f_mean = np.mean(rmsd_array)
        self.f_min = np.min(rmsd_array)
        self.f_max = np.max(rmsd_array)

    # Define get_stats() method
    def get_stats(self):
        """Method to read vina_rmsd_results_####.csv and carry out bivariate
        statistical analysis
        """

        # Invoke backup.make()
        file2backup = self.sf_file_in.replace(".csv","")
        file2backup += "_stats_joblib_models.csv"
        backup.make(file2backup,self.dir_in,self.dir_in+"backup/")

        # Open a new file
        file4stats = self.dir_in+self.sf_file_in.replace(".csv","")
        file4stats += "_stats_joblib_models.csv"
        fo_stats = open(file4stats,"w")

        # Write header
        h_stats = "Method,Mean RMSD(A),Minimum RMSD(A),Maximum RMSD(A),DA1,DA2,"
        h_stats += "r,p-value,r2,rho,p-value,MSE,RMSE,RSS\n"
        fo_stats.write(h_stats)

        # Looping through methods
        for method_in in self.methods:

            # Eliminate (kcal/mol)
            method_in = method_in.replace("(kcal/mol)","")
            method_in = method_in.replace(" ","")

            # Try to open vina_rmsd_results_####.csv
            try:
                file2open = self.dir_in+"models/"
                file2open += "vina_rmsd_results_"+method_in+".csv"
                fo_vina = open(file2open,"r")
                csv_vina = csv.reader(fo_vina)

                # Set up empty lists
                rmsd = []
                exp_bind = []
                calc_bind = []

                # Looping through csv_vina to jump first line
                for line in csv_vina:
                    break

                # Looping through csv_vina
                for line in csv_vina:
                    rmsd.append(float(line[2]))
                    exp_bind.append(float(line[3]))
                    calc_bind.append(float(line[4]))

                # Convert to arrays
                a_rmsd = np.array(rmsd)
                a_exp_bind = np.array(exp_bind)
                a_calc_bind = np.array(calc_bind)

                # Invoke docking_accuracy() method
                self.docking_accuracy(a_rmsd)

                # Instantiate an object of Metrics() class
                m1 = bi_analysis.Metrics(a_exp_bind,a_calc_bind,False)

                # Invoke bundle() method
                corr_p,pvalue_p,r2,corr_s,pvalue_s,mse,rmse_model,rss,\
                stats_results = m1.bundle()

                # Set up line (r p-value r2 rho p-value MSE RMSE RSS)
                a_out = method_in+","+str(self.f_mean)+","+str(self.f_min)
                a_out += ","+str(self.f_max)+","+str(self.da1)
                a_out += ","+str(self.da2)+","+str(corr_p)+","+str(pvalue_p)
                a_out += ","+str(r2)+","+str(corr_s)+","+str(pvalue_s)
                a_out += ","+str(mse)+","+str(rmse_model)+","+str(rss)
                print(a_out+"\n")

                # Write line
                fo_stats.write(a_out+"\n")

                # Close file
                fo_vina.close()

            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

        # Close file
        fo_stats.close()

    # Define get_centering() method
    def get_centering(self,pdb,rmsd_in):
        """Method to read vina_all_rmsd_results.csv and get centering to a
        given RMSD value"""

        # Try to open vina_all_rmsd_results.csv file
        try:
            file2open2 = self.dir_in+"vina_all_rmsd_results.csv"
            fo_vina = open(file2open2,"r")
            csv_vina = csv.reader(fo_vina)

            # Set up empty lists
            centering = []
            aux_rmsd = []

            # Looping through csv_vina to jump first line
            for v_line in csv_vina:
                break

            # Looping through csv_vina to get relevant data
            for v_line in csv_vina:

                # Get data for the right PDB
                if v_line[0] == pdb and \
                "ND" not in str(v_line[3]) and \
                "nan" not in str(v_line[3]):
                    aux_rmsd.append(float(v_line[3]))
                    centering.append(v_line[1])

            # Get index
            i_lowest = aux_rmsd.index(rmsd_in)

            # Get centering for lowest scoring function value
            self.center4lowest = str(centering[i_lowest])

            # Close file
            fo_vina.close()

        except IOError:
            print("\nI can't find "+file2open2+" file!")
            self.center4lowest = "None"
            return

    # Define get_methods() method
    def get_methods(self):
        """Method to read header and identify regression methods present in a
        CSV file"""

        # Try to open self.sf_file_in
        try:
            file2open = self.dir_in+self.sf_file_in
            fo_sf = open(file2open,"r")
            csv_sf = csv.reader(fo_sf)
        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            return

        # To append Vina scoring function
        self.methods.append("Affinity(kcal/mol)")

        # Looping through csv_sf lines (first line)
        i_score = 31    # i_score = 31 due to addition of Torsional
        for line1 in csv_sf:
            for line2 in line1[i_score:]:
                self.methods.append(line2)
            break

        # Close file
        fo_sf.close()

    # Define read_it() method
    def read_it(self,method_in):
        """Method to read self.sf_file_in and get PDB,RMSD,
        Experimental Affinity (pIC50, pKd, pKi),
        scoring function value (obtained with regression method) """

        # Try to open self.sf_file_in
        try:
            file2open = self.dir_in+self.sf_file_in
            fo_sf = open(file2open,"r")
            csv_sf = csv.reader(fo_sf)
        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            return

        # Looping through csv_sf lines (first line)
        for line in csv_sf:
            i_score = line.index(method_in)
            method_in = method_in.replace("(kcal/mol)","")
            method_in = method_in.replace(" ","")

            break

        # Main loop
        pdb = ""

        # Assign zero count_pdb and count_results
        count_pdb = 0
        count_results = 0

        # Set up empty lists
        rmsd = []
        log_binding_aff = []
        scores = []
        pdb_list = []

        # Open a new file
        file2create = self.dir_in+"models/vina_rmsd_results_"+method_in+".csv"
        fo_out = open(file2create,"w")

        # Write header1
        header1 = "PDB,Centering,RMSD(A),log("+self.bind_in+"),"+method_in+"\n"
        fo_out.write(header1)

        # Looping through csv_sf lines
        for line in csv_sf:

            # Test PDB
            if line[0] != pdb:

                # Update count_pdb
                count_pdb += 1

                # Update line
                if count_pdb > 1:

                    # Get index for minimum score
                    a_scores = np.array(scores)
                    i = np.argmin(a_scores)

                    # We might use an array of indexes for the case where
                    # the minimum in a_scores has more than one index
                    #minimum_score = np.amin(a_scores)
                    #i_array = np.where(a_scores == minimum_score)

                    # Check and set up line_out
                    if count_results > 0:

                        # Invoke get_centering()
                        self.get_centering(pdb_list[i],rmsd[i])

                        # Set up and write line_out
                        line_out = pdb_list[i]+","+self.center4lowest+","
                        line_out += str(rmsd[i])+","+str(log_binding_aff[i])
                        line_out += ","+str(scores[i])
                        fo_out.write(line_out+"\n")

                    # Update count_results
                    count_results += 1

                    # Set up empty lists
                    rmsd = []
                    log_binding_aff = []
                    scores = []
                    pdb_list = []

                    # Update pdb
                    pdb = line[0]

            # Update lists
            log_binding_aff.append(float(line[7]))
            rmsd.append(float(line[9]))
            scores.append(float(line[i_score]))
            pdb_list.append(line[0])

        # For last line get index
        a_scores = np.array(scores) #
        i = np.argmin(a_scores)     #

        # Invoke get_centering()
        self.get_centering(pdb_list[i],rmsd[i])

        # Set up line_out for last line
        line_out = pdb_list[i]+","+self.center4lowest+","
        line_out += str(rmsd[i])+","+str(log_binding_aff[i])
        line_out += ","+str(scores[i])
        fo_out.write(line_out+"\n")

        # Close files
        fo_sf.close()
        fo_out.close()

    # Define bundle() method
    def bundle(self):
        """Method to get all data"""

        # Invoke get_methods()
        self.get_methods()

        # Looping through methods
        for method_in in self.methods:

            # Show message
            msg_out = "\nReading data for method: "+method_in
            print(msg_out)

            # Invoke read_in() method
            self.read_it(method_in)

        # Invoke get_stats()
        self.get_stats()
