# Import packages
import csv
import os
import numpy as np
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import docking_analysis as analysis
from tools import docking_vina as vina

# Define Simulation() class
class Simulation(object):
    """Class to handle protein-ligand docking simulations"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    ############################################################################
    # Define docking_GUI() method
    def docking_GUI(self):
        """GUI to run docking simulations taking
        centering: center of mass (CM), electric center (EC), and
        geometric center GC"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access codes using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        number_of_pdbs = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_short_msg() method
        msg_out = "Number of structures in the dataset: {:8d}".\
        format(number_of_pdbs)
        msg_out += "                                                           "
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Define function to carry out docking simulation showing a progress bar
        def run_all():
            """Function to show a progress bar for docking simulations"""

            # Invoke progress_bar_docking()
            self.progress_bar_docking("Docking Simulations")

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('AutoDock Vina')
        top_txt.geometry(top_txt_geom)

        # Widgets for project directory
        Label(top_txt,
            text = "Docking Simulations with Vina:" ).grid(row = 0,
            column = 0, stick = W, padx = 0)

        # Widget for running docking simulations (with progress bar)
        Button(top_txt,text='Run',\
            command=run_all).grid(row=0,column=1,sticky = W)

        # Show Empty Label (52)
        Label(top_txt, text=149*" ",font="Arial").grid(row=2,column=5,stick = W)

        # Widgets for Close button
        Button(top_txt, text='  Close ', bg = "red",
        command=top_txt.destroy).grid(row = 3, column = 11,sticky = E)

    # Define progress_bar_docking() method
    def progress_bar_docking(self,progress_bar_docking_title):
        """Method to follow docking simulations with a progress bar"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get PDB access codes using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        number_of_pdbs = len(pdb_list)

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160)(52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_3,self.win_y_offset_type_3)

        # Define docking_loop() function
        def docking_loop():

            # Instantiate an object of Docking() class
            lig0 = vina.Docking(self.program_root,project_dir_string)

            # Looping through pdb_list and run AutoDock Vina
            i = 1
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke bundle() method
                    lig0.bundle(pdb)

                except:
                    pass

                # To handle exceptions related to the Done button
                try:
                    if i != 0:
                        pr_bar_01["value"] = i*100/number_of_pdbs
                    else:
                        pr_bar_01["value"] = i*100
                    root.update()
                except:
                    return

                # Add 1 to i
                i += 1

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished "
            msg_out += "\"One Click Docking with Vina\" request using "
            msg_out += "AutoDock Vina!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Set up progress bar (pr_bar_01)
        # Create child window
        root = tk.Tk()
        root.title(progress_bar_docking_title)
        root.geometry(top_txt_geom) # 870x52+0+540('870x50+0+430') length = 790
        pr_bar_01 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_01.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=docking_loop)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()

    ############################################################################
    # Define cm_docking_GUI() method
    def cm_docking_GUI(self):
        """GUI to run docking simulations taking
        centering: center of mass (CM)"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access codes using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        number_of_pdbs = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_short_msg() method
        msg_out = "Number of structures in the dataset: {:8d}".\
        format(number_of_pdbs)
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Define function to carry out docking simulation showing a progress bar
        def run_cm():
            """Function to show a progress bar for docking simulations"""

            # Invoke progress_bar_docking()
            self.progress_bar_cm_docking("Docking Simulations")

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('AutoDock Vina')
        top_txt.geometry(top_txt_geom)

        # Widgets for project directory
        Label(top_txt,
            text = "Docking Simulations with Vina:" ).grid(row = 0,
            column = 0, stick = W, padx = 0)

        # Widget for running docking simulations (with progress bar)
        Button(top_txt,text='Run',\
            command=run_cm).grid(row=0,column=1,sticky = W)

        # Show Empty Label
        Label(top_txt, text=52*" ",font="Arial").grid(row=2,column=5,stick = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 3, column = 11,sticky = E)

    # Define progress_bar_cm_docking() method
    def progress_bar_cm_docking(self,progress_bar_docking_title):
        """Method to follow docking simulations with a progress bar"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get PDB access codes using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        number_of_pdbs = len(pdb_list)

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160)(52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_3,self.win_y_offset_type_3)

        # Define cm_docking_loop() function
        def cm_docking_loop():

            # Instantiate an object of Docking() class
            lig1 = vina.Docking(self.program_root,project_dir_string)

            # Looping through pdb_list and run AutoDock Vina
            i = 1
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke fast_bundle() method
                    lig1.fast_bundle(pdb)

                except:
                    pass

                # To handle exceptions related to the Done button
                try:
                    if i != 0:
                        pr_bar_02["value"] = i*100/number_of_pdbs
                    else:
                        pr_bar_02["value"] = i*100
                    root.update()
                except:
                    return

                # Add 1 to i
                i += 1

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished "
            msg_out += "\"One Click Docking with Vina\" request using "
            msg_out += "AutoDock Vina!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Set up progress bar (pr_bar_02)
        # Create child window
        root = tk.Tk()
        root.title(progress_bar_docking_title)
        root.geometry(top_txt_geom) # 870x52+0+540('870x50+0+430') length = 790
        pr_bar_02 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_02.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=cm_docking_loop)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()

    ############################################################################
    ############################################################################
    # Define stats_GUI() method
    def stats_GUI(self):
        """GUI to carry out statistical analysis of a dataset"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Define function to carry out statistical analysis
        def stats_analysis():
            """Function to carry out statistical analysis"""

            # Get data from GUI
            project_dir_string = dataset_entry.get()
            ligand_in = xtal_entry.get()
            ligand_out = poses_entry.get()

            # Set up string with the header
            lines_out = "PDB,Centering Method,RMSD(A)\n"

            # Get PDB access codes using os.listdir()
            pdb_list = os.listdir(project_dir_string)

            # Show entries
            print("Dataset Directory: ",project_dir_string)
            print("Crystallographic ligand: ",ligand_in)
            print("Poses: ",ligand_out)

            # Instantiate an object of Stats() class
            ext_dataset = analysis.Stats(self.program_root,
            project_dir_string,ligand_in,ligand_out)

            ####################################################################
            # Looping through dataset
            for pdb in pdb_list:

                # Show message
                print("\nReading docking results for structure ",pdb)

                # Try to invoke bundle() method
                try:
                    # Invoke bundle() method
                    ext_dataset.bundle(pdb)
                except:
                    print("\nProblems with PDB: ",pdb)

                # Try to open vina_rmsd_results.csv
                file2open = project_dir_string+pdb+"/vina_results.csv"
                try:
                    fo_rmsd = open(file2open,"r")
                    csv_rmsd = csv.reader(fo_rmsd)

                    # Looping through csv_rmsd
                    for line in csv_rmsd:
                        if line[0] == "RMSD":
                            rmsd_data = float(line[1])

                    # Close file
                    fo_rmsd.close()

                except IOError:

                    # Assign "ND" to rmsd_data
                    rmsd_data = "ND"

                # Set up one line per PDB
                lines_out +=pdb+",ND,"+str(rmsd_data)+"\n"

            ####################################################################
            # Open a new file (vina_rmsd_results.csv)
            file2create = project_dir_string+"vina_rmsd_results.csv"
            fo_all_rmsd = open(file2create,"w")

            # Write RMSD data
            fo_all_rmsd.write(lines_out)

            # Close file
            fo_all_rmsd.close()
            ####################################################################
            ####################################################################
            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished "
            msg_out += "\"One Click Docking with Vina\" request using "
            msg_out += "AutoDock Vina!"
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Try to open vina_rmsd_results.csv
            try:
                file2open = project_dir_string+"vina_rmsd_results.csv"
                fo_stats = open(file2open,"r")
                csv_stats = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Set up empty string
            msg_stats = ""

            # Set up empty lists
            list_rmsd = []
            pdb_list_no_rmsd = []
            pdb_list_rmsd = []

            # Looping through csv_stats (first line)
            for line in csv_stats:
                # Some editing
                header_line = str(line[0])+"\t"+str(line[1])+"\t"+str(line[2])
                msg_stats += header_line+"\n"
                break

            # Looping through csv_stats
            for line in csv_stats:

                # Some editing
                if "mass" in line[1]:
                    centering = "mass     "
                elif "electric" in line[1]:
                    centering = "electric "
                elif "geometric" in line[1]:
                    centering = "geometric"
                else:
                    centering = "ND       "

                line_out = str(line[0])+"\t"+centering+"\t\t"+str(line[2])
                msg_stats += line_out+"\n"

                # To get RMSD values
                if "ND" not in line[2]:
                    list_rmsd.append(float(line[2]))
                    pdb_list_rmsd.append(line[0])
                else:
                    pdb_list_no_rmsd.append(line[0])

            ####################################################################
            # Convert list to array
            rmsd_array = np.array(list_rmsd)

            # Calculate docking accuracy (DA1 and DA2) (Xavier et al 2016)
            # doi: 10.2174/138620731966616092711134
            n_all = np.count_nonzero(rmsd_array > 0.0)
            n_a = np.count_nonzero(rmsd_array < 2.0)
            n_b = np.count_nonzero(rmsd_array < 3.0)
            n_c = np.count_nonzero(rmsd_array < 4.0)
            if n_all != 0:
                f_a = n_a/n_all
                f_b = n_b/n_all
                f_c = n_c/n_all
                da1 = f_a + 0.5*(f_b - f_a)
                da2 = da1 + 0.25*(f_c - f_b)
            else:
                print("\nError! Number of poses is zero!")
                print("Please check dataset!")
                return

            # Add docking accuracy data
            msg_stats +="\n\nDocking accuracies\n"
            formated_da1 = "{:.3f}".format(da1)
            formated_da2 = "{:.3f}".format(da2)
            msg_stats += "DA1 = "+str(formated_da1)+"\n"
            msg_stats += "DA2 = "+str(formated_da2)+"\n"

            # Add docking RMSD average, minimum and maximum
            msg_stats += "\n\nDocking RMSD\n"
            formated_mean = "{:.3f}".format(np.mean(rmsd_array))
            msg_stats += "Mean RMSD (A) = "+str(formated_mean)+"\n"
            msg_stats += "Maximum RMSD (A) = "+str(np.max(rmsd_array))+"\n"
            msg_stats += "Minimum RMSD (A) = "+str(np.min(rmsd_array))+"\n"

            # Add list of PDB with no docking results
            msg_stats += "\n\nNo docking results for the following PDB(s): "
            msg_stats += str(pdb_list_no_rmsd)+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_stats)

            # Write statistical analysis
            file2create = project_dir_string+"docking_summary.log"
            fo_summary = open(file2create,"w")
            fo_summary.write(msg_stats)

            # Close files
            fo_stats.close()
            fo_summary.close()
            ####################################################################

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('Statistical Analysis of Docking Results Generated with AutoDock Vina')
        top_txt.geometry(top_txt_geom)

        # Widget for dataset directory
        Label(top_txt, text="Dataset directory:" ).grid(row = 0,
        column = 0, stick = W, pady = 4)
        dataset_entry = Entry(top_txt,width = 50)
        dataset_entry.grid(row = 0, column = 1,stick = E, pady = 4)
        dataset_entry.insert(50,str(project_dir_string))

        # Widget for dataset directory
        Label(top_txt, text="Poses:" ).grid(row = 0,
        column = 2, stick = W, pady = 4)
        poses_entry = Entry(top_txt,width = 15)
        poses_entry.grid(row = 0, column = 3,stick = E, pady = 4)
        poses_entry.insert(15,"lig_out.pdbqt")

        # Widget for crystallographic ligand
        Label(top_txt, text="Crystallographic Ligand:" ).grid(row = 1,
        column = 2, stick = W, pady = 4)
        xtal_entry = Entry(top_txt,width = 10)
        xtal_entry.grid(row = 1, column = 3,stick = E, pady = 4)
        xtal_entry.insert(10,"lig.pdbqt")

        # Widget for running docking simulations (with progress bar)
        Button(top_txt,text='Run',\
            command=stats_analysis).grid(row=2,column=3,sticky = E)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 2, column = 11,sticky = E)
