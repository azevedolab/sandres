Here, we find five case studies focused on a protein system and one study to build a universal scoring function (case study 06). A protein system has one target and binding affinity data. Taking this definition, CDK2 with IC50 (case study 01) is a protein system different from CDK2 with Ki data (case study 03). In case study 06, we do not focus on one protein system. We train our scoring functions using a data set of high-resolution crystallographic structures. Our goal in case study 06 is to check the predictive performance of a universal scoring function generated with SAnDReS and other functions against the CASF-2016 [Su et al., 2019] benchmark with a test with Ki data.
For case studies 01 and 06, we find a folder named Xtal with predicted values determined using crystallographic structures. For case studies 03 and 05, we based our machine-learning model on docked structures. 
In the following, we have the list of files for each case study.

Case Study	Folder		File				Brief Description
01		Docking		scores4poses_test.csv		Predicted values for docked structures in the test set
01		Docking		scores4poses_training.csv	Predicted values for docked structures in the training set (not used for training here)
01		Xtal		scores_test.csv			Predicted values for crystal structures in the test set
01		Xtal		scores_training.csv		Predicted values for crystal structures in the training set (used for training regression models)

02		Docking		scores4poses.csv		Predicted values for docked structures using regression models developed on case study 01

03		Docking		scores_test.csv			Predicted values for docked structures in the test set
03		Docking		scores_training.csv		Predicted values for docked structures in the training set (used for training regression models)

04		Docking		scores4poses.csv		Predicted values for docked structures using regression models developed on case study 03

05		Docking		scores_test.csv			Predicted values for docked structures in the test set
05		Docking		scores_training.csv		Predicted values for docked structures in the training set (used for training regression models)

06		Xtal		scores_test.csv			Predicted values for crystal structures in the test set
06		Xtal		scores_training.csv		Predicted values for crystal structures in the training set (used for training regression models)


Reference
Su M, Yang Q, Du Y, Feng G, Liu Z, Li Y, Wang R. Comparative Assessment of Scoring Functions: The CASF-2016 Update. J Chem Inf Model. 2019 Feb 25;59(2):895-913.







