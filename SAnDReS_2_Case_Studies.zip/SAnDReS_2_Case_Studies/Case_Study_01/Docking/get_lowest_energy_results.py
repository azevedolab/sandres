# Script to read a CSV file with docking results and select the lowest energy
# poses for each PDB. This script writes the data of each chosen pose in a new
# CSV file. It considers that the PDB column is the first column.
#
# To run this script
# python get_lowest_energy_results.py scores4poses_test.csv Affinity(kcal/mol) scores4poses_test_unique1.csv
#
# Import section
import sys
import csv
import pandas as pd

# Define some_editing() function
def some_editing(string_in):
    """Ubiquitous function to carry out some string editing"""

    # Now editing
    string_out = string_in.replace("[","")
    string_out = string_out.replace("]","")
    string_out = string_out.replace("'","")
    string_out = string_out.replace(", ",",")
    string_out = string_out.replace(" ,",",")

    # Return edited string
    return string_out

# Get inputs
file_in = sys.argv[1]
energy_string_in = sys.argv[2]
file_out = sys.argv[3]


# Source https://www.usepandas.com/csv/sort-csv-data-by-column
#
# Read in your .csv files as dataframes
# df is a common standard for naming a dataframe. You can
# name them something more descriptive as well.
# Using a descriptive name is helpful when you are dealing
# with multiple .csv files.
df = pd.read_csv("scores4poses_test.csv")

# the .sort_values method returns a new dataframe, so make sure to
# assign this to a new variable.
sorted_df = df.sort_values(by=[energy_string_in], ascending=True)

# Index=False is a flag that tells pandas not to write
# the index of each row to a new column. If you'd like
# your rows to be numbered explicitly, leave this as
# the default, True
sorted_file = file_in.replace(".csv","_sorted.csv")
sorted_df.to_csv(sorted_file, index=False)

# Now getting the lowest energy poses
# Try to open sorted_file
try:
    fo = open(sorted_file,"r")
    csv_fo = csv.reader(fo)
except IOError:
    msg_out = "\nIOError! I can't find file "+sorted_file+"!"
    sys.exit(msg_out)

# Set up an empty list
pdb_list = []

# Looping through csv_fo (skip header)
for line in csv_fo:
    aux_line = str(line)

    # Call some_editing() function
    aux_line = some_editing(aux_line)
    lines_out = aux_line+"\n"
    break

# Looping through csv_fo (getting the data)
for line in csv_fo:
    pdb = line[0].strip()

    # Get new pdb
    if pdb not in pdb_list:

        # Update pdb_list
        pdb_list.append(pdb)

        aux_line = str(line)

        # Call some_editing() function
        aux_line = some_editing(aux_line)

        lines_out += aux_line+"\n"

# Open a new file
fo_new = open(file_out,"w")

# Write data
fo_new.write(lines_out)

# Close files
fo.close()
fo_new.close()