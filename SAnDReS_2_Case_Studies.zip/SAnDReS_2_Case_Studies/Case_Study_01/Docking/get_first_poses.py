# Script to read a CSV file with docking results and select the first poses for
# each PDB code. This script writes the data of each chosen pose in a new CSV
# file. It considers that the PDB column is the first column.
#
# To run this script
# python get_first_poses.py scores4poses_test.csv scores4poses_test_unique2.csv
#
# Import section
import sys
import csv

# Define some_editing() function
def some_editing(string_in):
    """Ubiquitous function to carry out some string editing"""

    # Now editing
    string_out = string_in.replace("[","")
    string_out = string_out.replace("]","")
    string_out = string_out.replace("'","")
    string_out = string_out.replace(", ",",")
    string_out = string_out.replace(" ,",",")

    # Return edited string
    return string_out

# Get inputs
file_in = sys.argv[1]
file_out = sys.argv[2]

# Try to open a file
try:
    fo = open(file_in,"r")
    csv_fo = csv.reader(fo)
except IOError:
    msg_out = "\nIOError! I can't find file "+file_in+"!"
    sys.exit(msg_out)

# Set up an empty list
pdb_list = []

# Looping through csv_fo (skip header)
for line in csv_fo:
    aux_line = str(line)

    # Call some_editing() function
    aux_line = some_editing(aux_line)
    lines_out = aux_line+"\n"
    break

# Looping through csv_fo (getting the data)
for line in csv_fo:
    pdb = line[0].strip()

    # Get new pdb
    if pdb not in pdb_list:

        # Update pdb_list
        pdb_list.append(pdb)

        aux_line = str(line)

        # Call some_editing() function
        aux_line = some_editing(aux_line)

        lines_out += aux_line+"\n"

# Open a new file
fo_new = open(file_out,"w")

# Write data
fo_new.write(lines_out)

# Close files
fo.close()
fo_new.close()