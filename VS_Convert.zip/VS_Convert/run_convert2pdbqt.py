# Import package
from tools import convert2pdbqt as conv2pdbqt

# Main function
def main():

    # Set up arguments
    program_root = "/home/walter/Dev/VS_Convert/"
    dir_in = "/home/walter/Dev/VS_Convert/FDA/"
    dir_out = "/home/walter/Dev/VS_Convert/FDA/"
    lig_in = "fda.mol2"
    root_out = "lig_"

    # Instantiate an object of LIGPDBQT() class
    mol = conv2pdbqt.LIGPDBQT(program_root,dir_in,dir_out)

    # Invoke mol2split() method
    mol.mol2split(lig_in,root_out)

    # Invoke pdb2pdbqt() method
    mol.pdb2pdbqt(lig_in,root_out)

main()