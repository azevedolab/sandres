#!/usr/bin/env python3
#
################################################################################
# Machine Learning Regression Methods in Python (MLRegMPy)                     #
################################################################################
#
# MLRegMPy has supervised machine-learning techniques implemented using the
# scikit-learn library (Pedregosa et al., 2011)
# (https://scikit-learn.org/stable/modules/linear_model.html). It employs
# CSV files (bind_###.csv and pdb_codes.csv) with energy terms and descriptors
# and takes them as features to build a machine-learning model targeted to a
# system of interest. MLRegMpy is an open-source machine-learning library that
# supports 54 supervised learning methods.
# Dr. Walter F. de Azevedo, Jr.
# (https://www.scopus.com/authid/detail.uri?authorId=7006435557) developed this
# code which is the main machine-learning engine used in the programs
# SAnDReS (Xavier et al., 2016), Taba (da Silva et al., 2020), and
# SFSXplorer (https://github.com/azevedolab/SFSXplorer). MLRegMPy explores the
# scoring function space concept (Ross et al., 2013; Heck et al., 2017;
# Bitencourt-Ferreira & de Azevedo, 2019b) to develop computational models
# targeted to specific protein systems. Although the development focused on
# scoring functions to predict protein-ligand interactions, this program can
# build supervised machine-learning models for any application. MLRegMPy
# relies on the metrics recommended by Walsh et al., 2021 to evaluate the
# predictive performance of the models created using scikit-learn. The
# explore-sfs and user-defined options of MLRegMPy allow the generation of
# several models through the combination features. After the modeling step,
# MLRegMPy returns the best model based on solid statistical analysis.
# We have three options to run MLRegMPy. One named explore-sfs aims to explore
# the scoring function space (SFS) by selecting the features with the best
# predictive performance. The user chooses the criterion
# (criterion_in,r2 in the file ml.in) to define the top-ranked features
# (e.g., r, r2, rho, RMSE, MAE, and R2). MLRegMPy creates combinations of the
# top-ranked features and tests them all. To run MLRegMPy for the explore-sfs
# option, type the following commands in a Linux terminal:
# python3 mlr.py mlr.in explore > mlr.log &
#
# The user-defined option focuses on a set of features defined by the user.
# MLRegMPy generates combinations of variables and tests them all. Taking the
# total number of inputs (ud_n_set_in,15 in the file ml.in) as 15 and creating
# models with eight variables (ud_n_features_in,8 in the file ml. in) will
# result in C15,8 equations (6435 regression models). To run MLRegMPy for the
# user-defined option, type the following commands in a Linux terminal:
# python3 mlr.py mlr.in user-defined > mlr.log &
#
# The last option aims to generate one regression model named single-model. We
# may use this option taking the best model developed using either explore-sfs
# or user-defined options. Use the following commands to run this option:
# python3 mlr.py mlr.in single-model > mlr.log &
#
#
# References:
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281. DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69–73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, Blondel
# M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A, Cournapeau D,
# Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning in Python. J
# Mach Learn Res. 2011; 12: 2825–2830. arXiv:1201.0490
#
# Ross GA, Morris GM, Biggin PC. One Size Does Not Fit All: The Limits of
# Structure-Based Models in Drug Discovery. J Chem Theory Comput. 2013; 9(9):
# 4266–4274. doi: 10.1021/ct4004228. PMID: 24124403; PMCID: PMC3793897.
#
# Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
# Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
# recommendations for supervised machine learning validation in biology. Nat
# Methods. 2021; 18(10): 1122–1127. doi: 10.1038/s41592-021-01205-4.
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Number: 306298/2022-8.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# October 19, 2023                                                             #
################################################################################
#
# To run MLRegMPy
#
# python3 mlr.py mlr.in single-model > mlr.log &
# or
# python3 mlr.py mlr.in explore-sfs > mlr.log &
# or
# python3 mlr.py mlr.in user-defined > mlr.log &
#
################################################################################
# Import section
from MLRegMPy import ML_Regression
import os
import sys
import csv
from datetime import datetime

################################################################################
# Define function to handle hash in a field (float or integer or string)
def handle_hash(type_in,line_in):
    """Function to handle hash in a field and returns a string"""

    # Test type_in
    if type_in == "str":
        # Handle hash for string output
        try:
            index_hash = str(line_in).index("#")
            data_out = line_in[:index_hash]
            data_out = data_out.replace(" ","")
        except:
            data_out = line_in.replace(" ","")
    else:
        # Print error message and return
        print("\nError! Undefined input!")
        return None

    # Return data
    return data_out

################################################################################
# Define main() function
def main():

    # Get start_time
    start_time = datetime.now()

    # Get input data from terminal
    mlr_in = sys.argv[1]        # Input file
    mode_in = sys.argv[2]       # single-model for performing all steps for
                                # one set of features, explore-sfs to explore
                                # the SFS, and user-defined to explore a defined
                                # set of features

    # Try to open mlr_in file
    try:
        fo_mlr = open(mlr_in,"r")
        csv_mlr = csv.reader(fo_mlr)

    # Handle IOError
    except IOError:
        msg_out = "IOError! I can't find "+mlr_in+" file!"
        sys.exit()

    # Looping through csv_mlr
    for line in csv_mlr:
        if "#" in str(line):
            pass
        elif line[0].strip() == "dataset_dir_in":
            dataset_dir_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "sf_file_in":
            sf_file_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "mlregmpy_in":
            mlregmpy_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "preprocessing_in":
            preprocessing_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "ml_parameters_in":
            ml_parameters_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "scoring_function_file_in":
            scoring_function_file_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "target_in":
            target_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "test_size_in":
            test_size_in = float(handle_hash("str",str(line[1])))
        elif line[0].strip() == "seed_in":
            seed_in = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "criterion_in":
            criterion_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "ml_criterion_in":
            ml_criterion_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "data4criterion_in":
            data4criterion_in = handle_hash("str",str(line[1]))
        elif line[0].strip() == "s_n_features_in":
            s_n_features_in = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "s_features_in":
            s_features_in = line[1:int(s_n_features_in)+1]
        elif line[0].strip() == "x_n_set_in":
            x_n_set_in = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "x_n_features_in":
            x_n_features_in = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "ud_n_set_in":
            ud_n_set_in = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "ud_n_features_in":
            ud_n_features_in = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "ud_features_in":
            ud_features_in = line[1:int(ud_n_set_in)+1]
        elif line[0].strip() == "plot2d_file":
            plot2d_file = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_title":
            plot2d_title = line[1].strip()
        elif line[0].strip() == "plot2d_title_size":
            plot2d_title_size = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_metrics_x":
            plot2d_metrics_x = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_metrics_y":
            plot2d_metrics_y = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_bar":
            plot2d_bar = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_x_axis_label":
            plot2d_x_axis_label = line[1].strip()
        elif line[0].strip() == "plot2d_y_axis_label":
            plot2d_y_axis_label = line[1].strip()
        elif line[0].strip() == "plot2d_bar_label":
            plot2d_bar_label = line[1].strip()
        elif line[0].strip() == "plot2d_bar_size":
            plot2d_bar_size = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_x_axis_size":
            plot2d_x_axis_size = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_y_axis_size":
            plot2d_y_axis_size = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_x_axis_min":
            plot2d_x_axis_min = float(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_x_axis_max":
            plot2d_x_axis_max = float(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_y_axis_min":
            plot2d_y_axis_min = float(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_y_axis_max":
            plot2d_y_axis_max = float(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_cmap_color":
            plot2d_cmap_color = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_marker":
            plot2d_marker = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_marker_edge":
            plot2d_marker_edge = handle_hash("str",str(line[1]))
        elif line[0].strip() == "plot2d_dpi":
            plot2d_dpi = int(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_alpha":
            plot2d_alpha = float(handle_hash("str",str(line[1])))
        elif line[0].strip() == "plot2d_grid":
            plot2d_grid = handle_hash("str",str(line[1]))

    # Close file
    fo_mlr.close()

    # Set up program root directory
    program_root = os.getcwd()+"/"

    # Instantiate an object of the Modeling() class
    ms = ML_Regression.Modeling(
                                program_root,
                                mode_in,
                                dataset_dir_in,
                                sf_file_in,
                                mlregmpy_in,
                                preprocessing_in,
                                ml_parameters_in,
                                scoring_function_file_in,
                                target_in,
                                test_size_in,
                                seed_in,
                                criterion_in,
                                ml_criterion_in,
                                data4criterion_in,
                                s_n_features_in,
                                s_features_in,
                                x_n_set_in,
                                x_n_features_in,
                                ud_n_set_in,
                                ud_n_features_in,
                                ud_features_in,
                                plot2d_file,
                                plot2d_title,
                                plot2d_title_size,
                                plot2d_metrics_x,
                                plot2d_metrics_y,
                                plot2d_bar,
                                plot2d_x_axis_label,
                                plot2d_y_axis_label,
                                plot2d_bar_label,
                                plot2d_bar_size,
                                plot2d_x_axis_size,
                                plot2d_y_axis_size,
                                plot2d_x_axis_min,
                                plot2d_x_axis_max,
                                plot2d_y_axis_min,
                                plot2d_y_axis_max,
                                plot2d_cmap_color,
                                plot2d_marker,
                                plot2d_marker_edge,
                                plot2d_dpi,
                                plot2d_alpha,
                                plot2d_grid
                                )

    # Invoke bundle() method
    ms.bundle()

    # Get end_time
    end_time = datetime.now()

    # Show duration
    print("\n\n\nDuration: {}".format(end_time - start_time))

# Call main() function
main()
print("\nFinished regression modeling!")