# Class to generate training and test set based on input information in
# ml_par.csv file.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import numpy as np
import random
from MLRegMPy import backup

# Class to handle a dataset and split it in training and test sets
class Dataset(object):
    """Class to generate training and test set based on input information
    in ml_par.csv"""

    # Define constructor method
    def __init__(self,dir_in,reference_file_in,secondary_file_in,test_size_in,
                seed_in):
        """Constructor method"""

        # Set up attributes
        self.dir_in = dir_in
        self.reference_file_in = reference_file_in
        self.secondary_file_in = secondary_file_in
        self.test_size_in = test_size_in
        self.seed_in = seed_in

        # Set up empty lists
        self.pdb_test = []
        self.pdb_train = []

    # Define random_pdb() method to automatically determine the structures
    # for training and test sets
    def random_pdb(self):
        """Method to generate the PDBs for training and test sets"""

        # Try to open self.reference_file_in
        try:
            file2open = self.dir_in+self.reference_file_in
            data = np.genfromtxt(file2open,skip_header=1,delimiter=",")
            rows = data[:,8]
            n_rows = len(rows)
            fo_data = open(file2open,"r")
            csv_data = csv.reader(fo_data)

            # Set up seed for pseudo-random number generator
            random.seed(a=self.seed_in, version=2)

            # Set up empty list
            test_rows = []

            # Assign zero to i
            i = 0

            # Get unique integers
            while i < int(self.test_size_in*n_rows):

                # Generate pseudo-random
                n = random.randint(0,n_rows)

                # Check if n is in the list
                if n not in test_rows:

                    # Append number
                    test_rows.append(n)

                    # Update i
                    i += 1

            # Assign zero to i
            i_line = 0

            # Looping through csv_data to jump first line
            for line in csv_data:
                break

            # Looping through csv_data
            for line in csv_data:

                # Split
                if i_line in test_rows:
                    self.pdb_test.append(line[0])
                else:
                    self.pdb_train.append(line[0])

                # Update
                i_line += 1

            # Close file (dataset)
            fo_data.close()

            # Get number of PDBs
            count_test = len(self.pdb_test)
            count_train = len(self.pdb_train)

            # Show message
            msg_out = "\nTraining set PDBs: "+str(self.pdb_train)
            msg_out += "\nTest set PDBs: "+str(self.pdb_test)
            msg_out+="\nNumber of structures in training set: "+str(count_train)
            msg_out += "\nNumber of structures in test set: "+str(count_test)
            print(msg_out)

            # Invoke write_pdb_access_codes() method
            self.write_pdb_access_codes()

        # Handle IOError
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            print(msg_out)
            return

    # Define generate() method to split a dataset
    def generate(self):
        """Method to split dataset in training and test sets"""

        # Try to open self.reference_file_in
        try:
            file2open = self.dir_in+self.reference_file_in
            fo_data = open(file2open,"r")
            csv_data = csv.reader(fo_data)

            # Set up empty lists
            test_set = []
            training_set = []

            # Looping through csv_data to get header
            for line in csv_data:

                # Some editing 1
                line_out = str(line)
                line_out = line_out.replace("[","")
                line_out = line_out.replace("]","")
                line_out = line_out.replace("'","")
                line_out = line_out.replace(" ,",",") # WFA 2021-10-19
                line_out = line_out.replace(", ",",") # WFA 2021-10-19
                header = str(line_out)
                break

            # Looping through csv_data
            for line in csv_data:

                # Some editing 2
                line_out = str(line)
                line_out = line_out.replace("[","")
                line_out = line_out.replace("]","")
                line_out = line_out.replace("'","")
                line_out = line_out.replace(" ","")

                # Split
                if line[0] in self.pdb_test:
                    test_set.append(line_out)
                elif line[0] in self.pdb_train:
                    training_set.append(line_out)
                else:
                    print("\nPDB "+str(line[0])+" not in the datasets!")

            # Close file (dataset)
            fo_data.close()

            # Backup files
            # Invoke backup.make()
            file2backup = self.reference_file_in.replace(".csv","")
            file2backup += "_training.csv"
            backup.make(file2backup,self.dir_in,self.dir_in+"backup/")
            file2backup = self.reference_file_in.replace(".csv","")
            file2backup += "_test.csv"
            backup.make(file2backup,self.dir_in,self.dir_in+"backup/")

            # Open new file (training set)
            file2create1 = self.dir_in+self.reference_file_in.replace(".csv","")
            file2create1 += "_training.csv"
            f_train = open(file2create1,"w")

            # Write header for training set
            f_train.write(header+"\n")

            # Assign zero to count_train and count_test
            count_train = 0
            count_test = 0

            # Looping through training set
            for line in training_set:
                f_train.write(line+"\n")
                count_train += 1

            # Close file (training set)
            f_train.close()

            # Open new file (test set)
            file2create2 = self.dir_in+self.reference_file_in.replace(".csv","")
            file2create2 += "_test.csv"
            f_test = open(file2create2,"w")

            # Write header for test set
            f_test.write(header+"\n")

            # Looping through test set
            for line in test_set:
                f_test.write(line+"\n")
                count_test += 1

            # Close file (test set)
            f_test.close()

            # Show message
            msg_out = "\nTest set files: "+file2create2
            msg_out += "\nTraining set files: "+file2create1
            msg_out += "\nNumber of structures in test set: "+str(count_test)
            msg_out+="\nNumber of structures in training set: "+str(count_train)
            print(msg_out)

        # Handle IOError
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            print(msg_out)
            return

    # Define read_pdb_access_codes() method
    def read_pdb_access_codes(self):
        """Method to read PDB access codes in the pdb_codes_training_set.csv
        and pdb_codes_test_set.csv files"""

        # Try to open pdb_codes_training_set.csv and pdb_codes_test_set.csv
        try:
            file2open1 = self.dir_in+"pdb_codes_training_set.csv"
            fo_train = open(file2open1,"r")
            csv_train = csv.reader(fo_train)
            file2open2 = self.dir_in+"pdb_codes_test_set.csv"
            fo_test = open(file2open2,"r")
            csv_test = csv.reader(fo_test)

            # Looping through csv_train
            pdb = ""
            for line1 in csv_train:

                # Some editing
                aux_line = str(line1)
                aux_line = aux_line.replace("'","")
                aux_line = aux_line.replace(" ","")
                aux_line = aux_line.replace("[","")
                aux_line = aux_line.replace("]","")

                # Get PDB acces codes
                for char1 in aux_line:
                    if char1 != ",":
                        pdb += char1
                    else:
                        self.pdb_train.append(pdb)
                        print(pdb)
                        pdb = ""

            # Add last PDB access code
            self.pdb_train.append(pdb)
            print(pdb)

            # Looping through csv_test
            pdb = ""
            for line2 in csv_test:

                # Some editing
                aux_line = str(line2)
                aux_line = aux_line.replace("'","")
                aux_line = aux_line.replace(" ","")
                aux_line = aux_line.replace("[","")
                aux_line = aux_line.replace("]","")

                # Get PDB acces codes
                for char2 in aux_line:
                    if char2 != ",":
                        pdb += char2
                    else:
                        self.pdb_test.append(pdb)
                        print(pdb)
                        pdb = ""

            # Add last PDB access code
            self.pdb_test.append(pdb)
            print(pdb)

            # Close files
            fo_train.close()
            fo_test.close()

        # Handle IOError
        except IOError:
            print("\nIOError! I can't find CSV file!")

    # Define write_PDB_access_codes()
    def write_pdb_access_codes(self):
        """Method to write PDB access codes for structured in the training
        and test sets"""

        # Open new file for training set
        file2create_training = self.dir_in+"pdb_codes_training_set.csv"
        fo_training = open(file2create_training,"w")

        # Write PDB access codes for training set
        # Write first PDB access code
        fo_training.write(str(self.pdb_train[0]))

        # Looping through self.pdb_train to write the remaining PDB access codes
        for pdb in self.pdb_train[1:]:
            fo_training.write(","+str(pdb))

        # Close file
        fo_training.close()

        # Open new file for test set
        file2create_test = self.dir_in+"pdb_codes_test_set.csv"
        fo_test = open(file2create_test,"w")

        # Write PDB access codes for test set
        # Write first PDB access code
        fo_test.write(str(self.pdb_test[0]))

        # Looping through self.pdb_test to write the remaining PDB access codes
        for pdb in self.pdb_test[1:]:
            fo_test.write(","+str(pdb))

        # Close file
        fo_test.close()

    # Define secondary_file
    def secondary_file(self):
        """Function to generate training and test set based on lists with
        PDB access codes for training and test sets"""

        # Handle secondary file
        # Try to open secondary file
        try:
            file2open = self.dir_in+self.secondary_file_in
            fo_second = open(file2open,"r")
            csv_second = csv.reader(fo_second)

            # Set up empty lists
            training_set = []
            test_set = []

            # Looping through csv_second to get header
            for line in csv_second:

                # Some editing 1
                line_out = str(line)
                line_out = line_out.replace("[","")
                line_out = line_out.replace("]","")
                line_out = line_out.replace("'","")
                header = str(line_out)
                break

            # Set up empty lists
            found_test_pdb = []
            found_train_pdb = []
            missing_test_pdb = []
            missing_train_pdb = []

            # Looping through csv_second
            for line in csv_second:

                # Some editing 2
                line_out = str(line)
                line_out = line_out.replace("[","")
                line_out = line_out.replace("]","")
                line_out = line_out.replace("'","")
                line_out = line_out.replace(" ","")

                # Split
                if line[0] in self.pdb_test:
                    test_set.append(line_out)
                    if line[0] not in found_test_pdb:
                        found_test_pdb.append(line[0])
                else:
                    training_set.append(line_out)
                    if line[0] not in found_train_pdb:
                        found_train_pdb.append(line[0])

            # Close file
            fo_second.close()

            # looping through self.pdb_test
            for pdb in self.pdb_test:
                if pdb not in found_test_pdb:
                    missing_test_pdb.append(pdb)

            # looping through self.pdb_train
            for pdb in self.pdb_train:
                if pdb not in found_train_pdb:
                    missing_train_pdb.append(pdb)

            # Invoke backup.make()
            file2backup = self.secondary_file_in.replace(".csv","")
            file2backup += "_training.csv"
            backup.make(file2backup,self.dir_in,self.dir_in+"backup/")
            file2backup = self.secondary_file_in.replace(".csv","")
            file2backup += "_test.csv"
            backup.make(file2backup,self.dir_in,self.dir_in+"backup/")

            # Open new file (training set)
            file2create1 = self.dir_in+self.secondary_file_in.replace(".csv","")
            file2create1 += "_training.csv"
            f_train = open(file2create1,"w")

            # Write header for training set
            f_train.write(header+"\n")

            # Looping through training set
            for line in training_set:
                f_train.write(line+"\n")

            # Close file (training set)
            f_train.close()

            # Open new file (test set)
            file2create2 = self.dir_in+self.secondary_file_in.replace(".csv","")
            file2create2 += "_test.csv"
            f_test = open(file2create2,"w")

            # Write header for test set
            f_test.write(header+"\n")

            # Looping through test set
            for line in test_set:
                f_test.write(line+"\n")

            # Close file (test set)
            f_test.close()

            # Show message
            msg_out = "\nMissing PDB in test set: "+str(missing_test_pdb)
            msg_out += "\nMissing PDB in training set: "+str(missing_train_pdb)
            print(msg_out)

        # Handle IOError
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            return
