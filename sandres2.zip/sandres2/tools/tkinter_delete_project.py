#!/usr/bin/env python3
#
# Class to delete a project directory.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
import os
import csv
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs

# Define Dir() class
class Dir(object):
    """Class to delete a project directory"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define pre_delete_GUI() method
    def pre_delete_GUI(self):
        """Method to invoke delete_GUI() method """

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() message
        msg_out = "Ready to delete a saved project directory!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Get first line of list_of_saved_projects.csv
        # Try to open list_of_saved_projects.csv
        file2open = self.program_root+"datasets/list_of_saved_projects.csv"
        try:
            fo_list = open(file2open,"r")
            csv_list = csv.reader(fo_list)

            # Looping through csv_list
            for proj in csv_list:

                # Some editing
                self.project_in = str(proj).replace("{}","")
                self.project_in = self.project_in.replace("'","")
                self.project_in = self.project_in.replace("[","")
                self.project_in = self.project_in.replace("]","")
                self.project_in = self.project_in.replace(",","")
                self.project_in = self.project_in.replace(" ","")
                self.project_in = self.project_in.replace("\n","")
                break

            # Close file
            fo_list.close()

            # Invoke delete_GUI() method
            self.delete_GUI()

        # Handle IOError exception
        except IOError:
            # Invoke show_botton_msg() message
            msg_out = "IOError!I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

    # Define delete_GUI() method
    def delete_GUI(self):
        """Method to call delete_project"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title("Project Directory")
        top_txt.geometry(top_txt_geom)

        # Widget for project
        Label(
        top_txt,text="Saved Project Directory:").grid(row=1,column=0,stick=W)
        self.project_entry = Entry(top_txt,width = 20)
        self.project_entry.grid(row = 1, column = 1,stick = E)
        self.project_entry.insert(0,self.project_in)

        # Dummy Label (Insert space to get the right position of botton bar) -8
        Label(top_txt, text = (self.win_y_offset_type_2-29)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=2, column=3, sticky=W)

        # Dummy Label (Insert space to get the right position of botton bar) -8
        Label(top_txt, text = (self.win_y_offset_type_2-29)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=3, column=3, sticky=W)

        # Dummy Label (Insert space to get the right position of botton bar) -8
        Label(top_txt, text = (self.win_y_offset_type_2-29)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Plot
        Button(top_txt,text='Delete',command=self.delete_project).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close ', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define delete_project() method
    def delete_project(self):
        """Method to delete a saved project directory"""

        # Import library
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Ask yes/no question
        result = messagebox.askyesno("",
                "Do you want to delete "+str(self.project_entry.get()))

        # Test answer
        if result:

            # Set up folder to delete
            f2delete=self.program_root+"datasets/"+str(self.project_entry.get())

            # Try to delete a file
            try:

                # Delete zipped file
                os.remove(f2delete)

                # Invoke show_botton_msg() message
                msg_out = "Project directory deleted successfully"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            # Handle exception
            except OSError:

                # Invoke show_botton_msg() message
                msg_out = "OSError! I can't find select project directory!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out="No request to delete project directory!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)