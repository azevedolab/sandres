#!/usr/bin/env python3
#
# Function to stamp a message on main GUI.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import section
from tools import tkinter_messages as tk_msg
import os
import sys
import csv

# Set up program root directory
program_root = os.getcwd()+"/"

# Define msg() function
def msg(root,msg_out):
    """Funtion to insert a message into the main GUI"""

    # Define read_strdir() function
    def read_strdir():
        """Function to read project directory"""

        # Import package
        from tkinter import messagebox

        # Try to open misc/data/stdir.in file
        try:
            f_strdir = open(program_root+"misc/inputs/strdir.in","r")
            info_in_strdir = csv.reader(f_strdir)
        except IOError:
            print("\nI can't find file strdir.in")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find file strdir.in"+\
                              "\nPlease check project directory!")
            return

        # Looping through the input file to get the project directory
        for line in info_in_strdir:
            if line[0][0:6].upper() == "STRDIR":
                project_dir_string = line[1].replace(" ","")
                break

        # Close file
        f_strdir.close()

        # Returns strdir
        return project_dir_string

    # Invoke read_strdir() function
    strdir_entry = read_strdir()

    # Instantiate an object of Messages() class
    msg1 = tk_msg.Messages(strdir_entry,root)

    # Show message
    msg1.show_botton_msg(msg_out,"black","light grey")