#!/usr/bin/env python3
#
# Class to check whether binding affinity data is in the database or
# not
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
import csv

# Define BindingInformation() class
class BindingInformation(object):
    """Class to check Ligand Databases"""

    # Define constructor method
    def __init__(self,program_root,dir_in,bind_in):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.bind_in = bind_in

    # Define read_pdb_codes() method
    def read_pdb_codes(self):
        """Method to read pdb_access.csv file"""

        # Set up an empty list
        self.pdb_access_codes = []

        # Try to open pdb_access.csv
        file2open = self.dir_in+"pdb_codes.csv"
        try:
            fo_pdb_codes = open(file2open,"r")

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get CSV data
        csv_in = csv.reader(fo_pdb_codes)

        # Looping through csv_in
        for line in csv_in:
            for line1 in line:
                self.pdb_access_codes.append(line1.strip())

        # Close file
        fo_pdb_codes.close()

    # Define method to check lig.pdbqt files
    def check_lig_pdbqt(self,pdb_in):
        """Method to check whether lig.pdbqt file exists"""

        # Set up a folder
        pdb_dir = self.program_root+"misc/data/pdbqt/"+self.bind_in+"/"
        pdb_dir += pdb_in.upper()+"/"

        # Try to open it
        try:
            lig2open = pdb_dir+"lig.pdbqt"
            fo_lig = open(lig2open,"r")

            # Close file
            fo_lig.close()

        # Handle IOError exception
        except IOError:
            print("\nMissing lig.pdbqt for structure: ",pdb_in)

    # Define bundle() method
    def bundle(self):
        """Method to invoke methods to check Ligand Database"""

        # Set up empty lists
        binding_data_list = []
        no_binding_data_list = []

        # Invoke read_pdb_codes() method
        self.read_pdb_codes()

        # Try to open Ligand Database file
        origin_file = "bind_"+self.bind_in+".csv"
        database2open = self.program_root+"misc/data/"+origin_file
        try:
            fo_database = open(database2open,"r")

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+database2open+" file!")
            return

        # Get CSV data
        database_csv_in = csv.reader(fo_database)

        # Looping through database_csv_in (first line)
        for line in database_csv_in:
            break

        # Assign zero to count_pdb
        count_pdb = 0

        # Looping through database_csv_in
        for line in database_csv_in:

            # Get PDB
            pdb_in = line[0].strip()

            # Append to binding_data_list
            binding_data_list.append(pdb_in)

        # Close file
        fo_database.close()

        # Looping through self.pdb_access_codes
        for pdb in self.pdb_access_codes:

            # Check whether exists binding data for a given structure
            if pdb not in binding_data_list:
                no_binding_data_list.append(pdb)

        # Show summary
        print("\nFor "+self.bind_in+" data")
        print("Number of structures in the Ligand Dataset: ",
            len(binding_data_list))
        print("Number of missing structures in the Ligand Dataset: ",
            len(no_binding_data_list))

        # Write file if there are missing structures
        if len(no_binding_data_list) > 0:

            # Open a new file
            file2create = self.dir_in+"no_"+self.bind_in+"_binding_data.csv"
            fo_no_bind = open(file2create,"w")

            # Add data
            lines_out = str(no_binding_data_list)

            # Some editing
            lines_out = lines_out.replace("'","")
            lines_out = lines_out.replace("[","")
            lines_out = lines_out.replace("]","")
            lines_out = lines_out.replace(" ","")

            # Write list
            fo_no_bind.write(lines_out)

            # Close file
            fo_no_bind.close()

        # Return no_binding_data_list
        return no_binding_data_list