# Import packages
import urllib.request, urllib.parse, urllib.error
import os
import shutil
from tools import tkinter_messages as tk_msg

# Define Database() class
class Database(object):
    """Class to download ligand databases available on GitHub:
    IC50.zip, Kd.zip, and Ki.zip
    """

    # Define constructor method
    def __init__(self,program_root,url_in,ligand_database,strdir_entry,root):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.url_in = url_in
        self.ligand_database = ligand_database
        self.strdir_entry = strdir_entry
        self.root = root
        self.target = self.program_root+"misc/data/pdbqt/"

    # Define get_it() method
    def get_it(self):
        """Method to download ligand database"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Set up url
        my_url = self.url_in+self.ligand_database

        # Download file
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()

        file_object = urllib.request.urlopen(my_url)
        structure_line = file_object.readline()
        file_object.close()

        # Write file
        with open(self.target+self.ligand_database,"wb") as my_file_4_download:
            my_file_4_download.write(structure)
            my_file_4_download.close()

        # Invoke show_botton_msg() method
        msg_out = "Database downloaded successfully"
        msg1.show_botton_msg(msg_out,"black","light grey")

    # Define get_csv() method
    def get_csv(self):
        """Method to download ligand CSV file"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Set up target1
        target1 = self.program_root+"misc/data/"

        # Set up url
        my_url = self.url_in+"bind_"+self.ligand_database

        # Download file
        file_object = urllib.request.urlopen(my_url)
        structure = file_object.read()
        file_object.close()

        file_object = urllib.request.urlopen(my_url)
        structure_line = file_object.readline()
        file_object.close()

        # Write file
        with open(target1+"bind_"+self.ligand_database,"wb") as my_file_4_download:
            my_file_4_download.write(structure)
            my_file_4_download.close()

        # Invoke show_botton_msg() method
        msg_out = "CSV file downloaded successfully"
        msg1.show_botton_msg(msg_out,"black","light grey")

    # Define unzip_it() method
    def unzip_it(self):
        """Method to unzip ligand database"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Unzip
        f2unzip = self.target+self.ligand_database
        extract_dir = f2unzip.replace(".zip","")

        # Check whether the dir exits or not
        dir_exists = os.path.exists(extract_dir)
        if dir_exists:

            # Invoke show_botton_msg() method
            msg_out = "Error! You're trying to recover a pre-existing "
            msg_out += "ligand database!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        else:

            # Full path of the archive file
            filename = self.target+self.ligand_database

            # Target directory
            extract_dir = self.target

            # Format of archive file
            archive_format = "zip"

            # Unpack the archive file
            shutil.unpack_archive(filename,extract_dir,archive_format)

            # Invoke show_botton_msg() method
            msg_out = "Database unpacked successfully"
            msg1.show_botton_msg(msg_out,"black","light grey")

    # Define unzip_csv() method
    def unzip_csv(self):
        """Method to unzip ligand CSV file"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Set up target1
        target1 = self.program_root+"misc/data/"

        # Unzip
        f2unzip = target1+"bind_"+self.ligand_database
        extract_dir = f2unzip.replace(".zip","")

        # Check whether the dir exits or not
        dir_exists = os.path.exists(extract_dir)
        if dir_exists:

            # Invoke show_botton_msg() method
            msg_out = "Error! You're trying to recover a pre-existing "
            msg_out += "ligand database!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        else:

            # Full path of the archive file
            filename = target1+"bind_"+self.ligand_database

            # Target directory
            extract_dir = target1

            # Format of archive file
            archive_format = "zip"

            # Unpack the archive file
            shutil.unpack_archive(filename,extract_dir,archive_format)

            # Invoke show_botton_msg() method
            msg_out = "CSV file unpacked successfully"
            msg1.show_botton_msg(msg_out,"black","light grey")

    # Define delete_old() method
    def delete_old(self):
        """Method to remove older databases"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Set up target2
        target2 = self.target+self.ligand_database.replace(".zip","/")

        # Invoke show_botton_msg() method
        msg_out = "Removing "+target2+"..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Get the directories to delete for each PDB
        dir_list = os.listdir(target2)

        # Looping through dir_list
        for pdb in dir_list:

            # Set up target_dir
            #target_dir = self.dir_in+"pdbqt/"+pdb
            target_dir = target2+pdb

            # Get the files to delete for each PDB
            file_list = os.listdir(target_dir)

            # Looping through file_list
            for file_in in file_list:
                os.remove(target_dir+"/"+file_in)

            # Try to remove dir (it should be empty)
            try:
                os.rmdir(target_dir)

            # Handle OSError exception
            except OSError:
                msg_out = "\nPlease check directory "+target_dir
                msg_out += ". It should be empty!"
                msg1.show_botton_msg(msg_out,"black","light grey")

        # File remove database directory and zipped file
        try:
            # Remove target2
            os.rmdir(target2)

            # Set up target3 and remove it
            target3 = self.target+self.ligand_database
            os.remove(target3)

            # Set up target4 and remove it
            target4=self.target.replace("pdbqt","")+"bind_"+self.ligand_database
            os.remove(target4)

            # Set up target5 and remove it
            target5 = target4.replace(".zip",".csv")
            os.remove(target5)

        # Handle OSError exception
        except OSError:

            # Invoke show_botton_msg() method
            msg_out = "Please check directory "+target2
            msg_out += ". It should be empty!"
            msg1.show_botton_msg(msg_out,"black","light grey")

    # Define summary() method
    def summary(self):
        """Method to show message"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() method
        msg_out = "SAnDReS updated Ligand Database!"
        msg1.show_botton_msg(msg_out,"black","light grey")

    # Define bundle() method
    def bundle(self):
        """Method to invoke all methods"""

        # Invoke delete_old() method
        try:
            self.delete_old()

        # Handle exception
        except:
            pass

        # Invoke get_csv() method
        self.get_csv()

        # Invoke unzip_csv() method
        self.unzip_csv()

        # Invoke get_it() method
        self.get_it()

        # Invoke unzip_it() method
        self.unzip_it()

        # Invoke summary() method
        self.summary()