# Class to handle ligand descriptors.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import add_descriptors as add_lig_data

# Define DescriptorData() class
class DescriptorData(object):
    """Class to handle ligand descriptors"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define descriptor_GUI() method
    def descriptor_GUI(self):
        """GUI to add ligand descriptors to bind_###.csv file"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() method
        msg_out = "Adding descriptors..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Define functions to add ligand descriptors
        def descriptor_ki():
            """Function to add descriptors bind_Ki.csv file"""

            # Set up message
            msg_yes_no = "Do you wish to add descriptors to bind_Ki.csv file?"
            msg_yes_no += "It will delete structures with missing PDBQT files!"

            # Show yes/no question
            result = messagebox.askyesno("Continue?",msg_yes_no)

            # Test result
            if result:

                # Instantiate an object of Descriptor class
                d1=add_lig_data.Descriptor(self.program_root,self.strdir_entry,
                "Ki")

                # Invoke read_all_data() method
                d1.read_all_data()

                # Invoke write_all_data() method
                d1.write_all_data()

                # Call show_botton_msg()
                msg_out = "Ligand descriptors added to bind_Ki.csv file!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            else:
                return

        def descriptor_kd():
            """Function to add descriptors bind_Kd.csv file"""

            # Set up message
            msg_yes_no = "Do you wish to add descriptors to bind_Kd.csv file?"
            msg_yes_no += "It will delete structures with missing PDBQT files!"

            # Show yes/no question
            result = messagebox.askyesno("Continue?",msg_yes_no)

            # Test result
            if result:

                # Instantiate an object of Descriptor class
                d1=add_lig_data.Descriptor(self.program_root,self.strdir_entry,
                "Kd")

                # Invoke read_all_data() method
                d1.read_all_data()

                # Invoke write_all_data() method
                d1.write_all_data()

                # Call show_botton_msg()
                msg_out = "Ligand descriptors added to bind_Kd.csv file!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            else:
                return

        def descriptor_ic50():
            """Function to add descriptors bind_IC50.csv file"""

            # Set up message
            msg_yes_no = "Do you wish to add descriptors to bind_IC50.csv file?"
            msg_yes_no += "It will delete structures with missing PDBQT files!"

            # Show yes/no question
            result = messagebox.askyesno("Continue?",msg_yes_no)

            # Test result
            if result:

                # Instantiate an object of Descriptor class
                d1=add_lig_data.Descriptor(self.program_root,self.strdir_entry,
                "IC50")

                # Invoke read_all_data() method
                d1.read_all_data()

                # Invoke write_all_data() method
                d1.write_all_data()

                # Call show_botton_msg()
                msg_out = "Ligand descriptors added to bind_IC50.csv file!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            else:
                return

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('Ligand Descriptors')
        top_txt.geometry(top_txt_geom)

        # Widgets for binding affinity
        Label(top_txt,text="Type of Binding Affinity:"\
            ).grid(row=1,column=0,stick=W)

        # Widgets for binding affinity buttons
        Button(top_txt,text='Inhibition Constant (Ki)',
            command=descriptor_ki).grid(row=2,column=0,sticky = W)
        Button(top_txt,text='Dissociation Constant (Kd)',
            command=descriptor_kd).grid(row=2,column=1,sticky = W)
        Button(top_txt,text='Half-maximal Inhibitory Concentration (IC50)',
            command=descriptor_ic50).grid(row=2,column=2, sticky=W)

        # Show Empty Label
        Label(top_txt, text=4*" ", font = "Arial" ).grid(row = 2,
            column = 4, stick = W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
            command=top_txt.destroy).grid(row = 3, column = 11,sticky = E)
