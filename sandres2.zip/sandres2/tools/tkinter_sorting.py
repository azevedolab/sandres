# Import packages
import numpy as np
import sklearn
import csv
from tkinter import *
from tools import string_tools as string_t
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import binding_affinity as b_aff
from MLRegMPy import backup

# Instantiate an object of the Palavra class
a1 = string_t.Palavra("","pdb_codes.csv")

# Invoke ascii_art() method
_,_,_,_,_,_,scikit_art = a1.ascii_art()

# Define DataVS() class
class DataVS(object):
    """Class to sort virtual screening results"""

    # Define constructor method
    def __init__(self,program_root,dir_in,root,string_in):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.root = root
        self.string_in = string_in

        # Get scikit-learn version
        self.sk_version = str(sklearn.__version__)

        # Set up message about the main reference for scikit-learn
        self.scikit_ref = "\nWhen using scikit-learn, please cite: "
        self.scikit_ref += "Pedregosa F, Varoquaux G, Gramfort A, Michel V, "
        self.scikit_ref += "\nThirion B, Grisel O, Blondel M, Prettenhofer P, "
        self.scikit_ref += "Weiss R, Dubourg V, Vanderplas J, Passos A, "
        self.scikit_ref += "\nCournapeau D, Brucher M, Perrot M, Duchesnay E. "
        self.scikit_ref += "Scikit-learn: machine learning in python. "
        self.scikit_ref += "\nJ Mach Learn Res. 2011; 12: 2825-2830."
        self.scikit_short_msg = self.scikit_ref

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define prep_GUI() method
    def prep_GUI(self,file_in,file_out):
        """Method to invoke sorting_GUI() method """

        # Invoke input_GUI() method
        self.input_GUI(file_in,file_out)

    # Define input_GUI() method
    def input_GUI(self,file_in,file_out):
        """Method to call joblib"""

        # Invoke backup.make()
        backup.make(file_out,self.dir_in,self.dir_in+"backup/")

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title('Sorting VS Results')
        top_txt.geometry(top_txt_geom)

        # Widget for CSV file
        Label(top_txt,text="CSV Input File:").grid(row=1,column=0,stick=W)
        self.csv_in = Entry(top_txt,width = 30)
        self.csv_in.grid(row = 1, column = 1,stick = E)
        self.csv_in.insert(0,file_in)

        # Widget for CSV output file
        Label(top_txt,text="CSV Output File:").grid(row=2,column=0,stick=W)
        self.csv_out = Entry(top_txt,width = 30)
        self.csv_out.grid(row = 2, column = 1,stick = E)
        self.csv_out.insert(0,file_out)

        # Widget for sort criterion
        Label(top_txt,text="Sort Criterion:" ).grid(row = 3,column = 0,stick=W)
        self.criterion_entry = Entry(top_txt,width = 30)
        self.criterion_entry.grid(row = 3, column = 1,stick = E)
        self.criterion_entry.insert(0,self.string_in) # "Affinity(kcal/mol)"

        # Label (Insert space to get the right position of botton bar) -25
        Label(top_txt, text = (self.win_y_offset_type_2-28)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Joblib
        Button(top_txt,text=' Sort',command=self.do_it).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define do_it() method
    def do_it(self):
        """Method to sort VS results"""

        # Import library
        from tkinter import messagebox

        # Get sort criterion
        chosen_option = str(self.criterion_entry.get())

        # Get csv_in
        chosen_csv_in = str(self.csv_in.get())

        # Get csv_out
        chosen_csv_out = str(self.csv_out.get())

        # Get column number for chosen_option
        # Try to open csv_in
        try:
            file2open = self.dir_in+chosen_csv_in
            fo_vs = open(file2open,"r")
            csv_vs = csv.reader(fo_vs)

            # Set up empty lists
            a_list = []
            codes_out = []
            lines_out_1 = []

            # Looping through csv_vs
            for line in csv_vs:

                # Get index for column
                i_sel = line.index(chosen_option)
                col_sel = line[i_sel]
                print("\nColumn: ",i_sel,col_sel)

                # Some editing
                line_out = str(line)
                line_out = line_out.replace(" ","")
                line_out = line_out.replace("[","")
                line_out = line_out.replace("]","")
                line_out = line_out.replace("'","")
                line_out = line_out.replace("\n","")
                line_out = line_out.replace("\"","")

                # Get header
                header = line_out

                break

            # Looping through the remaining of csv_vs
            for line in csv_vs:
                try:

                    # Some editing
                    line_out = str(line)
                    line_out = line_out.replace(" ","")
                    line_out = line_out.replace("[","")
                    line_out = line_out.replace("]","")
                    line_out = line_out.replace("'","")
                    line_out = line_out.replace("\n","")
                    line_out = line_out.replace("\"","")

                    # Append to lists
                    a_list.append(float(line[i_sel]))
                    lines_out_1.append(line_out)
                    codes_out.append(line[2])

                # Handle exception
                except:
                    print("\nPlease check columns in "+file2open+" file")
                    return

            # Convert to numpy array
            a_array = np.array(a_list)

            # Get indices that would sort an array
            # https://numpy.org/doc/stable/reference/generated/numpy.argsort.html#numpy.argsort
            i_sorted = np.argsort(a_array)

            # Open output file
            file2create1 = self.dir_in+chosen_csv_out
            fo_sorted_vs = open(file2create1,"w")

            # Open output file
            file2create2 = self.dir_in+chosen_csv_out.replace(".csv","")
            file2create2 += "_unified.csv"
            fo_sorted_unified_vs = open(file2create2,"w")

            # Write header
            print(header)
            fo_sorted_vs.write(header+"\n")
            fo_sorted_unified_vs.write(header+"\n")

            # Set up empty list
            found_codes = []

            # Show sorted data
            for i in i_sorted:
                print(lines_out_1[i])
                fo_sorted_vs.write(lines_out_1[i]+"\n")
                aux_code = codes_out[i]

                # Write unified codes
                if aux_code not in found_codes:
                    found_codes.append(aux_code)
                    fo_sorted_unified_vs.write(lines_out_1[i]+"\n")

            # Close files
            fo_vs.close()
            fo_sorted_vs.close()
            fo_sorted_unified_vs.close()

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.dir_in,self.root)

            # Invoke show_botton_msg() method
            msg_out = "Finished sorting VS results!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Handle IOError exception
        except:
            print("\nIOError! I can't find "+file2open+" file!")
            return
