#!/usr/bin/env python3
#
# Class to preprocess data for machine learning modeling.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# August 25, 2023                                                                #
################################################################################
#
# Import packages
from sklearn.preprocessing import MaxAbsScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import StandardScaler
from tools import csv2data as c2d
import numpy as np
import csv
from tools import binding_affinity as b_aff

# Define Pre_proc() class
class Pre_proc(object):
    """Class to preprocess data for machine learning modeling"""

    # Define constructor method
    def __init__(self,program_root,dir_in,file_out):
        """Define constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.file_out = file_out

        # Try to open parameter file
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo_par = open(file2open,"r")
            csv_par = csv.reader(fo_par)

            # Looping through csv_par
            for line in csv_par:
                if "#" in line[0]:
                    pass
                elif line[0] == "preprocessing":
                    self.method_in = line[1]

            # Close file
            fo_par.close()

        except IOError:
            print("\nI cant find "+file2open+" file!")
            return

    # Define scaling() method
    def scaling(self):
        """Methods for preprocessing data"""

        # Reshape X array
        self.X = np.array(self.X).reshape(-1,1)

        # Choose the method
        if self.method_in == "StandardScaler":
            # https://towardsdatascience.com/scale-standardize-or-normalize-with-scikit-learn-6ccc7d176a02
            # StandardScaler standardizes a feature by subtracting the mean and then
            # scaling to unit variance. Unit variance means dividing all the values by the
            # standard deviation. StandardScaler does not meet the strict definition of
            # scale I introduced earlier.
            # StandardScaler results in a distribution with a standard deviation equal to 1.
            # The variance is equal to 1 also,
            # because variance = standard deviation squared. And 1 squared = 1.
            # StandardScaler makes the mean of the distribution 0.
            # About 68% of the values will lie be between -1 and 1.
            #
            # https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html

            #std_scaler = StandardScaler() # StandardScaler().fit_transform()
            #X_scaled = std_scaler.fit_transform(self.X)

            scaler = StandardScaler().fit(self.X)
            scaler
            self.X_scaled = scaler.transform(self.X)

        elif self.method_in == "MaxAbsScaler":
            # Scales in a way that the training data lies within the range [-1, 1]
            # by dividing through the largest maximum value in each feature.
            # It is meant for data that is already centered at zero or sparse data.
            # https://scikit-learn.org/stable/modules/preprocessing.html

            scaler = MaxAbsScaler()
            self.X_scaled = scaler.fit_transform(self.X)

        elif self.method_in == "MinMaxScaler":
            # For each value in a feature, MinMaxScaler subtracts the minimum value in the
            # feature and then divides by the range. The range is the difference between
            # the original maximum and original minimum.
            # MinMaxScaler preserves the shape of the original distribution.
            # It doesn’t meaningfully change the information embedded in the original data.
            # Note that MinMaxScaler doesn’t reduce the importance of outliers.
            # The default range for the feature returned by MinMaxScaler is 0 to 1.
            #
            # Notice how the features are all on the same relative scale.
            # The relative spaces between each feature’s values have been maintained.
            # MinMaxScaler is a good place to start unless you know you want your
            # feature to have a normal distribution or want outliers
            # to have reduced influence.
            # https://towardsdatascience.com/scale-standardize-or-normalize-with-scikit-learn-6ccc7d176a02

            scaler = MinMaxScaler()
            self.X_scaled = scaler.fit_transform(self.X)

        elif self.method_in == "RobustScaler":
            # RobustScaler transforms the feature vector by subtracting the median and
            # then dividing by the interquartile range (75% value — 25% value).
            # Like MinMaxScaler, our feature with large values — normal-big — is now of
            # similar scale to the other features. Note that RobustScaler does not scale
            # the data into a predetermined interval like MinMaxScaler. It does not meet
            # the strict definition of scale I introduced earlier.
            # Note that the range for each feature after RobustScaler is applied is larger
            # than it was for MinMaxScaler.
            # Use RobustScaler if you want to reduce the effects of outliers,
            # relative to MinMaxScaler.

            scaler = RobustScaler()
            self.X_scaled = scaler.fit_transform(self.X)

        elif self.method_in == "Normalizer":
            # Normalizer works on the rows, not the columns! I find that very unintuitive.
            # It’s easy to miss this information in the docs.
            # By default, L2 normalization is applied to each observation so the that the
            # values in a row have a unit norm. Unit norm with L2 means that if each
            # element were squared and summed, the total would equal 1.
            # Alternatively, L1 (aka taxicab or Manhattan) normalization can be applied
            # instead of L2 normalization.

            scaler = Normalizer()
            self.X_scaled = scaler.fit_transform(self.X)

        # Show mean and standard deviation
        print("\nMethod:",self.method_in)
        print("Mean: ",self.X_scaled.mean(axis=0))
        print("Standard Deviation: ",self.X_scaled.std(axis=0))

    # Define read_column()
    def read_column(self,n_col):
        """Method to read bind_####.csv file"""

        # Set up an empty string
        lines_out = ""

        # Get numerical data
        array1 = np.genfromtxt(self.dir_in+"bind_"+bind+".csv",delimiter=",",skip_header=1)
        self.X = array1[:,n_col:n_col+1]

    # Define bundle() method
    def bundle(self):
        """Method to bundle together all necessary steps to preprocess data"""

        # Invoke read_it function
        bind_in = b_aff.read_it(self.dir_in)

        # Set up empty string
        data_out = ""

        # Try to open self.file_out to get headers
        file2open = self.dir_in+self.file_out
        try:
            fo_pose = open(file2open,"r")
            csv_pose = csv.reader(fo_pose)
            for line in csv_pose:
                header = line
                break
            # Close file
            fo_pose.close()
        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            print(msg_out)
            return

        # Get numerical data
        array_in = np.genfromtxt(file2open,delimiter=",",skip_header=1)

        # Set up number of rows and number of columns
        n_rows =  len(array_in[0:,0])
        n_cols = len(array_in[0,:])

        # Set up list of columns not to be scaled
        ex_list = []
        try:
            ex_list.append(header.index(" "+bind_in+"(M)"))
            ex_list.append(header.index(" log("+bind_in+")"))
            ex_list.append(header.index(" p"+bind_in))
            ex_list.append(header.index(" RMSD(A)"))
            ex_list.append(header.index(" Pose Number"))    # WFA 2023/07/19
            ex_list.append(header.index(" Affinity(kcal/mol)"))
        except:
            try:
                ex_list.append(header.index(bind_in+"(M)"))
                ex_list.append(header.index("log("+bind_in+")"))
                ex_list.append(header.index("p"+bind_in))
                ex_list.append(header.index("RMSD(A)"))
                ex_list.append(header.index("Pose Number")) # WFA 2023/07/19
                ex_list.append(header.index("Affinity(kcal/mol)"))
            except:
                pass

        # Looping through numerical data
        for j in range(5,n_cols):
            if j not in ex_list:
                self.X = np.zeros(n_rows)
                for i in range(n_rows):
                    self.X[i] = array_in[i][j]

                # Invoke scaling() method
                self.scaling()

                # Update numerical with scaled version
                for i in range(n_rows):
                    array_in[i][j] = self.X_scaled[i]

        # Reopen self.file_out
        fo_pose = open(file2open,"r")
        csv_pose = csv.reader(fo_pose)

        # Jump first line
        for line in csv_pose:
            break

        # For number of rows
        i = 0

        # Looping through csv_pose
        for line in csv_pose:

            # Some editing
            line_out = str(line[:5]).replace("[","")
            line_out = line_out.replace("]","")
            line_out = line_out.replace("'","")
            line_out = line_out.replace(" ","")

            # Looping through numerical data
            for j in range(5,n_cols):
                line_out += ","+str(array_in[i][j])

            # Update count of rows
            i += 1

            # Add complete line for output file
            data_out += line_out+"\n"

        # Close file
        fo_pose.close()

        # open new file
        fo_out = open(self.dir_in+self.file_out,"w")

        # Instantiate an object of Header() class
        h1 = c2d.Header(self.dir_in,"bind_"+bind_in+".csv")

        # Invoke get_string method
        header = h1.get_string()

        # Add Pose Number to header
        header = header.replace(",Torsions",",Pose Number,Torsions")

        # Write header
        fo_out.write(header+"\n")

        # Write data
        fo_out.write(data_out)

        # Close file
        fo_out.close()