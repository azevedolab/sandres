#!/usr/bin/env python3
#
# Class to handle calculation of energy terms using AutoDock Vina
# (Trott & Olson, 2010; Eberhardt et al., 2021) for protein-pose complexes.
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import os
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import docking_vina as vina
from tools import binding_affinity as b_aff

# Define EnergyPose() class
class EnergyPose(object):
    """Class to handle calculation of energy terms for protein-pose complexes"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,scores_docking_in,root,
                list_lig_out):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.scores_docking_in = scores_docking_in
        self.root = root
        self.list_lig_out = list_lig_out

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    ############################################################################
    # Define working_GUI() method
    def working_GUI(self):
        """GUI to calculate energy terms for poses"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Get PDB access codes using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        number_of_pdbs = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_short_msg() method
        msg_out = "Number of structures in the dataset: {:8d}".\
        format(number_of_pdbs)
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Define function to carry out energy calculations showing a progress bar
        def run_all():
            """Function to show a progress bar for energy calculation"""

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Try to open bind_####.csv file
            try:
                fo_bind = open(self.strdir_entry+"bind_"+bind_in+".csv","r")
                print("\nBinding affinity: ",bind_in)
                csv_bind = csv.reader(fo_bind)

                # Get header
                for line in csv_bind:
                    bind_header = str(line)

                    # Some editing
                    bind_header = bind_header.replace("[","")
                    bind_header = bind_header.replace("]","")
                    bind_header = bind_header.replace("'","")
                    bind_header = bind_header.replace("\n","")
                    break

                # Close file
                fo_bind.close()

            # Handle IOError exception
            except IOError:
                print("\n")
                pass

            # Open a new file for docking results
            file2create1 = self.strdir_entry+"vina_all_rmsd_results.csv"
            fo_all_rmsd = open(file2create1,"w")

            # Open a new file for docking scoring results
            file2create2 = self.strdir_entry+self.scores_docking_in
            fo_all_docking = open(file2create2,"w")

            # Set up headers
            header_docking = "PDB,Centering Method,Pose,RMSD(A),"
            header_docking += "Affinity(kcal/mol),Gauss 1,Gauss 2,Repulsion,"
            header_docking += "Hydrophobic,Hydrogen,Torsional\n"
            header_scores = bind_header+"\n"
            # Affinity(kcal/mol),Gauss 1,Gauss 2,Repulsion,Hydrophobic,Hydrogen,Torsional

            # Some editing
            header_scores = header_scores.replace("[","")
            header_scores = header_scores.replace("]","")
            header_scores = header_scores.replace("'","")
            header_scores = header_scores.replace(" ,",",")
            header_scores = header_scores.replace(", ",",")

            # Write a line
            fo_all_rmsd.write(header_docking)

            # Write a line
            fo_all_docking.write(header_scores)

            # Close files
            fo_all_rmsd.close()
            fo_all_docking.close()

            # Invoke progress_bar()
            gui_title = "Energy Terms for Poses"
            self.progress_bar(gui_title)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
            self.pr1.tkinter_geometry(self.screen_geometry_var,
            self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('AutoDock Vina')
        top_txt.geometry(top_txt_geom)

        # Widgets for project directory
        Label(top_txt,
            text = "Energy Calculations with Vina:" ).grid(row = 0,
            column = 0, stick = W, padx = 0)

        # Widget for running energy calculations (with progress bar)
        Button(top_txt,text='Run',\
            command=run_all).grid(row=0,column=1,sticky = W)

        # Show Empty Label
        Label(top_txt, text=52*" ",font="Arial").grid(row=2,column=5,stick = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 3, column = 11,sticky = E)

    # Define progress_bar() method
    def progress_bar(self,progress_bar_title):
        """Method to follow energy calculations with a progress bar"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Invoke read_it function
        bind_in = b_aff.read_it(project_dir_string)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get PDB access codes using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        number_of_pdbs = len(pdb_list)

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160)(52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
            self.pr1.tkinter_geometry(self.screen_geometry_var,
                self.win_height_type_3,self.win_y_offset_type_3)

        # Define progress_bar_loop() function
        def progress_bar_loop():

            # Instantiate an object of Docking() class
            lig0 = vina.Docking(self.program_root,project_dir_string,
                                self.list_lig_out)

            # Looping through pdb_list and run AutoDock Vina
            i = 1
            for pdb in pdb_list:

                # Show information
                print("Calculating energy terms for PDB: ",pdb)

                # Try to run
                try:

                    # Invoke add_data4pdb() method
                    lig0.add_data4pdb(self.scores_docking_in,pdb,bind_in)

                    # Instantiate an object of Messages() class
                    msg2 = tk_msg.Messages(self.strdir_entry,self.root)

                    # Invoke show_botton_msg() method
                    msg_out = "AutoDock Vina successfully finished "
                    msg_out += "energy calculations for structure: "+str(pdb)
                    msg2.show_botton_msg(msg_out,"black","light grey")

                # Handle exception
                except:

                    # Instantiate an object of Messages() class
                    msg3 = tk_msg.Messages(self.strdir_entry,self.root)

                    # Invoke show_botton_msg() method
                    msg_out = "Warning! AutoDock Vina couldn't run "
                    msg_out +="energy calculations for structure: "+str(pdb)+"!"
                    msg3.show_botton_msg(msg_out,"grey","white")
                    print(msg_out)
                    pass

                # To handle exceptions related to the Done button
                try:
                    if i != 0:
                        pr_bar_01["value"] = i*100/number_of_pdbs
                    else:
                        pr_bar_01["value"] = i*100
                    root.update()
                except:
                    return

                # Add 1 to i
                i += 1

            # Instantiate an object of Messages() class
            msg4 = tk_msg.Messages(self.strdir_entry,self.root)

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished the "
            msg_out += "\"Add Energy Terms (Vina) for Poses\" request!"
            msg4.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        # Set up progress bar (pr_bar_01)
        # Create child window
        root = tk.Tk()
        root.title(progress_bar_title)
        root.geometry(top_txt_geom) # 870x52+0+540('870x50+0+430') length = 790
        pr_bar_01 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_01.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=progress_bar_loop)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()