#!/usr/bin/env python3
#
# Class to convert a PDB file for a protein structure to the PDBQT format.
# This script reads atom types from a PDB file and look up in a CSV file
# (atomic_charges.csv) the data about the charges. No hydrogen atoms are added
# during this process.
# All PDB files should be in a directory with the PDB access codes.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv

# Define ProteinStructure() class
class ProteinStructure(object):
    """Class to convert a PDB file to the PDBQT format for a protein
    structure"""

    # Define constructor method
    def __init__(self,program_root,dir_in,dataset):
        """Constructor method"""

        # Assign attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.dataset = dataset

    # Define method to write a dictionary with atomic charges
    def write_dictionary(self):
        """Method to write a script with definition of a dictionary for atomic
        charges"""

        # Set up a csv file with atomic charge data
        q_file = self.program_root+"misc/data/atomic_charges.csv"

        # Set up empty strings
        ala_string = ""
        arg_string = ""
        asn_string = ""
        asp_string = ""
        cys_string = ""
        gln_string = ""
        glu_string = ""
        gly_string = ""
        his_string = ""
        ile_string = ""
        leu_string = ""
        lys_string = ""
        met_string = ""
        phe_string = ""
        pro_string = ""
        ser_string = ""
        thr_string = ""
        trp_string = ""
        tyr_string = ""
        val_string = ""
        unk_string = ""

        # Try to read atomic charges
        try:
            fo_q = open(q_file,"r")
            csv_q = csv.reader(fo_q)

        except IOError:
            print("\nI can't find "+q_file+" file!")

        # Open atomic_charges.py (for dictionary)
        dict_file = open(self.dir_in+"atomic_charges.py","w")

        # For the first line (header)
        for line in csv_q:
            break

        # Get data for each amino acid
        for line in csv_q:
            if line[0] == "ALA":
                ala_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "ARG":
                arg_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "ASN":
                asn_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "ASP":
                asp_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "CYS":
                cys_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "GLN":
                gln_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "GLU":
                glu_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "GLY":
                gly_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "HIS":
                his_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "ILE":
                ile_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "LEU":
                leu_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "LYS":
                lys_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "MET":
                met_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "PHE":
                phe_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "PRO":
                pro_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "SER":
                ser_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "THR":
                thr_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "TRP":
                trp_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "TYR":
                tyr_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "VAL":
                val_string += "\""+line[1]+"\""+":"+str(line[2])+","
            elif line[0] == "UNK":
                unk_string += "\""+line[1]+"\""+":"+str(line[2])+","

        # Write dictionary with atomic charge data
        dict_file.write("ala_dict = {"+ala_string[:len(ala_string)-1]+"}\n")
        dict_file.write("arg_dict = {"+arg_string[:len(arg_string)-1]+"}\n")
        dict_file.write("asn_dict = {"+asn_string[:len(asn_string)-1]+"}\n")
        dict_file.write("asp_dict = {"+asp_string[:len(asp_string)-1]+"}\n")
        dict_file.write("cys_dict = {"+cys_string[:len(cys_string)-1]+"}\n")
        dict_file.write("gln_dict = {"+gln_string[:len(gln_string)-1]+"}\n")
        dict_file.write("glu_dict = {"+glu_string[:len(glu_string)-1]+"}\n")
        dict_file.write("gly_dict = {"+gly_string[:len(gly_string)-1]+"}\n")
        dict_file.write("his_dict = {"+his_string[:len(his_string)-1]+"}\n")
        dict_file.write("ile_dict = {"+ile_string[:len(ile_string)-1]+"}\n")
        dict_file.write("leu_dict = {"+leu_string[:len(leu_string)-1]+"}\n")
        dict_file.write("lys_dict = {"+lys_string[:len(lys_string)-1]+"}\n")
        dict_file.write("met_dict = {"+met_string[:len(met_string)-1]+"}\n")
        dict_file.write("phe_dict = {"+phe_string[:len(phe_string)-1]+"}\n")
        dict_file.write("pro_dict = {"+pro_string[:len(pro_string)-1]+"}\n")
        dict_file.write("ser_dict = {"+ser_string[:len(ser_string)-1]+"}\n")
        dict_file.write("thr_dict = {"+thr_string[:len(thr_string)-1]+"}\n")
        dict_file.write("trp_dict = {"+trp_string[:len(trp_string)-1]+"}\n")
        dict_file.write("tyr_dict = {"+tyr_string[:len(tyr_string)-1]+"}\n")
        dict_file.write("val_dict = {"+val_string[:len(val_string)-1]+"}\n")
        dict_file.write("unk_dict = {"+unk_string[:len(unk_string)-1]+"}\n")

        # Close files
        dict_file.close()
        fo_q.close()

    # Define write_pdbqt() method
    def write_pdbqt(self,pdb_in,pdbqt_out):
        """Method to convert PDB to PDBQT for a protein structure"""

        # Import dictionary with atomic charges
        from tools import atomic_charges as charges

        ########################################################################
        # Define fix_str() function
        def fix_str(number_in,number_char_in):
            """Function to fix the number of characters"""

            # Convert to string
            str_in = str(number_in)

            # To avoid problems with the position in the line
            if "-" not in str_in and len(str_in) == 4:
                str_in = str_in+"0"
            elif "-" not in str_in and len(str_in) == 3:
                str_in = str_in+"00"
            elif "-" in str_in and len(str_in) == 5:
                str_in = str_in+"0"

            # fix the number of characters in a string
            while len(str_in) < number_char_in+1:
                str_in = " "+str_in

            # Return string
            return str_in
        ########################################################################

        # Try to open a pdb file
        try:
            fo_receptor = open(self.dataset+"/"+pdb_in,"r")
            receptor_lines = fo_receptor.readlines()

            # Open new pdbqt file
            fo_pdbqt = open(self.dataset+"/"+pdbqt_out,"w")

            # Looping through receptor_lines
            for line2 in receptor_lines:
                if line2[0:6] == "ATOM  ":

                    # Get atom label
                    atom = line2[12:16]

                    # Check each amino acid and write lines in a pdbqt file
                    if line2[17:20] == "ALA":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.ala_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "ARG":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.arg_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            if atom == "HH11":
                                atom = '1HH1'
                                atom_tag = "HD"
                                charge_in = charges.arg_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")
                            elif atom == "HH12":
                                atom = '2HH1'
                                atom_tag = "HD"
                                charge_in = charges.arg_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")
                            elif atom == "HH21":
                                atom = '1HH2'
                                atom_tag = "HD"
                                charge_in = charges.arg_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")
                            elif atom == "HH22":
                                atom = '2HH2'
                                atom_tag = "HD"
                                charge_in = charges.arg_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")

                    elif line2[17:20] == "ASN":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.asn_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OD1" \
                                or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            if atom == "HD21":
                                atom = '1HD2'
                                atom_tag = "HD"
                                charge_in = charges.asn_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")
                            elif atom == "HD22":
                                atom = '2HD2'
                                atom_tag = "HD"
                                charge_in = charges.asn_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")

                    elif line2[17:20] == "ASP":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.asp_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OD1" \
                                or atom == " OD2" or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "CYS":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.cys_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            elif atom == " SG ":
                                atom_tag = "SA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "GLN":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.gln_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OE1" \
                                or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            if atom == "HE21":
                                atom = '1HE2'
                                atom_tag = "HD"
                                charge_in = charges.gln_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")
                            elif atom == "HE22":
                                atom = '2HE2'
                                atom_tag = "HD"
                                charge_in = charges.gln_dict[atom]
                                charge_value = fix_str(charge_in,5)
                                fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                                charge_value+" "+atom_tag+"\n")

                    elif line2[17:20] == "GLU":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.glu_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OE1" \
                                or atom == " OE2" or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "GLY":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.gly_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "HIS":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.his_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HD1" or atom == " HE2":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            elif atom == " CD2" or atom == " CE1" \
                                or atom ==" CG ":
                                atom_tag = "A"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "ILE":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.ile_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "LEU":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.leu_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "LYS":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.lys_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE " or atom == " HZ1" \
                                or atom == " HZ2" or atom == " HZ3":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "MET":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.met_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            elif atom == " SD ":
                                atom_tag = "SA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "PHE":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.phe_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            elif atom == " CG ":
                                atom_tag = "A"
                            elif atom == " CD1":
                                atom_tag = "A"
                            elif atom == " CD2":
                                atom_tag = "A"
                            elif atom == " CE1":
                                atom_tag = "A"
                            elif atom == " CE2":
                                atom_tag = "A"
                            elif atom == " CZ ":
                                atom_tag = "A"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "PRO":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.pro_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "SER":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.ser_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HG ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OG " \
                                or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "THR":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.thr_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HG1":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OG1" \
                                or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "TRP":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.trp_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN " \
                                or atom == " HE1":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OH " \
                                or atom == " OXT":
                                atom_tag = "OA"
                            elif atom == " CG ":
                                atom_tag = "A"
                            elif atom == " CD1":
                                atom_tag = "A"
                            elif atom == " CD2":
                                atom_tag = "A"
                            elif atom == " CE2":
                                atom_tag = "A"
                            elif atom == " CE3":
                                atom_tag = "A"
                            elif atom == " CZ2":
                                atom_tag = "A"
                            elif atom == " CZ3":
                                atom_tag = "A"
                            elif atom == " CH2":
                                atom_tag = "A"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "TYR":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.tyr_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OH " \
                                or atom == " OXT":
                                atom_tag = "OA"
                            elif atom == " CG ":
                                atom_tag = "A"
                            elif atom == " CD1":
                                atom_tag = "A"
                            elif atom == " CD2":
                                atom_tag = "A"
                            elif atom == " CE1":
                                atom_tag = "A"
                            elif atom == " CE2":
                                atom_tag = "A"
                            elif atom == " CZ ":
                                atom_tag = "A"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "VAL":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.val_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

                    elif line2[17:20] == "UNK":

                        # Find charge in a dictionary
                        try:
                            charge_in = charges.unk_dict[atom]
                            charge_value = fix_str(charge_in,5)
                            if atom == " H  " or atom == " HN ":
                                atom_tag = "HD"
                            elif atom == " O  " or atom == " OXT":
                                atom_tag = "OA"
                            else:
                                atom_tag_aux = atom.replace(" ","")
                                atom_tag = atom_tag_aux[0]
                            fo_pdbqt.write(line2[:12]+atom+line2[16:70]+
                            charge_value+" "+atom_tag+"\n")
                        except:
                            pass

        # Handle IOError exception
        except IOError:
            print("I can't find structure!")

        # Close files
        fo_receptor.close()
        fo_pdbqt.close()
