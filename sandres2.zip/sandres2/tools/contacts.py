#!/usr/bin/env python3
#
# Class to calculate intermolecular contacts.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
import os
import csv
import numpy as np
from tools import bar_plot as bar

# Define InterMol() class
class InterMol(object):
    """Class to calculate intermolecular contacts"""

    # Define constructor method
    def __init__(self,program_root,dir_in,par_file_in,nres,cut_off):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.par_file_in = par_file_in
        self.nres = nres
        self.cut_off = cut_off

        # Set up self.dataset_dir
        self.dataset_dir = self.dir_in+"pdbqt"

        # Get a list with directories
        self.list_dataset_dir = os.listdir(self.dataset_dir)

        # Set up parameter file to open
        par_2_open = self.program_root+"misc/data/"+self.par_file_in

        # Try to open parameter file (bar_plot_par.csv)
        try:
            fo_pars = open(par_2_open,"r")
            csv_pars = csv.reader(fo_pars)
        except IOError:
            print("\nI can't find "+par_2_open+" file!")
            return

        # Looping through csv_pars
        for line in csv_pars:
            if line[0] == "xlabel_in":
                self.xlabel_in = line[1]
            elif line[0] == "xlabel_font_size":
                self.xlabel_font_size = line[1]
            elif line[0] == "ylabel_in":
                self.ylabel_in = line[1]
            elif line[0] == "ylabel_font_size":
                self.ylabel_font_size = int(line[1])
            elif line[0] == "plt_title_in":
                self.plt_title_in = line[1]
            elif line[0] == "title_size_in":
                self.title_size_in = int(line[1])
            elif line[0] == "plt_bar_color":
                self.plt_bar_color = line[1]
            elif line[0] == "dpi_in":
                self.dpi_in = int(line[1])

        # Close file
        fo_pars.close()

    # Define calculate() method
    def calculate(self):
        """ Method to read receptor.pdb and lig.pdb files and determine
            intermolecular contacts"""

        # Set up empty lists. Lists where each element is a residue
        list_of_all_contacts = []
        list_of_mc_contacts = []
        list_of_sc_contacts = []

        # Define lig_xyz() function
        def lig_xyz(lig_lines):
            """Function to read atomic coordinates for the ligand"""

            # Set up empty lists
            x_l = []
            y_l = []
            z_l = []

            # Looping through lig_lines:
            for line in lig_lines:
                if line[0:6] == "HETATM" and line[13:14] != "H":
                    x_l.append(float(line[30:38]))
                    y_l.append(float(line[38:46]))
                    z_l.append(float(line[46:54]))

            # Set up arrays
            self.x_l_a = np.array(x_l)
            self.y_l_a = np.array(y_l)
            self.z_l_a = np.array(z_l)

        # Define receptor_all_xyz() function
        def receptor_all_xyz(receptor_lines):
            """Function to read atomic coordinates for all atoms
            in the receptor"""

            # Set up empty lists
            self.residues = []
            self.res_names = []
            res_number = []
            x_r = []
            y_r = []
            z_r = []

            aux_res_number = -10

            # Looping through receptor_lines for all atoms:
            for line in receptor_lines:
                if line[0:6] == "ATOM  " and line[13:14] != "H":
                    res_number.append(int(line[22:26]))
                    x_r.append(float(line[30:38]))
                    y_r.append(float(line[38:46]))
                    z_r.append(float(line[46:54]))

                    # Get residue name
                    if aux_res_number != int(line[22:26]):
                        aux_res_number = int(line[22:26])
                        self.residues.append(aux_res_number)
                        self.res_names.append(line[17:20])

            # Set up arrays for all atoms
            self.res_r = np.array(res_number)
            self.x_r_a = np.array(x_r)
            self.y_r_a = np.array(y_r)
            self.z_r_a = np.array(z_r)

        # Define receptor_mc_xyz() function
        def receptor_mc_xyz(receptor_lines):
            """Function to read atomic coordinates for main-chain atoms
            in the receptor"""

            # Set up lists
            self.mc_residues = []
            self.mc_res_names = []
            mc_res_number = []
            x_r_mc = []
            y_r_mc = []
            z_r_mc = []
            main_chain_atoms = ["N  ","CA ","C  ","O  "]

            aux_res_number = -10

            # Looping through receptor_lines for main-chain atoms:
            for line in receptor_lines:
                if line[0:6] == "ATOM  " and line[13:14] != "H" \
                    and line[13:16] in main_chain_atoms:
                    mc_res_number.append(int(line[22:26]))
                    x_r_mc.append(float(line[30:38]))
                    y_r_mc.append(float(line[38:46]))
                    z_r_mc.append(float(line[46:54]))

                    # Get residue name
                    if aux_res_number != int(line[22:26]):
                        aux_res_number = int(line[22:26])
                        self.mc_residues.append(aux_res_number)
                        self.mc_res_names.append(line[17:20])

            # Set up arrays for main-chain atoms
            self.mc_res_r = np.array(mc_res_number)
            self.x_r_mc_a = np.array(x_r_mc)
            self.y_r_mc_a = np.array(y_r_mc)
            self.z_r_mc_a = np.array(z_r_mc)

        # Define receptor_sc_xyz() function
        def receptor_sc_xyz(receptor_lines):
            """Function to read atomic coordinates for side-chain atoms
            in the receptor"""

            # Set up lists
            self.sc_residues = []
            self.sc_res_names = []
            sc_res_number = []
            x_r_sc = []
            y_r_sc = []
            z_r_sc = []
            main_chain_atoms = ["N  ","CA ","C  ","O  "]

            aux_res_number = -10

            # Looping through receptor_lines for side-chain atoms:
            for line in receptor_lines:
                if line[0:6] == "ATOM  " and line[13:14] != "H" \
                    and line[13:16] not in main_chain_atoms:
                    sc_res_number.append(int(line[22:26]))
                    x_r_sc.append(float(line[30:38]))
                    y_r_sc.append(float(line[38:46]))
                    z_r_sc.append(float(line[46:54]))

                    # Get residue name
                    if aux_res_number != int(line[22:26]):
                        aux_res_number = int(line[22:26])
                        self.sc_residues.append(aux_res_number)
                        self.sc_res_names.append(line[17:20])

            # Set up arrays for all atoms
            self.sc_res_r = np.array(sc_res_number)

            # Set up arrays for side-chain atoms
            self.x_r_sc_a = np.array(x_r_sc)
            self.y_r_sc_a = np.array(y_r_sc)
            self.z_r_sc_a = np.array(z_r_sc)

        # Define interatomic_dist() function
        def interatomic_dist(x1,y1,z1,x2,y2,z2):
            """Function to calculate interatomic distance"""

            # Calculate Euclidean distance between two atoms
            aux = (x1-x2)**2 + (y1-y2)**2 + (z1-z2)**2
            self.dist = np.sqrt(aux)

        # Show message
        print("Counting intermolecular contacts, it may take several minutes for large datasets..")

        # Looping through structures
        for pdb in self.list_dataset_dir:

            # Set up ligand file to open
            lig_file = self.dataset_dir+"/"+pdb+"/lig.pdb"

            # Try to open ligand file
            try:
                fo_lig = open(lig_file,"r")
                lig_lines = fo_lig.readlines()
            except IOError:
                print("\nI can't find "+lig_file+"/file!")

            # Set up receptor file to open
            receptor_file = self.dataset_dir+"/"+pdb+"/receptor.pdb"

            # Try to open receptor file
            try:
                fo_receptor = open(receptor_file,"r")
                receptor_lines = fo_receptor.readlines()
            except IOError:
                print("\nI can't find "+receptor_file+"/file!")

            # Call lig_xyz() function
            lig_xyz(lig_lines)

            # Call receptor_all_xyz() function
            receptor_all_xyz(receptor_lines)

            # For all atoms
            # Looping through ligand(i) and receptor(j) atoms
            # Ligand atoms (i)
            for i in range(len(self.x_l_a)):

                # Looping through receptor all atoms (j)
                for j in range(len(self.x_r_a)):

                    # Call interatomic_dist() function for all atoms
                    interatomic_dist(self.x_l_a[i],self.y_l_a[i],self.z_l_a[i],
                    self.x_r_a[j],self.y_r_a[j],self.z_r_a[j])

                    # Check if self.dist <= self.cut_off for all atoms
                    if self.dist <= self.cut_off:
                        list_of_all_contacts.append(int(self.res_r[j]))

            # Call lig_xyz() function
            lig_xyz(lig_lines)

            # Call receptor_mc_xyz() function
            receptor_mc_xyz(receptor_lines)

            # For main-chain atoms
            # Looping through ligand(i) and receptor(j) atoms
            # Ligand atoms (i)
            for i in range(len(self.x_l_a)):

                # Looping through receptor main-chain atoms (j)
                for j in range(len(self.x_r_mc_a)):

                    # Call interatomic_dist() function for main-chain atoms
                    interatomic_dist(self.x_l_a[i],self.y_l_a[i],self.z_l_a[i],
                    self.x_r_mc_a[j],self.y_r_mc_a[j],self.z_r_mc_a[j])

                    # Check if self.dist <= self.cut_off for main-chain atoms
                    if self.dist <= self.cut_off:
                        list_of_mc_contacts.append(int(self.mc_res_r[j]))

            # Call lig_xyz() function
            lig_xyz(lig_lines)

            # Call receptor_sc_xyz() function
            receptor_sc_xyz(receptor_lines)

            # For side-chain atoms
            # Looping through ligand(i) and receptor(j) atoms
            # Ligand atoms (i)
            for i in range(len(self.x_l_a)):

                # Looping through receptor side-chain atoms (j)
                for j in range(len(self.x_r_sc_a)):

                    # Call interatomic_dist() function for side-chain atoms
                    interatomic_dist(self.x_l_a[i],self.y_l_a[i],self.z_l_a[i],
                    self.x_r_sc_a[j],self.y_r_sc_a[j],self.z_r_sc_a[j])

                    # Check if self.dist <= self.cut_off for side-chain atoms
                    if self.dist <= self.cut_off:
                        list_of_sc_contacts.append(int(self.sc_res_r[j]))

            # Close files
            fo_lig.close()
            fo_receptor.close()

        # Set up csv files to open
        intermol_all_atom_file = self.dir_in+"/intermol_all_contacts.csv"
        intermol_mc_atom_file = self.dir_in+"/intermol_mc_contacts.csv"
        intermol_sc_atom_file = self.dir_in+"/intermol_sc_contacts.csv"

        # Open new files
        fo_inter_all = open(intermol_all_atom_file,"w")
        fo_inter_mc = open(intermol_mc_atom_file,"w")
        fo_inter_sc = open(intermol_sc_atom_file,"w")

        # Write headers
        fo_inter_all.write("Residue Number,Residue,Contacts\n")
        fo_inter_mc.write("Residue Number,Residue,Contacts\n")
        fo_inter_sc.write("Residue Number,Residue,Contacts\n")

        # Looping through residue number for all atoms
        for i in range(1,self.nres):
            count_for_res = list_of_all_contacts.count(i)
            try:
                ind_res = self.residues.index(i)
                fo_inter_all.write(str(i)+","+str(self.res_names[ind_res])+
                ","+str(count_for_res)+"\n")
            except:
                pass

        # Looping through residue number for main-chain atoms
        for i in range(1,self.nres):
            count_for_res = list_of_mc_contacts.count(i)
            try:
                ind_res = self.mc_residues.index(i)
                fo_inter_mc.write(str(i)+","+str(self.mc_res_names[ind_res])+
                ","+str(count_for_res)+"\n")
            except:
                pass

        # Looping through residue number for side-chain atoms
        for i in range(1,self.nres):
            count_for_res = list_of_sc_contacts.count(i)
            try:
                ind_res = self.sc_residues.index(i)
                fo_inter_sc.write(str(i)+","+str(self.sc_res_names[ind_res])+
                ","+str(count_for_res)+"\n")
            except:
                pass

        # Close files
        fo_inter_all.close()
        fo_inter_mc.close()
        fo_inter_sc.close()

        # Plotting part
        # Try to open intermol_all_contacts.csv
        try:
            data_inter=np.genfromtxt(intermol_all_atom_file,delimiter=",",
            skip_header=1)
        except IOError:
            print("\nI can't find "+intermol_all_atom_file+"/file!")
            return

        # Get x,y data
        self.x_bar_plot = data_inter[:,0]
        self.y_bar_plot = data_inter[:,2]

        # Assign values to define plotting
        file_out = "intermolecular_all_contacts.pdf"
        font_size_in = 14

        # Instantiate an object of Plots() class
        all_contacts = bar.Plots(self.program_root,self.dir_in+"plots/")

        # Invoke generate()
        all_contacts.generate(self.x_bar_plot,self.y_bar_plot,
        self.nres,
        self.xlabel_in,self.xlabel_font_size,
        self.ylabel_in,self.ylabel_font_size,
        self.plt_title_in,self.title_size_in,
        self.plt_bar_color,
        file_out,
        self.dpi_in)

        # Try to open intermol_mc_contacts.csv
        try:
            data_inter=np.genfromtxt(intermol_mc_atom_file,delimiter=",",
            skip_header=1)
        except IOError:
            print("\nI can't find "+intermol_mc_atom_file+"/file!")
            return

        # Get x,y data
        self.x_bar_plot = data_inter[:,0]
        self.y_bar_plot = data_inter[:,2]

        # Assign file name
        file_out = "intermolecular_mc_contacts.pdf"

        # Instantiate an object of Plots() class
        mc_contacts = bar.Plots(self.program_root,self.dir_in+"plots/")

        # Invoke generate()
        mc_contacts.generate(self.x_bar_plot,self.y_bar_plot,
        self.nres,
        self.xlabel_in,self.xlabel_font_size,
        self.ylabel_in,self.ylabel_font_size,
        self.plt_title_in,self.title_size_in,
        self.plt_bar_color,
        file_out,
        self.dpi_in)

        # Try to open intermol_sc_contacts.csv
        try:
            data_inter=np.genfromtxt(intermol_sc_atom_file,delimiter=",",
            skip_header=1)
        except IOError:
            print("\nI can't find "+intermol_sc_atom_file+"/file!")
            return

        # Get x,y data
        self.x_bar_plot = data_inter[:,0]
        self.y_bar_plot = data_inter[:,2]

        # Assign file name
        file_out = "intermolecular_sc_contacts.pdf"

        # Instantiate an object of Plots() class
        sc_contacts = bar.Plots(self.program_root,self.dir_in+"plots/")

        # Invoke generate()
        sc_contacts.generate(self.x_bar_plot,self.y_bar_plot,
        self.nres,
        self.xlabel_in,self.xlabel_font_size,
        self.ylabel_in,self.ylabel_font_size,
        self.plt_title_in,self.title_size_in,
        self.plt_bar_color,
        file_out,
        self.dpi_in)

        # Show message
        print("Done!")