#!/usr/bin/env python3
#
# Class to perform bivariate statistical analysis.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Import packages
import numpy as np
from scipy.stats import spearmanr, pearsonr
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error     # WFA 2023/01/02
from sklearn.metrics import r2_score                # WFA 2023/01/02

# Define class to carry out basic bivariate statistcal analysis
class Metrics(object):
    """Class to calculate bivariate analysis"""

    # Define constructor method
    def __init__(self,y1,y2,boolean_flag,num_features):
        """Define constructor method"""

        # Define attributes
        self.y1 = y1
        self.y2 = y2
        self.boolean_flag = boolean_flag
        self.num_features = num_features

    # Define bundle() method
    def bundle(self):
        """Method to carry out bivariate statistical analysis"""

        # Invoke calc_RSS
        self.calc_RSS()

        # Invoke calc_ESS
        self.calc_ESS()

        # Get Spearman's rank and Pearson correlation coefficient and p-value
        self.corr_s,self.pvalue_s = spearmanr(self.y1,self.y2)
        self.corr_p,self.pvalue_p = pearsonr(self.y1,self.y2)

        # Basic bivariate statistical analysis
        n = len(self.y1)                                                                # Number of data points
        self.r2 = self.corr_p*self.corr_p                                               # R-square
        #self.s_dev = np.sqrt(self.rss/(n-self.num_features-1))                          # Standard deviation
        self.mse = mean_squared_error(self.y2,self.y1)                                  # Mean squared error (mse)
        self.rmse_model = np.sqrt(mean_squared_error(self.y2,self.y1))                  # RMSE
        self.mae_model = mean_absolute_error(self.y2,self.y1)                           # MAE WFA 2023/01/02
        self.r2_score = r2_score(self.y2,self.y1)                                       # R2 WFA 2023/01/02
        #self.f_stat = (self.ess/self.num_features)*((n-self.num_features-1)/self.rss)   # Calculate F-stat (Not used)

        # Check boolean variable
        if self.boolean_flag:

            # Invoke show_results()
            self.show_results()

        # Set up a line with statistical analysis
        #Feature,r,p-value,r2,rho,p-value,MSE,RMSE,RSS,MAE,R2
        stats_out = str(self.corr_p)+","+\
            str(self.pvalue_p)+","+str(self.r2)+","+str(self.corr_s)+","+\
            str(self.pvalue_s)+","+str(self.mse)+","+str(self.rmse_model)+","+\
            str(self.rss)+","+str(self.mae_model)+","+str(self.r2_score)+"\n"

        # Return line
        return self.corr_p,self.pvalue_p,self.r2,self.corr_s,self.pvalue_s,\
                self.mse,self.rmse_model,self.rss,self.mae_model,\
                self.r2_score,stats_out

    # Define calc_ESS() method
    def calc_ESS(self):
        """Method to calculate Explained Sum of Squares (ESS)"""

        # Get number of data points
        n = len(self.y1)

        # Set up array with zeros
        aux = np.zeros(n,dtype=float)

        # Calculate mean
        mean_y_in = np.mean(self.y1)

        # Looping through data points
        for i in range(n):
            aux[i] = (self.y2[i] - mean_y_in)**2

        # Calculate Explained Sum of Squares (ESS)
        self.ess = np.sum(aux)

    # Define calc_RSS() method
    def calc_RSS(self):
        """Method to calculate Residual Sum of Squares (RSS)"""

        # Get number of data points
        n = len(self.y1)

        # Set up array with zeros
        aux = np.zeros(n,dtype=float)

        # Calculate aux
        aux = (self.y1 - self.y2)**2

        # Calculate Residual Sum of Squares (RSS)
        self.rss = np.sum(aux)

    # Define show_results()
    def show_results(self):
        """Method to print out results"""

        # Show statistical analysis
        print("\nBivariate Statistical Analysis")
        print("Spearman's rank correlation coefficient : {:.6f}".format(self.corr_s),
        "p-value: ",np.format_float_scientific(self.pvalue_s,precision=4,exp_digits=3))
        print("Pearson's correlation coefficient (r): {:.6f}".format(self.corr_p),"p-value: ",
        np.format_float_scientific(self.pvalue_p,precision=4,exp_digits=3))
        print("r"+u"\u00b2"+": {:.6f}".format(self.r2))
        print('MSE: {:.7f}'.format(self.mse))
        print('RMSE: {:.6f}'.format(self.rmse_model))
        print('RSS: {:.6f}'.format(self.rss))
        print('MAE: {:.6f}'.format(self.mae_model))
        print('R2: {:.6f}'.format(self.r2_score))

        input("BUM Here 2")
