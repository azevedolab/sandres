#!/usr/bin/env python3
#
# Class to delete structure(s) in a list.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
import os
import csv
from tools import backup_all
from tools import string_tools as string_t

# Define Remove() class
class Remove(object):
    """Class to delete structure(s) in a list"""

    # Define constructor method
    def __init__(self,dir_in,delete_list,csv_data_file):
        """Constructor method"""

        # Set up attributes
        self.dir_in = dir_in
        self.delete_list = delete_list
        self.csv_data_file = csv_data_file
        self.pdb_out = []

        # Instantiate an object of the Palavra class
        self.p1 = string_t.Palavra(self.dir_in,"pdb_codes.csv")

        # Invoke count_codes() method
        self.number_pdbs = self.p1.count_codes()

        # Invoke list_pdb() method
        self.list_all_pdbs = self.p1.list_pdb()

        # Looping through self.list_all_pdbs
        for pdb in self.list_all_pdbs:
            if pdb not in self.delete_list:
                self.pdb_out.append(pdb)

    # Define pdb_codes() method
    def pdb_codes(self):
        """Method to delete PDB access codes from pdb_codes.csv file"""

        # Set up csv_file
        csv_file = self.dir_in+"pdb_codes.csv"

        # Invoke backup_all.make()
        backup_all.make(csv_file,self.dir_in,self.dir_in+"backup/")

        # Open new csv_file
        fo_csv = open(csv_file,"w")

        # Write first PDB in csv_file
        fo_csv.write(str(self.pdb_out[0]))

        # Looping through self.pdb_out to write the remaining PDBs
        for pdb in self.pdb_out[1:]:
            fo_csv.write(","+pdb)

        # Close file
        fo_csv.close()

    # Define pdb_dir() method
    def pdb_dir(self):
        """Method to remove PDB directories for missing structures"""

        # Looping through self.delete_list
        for pdb in self.delete_list:

            # Try to remove a file
            try:
                os.remove(self.dir_in+"pdb/"+pdb+".pdb")
                print("\nRemoving "+self.dir_in+"pdb/"+pdb+".pdb...")

            # Handle OSError exception
            except OSError:
                msg_out = "\nPlease check file "+self.dir_in+"pdb/"+pdb+".pdb"
                print(msg_out)

    # Define pdbqt_dir() method
    def pdbqt_dir(self):
        """Method to remove PDBQT directories for missing structures"""

        # Looping through self.delete_list
        for pdb in self.delete_list:

            # Set up target_dir
            target_dir = self.dir_in+"pdbqt/"+pdb

            # Get the files to delete for each PDB
            file_list = os.listdir(target_dir)

            # Looping through file_list
            for file_in in file_list:
                os.remove(target_dir+"/"+file_in)

            # Try to remove dir (it should be empty)
            try:
                os.rmdir(target_dir)
                print("\nRemoving "+target_dir+"...")

            # Handle OSError exception
            except OSError:
                msg_out = "\nPlease check directory "+target_dir
                msg_out += ". It should be empty!"
                print(msg_out)

    # Define data_csv() method
    def data_csv(self):
        """Method to update structures in a CSV file"""

        # Set up empty string
        lines_out = ""

        # Try to open a CSV file
        csv2open = self.dir_in+self.csv_data_file
        try:
            fo_data= open(csv2open,"r")
            csv_data = csv.reader(fo_data)

            # Looping through csv_data:
            for line in csv_data:
                if line[0] not in self.delete_list:

                    # Some editing
                    aux_line = str(line)
                    aux_line = aux_line.replace(", ",",")
                    aux_line = aux_line.replace(" ,",",")
                    aux_line = aux_line.replace("[","")
                    aux_line = aux_line.replace("]","")
                    aux_line = aux_line.replace("'","")
                    lines_out += aux_line+"\n"

            # Close file
            fo_data.close()

            # Invoke backup_all.make()
            backup_all.make(self.csv_data_file,self.dir_in,
            self.dir_in+"backup/")

            # Open new file
            fo_new = open(csv2open,"w")

            # Write new bind_####.csv file
            fo_new.write(lines_out)

            # Close file
            fo_new.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+csv2open+" file!")
            return

    # Define summary() method
    def summary(self):
        """Method to show the number of structures in the original and
        updated files"""

        # Get number of structures
        n_pdb = len(self.pdb_out)

        # Show summary
        print("\nSummary")
        print("Number of PDBs in the original dataset: "+str(self.number_pdbs))
        print("Number of PDBs in the updated dataset: "+str(n_pdb))

    # Define bundle() method
    def bundle(self):
        """Method to invoke all necessary methods"""

        # Invoke pdb_codes() method
        self.pdb_codes()

        # Invoke pdb_dir() method
        self.pdb_dir()

        # Invoke pdbqt_dir() method
        self.pdbqt_dir()

        # Invoke data_csv() method
        self.data_csv()

        # Invoke summary() method
        self.summary()