# Import packages
import sklearn
import csv
from MLRegMPy import backup
from tools import tkinter_messages as tk_msg

# Class to grab previously generated statistical analysis for joblib models
class Analysis(object):
    """Class to read statistical analysis of the predictive performances of
    joblib models available in models/"""

    # Define constructor method
    def __init__(self,program_root,dir_in,reference_file,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.reference_file = reference_file
        self.root = root
        self.stats_out = ""
        self.stats_data_lines = ""

        # Get scikit-learn version
        self.sk_version = str(sklearn.__version__)

        # Set up message about the main reference for Scikit-Learn
        self.scikit_ref = "\nWhen using Scikit-Learn, please cite: "
        self.scikit_ref += "Pedregosa F, Varoquaux G, Gramfort A, Michel V, "
        self.scikit_ref += "\nThirion B, Grisel O, Blondel M, Prettenhofer P, "
        self.scikit_ref += "Weiss R, Dubourg V, Vanderplas J, Passos A, "
        self.scikit_ref += "\nCournapeau D, Brucher M, Perrot M, Duchesnay E. "
        self.scikit_ref += "Scikit-learn: machine learning in python. "
        self.scikit_ref += "\nJ Mach Learn Res. 2011; 12: 2825-2830."

    # Define get_header() method
    def get_header(self,file_in):
        """Method to read a CSV file and get the header"""

        # Header
        self.stats_data_lines += "\t\t\tMethod\t r \tp-value \t r2 \t rho "
        self.stats_data_lines += "\tp-value \t MSE \t RMSE \t SD \t RSS \t "
        self.stats_data_lines += "F-stat\n"

        # Try to open file_in
        try:
            file2open = self.dir_in+"models/"+file_in
            fo_data = open(file2open,"r")
            csv_data = csv.reader(fo_data)

            # Looping through csv_data to get header
            for line in csv_data:

                # Some editing 1
                line_out = str(line)
                line_out = line_out.replace("[","")
                line_out = line_out.replace("]","")
                line_out = line_out.replace("'","")
                self.stats_out += str(line_out)+"\n"

                # Close file
                fo_data.close()
                break

        # Handle IOError
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            self.header = ""
            return

    # Define show_stats() method
    def show_stats(self):
        """Method to show and write statistical analysis"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Backup file
        # Invoke backup.make()
        file2backup = self.reference_file.replace(".csv","")
        file2backup += "_statistical_analysis.csv"
        backup.make(file2backup,self.dir_in,self.dir_in+"backup/")

        # Set up report_out message
        report_out = "\nSAnDReS determined metrics using Scikit-Learn ("
        report_out += str(self.sk_version)+") and SciPy.\n"
        report_out += self.scikit_ref

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.stats_data_lines+"\n\n"+report_out)

        # Open new file
        #file2create = self.dir_in+"statistical_analysis_"+self.reference_file
        file2create = self.dir_in+self.reference_file.replace(".csv","")
        file2create += "_statistical_analysis.csv"
        fo_stats_out = open(file2create,"w")

        # Write results
        fo_stats_out.write(self.stats_out)

        # Close file
        fo_stats_out.close()

    # Define bundle()
    def bundle(self):
        """Method to bundle all methods to read statistical results"""

        # Define function to handle hash in a field
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Set up an empty list
        all_mlr_methods = []

        # Read regression methos (mlr_method) in ml_par.csv
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo_ml_par = open(file2open,"r")
            csv_ml_par = csv.reader(fo_ml_par)
        except IOError:
            print("\nIOError! I can't find "+file2open+"!")
            return

        # Looping through input file to get mlr_methods
        for line in csv_ml_par:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                all_mlr_methods.append(mlr_method_in)

        # Close file
        fo_ml_par.close()

        # Invoke get_header() method
        file_in = self.reference_file.replace(".csv","_")
        self.get_header(file_in+all_mlr_methods[1]+".csv")

        # Looping through regression methods
        for method2read in all_mlr_methods:

            # Try to open a file
            try:
                file2open = self.dir_in+"models/"+file_in+method2read+".csv"
                fo_method = open(file2open,"r")
                csv_method =csv.reader(fo_method)

                # Looping through csv_method
                for line in csv_method:
                    break

                # Looping through csv_method
                for line in csv_method:

                    # Some editing 2
                    line_out = str(line)
                    line_out = line_out.replace("[","")
                    line_out = line_out.replace("]","")
                    line_out = line_out.replace("'","")
                    line_out = line_out.replace(" ","")

                    # Add line
                    self.stats_out += str(line_out)+"\n"

                    # Some editing 3
                    formatted_line = "{0:>30}".format(str(line[0]))
                    aux_float = "{:.3f}".format(float(line[1]))
                    formatted_line += "\t\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[2]))
                    formatted_line += "\t\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[3]))
                    formatted_line += "\t\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[4]))
                    formatted_line += "\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[5]))
                    formatted_line += "\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[6]))
                    formatted_line += "\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[7]))
                    formatted_line += "\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[8]))
                    formatted_line += "\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[9]))
                    formatted_line += "\t"+str(aux_float)
                    aux_float = "{:.3f}".format(float(line[10]))
                    formatted_line += "\t"+str(aux_float)
                    aux_line = str(formatted_line).replace("[","")
                    aux_line = aux_line.replace("]","")
                    aux_line = aux_line.replace("'","")

                    # Add line
                    self.stats_data_lines += str(aux_line)+"\n"

                # Close file
                fo_method.close()

            # Handle exception
            except IOError:
                print("\nIOError! I can't find "+file2open+"!")
                return

        # Invoke show_stats() method
        self.show_stats()