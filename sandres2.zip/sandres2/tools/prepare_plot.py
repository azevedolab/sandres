#!/usr/bin/env python3
#
# Class to prepare an input file for generation of scatter plots.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Import packages
import csv
from tools import binding_affinity as b_aff

# Define class to prepare input file for scatter plots
class Scatter(object):
    """Class to prepare an input file for generation of scatter plots"""

    # Define constructor method
    def __init__(self,program_root,dir_in,file_in,file_out,X_label,
                y_label):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.file_in = file_in
        self.file_out = file_out
        self.X_label = X_label      # X-axis
        self.y_label = y_label      # String for column to be used as y axis

    # Define get_indexes() method
    def get_indexes(self):
        """Method to get the indexes for X and y columns """

        # Try to open a file
        file2open = self.dir_in+self.file_in
        try:
            fo_csv = open(file2open,"r")
            csv_in = csv.reader(fo_csv)

            # Looping through csv_in for the first line only
            for line1 in csv_in:
                i = 0
                for line2 in line1:
                    if self.X_label in str(line2):
                        self.i_X = str(i)
                    elif self.y_label in str(line2):
                        self.i_y = str(i)
                    i += 1
                break

            # Close file
            fo_csv.close()

        # Handle IOError exception
        except IOError:
            msg_out = "\nIOError! I can't find "+file2open+" file!"
            print(msg_out)
            return

    # Define write_input() method
    def write_input(self):
        """Method to write updated /misc/data/scatter_plot_par.csv file"""

        # Try to open a file
        file2open = self.program_root+"/misc/data/scatter_plot_par.csv"
        try:
            fo = open(file2open,"r")
            lines_in = csv.reader(fo)

        # Handle IOError exception
        except IOError:
            msg_out = "\nIOError! I can't find "+file2open+" file!"
            print(msg_out)
            return

        # Set up file2create
        file2create = self.program_root+"/misc/data/scatter_plot_par.csv"

        # Set uṕ an empty string
        lines_out = ""

        # Looping through lines_in
        for line in lines_in:
            if  "data_file" == str(line[0]):
                line_out = "data_file,"+self.file_in
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"
            elif  "plot_file" == str(line[0]):
                line_out = "plot_file,"+self.file_out
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"
            elif  "y_label" == str(line[0]):
                line_out = "y_label,"+self.y_label
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"
            elif str(line[0]) == "X_col":
                line_out = "X_col,"+self.i_X
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"
            elif str(line[0]) == "y_col":
                line_out = "y_col,"+self.i_y
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"
            elif str(line[0]) == "X_label":
                #edited_string = self.gen_binding()
                #line_out = "X_label,"+edited_string
                line_out = "X_label,"+self.X_label
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"
            else:
                line_out = str(line)
                line_out = self.some_editing(line_out)
                lines_out += line_out+"\n"

        # Close file
        fo.close()

        # Create a new file
        fo_new = open(file2create,"w")

        # Write lines_out
        fo_new.write(lines_out)

        # Close file
        fo_new.close()

    # Define some_editing() method
    def some_editing(self,string_in):
        """Method to edit a string"""

        # Some editing
        string_out = str(string_in)
        string_out = string_out.replace("[","")
        string_out = string_out.replace("]","")
        string_out = string_out.replace("'","")
        string_out = string_out.replace("\n","")
        string_out = string_out.replace(" ,",",")
        string_out = string_out.replace(", ",",")

        # Return string_out
        return string_out

    # Define gen_binding() method
    def gen_binding(self):
        """Method to generate binding strings"""

        # Invoke read_it function
        bind_in = b_aff.read_it(self.dir_in)

        # Set up string for binding data
        if bind_in == "Ki":
            bind_out = "pK$_{i}$"
        elif bind_in == "Kd":
            bind_out = "pK$_{d}$"
        elif bind_in == "IC50":
            bind_out = "pIC$_{50}$"
        else:
            print("\nUnrecognizable binding affinity type!")
            bind_out =""

        # Return bind_out
        return bind_out

    # Define bundle() method
    def bundle(self):
        """Method to pack all necessary methods"""

        # Try to update input file
        try:

            # Invoke get_indexes() method
            self.get_indexes()

            # Invoke write_input() method
            self.write_input()

            # Show message
            print("\nThe plotting information was successfully updated!")

        # Handle exception
        except:

            # Show message
            print("\nUnsuccessful information update!")
