# Import packages
import csv
import os
import shutil
import sys
import time
import numpy as np
import sklearn
from tkinter import *
from tkinter import filedialog
from tools import string_tools as string_t
from tools import tkinter_downloads as tk_downloads
from tools import tkinter_messages as tk_msg
from tools import tkinter_pdbqt as tk_pdbqt
from tools import tkinter_lig as tk_lig
from tools import tkinter_descriptors as tk_descriptors
from tools import tkinter_intermol as tk_intermol
from tools import tkinter_intermol3d as tk_intermol3d
from tools import tkinter_docking_hub as tk_docking
from tools import tkinter_joblib as tk_joblib
from tools import tkinter_joblib_vs as tk_joblib_vs
from tools import tkinter_sorting as tk_sorting
from tools import docking_vina as vina
from tools import preprocess_data as scaling
from tools import preprocess_poses as poses
from tools import preferences as prefs
from tools import check_dataset as check_data
from tools import binding_affinity as b_aff
from tools import regression_results4docking as reg
from tools import stats4models as stats
from tools import split as sp
from tools import plot_xy as p_xy
from tools import convert2pdbqt as conv2pdbqt
from tools import docking_screen as dock_s
from tools import docking_screen_data as dock_s_data
from MLRegMPy import ML_ACCESS
from MLRegMPy import ML_APPLY
from MLRegMPy import ML_STATS
from MLRegMPy import backup

# Create root widget
# It has to be created before any other widgets and
# there can only be one root widget
root = Tk()

# Instantiate an object of the Palavra class
a1 = string_t.Palavra("","pdb_codes.csv")

# Invoke ascii_art() method
opening_message,_,_,_,_,_,_ = a1.ascii_art()

# define GUI() class
class GUI(object):
    """Class to show Graphical User Interface"""

    # Define constructor method
    def __init__(self,program_root):
        """Constructor method"""

        # Set up attribute
        self.program_root = program_root

        # Set up program_id
        self.program_id = "SAnDReS"

        # Get scikit-learn version
        self.sk_version = str(sklearn.__version__)

        # Set up sk_msg
        self.sk_msg = "Scikit-Learn ("+self.sk_version+")"

        # Set up ad4_msg
        self.ad4_msg = "AutoDock Vina"

        # Set up stats_msg
        self.stats_msg = "Statistical Analysis of Docking Results"

        # Try to invoke About() method
        try:
            self.About()
        except:
            fo = open(self.program_root+"misc/inputs/strdir.in","w")
            fo.write("STRDIR,"+self.program_root)
            fo.close()
            print("\n\nI can't find Project Directory!"+\
            " Please use 'Find' button to browse for a new Project Directory!")
            print("\a")
            input("\nPress Enter to continue ")

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        self.win_height_type_1,self.win_y_offset_type_1,\
        _,_,\
        _,_,\
        self.spaces_in_row_2,self.spaces_in_row_3,\
        self.spaces_in_row_4,self.spaces_in_row_5,self.spaces_in_row_9,\
        self.fast_editor_txt_width,self.fast_editor_txt_height,\
        self.w,self.h,self.s_x,self.s_y = self.pr1.read_gui()

        # Type 1 GUI Window (new_win_height = 250, y_offset = 50) (250, 83)
        # Invoke tkinter_geometry() method
        _,_,self.top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_1,self.win_y_offset_type_1)

        # Set up message about the main reference for AutoDock Vina
        self.vina_ref = "\nWhen using AutoDock Vina, please cite: "
        self.vina_ref += "Trott O, Olson AJ. AutoDock Vina: improving the "
        self.vina_ref += "speed and "
        self.vina_ref += "\naccuracy of docking with a new scoring function, "
        self.vina_ref += "efficient optimization, and multithreading."
        self.vina_ref += "\nJ Comput Chem. 2010; 31(2): 455-461. "
        self.vina_ref += "\ndoi: 10.1002/jcc.21334. PMID: 19499576."
        self.vina_short_msg = self.vina_ref

        # Set up message about the main reference for Scikit-Learn
        self.scikit_ref = "\nWhen using Scikit-Learn, please cite: "
        self.scikit_ref += "Pedregosa F, Varoquaux G, Gramfort A, Michel V, "
        self.scikit_ref += "\nThirion B, Grisel O, Blondel M, Prettenhofer P, "
        self.scikit_ref += "Weiss R, Dubourg V, Vanderplas J, Passos A, "
        self.scikit_ref += "\nCournapeau D, Brucher M, Perrot M, Duchesnay E. "
        self.scikit_ref += "Scikit-learn: machine learning in python. "
        self.scikit_ref += "\nJ Mach Learn Res. 2011; 12: 2825-2830."

        # Set up message about main reference for AutoDockTools4
        self.autodocktools4_ref = "\nWhen using AutoDockTools4, please cite: "
        self.autodocktools4_ref += "Morris GM, Huey R, Lindstrom W, Sanner MF, "
        self.autodocktools4_ref += "Belew RK, Goodsell DS, Olson AJ. "
        self.autodocktools4_ref += "AutoDock4 and AutoDockTools4: Automated "
        self.autodocktools4_ref += "docking with selective receptor "
        self.autodocktools4_ref += "flexibility. "
        self.autodocktools4_ref += "\nJ Comput Chem. 2009; 30(16): 2785-2791. "
        self.autodocktools4_ref += "\ndoi: 10.1002/jcc.21256. PMID: 19399780."

        # Set up message about docking accuracy source
        self.da_ref = "\nDocking accuracy (DA1 and DA2) defined "
        self.da_ref += "in : Xavier MM, Heck GS, Avila MB, Levin NMB, "
        self.da_ref += "Pintro VO, Carvalho NL, Azevedo WF. SAnDReS a "
        self.da_ref += "Computational Tool for Statistical Analysis of Docking "
        self.da_ref += "Results and Development of Scoring Functions. \nComb "
        self.da_ref += "Chem High Throughput Screen. 2016;19(10):801-812."
        self.da_ref += "\ndoi: 10.2174/1386207319666160927111347. "
        self.da_ref += "PMID: 27686428."

    # Define open_main_gui() method
    def open_main_gui(self):
        """Method open main graphical user interface"""

        # Set up global image
        global img

        # Set up main GUI title, geometry and background color
        title_m="Statistical Analysis of Docking Results and Scoring functions"
        root.title(title_m)
        background_color = '#%02x%02x%02x' % (240, 240, 240)
        root.geometry(self.screen_geometry_var)
        root.configure(bg=background_color)
        menu = Menu(root)

        # Create a menubar
        root.config(menu=menu)

        # Set up logos
        logo_img_01 = self.program_root+"misc/logos/program_logo_1.gif"
        #logo_img_02 = self.program_root+"misc/logos/program_logo_2.gif"
        logo1 = PhotoImage(file=logo_img_01)
        Label(root, image = logo1 ).grid(row = 0, column = 0, stick = W)
        #logo2 = PhotoImage(file=logo_img_02)
        #Label(root, image = logo2 ).grid(row = 0, column = 0, stick = E)

        # Clear Label (Insert space to get the right position of botton bar)
        # self.widget_entry_main_width+11 (92*" ")
        #Label(root, text = (self.spaces_in_row_9)*" " ,
        #    fg = "black",bg="light grey",
        #    font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)
        Label(root, text = (self.spaces_in_row_9+9)*" " ,
            fg = "black",bg="light grey",
            font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)
        # WFA 2021-09-19

        # Widgets for project directory
        Label(root,
            text = self.spaces_in_row_2*" "+"Project Directory:" ).grid(row = 2,
            column = 0, stick = W, padx = 0)
        self.strdir_entry = Entry(root,width = self.widget_entry_main_width)

        # it was 75 (Linux 81) (self.widget_entry_main_width)
        self.strdir_entry.grid(row = 2,column = 0, stick = E, padx = 1)
        Button(root, text=' Find ', command=self.dir_chooser).grid(row = 2,
                column = 1, sticky = W)
        Button(root, text=' Update', command=self.update_strdir).grid(row = 2,
                column = 2, stick = E) # column = 1, stick = E WFA 2021-09-19
        my_strdir_main_GUI = self.read_strdir()
        self.strdir_entry.insert(10,my_strdir_main_GUI)

        # Widgets to read csv file name with docking results
        Label(root,
            text = self.spaces_in_row_3*" "+"Docking CSV File:" ).grid(row =3,
            column = 0, stick = W, padx = 0)
        self.docking_results_entry=Entry(root,
                width = self.widget_entry_main_width+1)     # (Linux 80)
        self.docking_results_entry.grid(row = 3, column = 0,stick = E, padx = 1)
        Button(root, text=' Clear',
                command=self.clear_docking_results_entry).grid(row = 3,
                column = 1, sticky = W)
        Button(root, text=' Update',
                command=self.update_docking_results_csv).grid(row = 3,
                column = 2, sticky = E)
        docking_results_main_GUI = self.read_docking_results_csv()
        self.docking_results_entry.insert(10,docking_results_main_GUI)

        # Widgets to read scoring function csv file name
        Label(root, text =
            self.spaces_in_row_4*" "+"Scoring Function CSV File:").grid(row = 4,
            column = 0, stick = W)
        self.input_score_csv_file_entry = Entry(root,width =
            self.widget_entry_main_width-8) # Linux 73
        self.input_score_csv_file_entry.grid(row=4,column = 0,stick = E,padx=1)
        Button(root, text=' Clear',
                command=self.clear_score_results_entry).grid(row=4,
                column = 1, sticky = W)
        Button(root,text=' Update',
                command=self.update_score_results_csv).grid(row=4,column = 2,
                sticky = E)
        score_results_main_GUI = self.read_score_results_csv()
        self.input_score_csv_file_entry.insert(10,score_results_main_GUI)

        # Widgets to read virtual screening csv file name
        Label(root,
            text =
            self.spaces_in_row_5*" "+"Virtual Screening CSV File:").grid(row =5,
            column = 0, stick = W)
        self.input_vs_csv_file_entry = Entry(root,width =
        self.widget_entry_main_width-9) # Linux 73
        self.input_vs_csv_file_entry.grid(row = 5,column=0,stick = E,padx = 1)
        Button(root,text=' Clear',
                command=self.clear_vs_results_entry).grid(row=5,
                column = 1, sticky = W)
        Button(root,text=' Update',
                command=self.update_vs_results_csv).grid(row=5,
                column = 2, sticky = E)
        vs_results_main_GUI = self.read_vs_results_csv()
        self.input_vs_csv_file_entry.insert(10,vs_results_main_GUI)

        # Widgets to read window_txt and show file (it was width = 109
        # columnspan = 2)
        #scrollbar = Scrollbar(root)
        #scrollbar.grid(row=6, column = 2, sticky=W)
        #self.window_txt = Text(root, width = int(self.window_txt_width),
        #        height = int(self.window_txt_height),font ="Courier 10",
        #        yscrollcommand=scrollbar.set) # It was width=106  height = 8
        #self.window_txt.grid(row = 6, column = 0, columnspan = 2, sticky = W)
        #scrollbar.config(command=self.window_txt.yview)

        # Show opening message
        #self.window_txt.insert(0.0,opening_message+
        #"Statistical Analysis of Docking Results and Scoring functions\n"+
        #"Developed by Dr. Walter F. de Azevedo, Jr.\n"+cat_art)

        #Button(root, text=' Clear',command=self.not_implemented_yet).grid(row=9,
        #        column=1, sticky=W, pady=4)
        Button(root, text='  Exit ', bg ="red",
                command=self.exit_function).grid(row=9,column=2,sticky=E)

        ########################################################################
        # Main Menu                                                            #
        ########################################################################
        # Set up auxiliary strings used in this Menu
        tab_spaces = 5*" "

        # File Menu
        filemenu = Menu(menu)
        menu.add_cascade(label="File", menu=filemenu)
        filemenu.add_command(label="Set up Parameters",)
        filemenu.add_command(
                label=tab_spaces+"Binding Affinity Ligand Data (IC50)",
                command=self.bind_IC50_parameters)
        filemenu.add_command(
                label=tab_spaces+"Binding Affinity Ligand Data (Kd)",
                command=self.bind_Kd_parameters)
        filemenu.add_command(
                label=tab_spaces+"Binding Affinity Ligand Data (Ki)",
                command=self.bind_Ki_parameters)
        filemenu.add_command(label=tab_spaces+"Machine-Learning",
                command=self.ml_parameters)
        filemenu.add_command(label=tab_spaces+"Program Preferences",
                command=self.program_preferences)
        filemenu.add_command(label=tab_spaces+"Vina",
                command=self.vina_parameters)
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=self.exit_function)

        # Dataset Menu
        add_struc = "Structures "
        datamenu = Menu(menu)
        menu.add_cascade(label="Dataset", menu=datamenu)
        datamenu.add_command(label="Add")
        datamenu.add_command(label=tab_spaces+"Summary",
            command=self.edit_summary_file)
        datamenu.add_command(label=tab_spaces+"PDB Access Codes",
                command = self.edit_pdb_codes)
        datamenu.add_command(label=tab_spaces+"Unified PDB Access Codes",
                command = self.unify_pdb_codes)
        datamenu.add_command(label=tab_spaces+"Binding Affinity Data",
                command = self.ligand_data)
        datamenu.add_command(label=tab_spaces+add_struc+"(PDB)",
                command=self.add_str_pdb)
        datamenu.add_command(label=tab_spaces+add_struc+"(PDBQT)",
                command = self.add_str_pdbqt)
        datamenu.add_command(
                label=tab_spaces+add_struc+"(PDBQT) using AutoDockTools4",
                command = self.add_adt_str_pdbqt)
        datamenu.add_command(label=tab_spaces+"Check Missing PDBQT Files",
         command = self.check_missing_pdbqt)

        # Docking Hub Menu
        one_str = "One-Click Docking with Vina "
        center_str = "(Centering: CM, EC, GC)"
        cm_str = "(Centering: CM)"
        stats_str = "Statistical Analysis of Docking Results "
        dockmenu = Menu(menu)
        menu.add_cascade(label="Docking Hub", menu = dockmenu)
        ###dockmenu.add_command(label=one_str+center_str,
        ###        command = self.docking_with_vina)
        dockmenu.add_command(label=one_str+center_str)
        dockmenu.add_command(label=tab_spaces+"Run Simulation",
                command = self.simulation_CM_EC_GC)
        dockmenu.add_command(label=tab_spaces+stats_str,
                command = self.stats_CM_EG_GC)
        dockmenu.add_separator()
        dockmenu.add_command(label=one_str+cm_str)
        dockmenu.add_command(label=tab_spaces+"Run Simulation",
                command = self.simulation_CM)
        dockmenu.add_command(label=tab_spaces+stats_str,command = self.stats_CM)
        dockmenu.add_separator()
        dockmenu.add_command(label= stats_str+"(External Dataset)",
                command = self.external_dataset)

        # Scoring Function Menu
        score_f_str = "Energy Terms (Vina) for Crystal Structures"
        scorefunctionmenu = Menu(menu)
        menu.add_cascade(label="Scoring Functions", menu = scorefunctionmenu)
        scorefunctionmenu.add_command(label="Add",)
        scorefunctionmenu.add_command(label=tab_spaces+"Descriptors",
         command = self.add_ligand_descriptors)
        scorefunctionmenu.add_command(label=tab_spaces+score_f_str,
         command = self.xtal_with_vina)
        scorefunctionmenu.add_command(
         label=tab_spaces+"Energy Terms (Vina) for Poses",
         command = self.pose_with_vina)

        # Virtual Screening Menu
        virtualscreeningmenu = Menu(menu)
        menu.add_cascade(label="Virtual Screening", menu = virtualscreeningmenu)
        virtualscreeningmenu.add_command(label="Simulation",)
        virtualscreeningmenu.add_command(label=tab_spaces+"Set up Parameters",
            command = self.edit_vs_par)
        virtualscreeningmenu.add_command(label=tab_spaces+"Import Ligands",
            command = self.mol2pdbqt)
        virtualscreeningmenu.add_command(label=tab_spaces+"Import Receptor",
            command = self.get_receptor_pdbqt)
        virtualscreeningmenu.add_command(label=tab_spaces+"Run",
            command = self.simulation_vs)
        virtualscreeningmenu.add_command(
            label=tab_spaces+"Merge VS Results",
            command = self.merge_vs)
        virtualscreeningmenu.add_command(
            label=tab_spaces+"Sort VS Results",
            command = self.sort_vs)

        # Machine Learning Box Menu
        x_str = " Crystal Structures"
        auto_pdb_str = "Automatic Generation of PDBs for Training and Test Sets"
        auto_str = "Generate Training and Test Sets"
        do_str = " Docking Results"
        bivariate_str = "Bivariate Analysis of Regression Models"
        mlmenu = Menu(menu)
        menu.add_cascade(label="Machine Learning Box",
                menu = mlmenu)
        mlmenu.add_command(label="For"+x_str)
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess)
        mlmenu.add_command(label=tab_spaces+"Choose PDBs for Training Set",
        command=self.choose_training_set)
        mlmenu.add_command(label=tab_spaces+"Choose PDBs for Test Set",
        command=self.choose_test_set)
        mlmenu.add_command(label=tab_spaces+auto_pdb_str,
        command=self.pdb_training_test_xtal)
        mlmenu.add_command(label=tab_spaces+auto_str,
        command=self.training_test_xtal)
        mlmenu.add_command(label=tab_spaces+"Filter Data",
        command=self.filter_data4xtal)
        mlmenu.add_command(label=tab_spaces+"Statistical Analysis (Features)",
        command=self.stat_analysis_features)
        mlmenu.add_command(label=tab_spaces+"Regression Methods",
        command=self.regression_methods)
        #mlmenu.add_command(label="Apply All Regression Models to"+x_str,
        #command=self.apply_joblib2xtal)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2xtal)
        mlmenu.add_command(label=tab_spaces+bivariate_str,
        command=self.stats_joblib2xtal)
        mlmenu.add_separator()
        mlmenu.add_separator()
        mlmenu.add_command(label="For"+do_str)
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess_p)
        mlmenu.add_command(label=tab_spaces+"Generate Training and Test Sets",
        command=self.training_test_p)
        mlmenu.add_command(label=tab_spaces+"Filter Data",
        command=self.filter_data4poses)
        #mlmenu.add_command(label=tab_spaces+"Apply All Regression Models",
        #command=self.apply_joblib2poses)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2poses)
        mlmenu.add_command(label=tab_spaces+bivariate_str,
        command=self.stats_joblib2poses)
        mlmenu.add_separator()
        mlmenu.add_separator()
        mlmenu.add_command(label="For Virtual Screening Results")
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess_vs)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2vs)
        mlmenu.add_command(label=tab_spaces+"Sort VS Results",
            command = self.sort_vs_ml)

        # Set up Plotting Menu
        plottingmenu = Menu(menu)
        menu.add_cascade(label="Plotting", menu=plottingmenu)
        plottingmenu.add_command(label="Generate")
        plottingmenu.add_command(
                label=tab_spaces+"2D Plot Intermolecular Interactions",
                command = self.contact_plot)
        plottingmenu.add_command(
                label=tab_spaces+"3D Plot Intermolecular Interactions",
                command = self.contact_3dplot)
        plottingmenu.add_command(
                label=tab_spaces+"Parameters for Scatter Plotting",
                command = self.edit_scatter_xy)
        plottingmenu.add_command(
                label=tab_spaces+"Scatter Plot",
                command = self.scatter_xy)

        root.mainloop()

    # Define show_opening_msg() message
    def show_opening_msg(self):
        """Method to show opening message"""

        # Show opening message
        print(opening_message+
        "Statistical Analysis of Docking Results and Scoring functions\n"+
        " Written by Dr. Walter F. de Azevedo, Jr.")

    # Define show_done_message1() method
    def show_done_message1(self,chosen_method,additional_msg):
        """A method to show done message"""

        # Instantiate an object of Messages() class
        msg = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = self.program_id
        msg_out += " finished \""+chosen_method+"\" request using "
        msg_out += additional_msg+"!"
        msg.show_botton_msg(msg_out,"black","light grey")

    # Define show_done_message2() method
    def show_done_message2(self,chosen_method):
        """A method to show done message"""

        # Instantiate an object of Messages() class
        msg = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = self.program_id
        msg_out += " finished \""+chosen_method+"\" request!"
        msg.show_botton_msg(msg_out,"black","light grey")

    # Define check_strdir() function
    def check_strdir(self):
        """Function to check strdir"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Test if the directory exits
        dir = os.path.isdir(project_dir_string)

        # Check if dir is True
        if dir:
            print("\nThe "+project_dir_string+" exists!")
        else:
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                    "I didn't find "+project_dir_string+" directory!"+\
                    " \nYou may use \"Find\" button to browse for a "+\
                    "new Project Directory!")

            # Update project dir
            project_dir_string = self.program_root
            self.clear_strdir_entry()
            self.strdir_entry.insert(10,self.program_root)

        return

    # Define update_docking_results_csv() method
    def update_docking_results_csv(self):
        """Method to update CSV file with docking results"""

        # Get new docking_string
        docking_string = str(self.docking_results_entry.get())

        # Open new c:\sandres\inputs\strdock.in
        f_strdir = open(self.program_root+"misc/inputs/strdock.in",'w')
        f_strdir.write("strdock,"+docking_string+" \n")
        f_strdir.close()

        # Invoke show_done_message1()
        self.show_done_message1("Update Docking Results CSV File","SAnDReS")

    # Define update_score_results_csv() method
    def update_score_results_csv(self):
        """Method to update CSV file with scoring results"""

        # Get new scoring_string
        scoring_string = str(self.input_score_csv_file_entry.get())

        # Open new c:\sandres\inputs\strscore.in
        f_strdir = open(self.program_root+"misc/inputs/strscore.in",'w')
        f_strdir.write("strscore,"+scoring_string+" \n")
        f_strdir.close()

        # Invoke show_done_message1()
        self.show_done_message1("Update Scoring Results CSV File","SAnDReS")

    # Define update_vs_results_csv() method
    def update_vs_results_csv(self):
        """Method to update CSV file with VS results"""

        # Get vs_string
        vs_string = str(self.input_vs_csv_file_entry.get())

        # Open new c:\sandres\inputs\strscore.in
        f_strdir = open(self.program_root+"misc/inputs/strvs.in",'w')
        f_strdir.write("strvs,"+vs_string+" \n")
        f_strdir.close()

        # Invoke show_done_message1()
        self.show_done_message1("Update VS Results CSV File","SAnDReS")

    # Define clear_strdir_entry() function
    def clear_strdir_entry(self):
        """Function to clear strdir entry"""

        self.strdir_entry.delete(0,END)

    # Define exit_function() function
    def exit_function(self):
        """Function to exit"""

        # Import package
        from tkinter import messagebox

        # Set up local time
        my_local_time = str(time.strftime("%Y.%m.%d_%Hh%Mmin%Ss"))

        # Show message
        print("Finishing execution on ",my_local_time)

        # Show yes/no question
        result = messagebox.askyesno("Continue?","Do you wish to finish?")

        # Test answer
        if result:
            sys.exit()
        else:
            # Show message
            print("I'm back...")

    # Define dir_chooser() function
    def dir_chooser(self):
        """Function to return dir name to be open"""

        root = Tk()
        root.withdraw()
        dir_name = str(filedialog.askdirectory()  )
        dir_name_windows = dir_name

        # Clear strdir
        self.clear_strdir_entry()

        # To avoid problems with void dir
        if dir_name == "":
            my_backup_strdir = self.strdir_entry.get()
            self.strdir_entry.insert(10,my_backup_strdir)
        else:
            # Insert new strdir
            self.strdir_entry.insert(10,dir_name_windows+"/")

        # Update strdir
        self.update_strdir()

    # Define update_strdir() function
    def update_strdir(self):
        """Function to update project directory"""

        # Import package
        from tkinter import messagebox

        # Call check_strdir()
        self.check_strdir()

        # Get new project directory
        project_dir_string = str(self.strdir_entry.get())

        # Open new project directory into c:\sandres\inputs\strdir.in
        f_strdir = open(self.program_root+"misc/inputs/strdir.in",'w')
        f_strdir.write("STRDIR,"+project_dir_string+" \n")
        f_strdir.close()

        # Show information about the update
        print("\nNew Project Directory: %s" % (project_dir_string ) )
        print("All structures and input files should be in the directory: %s"
         % (project_dir_string ))

        # Try to open showinfo.in into new project directory
        try:
            f_showinfo = open(project_dir_string+"showinfo.in",'w')
            shutil.copy2(self.program_root+"misc/inputs/copyin.in",
            project_dir_string+"copyin.in")
            shutil.copy2(self.program_root+"misc/inputs/sandres.in",
            project_dir_string+"sandres.in")
        except IOError:
            messagebox.showerror("IOError!",\
                             "I can't find  "+project_dir_string+" directory!"\
                              "\nPlease check project directory!")
            print("IOError! I can't find file ",project_dir_string,
            "showinfo.in")
            print("I've changed the project directory information "+
            "into the file "+self.program_root+"misc/inputs/strdir.in")
            print("New project directory is "+self.program_root)

            self.clear_strdir_entry()
            self.strdir_entry.insert(10,self.program_root)
            project_dir_string = self.program_root
            # WFA 2018 01 09
            fo = open(project_dir_string+"misc/inputs/strdir.in","w")
            fo.write("STRDIR,"+self.program_root+" \n")
            fo.close()

            # Copy copyin.in and sandres.in files
            f_showinfo = open(project_dir_string+"showinfo.in",'w')
            shutil.copy2(self.program_root+"misc/inputs/copyin.in",
            project_dir_string+"copyin.in")
            shutil.copy2(self.program_root+"misc/inputs/sandres.in",
            project_dir_string+"sandres.in")

        f_showinfo.write("SHOWINFO, \n")
        f_showinfo.close()

    # Define read_strdir() function
    def read_strdir(self):
        """Function to read project directory"""

        # Import package
        from tkinter import messagebox

        # Try to open stdir.in file in the project directory
        # (STRDIR) from misc/inputs/
        try:
            f_strdir = open(self.program_root+"misc/inputs/strdir.in","r")
            info_in_strdir = csv.reader(f_strdir)
        except IOError:
            print("\nI can't find file strdir.in")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find file strdir.in"+\
                              "\nPlease check project directory!")
            return

        # Looping through the input file to get the project directory
        for line in info_in_strdir:
            if line[0][0:6].upper() == "STRDIR":
                project_dir_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                sandres_line = "Unrecognizable command strdir.in"
                print(sandres_line)
                sys.exit()

        # Returns strdir
        return project_dir_string

    # Define read_docking_results_csv() function
    def read_docking_results_csv(self):
        """Function to read docking results CSV file"""

        # Import package
        from tkinter import messagebox

        # Try to open strdock.in file in the project directory
        # from misc/inputs/
        file2open = self.program_root+"misc/inputs/strdock.in"
        try:
            f_strdock = open(file2open,"r")
            info_in_strdock = csv.reader(f_strdock)
        except IOError:
            print("\nI can't find "+file2open+" file!")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find "+file2open+\
                              "\nPlease check directory!")
            return

        # Looping through info_in_strdock
        for line in info_in_strdock:
            if line[0] == "strdock":
                strdock_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                msg1 = "Unrecognizable command in strdock.in"
                print(msg1)
                sys.exit()

        # Returns strdock_string
        return strdock_string

    # Define read_score_results_csv() function
    def read_score_results_csv(self):
        """Function to read scoring function results CSV file"""

        # Import package
        from tkinter import messagebox

        # Try to open strscore.in file in the project directory
        # from misc/inputs/
        file2open = self.program_root+"misc/inputs/strscore.in"
        try:
            f_strscore = open(file2open,"r")
            info_in_strscore = csv.reader(f_strscore)
        except IOError:
            print("\nI can't find "+file2open+" file!")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find "+file2open+\
                              "\nPlease check directory!")
            return

        # Looping through info_in_strscore
        for line in info_in_strscore:
            if line[0] == "strscore":
                strscore_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                msg1 = "Unrecognizable command in strscore.in"
                print(msg1)
                sys.exit()

        # Returns strscore_string
        return strscore_string

    # Define read_vs_results_csv() function
    def read_vs_results_csv(self):
        """Function to read vs results CSV file"""

        # Import package
        from tkinter import messagebox

        # Try to open strsvs.in file in the project directory
        # from misc/inputs/
        file2open = self.program_root+"misc/inputs/strvs.in"
        try:
            f_vs = open(file2open,"r")
            info_in_strvs = csv.reader(f_vs)
        except IOError:
            print("\nI can't find "+file2open+" file!")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find "+file2open+\
                              "\nPlease check directory!")
            return

        # Looping through info_in_strvs
        for line in info_in_strvs:
            if line[0] == "strvs":
                strvs_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                msg1 = "Unrecognizable command in strvs.in"
                print(msg1)
                sys.exit()

        # Close file
        f_vs.close()

        # Returns strvs_string
        return strvs_string

    # Define clear_docking_results_entry() method
    def clear_docking_results_entry(self):
        """Method to clear input csv file entry"""

        # Delete self.docking_results_entry
        self.docking_results_entry.delete(0,END)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg1.show_botton_msg("Done! It is all clear now!","black","light grey")

    # Define clear_score_results_entry() method
    def clear_score_results_entry(self):
        """Method to clear input csv file entry"""

        # Delete self.input_score_csv_file_entry
        self.input_score_csv_file_entry.delete(0,END)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg1.show_botton_msg("Done! It is all clear now!","black","light grey")

    # Define clear_vs_results_entry() method
    def clear_vs_results_entry(self):
        """Method to clear input csv file entry"""

        # Delete self.input_vs_csv_file_entry
        self.input_vs_csv_file_entry.delete(0,END)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg1.show_botton_msg("Done! It is all clear now!","black","light grey")

    # Define not_implemented_yet() function
    def not_implemented_yet(self):
        """Function to show message that this function is not implemented yet"""

        print("Not implemented yet!")

    # Define About() function
    def About(self):
        """Function to show information about this program"""

        # String for local time
        my_local_date = str(time.strftime("%Y %m %d"))
        my_local_time = str(time.strftime("%Hh%Mmin%Ss"))

        print("\nLoading files...")
        print("\nToday's date: ",my_local_date)
        print("Local time: ",my_local_time)

        # Call show_opening_msg()
        self.show_opening_msg()

        return

    # Define program_preferences() method
    def program_preferences(self):
        """Method to edit program_par.csv file"""

        # Try to open program_par.csv file
        try:
            fo1 = open(self.program_root+"misc/data/program_par.csv","r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find file misc/data/program_par.csv!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/program_par.csv")

    # Define bind_IC50_parameters() method
    def bind_IC50_parameters(self):
        """Method to edit bind_IC50.csv file"""

        # Try to open program_par.csv file
        try:
            file2open = self.program_root+"misc/data/bind_IC50.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/bind_IC50.csv")

    # Define bind_Kd_parameters() method
    def bind_Kd_parameters(self):
        """Method to edit bind_Kd.csv file"""

        # Try to open program_par.csv file
        try:
            file2open = self.program_root+"misc/data/bind_Kd.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/bind_Kd.csv")

    # Define bind_Ki_parameters() method
    def bind_Ki_parameters(self):
        """Method to edit bind_Ki.csv file"""

        # Try to open program_par.csv file
        try:
            file2open = self.program_root+"misc/data/bind_Ki.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/bind_Ki.csv")

    # Define ml_parameters() method
    def ml_parameters(self):
        """Method to edit ml_par.csv file"""

        # Try to open program_par.csv file
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/ml_par.csv")

    # Define vina_parameters() method
    def vina_parameters(self):
        """Method to edit vina_par.csv file"""

        # Try to open program_par.csv file
        try:
            file2open = self.program_root+"misc/data/vina_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/vina_par.csv")

    # Define edit_summary_file() method
    def edit_summary_file(self):
        """Method to edit summary file"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open summary file
        try:
            fo1 = open(project_dir_string+"summary.txt","r")

            # Close file
            fo1.close()

        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find file summary.txt!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            fo_summary = open(project_dir_string+"summary.txt","w")
            print("\nA new summary.txt file was created!")

            # Close file
            fo_summary.close()

        # Call function edit_file()
        self.edit_file(project_dir_string,"summary.txt")

    # Define edit_scatter_xy() method
    def edit_scatter_xy(self):
        """Method to edit scatter_plot_par.csv file"""

        # Try to open scatter_plot_par.csv file
        try:
            file2open = self.program_root+"misc/data/scatter_plot_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/scatter_plot_par.csv")

    # Define edit_vs_par() method
    def edit_vs_par(self):
        """Method to edit vs_par.csv file"""

        # Try to open scatter_plot_par.csv file
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Call function edit_file()
        self.edit_file(self.program_root,"misc/data/vs_par.csv")

    # Define edit_file() method
    def edit_file(self,dir_in,my_file_2_open):
        """Method to edit any text file"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        short_msg = "Fast Editor opened "+my_file_2_open+" file."
        msg1.show_short_msg(short_msg)

        # Try to open file
        try:
            my_info_input_file = open(dir_in+my_file_2_open,"r")
        except IOError:
            print("I can't find ",dir_in+my_file_2_open)
            messagebox.showerror("IOError!", "I can't find input file "+
            dir_in+my_file_2_open+"\nPlease check input file name!")
            return

        # Define save_01() function
        def save_01():
            """Function to save edit input file content"""

            # Set up local time
            my_local_time = str(time.strftime("%Y.%m.%d_%Hh%Mmin%Ss"))

            # Get input file name
            string_input_file = str(top_inputfile_entry.get())

            # Open input file
            my_info_input_file = open(dir_in+string_input_file,"w")

            # Get input file content from txt window
            string_input_file_content = top_txt.get(0.0,END)

            # Write txt window content to input file
            my_info_input_file.write(string_input_file_content.strip())

            # Close updated input file
            my_info_input_file.close()

            # Call show_botton_msg()
            msg_out = "Done! File updated on "+my_local_time
            msg1.show_botton_msg(msg_out ,"black","light grey")

        # Define read_01() function
        def read_01():
            """Function to read input file from edit window"""

            # Edit text
            top_txt.delete(0.0,END)

            # Get input file name from edit window
            string_input_file = str(top_inputfile_entry.get())

            # Try to open input file
            try:
                my_info_input_file = open(dir_in+string_input_file,
                "r")
            except IOError:
                print("I can't find ",dir_in+string_input_file)
                messagebox.showerror("IOError!",
                            " I can't find input file"+
                            dir_in+string_input_file+\
                            "\nPlease check input file name!")
                return

            # message_tail adds new lines to text to be show
            message_tail = "\n\n\n\n\n\n\n\n\n\n\n"

            # Read file content
            top_txt.insert(END,my_info_input_file.read()+message_tail)

            # Close input file
            my_info_input_file.close()

        # Define clear_01() function
        def clear_01():
            """Function to clear txt content in editing window"""

            top_txt.delete(0.0,END)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('Fast Editor')
        top_txt.geometry(self.top_txt_geom)

        # Widgets for file name
        Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)
        top_inputfile_entry = Entry(top_txt,width = 95) # width was 95
        top_inputfile_entry.grid(row = 2, column = 0,stick = E)
        top_inputfile_entry.insert(10,my_file_2_open)

        # Widgets for buttons
        Button(top_txt,text='Read',command=read_01).grid(row=2,column=1,
        sticky=W)
        Button(top_txt,text='Clear',command=clear_01).grid(row=2,column=1,
        sticky=E)

        Button(top_txt,text='Save',command=save_01).grid(row=3,column=1,
        sticky=W)
        Button(top_txt,text='Close',bg="red",
        command=top_txt.destroy).grid(row=3,column=1,sticky = E)

        # Widgets for txt (it was 125) (width = 120, height = 15 )
        top_scrollbar = Scrollbar(top_txt)
        top_scrollbar.grid(row=8, column = 2,sticky=W)
        top_txt = Text(top_txt,width=self.fast_editor_txt_width,
        height=self.fast_editor_txt_height,
        yscrollcommand=top_scrollbar.set)
        top_txt.grid(row=8,column=0,columnspan=2,sticky=W)
        top_scrollbar.config(command=top_txt.yview)

        # message_tail adds new lines to text to be show
        message_tail = "\n\n\n\n\n\n\n"

        # Read file content
        top_txt.insert(END,my_info_input_file.read()+message_tail)

        # Close input file
        my_info_input_file.close()

    # Define edit_pdb_codes() method
    def edit_pdb_codes(self):
        """Method to edit pdb_codes.csv"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Assign zero to number_of_pdbs
        number_of_pdbs = 0

        # To create an empty file for the first run
        # Try to open csv file
        try:
            fo1 = open(project_dir_string+"pdb_codes.csv","r")

            # Close file
            fo1.close()
        except IOError:
            print("\nIOError! I can't find file pdb_codes.csv!")
            fo2 = open(project_dir_string+"pdb_codes.csv","w")
            print("\nA new pdb_codes.csv was created!")

            # Close files
            fo2.close()

        # Instantiate an object of the Palavra class
        p1 = string_t.Palavra(project_dir_string,"pdb_codes.csv")

        # Call count_codes() method
        number_of_pdbs = p1.count_codes()

        # Call function edit_file()
        self.edit_file(project_dir_string,"pdb_codes.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Call show_botton_msg()
        msg_out = "Number of PDB files in the ensemble (pdb_codes.csv): "
        msg1.show_botton_msg(msg_out+str(number_of_pdbs),"black","light grey")

    # Define unify_pdb_codes() method
    def unify_pdb_codes(self):
        """Method to unify PDB access codes"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the Palavra class
        p1 = string_t.Palavra(project_dir_string,"pdb_codes.csv")

        # Call backup_file() method
        p1.backup_file("pdb_codes.csv")

        # Call unify_pdb() method
        count_repeated_pdb,list_repeated_pdb = p1.unify_pdb("pdb_codes.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        msg_out = "\nList of PDBs deleted from pdb_codes.csv: "+\
        str(list_repeated_pdb)
        msg1.show_short_msg(msg_out)

        # Show message about the number of repeated structures
        msg_out ="Done! Number of repeated PDB files: "\
        +str(count_repeated_pdb)+"."
        msg1.show_botton_msg(msg_out ,"black","light grey")

    # Define add_str_pdb() method
    def add_str_pdb(self):
        """Method to download PDB files"""

        # Instantiate an object of the PDBData() class
        pdb1 = tk_downloads.PDBData(self.program_root,self.strdir_entry,root)

        # Invoke pdb_GUI() method
        pdb1.pdb_GUI()

    # Define ligand_data method
    def ligand_data(self):
        """Method to read ligand data from an internal database"""

        # Instantiate an object of the LigData() class
        lig0 = tk_lig.LigData(self.program_root,self.strdir_entry,root)

        # Invoke ligand_GUI() method
        lig0.ligand_GUI()

    # Define add_str_pdbqt method
    def add_str_pdbqt(self):
        """Method to add pdbqt files to the dataset.
        PDBQT format is very similar to PDB format but it includes
        partial charges ('Q') and AutoDock 4 (AD4) atom types ('T')."""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        msg_out = "\nLigand structures generated using AutoDockTools4."
        msg_out += self.autodocktools4_ref
        msg1.show_short_msg(msg_out)

        # Show yes/no question
        w_msg1 = "PDBQT Format Converter"
        w_msg2 = self.program_id
        w_msg2 += " will convert proteins to PDBQT format based only on "
        w_msg2 += "the experimental crystallographic atomic coordinates."
        w_msg2 += "\nNo atoms will be added to the crystallographic structures!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Dataset() class
            dataset1 = tk_pdbqt.Dataset(self.program_root,self.strdir_entry,
            root)

            # Invoke add_pdbqt_GUI() method
            dataset1.add_pdbqt_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No format conversion perfomed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define add_adt_str_pdbqt method
    def add_adt_str_pdbqt(self):
        """Method to add pdbqt files to the dataset using AutoDockTools"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDockTools4..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.autodocktools4_ref)

        # Show yes/no question
        w_msg1 = "AutoDockTools4"
        w_msg2 = "PDBQT structures will be converted using AutoDockTools4"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Dataset() class
            dataset2 = tk_pdbqt.Dataset(self.program_root,self.strdir_entry,
            root)

            # Invoke add_adt_pdbqt_GUI() method
            dataset2.add_adt_pdbqt_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define check_missing_pdbqt() method
    def check_missing_pdbqt(self):
        """Method to identify missing PDBQT files after making the dataset"""

        # Get new project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the PDBQT() class
        pdbqt1 = check_data.PDBQT(self.program_root,project_dir_string)

        # Invoke check_pqbqt() method
        missing_pdbqt = pdbqt1.check_pqbqt()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        msg_out = "\nLigand structures generated using AutoDockTools4."
        msg_out += self.autodocktools4_ref
        msg1.show_short_msg(msg_out)

        # Check whether there is missing PDBQT file
        if missing_pdbqt:

            # Set up msg_out
            msg_out = "Done! "+self.program_id+" found "
            msg_out += "missing PDBQT file(s) in this dataset! "
            msg_out += "PDB written in missing_pdbqt.csv!"
        else:

            # Set up msg_out
            msg_out = "Done! No missing PDBQT files in the dataset!"

        # Call show_botton_msg()
        msg1.show_botton_msg(msg_out,"black","light grey")

    # Define add_ligand_descriptors() method
    def add_ligand_descriptors(self):
        """Method to add descriptors to bind_###.csv file"""

        # Get new project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the DescriptorData() class
        d1 = tk_descriptors.DescriptorData(self.program_root,project_dir_string,
        root)

        # Invoke descriptor_GUI() method
        d1.descriptor_GUI()

    # Define contact_plot method
    def contact_plot(self):
        """Method to generate intermolecular contact plot"""

        # Instantiate an object of the ContactMap() class
        map1 = tk_intermol.ContactMap(self.program_root,self.strdir_entry,root)

        # Invoke pre_intermol_GUI() method
        map1.pre_intermol_GUI()

    # Define contact_3dplot method
    def contact_3dplot(self):
        """Method to generate intermolecular contact plot"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the ContactMap3D() class
        map3d = tk_intermol3d.ContactMap3D(self.program_root,self.strdir_entry,
        root)

        # Invoke pre_intermol3d_GUI() method
        map3d.pre_intermol3d_GUI()

    # Define simulation_CM_EC_GC() method
    def simulation_CM_EC_GC(self):
        """Method to run docking simulations using AutoDock Vina taking
        centering: center of mass (CM), electric center (EC), and
        geometric center GC"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "AutoDock Vina ready to go..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += " Docking may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Simulation() class
            prot_lig1 = tk_docking.Simulation(self.program_root,
            self.strdir_entry,root)

            # Invoke docking_GUI() method
            prot_lig1.docking_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define docking_with_vina_no_GUI() method
    def docking_with_vina_no_GUI(self):
        """Method to carry out docking simulations with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = "Docking with AutoDock Vina"
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += " Docking may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of Docking() class
            lig0 = vina.Docking(self.program_root,project_dir_string)

            # Looping through pdb_list and run AutoDock Vina
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke bundle() method
                    lig0.bundle(pdb)

                except:
                    pass

            # Invoke show_botton_msg() method
            msg_out = "Finished running AutoDock Vina for docking simulations!"
            msg1.show_botton_msg(msg_out,"black","light grey")

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define simulation_CM() method
    def simulation_CM(self):
        """Method to carry out docking simulations with AutoDock Vina using
        a faster approach.
        In this method we rely on one single type of centering for config.txt"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "AutoDock Vina ready to go..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += " Docking may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Simulation() class
            prot_lig2 = tk_docking.Simulation(self.program_root,
            self.strdir_entry,root)

            # Invoke cm_docking_GUI() method
            prot_lig2.cm_docking_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define stats_CM() method
    def stats_CM(self):
        """Method to carry out statistical analysis of docking simulations
        performed with AutoDock Vina (single run)"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.da_ref)

        # Show yes/no question
        w_msg1 = self.stats_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of Docking() class
            lig3 = vina.Docking(self.program_root,project_dir_string)

            # Looping through pdb_list and run AutoDock Vina
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke check_rmsd() method
                    lig3.check_single_rmsd(pdb)

                except:
                    pass

            # Invoke show_lowest_rmsd() method
            lig3.show_lowest_rmsd()

            # Invoke choose_rmsd() method
            lig3.choose_rmsd()

            # Invoke clean_dir() method
            # lig3.clean_dir()  # WFA 2021-09-18

            # Invoke add_results() method (WFA 2021-08-08)
            lig3.add_results()

            # Try to open vina_rmsd_results.csv
            try:
                file2open = project_dir_string+"vina_rmsd_results.csv"
                fo_stats = open(file2open,"r")
                csv_stats = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Set up empty string
            msg_stats = ""

            # Set up empty lists
            list_rmsd = []
            pdb_list_no_rmsd = []
            pdb_list_rmsd = []

            # Looping through csv_stats (first line)
            for line in csv_stats:
                # Some editing
                header_line = str(line[0])+"\t"+str(line[1])+"\t"+str(line[2])
                msg_stats += header_line+"\n"
                break

            # Looping through csv_stats
            for line in csv_stats:
                # Some editing
                if "mass" in line[1]:
                    centering = "mass     "
                elif "electric" in line[1]:
                    centering = "electric "
                else:
                    centering = str(line[1])

                line_out = str(line[0])+"\t"+centering+"\t\t"+str(line[2])
                msg_stats += line_out+"\n"

                # To get RMSD values
                if "ND" not in line[2]:
                    list_rmsd.append(float(line[2]))

            # Convert list to array
            rmsd_array = np.array(list_rmsd)

            # Calculate docking accuracy (DA1 and DA2) (Xavier et al 2016)
            # doi: 10.2174/138620731966616092711134
            n_all = np.count_nonzero(rmsd_array > 0.0)
            n_a = np.count_nonzero(rmsd_array < 2.0)
            n_b = np.count_nonzero(rmsd_array < 3.0)
            n_c = np.count_nonzero(rmsd_array < 4.0)
            if n_all != 0:
                f_a = n_a/n_all
                f_b = n_b/n_all
                f_c = n_c/n_all
                da1 = f_a + 0.5*(f_b - f_a)
                da2 = da1 + 0.25*(f_c - f_b)
            else:
                print("\nError! Number of poses is zero!")
                print("Please check dataset!")
                return

            # Add docking accuracy data
            msg_stats +="\n\nDocking accuracies\n"
            formated_da1 = "{:.3f}".format(da1)
            formated_da2 = "{:.3f}".format(da2)
            msg_stats += "DA1 = "+str(formated_da1)+"\n"
            msg_stats += "DA2 = "+str(formated_da2)+"\n"

            # Add docking RMSD average, minimum and maximum
            msg_stats += "\n\nDocking RMSD\n"
            formated_mean = "{:.3f}".format(np.mean(rmsd_array))
            msg_stats += "Mean RMSD (A) = "+str(formated_mean)+"\n"
            msg_stats += "Maximum RMSD (A) = "+str(np.max(rmsd_array))+"\n"
            msg_stats += "Minimum RMSD (A) = "+str(np.min(rmsd_array))+"\n"

            # Get the type of binding affinity
            # Set up a list
            bind_list = ["IC50","Kd","Ki"]

            # Try to open bind_####.csv file
            for bind in bind_list:
                try:
                    fo_bind = open(project_dir_string+"bind_"+bind+".csv","r")
                    print("\nBinding affinity: ",bind)

                    # Close file
                    fo_bind.close()

                    break
                except IOError:
                    pass

            # Try to open bind_###.csv
            try:
                file2open = project_dir_string+"bind_"+bind+".csv"
                fo_bind = open(file2open,"r")
                csv_bind = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Looping through csv_bind (first line)
            for line in csv_bind:
                break

            # Looping through csv_bind
            for line in csv_bind:
                try:
                    # Test to get PDB for structures with no docking results
                    if "ND" not in line[9]:
                        pdb_list_rmsd.append(line[0])
                    else:
                        pdb_list_no_rmsd.append(line[0])
                except:
                    pass

            # Add list of PDB with no docking results
            msg_stats += "\n\nPDB with no docking results: "
            msg_stats += str(pdb_list_no_rmsd)+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_stats)

            # Write statistical analysis
            file2create = project_dir_string+"docking_summary.log"
            fo_summary = open(file2create,"w")
            fo_summary.write(msg_stats)

            # Close files
            fo_stats.close()
            fo_bind.close()
            fo_summary.close()

            # Invoke show_done_message1()
            self.show_done_message1(self.stats_msg,self.ad4_msg)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define external_dataset() method
    def external_dataset(self):
        """Method to carry out statistical analysis of docking results
        of an external dataset generated with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.da_ref)

        # Invoke show_botton_msg() method
        msg_out = "Ready to carry out statistical analysis of docking results"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.stats_msg
        w_msg2 = "Please set up a directory with AutoDock Vina results"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Simulation() class
            ext_data1 = tk_docking.Simulation(self.program_root,
            self.strdir_entry,root)

            # Invoke stats_GUI() method
            ext_data1.stats_GUI()

            # Invoke show_done_message1()
            self.show_done_message1(self.stats_msg,self.ad4_msg)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define xtal_with_vina() method
    def xtal_with_vina(self):
        """Method to calculate binding energy for crystallographic position of
        the ligand with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of Docking() class
            lig0 = vina.Docking(self.program_root,project_dir_string)

            # Looping through pdb_list and run AutoDock Vina
            for pdb in pdb_list:

                # Invoke energy() method
                lig0.energy(pdb)

            # Invoke add_energy() method
            lig0.add_energy()

            # Invoke show_done_message()
            msg_out = "Add Energy Terms (Vina) for Crystal Structures"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No calculation performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define pose_with_vina() method
    def pose_with_vina(self):
        """Method to calculate binding energy for pose position of the ligand
         with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of Docking() class
            lig0 = vina.Docking(self.program_root,project_dir_string)

            # Set up a list with binding affinity
            bind_list = ["IC50","Kd","Ki"]

            # Get self.docking_results_entry()
            scores_docking_in = str(self.docking_results_entry.get())

            # Invoke add_data() method
            lig0.add_data(bind_list,scores_docking_in)

            # Invoke show_done_message2()
            msg_out = "Add Energy Terms (Vina) for Poses"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No calculation performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define stats_CM_EG_GC() method
    def stats_CM_EG_GC(self):
        """Method to carry out statistical analysis of docking simulations
        performed with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.da_ref)

        # Show yes/no question
        w_msg1 = self.stats_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of Docking() class
            lig1 = vina.Docking(self.program_root,project_dir_string)

            # Looping through pdb_list and run AutoDock Vina
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke check_rmsd() method
                    lig1.check_rmsd(pdb)

                except:
                    pass

            # Invoke show_lowest_rmsd() method
            lig1.show_lowest_rmsd()

            # Invoke choose_rmsd() method
            lig1.choose_rmsd()

            # Invoke clean_dir() method
            #lig1.clean_dir() # WFA 2021-09-18

            # Invoke add_results() method (WFA 2021-08-08)
            lig1.add_results()

            # Try to open vina_rmsd_results.csv
            try:
                file2open = project_dir_string+"vina_rmsd_results.csv"
                fo_stats = open(file2open,"r")
                csv_stats = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Set up empty string
            msg_stats = ""

            # Set up empty lists
            list_rmsd = []
            pdb_list_no_rmsd = []
            pdb_list_rmsd = []

            # Looping through csv_stats (first line)
            for line in csv_stats:
                # Some editing
                header_line = str(line[0])+"\t"+str(line[1])+"\t"+str(line[2])
                msg_stats += header_line+"\n"
                break

            # Looping through csv_stats
            for line in csv_stats:
                # Some editing
                if "mass" in line[1]:
                    centering = "mass     "
                elif "electric" in line[1]:
                    centering = "electric "
                else:
                    centering = str(line[1])

                line_out = str(line[0])+"\t"+centering+"\t\t"+str(line[2])
                msg_stats += line_out+"\n"

                # To get RMSD values
                if "ND" not in line[2]:
                    list_rmsd.append(float(line[2]))

            # Convert list to array
            rmsd_array = np.array(list_rmsd)

            # Calculate docking accuracy (DA1 and DA2) (Xavier et al 2016)
            # doi: 10.2174/138620731966616092711134
            n_all = np.count_nonzero(rmsd_array > 0.0)
            n_a = np.count_nonzero(rmsd_array < 2.0)
            n_b = np.count_nonzero(rmsd_array < 3.0)
            n_c = np.count_nonzero(rmsd_array < 4.0)
            if n_all != 0:
                f_a = n_a/n_all
                f_b = n_b/n_all
                f_c = n_c/n_all
                da1 = f_a + 0.5*(f_b - f_a)
                da2 = da1 + 0.25*(f_c - f_b)
            else:
                print("\nError! Number of poses is zero!")
                print("Please check dataset!")
                return

            # Add docking accuracy data
            msg_stats +="\n\nDocking accuracies\n"
            formated_da1 = "{:.3f}".format(da1)
            formated_da2 = "{:.3f}".format(da2)
            msg_stats += "DA1 = "+str(formated_da1)+"\n"
            msg_stats += "DA2 = "+str(formated_da2)+"\n"

            # Add docking RMSD average, minimum and maximum
            msg_stats += "\n\nDocking RMSD\n"
            formated_mean = "{:.3f}".format(np.mean(rmsd_array))
            msg_stats += "Mean RMSD (A) = "+str(formated_mean)+"\n"
            msg_stats += "Maximum RMSD (A) = "+str(np.max(rmsd_array))+"\n"
            msg_stats += "Minimum RMSD (A) = "+str(np.min(rmsd_array))+"\n"

            # Get the type of binding affinity
            # Set up a list
            bind_list = ["IC50","Kd","Ki"]

            # Try to open bind_####.csv file
            for bind in bind_list:
                try:
                    fo_bind = open(project_dir_string+"bind_"+bind+".csv","r")
                    print("\nBinding affinity: ",bind)

                    # Close file
                    fo_bind.close()

                    break
                except IOError:
                    pass

            # Try to open bind_###.csv
            try:
                file2open = project_dir_string+"bind_"+bind+".csv"
                fo_bind = open(file2open,"r")
                csv_bind = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Looping through csv_bind (first line)
            for line in csv_bind:
                break

            # Looping through csv_bind
            for line in csv_bind:
                try:
                    # Test to get PDB for structures with no docking results
                    if "ND" not in line[9]:
                        pdb_list_rmsd.append(line[0])
                    else:
                        pdb_list_no_rmsd.append(line[0])
                except:
                    pass

            # Add list of PDB with no docking results
            msg_stats += "\n\nPDB with no docking results: "
            msg_stats += str(pdb_list_no_rmsd)+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_stats)

            # Write statistical analysis
            file2create = project_dir_string+"docking_summary.log"
            fo_summary = open(file2create,"w")
            fo_summary.write(msg_stats)

            # Close files
            fo_stats.close()
            fo_bind.close()
            fo_summary.close()

            # Invoke show_done_message1()
            self.show_done_message1(self.stats_msg,self.ad4_msg)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No statistical analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define preprocess() method
    def preprocess(self):
        """Method to preprocess data for machine learning modeling"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Data will be scaled."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file
            sf_file_in = str(self.input_score_csv_file_entry.get())

            # Instantiate an object of Pre_proc() class
            data1 = scaling.Pre_proc(self.program_root,project_dir_string,
            sf_file_in)

            # Invoke bundle() method
            data1.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS preprocessed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Preprocess Data for Crystal Structures"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No scaling performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define preprocess_p() method
    def preprocess_p(self):
        """Method to preprocess pose data for machine learning modeling"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Data will be scaled."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file
            sf_dock_in = str(self.docking_results_entry.get())

            # Instantiate an object of Pre_proc() class
            data2 = poses.Pre_proc(self.program_root,project_dir_string,
            sf_dock_in)

            # Invoke bundle() method
            data2.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS preprocessed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Preprocess Data for Docking Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No scaling performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define preprocess_vs() method
    def preprocess_vs(self):
        """Method to preprocess virtual screening results
        for machine learning modeling"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Data will be scaled."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file
            sf_vs_in = str(self.input_vs_csv_file_entry.get())

            # Instantiate an object of Pre_proc() class
            data2 = poses.Pre_proc(self.program_root,project_dir_string,
            sf_vs_in)

            # Invoke bundle() method
            data2.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS preprocessed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Preprocess Data for Virtual Screening Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No scaling performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define regression_methods() method
    def regression_methods(self):
        """Method to apply regression methods available on
        https://scikit-learn.org/stable/modules/linear_model.html and
        https://xgboost.readthedocs.io/en/latest/python/python_api.html.
        Here we have access to a set of regression methods in which the target
        value is expected to be a linear combination of the features.

        """

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get scoring function file
        sf_file_in = str(self.input_score_csv_file_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Set up variables
        # For ML_ACCESS
        mlregmpy_in = "ml_par.csv" # Parameter file

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+")..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Modeling may take several minutes."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up empty list
            list_of_mlr_methods = []

            # Read regression methods (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)
            except IOError:
                sys.exit("\nIOError! I can't find "+file2open+"!")

            # Looping through input file to get mlr_methods
            for line in csv_in:
                if "#" in line[0]:
                    continue
                elif line[0] == "mlr_method":
                    mlr_method_in = handle_hash("str",str(line[1]))
                    list_of_mlr_methods.append(mlr_method_in)

            # Close ml_par.csv
            fo.close()

            # Instantiate an object of GATE() class
            model = ML_ACCESS.GATE(self.program_root,project_dir_string,
            mlregmpy_in,sf_file_in)

            # Regression loop
            # Looping through list_of_mlr_methods
            for mlr_method in list_of_mlr_methods:

                # Show message
                print("Running method "+mlr_method+"...")

                # Invoke read_input() method
                model.read_input(mlr_method)

                # Invoke select_features() method
                model.select_features()

                # Invoke write_features()
                model.write_features()

                # Invoke generate() method
                model.generate()

            # Backup files
            # Invoke backup.make()
            backup.make("features.csv",
            project_dir_string+"models/",project_dir_string+"backup/")
            backup.make("scores.csv",
            project_dir_string,project_dir_string+"backup/")

            # Set up report_out message
            report_out = "New regression models written in "+\
            project_dir_string+"/models"
            report_out += "\nSAnDReS generated regression models with the "
            report_out += "following methods available in "
            report_out += "Scikit-Learn "+str(self.sk_version)+" :\n"
            for mlr_method in list_of_mlr_methods:
                report_out += str(mlr_method)+"\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Regression Methods for Crystal Structures"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No regression performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define stat_analysis_features() method
    def stat_analysis_features(self):
        """Method to determine to correlation between features and experimental
        binding affinity.
        List of features available in the file misc/data/features_in.csv
        i.e.
        Torsions,Q,Average Q,C,N,O,S,F,Gauss 1,Gauss 2,Repulsion,Hydrophobic,
        Hydrogen
        """

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get scoring function file
        sf_file_in = str(self.input_score_csv_file_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+") and SciPy..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Correlation will be calculated using SciPy and Scikit-Learn. "
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Instantiate an object of Analysis() class
            features = ML_STATS.Analysis(self.program_root,project_dir_string,
            sf_file_in)

            # Set up exp_label
            exp_label = "log("+bind_in.replace(" ","")+")"

            # Invoke bundle() method
            features.bundle(exp_label)

            # Invoke show_botton_msg() method
            msg_out = "Finished!"
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Set up report_out message
            report_out = "\nSAnDReS determined metrics using Scikit-Learn ("
            report_out += str(self.sk_version)+") and SciPy.\n"
            report_out += self.scikit_ref

            # Invoke show_botton_msg() method
            msg_out = "Done!"
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Try to open statistical_analysis_features.csv
            #file2open = project_dir_string+"statistical_analysis_features.csv"
            file2open = project_dir_string+sf_file_in.replace(".csv","")
            file2open += "_stats4features.csv"
            try:
                fo_stats = open(file2open,"r")
                stats_data = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't  find "+file2open+" file!")
                return

            # Set up empty string
            stats_data_lines = ""

            # Looping through stats_data (first line)
            for line in stats_data:
                break

            # Header (Feature, r, p-value, r2, rho, p-value, MSE, RMSE, RSS)
            stats_data_lines += "\tFeature\t\t r \t\tp-value \t r2 \t rho "
            stats_data_lines += "\tp-value \t MSE \t RMSE \t RSS\n"

            # Looping through stats_data
            for line in stats_data:
                line_out = "{0:>16}".format(str(line[0]))
                aux_float = "{:.3f}".format(float(line[1]))
                line_out += "\t\t\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[2]))
                line_out += "\t\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[3]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[4]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[5]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[6]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[7]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[8]))
                line_out += "\t"+str(aux_float)

                # Some editing
                aux_line = str(line_out).replace("[","")
                aux_line = aux_line.replace("]","")
                aux_line = aux_line.replace("'","")

                # Add line
                stats_data_lines += str(aux_line)+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(stats_data_lines+"\n\n"+report_out)

            # Backup files
            # Invoke backup.make()
            file2backup = sf_file_in.replace(".csv","")+"_stats4features.csv"
            backup.make(file2backup,project_dir_string,
            project_dir_string+"backup/")

            # Close file
            fo_stats.close()

            # Invoke show_done_message2()
            msg_out = "Statistical Analysis (Features) for Crystal Structures"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No statistical analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            return

    # Define apply_joblib2xtal() method
    def apply_joblib2xtal(self):
        """Method to apply joblib model to a CSV file for xtal structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get scoring function file
        sf_file_in = str(self.input_score_csv_file_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+") and SciPy..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a float,
            an integer, or a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Set up empty list
        list_of_mlr_methods = []

        # Read regression methos (mlr_method) in ml_par.csv
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            print("\nIOError! I can't find "+file2open+"!")
            return

        # Looping through input file to get mlr_methods
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                list_of_mlr_methods.append(mlr_method_in)

        # Close ml_par.csv
        fo.close()

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Correlation will be calculated using SciPy and Scikit-Learn. "
        w_msg2 += "Predicted values will be added to "+sf_file_in+"."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Set up empty string for statistical analysis
        stats_out = ""

        # Test answer
        if result:

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Set up exp_label
            exp_label = "log("+bind_in.replace(" ","")+")"

            # Looping through list_of_mlr_methods
            for mlr_method in list_of_mlr_methods:

                # Show message
                print("\nAdding column method: ",mlr_method)

                # Assign variables related to the method strings
                model_in = "models/model_"+mlr_method+".joblib"
                new_label = mlr_method

                # Instantiate an object of JoblibModel() class
                pred = ML_APPLY.JoblibModel(project_dir_string,model_in,new_label)

                # Invoke bundle() method
                results = pred.bundle(sf_file_in,exp_label)

                # Add results
                stats_out += results

            # Backup files
            # Invoke backup.make()
            backup.make(sf_file_in,project_dir_string,project_dir_string+"backup/")
            backup.make("statistical_analysis.csv",project_dir_string,project_dir_string+"backup/")

            # Open a new file fot statistical analysis of regression models
            fo_stats = open(project_dir_string+"statistical_analysis.csv","w")

            # Write first line
            fo_stats.write("Method,r,p-value(r),r2,rho,p-value(rho),MSE,RMSE,Standard Deviation,RSS,F-stat\n")

            # Write all results
            fo_stats.write(stats_out)

            # Close file
            fo_stats.close()

            # Invoke show_stats_on_screen() method
            self.show_stats_on_screen("statistical_analysis.csv")

            # Invoke show_done_message2()
            msg_out = "Apply All Regression Models to Crystal Structures"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No joblibs applied!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define show_stats_on_screen() method
    def show_stats_on_screen(self,file_in):
        """Method to show statistical analysis on screen"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Set up report_out message
        report_out = "\nSAnDReS determined metrics using Scikit-Learn ("
        report_out += str(self.sk_version)+") and SciPy.\n"
        report_out += self.scikit_ref

        # Try to open file_in
        file2open = project_dir_string+file_in
        try:
            fo_stats = open(file2open,"r")
            stats_data = csv.reader(fo_stats)
        except IOError:
            print("\nIOError! I can't  find "+file2open+" file!")
            return

        # Set up empty string
        stats_data_lines = ""

        # Looping through stats_data (first line)
        for line in stats_data:
            break

        # Header (Feature, r, p-value, r2, rho, p-value, MSE, RMSE, RSS)
        stats_data_lines += "\t\t\tMethod\t r \tp-value \t r2 \t rho "
        stats_data_lines += "\tp-value \t MSE \t RMSE \t SD \t RSS \t "
        stats_data_lines += "F-stat\n"

        # Looping through stats_data
        for line in stats_data:
            line_out = "{0:>30}".format(str(line[0]))
            aux_float = "{:.3f}".format(float(line[1]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[2]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[3]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[4]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[5]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[6]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[7]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[8]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[9]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[10]))
            line_out += "\t"+str(aux_float)

            # Some editing
            aux_line = str(line_out).replace("[","")
            aux_line = aux_line.replace("]","")
            aux_line = aux_line.replace("'","")

            # Add line
            stats_data_lines += str(aux_line)+"\n"

        # Invoke show_short_msg() method
        msg1.show_short_msg(stats_data_lines+"\n\n"+report_out)

        # Close file
        fo_stats.close()

    # Define filter_data4xtal() method
    def filter_data4xtal(self):
        """Method to invoke filter_csv() method for sf_file_in file"""

        # Get scoring function file for xtal structures
        sf_file_in = str(self.input_score_csv_file_entry.get())

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(sf_file_in)

    # Define filter_csv_xtal() method
    def filter_csv_xtal(self,file_in):
        """Method eliminate lines with nan data"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to eliminate nan from "+file_in+" file!"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = "Filter Dataset"
        w_msg2 = "SAnDReS will delete nan lines."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up an empty string
            data_out = ""

            # Backup files
            # Invoke backup.make()
            backup.make(file_in,project_dir_string,project_dir_string+"backup/")

            # Try to open file_in
            try:
                file2open = project_dir_string+file_in
                fo_filter = open(file2open,"r")
                csv_filter = csv.reader(fo_filter)

                # Looping through csv_filter
                for line in csv_filter:
                    part_line = str(line[10:])
                    aux_line = str(line)

                    # Some editing
                    aux_line = str(aux_line).replace("[","")
                    aux_line = aux_line.replace("]","")
                    aux_line = aux_line.replace("'","")
                    aux_line = aux_line.replace(" ,",",")
                    aux_line = aux_line.replace(", ",",")
                    aux_line = aux_line.replace("\n","")

                    # Check if nan and ND are present
                    if "nan" in part_line:
                        pass
                    else:
                        data_out += aux_line+"\n"

                # Close file
                fo_filter.close()

            except IOError:

                # Invoke show_botton_msg() method
                msg_out = "I can't find "+file2open+" file!"
                msg_out += " finishing Filter Data request!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                return

            # Open a new file
            fo_filter = open(file2open,"w")

            # Some editing
            data_out = data_out.replace(" ,",",")
            data_out = data_out.replace(", ",",")

            # Write filtered data
            fo_filter.write(data_out)

            # Close file
            fo_filter.close()

            # Invoke show_done_message2()
            msg_out = "Filter Data for Crystal Structures"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No filtering performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define choose_training_set() method
    def choose_training_set(self):
        """Method to choose PDBs for the training set"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open a file
        try:
            file2open = project_dir_string+"pdb_codes_training_set.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            fo2 = open(file2open,"w")
            print("\nA new "+file2open+"file was created!")

            # Close file
            fo2.close()

        # Call function edit_file()
        self.edit_file(project_dir_string,"pdb_codes_training_set.csv")

    # Define choose_test_set() method
    def choose_test_set(self):
        """Method to choose PDBs for the test set"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open a file
        try:
            file2open = project_dir_string+"pdb_codes_test_set.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            fo2 = open(file2open,"w")
            print("\nA new "+file2open+"file was created!")

            # Close file
            fo2.close()

        # Call function edit_file()
        self.edit_file(project_dir_string,"pdb_codes_test_set.csv")

    # Define pdb_training_test_xtal() method
    def pdb_training_test_xtal(self):
        """Method to generate PDBs for training and test datasets
        for machine learning modeling for crystal structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to generate PDBs"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = "Automatic Generation of PDBs"
        w_msg2 = "PDB access codes will be randomly created."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Test answer
        if result:

            # Get scoring function file
            sf_file_in = str(self.input_score_csv_file_entry.get())

            # Get scoring function file for docking results
            sf_dock_in = str(self.docking_results_entry.get())

            # Read regression methods (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)
            except IOError:
                sys.exit("\nIOError! I can't find "+file2open+"!")

            # Looping through input file
            for line in csv_in:
                if "#" in line[0]:
                    continue
                elif line[0] == "test_size_in":
                    test_size_in = float(handle_hash("str",str(line[1])))
                elif line[0] == "seed_in":
                    seed_in = int(handle_hash("str",str(line[1])))

            # Close ml_par.csv
            fo.close()

            # Instantiate an object of Dataset() class
            d = sp.Dataset(project_dir_string,sf_file_in,sf_dock_in,
            test_size_in,seed_in)

            # Invoke random_pdb() method
            d.random_pdb()

            # Invoke show_done_message2()
            msg_out = "Automatic Generation of PDBs for Training and Test Sets"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No PDBs generated for training and test sets!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define training_test_xtal() method
    def training_test_xtal(self):
        """Method to generate training and test datasets for machine learning
        modeling for crystal structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to split datasets"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = "Split Dataset"
        w_msg2 = "Data will be divided in training and test sets."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Test answer
        if result:

            # Get scoring function file
            sf_file_in = str(self.input_score_csv_file_entry.get())

            # Get scoring function file for docking results
            sf_dock_in = str(self.docking_results_entry.get())

            # Read regression methods (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)
            except IOError:
                sys.exit("\nIOError! I can't find "+file2open+"!")

            # Looping through input file
            for line in csv_in:
                if "#" in line[0]:
                    continue
                elif line[0] == "test_size_in":
                    test_size_in = float(handle_hash("str",str(line[1])))
                elif line[0] == "seed_in":
                    seed_in = int(handle_hash("str",str(line[1])))

            # Close ml_par.csv
            fo.close()

            # Instantiate an object of Dataset() class
            d = sp.Dataset(project_dir_string,sf_file_in,sf_dock_in,
            test_size_in,seed_in)

            # Invoke read_pdb_access_codes() method
            d.read_pdb_access_codes()

            # Invoke generate() method
            d.generate()

            # Invoke show_done_message2()
            msg_out = "Generate Training and Test Sets"
            self.show_done_message2(msg_out)

            # Delete self.input_score_csv_file_entry
            self.input_score_csv_file_entry.delete(0,END)

            # Insert training set file name
            #score_results_main_GUI = "training_"+sf_file_in
            score_results_main_GUI = sf_file_in.replace(".csv","")
            score_results_main_GUI += "_training.csv"
            self.input_score_csv_file_entry.insert(10,score_results_main_GUI)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No training and test sets generated!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define training_test_p() method
    def training_test_p(self):
        """Method to generate training and test datasets for machine learning
        modeling for poses"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to split datasets"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = "Split Dataset"
        w_msg2 = "Docking data will be divided in training and test sets."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up empty lists
            pdb_train = []
            pdb_test = []

            # Get scoring function file for docking results
            sf_dock_in = str(self.docking_results_entry.get())

            # Try to open pdb_codes_training_set.csv
            try:

                # For training set
                file2open = project_dir_string+"pdb_codes_training_set.csv"
                fo_train = open(file2open,"r")
                csv_train = csv.reader(fo_train)

                # Looping through csv_train
                pdb = ""
                for line1 in csv_train:
                    aux_line = str(line1)

                    # Looping through each character of the line
                    for char1 in aux_line:
                        if char1 != ",":
                            pdb += char1
                        else:
                            # Some editing 2
                            pdb = pdb.replace("[","")
                            pdb = pdb.replace("]","")
                            pdb = pdb.replace("'","")
                            pdb = pdb.replace(" ","")
                            pdb_train.append(pdb)
                            pdb = ""

                    # For the last PDB access code
                    # Some editing 2
                    pdb = pdb.replace("[","")
                    pdb = pdb.replace("]","")
                    pdb = pdb.replace("'","")
                    pdb = pdb.replace(" ","")
                    pdb_train.append(pdb)

                # Close file
                fo_train.close()

                # Show PDB access codes for the training set
                print("\nTraining set: ",pdb_train)

                # Repeat the process for the test set
                file2open = project_dir_string+"pdb_codes_test_set.csv"
                fo_test = open(file2open,"r")
                csv_test = csv.reader(fo_test)

                # Looping through csv_test
                pdb = ""
                for line1 in csv_test:
                    aux_line = str(line1)

                    # Looping through each character of the line
                    for char1 in aux_line:
                        if char1 != ",":
                            pdb += char1
                        else:
                            # Some editing 2
                            pdb = pdb.replace("[","")
                            pdb = pdb.replace("]","")
                            pdb = pdb.replace("'","")
                            pdb = pdb.replace(" ","")
                            pdb_test.append(pdb)
                            pdb = ""

                    # For the last PDB access code
                    # Some editing 2
                    pdb = pdb.replace("[","")
                    pdb = pdb.replace("]","")
                    pdb = pdb.replace("'","")
                    pdb = pdb.replace(" ","")
                    pdb_test.append(pdb)

                # Close file
                fo_test.close()

                # Show PDB access codes for the test set
                print("\nTest set: ",pdb_test)

                # Try to open sf_dock_in
                try:

                    # Open new training and test sets
                    #file2create_train= project_dir_string+"training_"+sf_dock_in
                    file2create_train = project_dir_string
                    file2create_train += sf_dock_in.replace(".csv","")
                    file2create_train += "_training.csv"
                    #file2create_test = project_dir_string+"test_"+sf_dock_in
                    file2create_test = project_dir_string
                    file2create_test += sf_dock_in.replace(".csv","")
                    file2create_test += "_test.csv"
                    fo_train = open(file2create_train,"w")
                    fo_test = open(file2create_test,"w")

                    # Open docking results file
                    file2open_dock = project_dir_string+sf_dock_in
                    fo_dock = open(file2open_dock,"r")
                    csv_dock = csv.reader(fo_dock)

                    # Looping through csv_dock to get header
                    for line in csv_dock:

                        # Some editing 1
                        line_out = str(line)
                        line_out = line_out.replace("[","")
                        line_out = line_out.replace("]","")
                        line_out = line_out.replace("'","")
                        header = str(line_out)

                        # Write headers
                        fo_train.write(header+"\n")
                        fo_test.write(header+"\n")
                        break

                    # Looping through csv_dock to get the remaing line
                    for line in csv_dock:

                        # Some editing 2
                        line_out = str(line)
                        line_out = line_out.replace("[","")
                        line_out = line_out.replace("]","")
                        line_out = line_out.replace("'","")
                        line_out = line_out.replace(" ","")

                        if str(line[0]) in pdb_train:
                            fo_train.write(line_out+"\n")
                        elif str(line[0]) in pdb_test:
                            fo_test.write(line_out+"\n")
                        else:
                            msg_out = "\nI can't find PDB "+str(line[0])+ " in "
                            msg_out += "training and/or test sets!"
                            print(msg_out)

                    # Close files
                    fo_train.close()
                    fo_test.close()
                    fo_dock.close()

                # Handle IOError
                except IOError:
                    msg_out = "\nI can't find "+file2open_dock+" file!"
                    print(msg_out)
                    return

            # Handle IOError
            except IOError:
                msg_out = "\nI can't find "+file2open+" file!"
                print(msg_out)
                return

            # Invoke show_done_message2()
            msg_out = "Generate Training and Test Sets"
            self.show_done_message2(msg_out)

            # Delete text in self.docking_results_entry
            self.docking_results_entry.delete(0,END)

            # Insert training set file name
            #docking_results_main_GUI = "training_"+sf_dock_in
            docking_results_main_GUI = sf_dock_in.replace(".csv","")
            docking_results_main_GUI += "_training.csv"
            self.docking_results_entry.insert(10,docking_results_main_GUI)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No training and test sets generated!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define filter_data4poses() method
    def filter_data4poses(self):
        """Method to invoke filter_csv() method for sf_dock_in file"""

        # Get scoring function file for poses
        sf_dock_in = str(self.docking_results_entry.get())

        # Invoke filter_csv() method
        self.filter_csv(sf_dock_in)

    # Define filter_csv() method
    def filter_csv(self,file_in):
        """Method eliminate lines with nan and ND data"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to eliminate nan from "+file_in+" file!"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = "Filter Dataset"
        w_msg2 = "SAnDReS will delete nan lines."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up an empty string
            data_out = ""

            # Backup files
            # Invoke backup.make()
            backup.make(file_in,project_dir_string,project_dir_string+"backup/")

            # Try to open file_in
            try:
                file2open = project_dir_string+file_in
                fo_filter = open(file2open,"r")
                csv_filter = csv.reader(fo_filter)

                # Looping through csv_filter
                for line in csv_filter:
                    aux_line = str(line)

                    # Some editing
                    aux_line = str(aux_line).replace("[","")
                    aux_line = aux_line.replace("]","")
                    aux_line = aux_line.replace("'","")
                    aux_line = aux_line.replace(" ,",",")
                    aux_line = aux_line.replace(", ",",")
                    aux_line = aux_line.replace("\n","")

                    # Check if nan and ND are present
                    if "nan" in aux_line or "ND" in aux_line:
                        pass
                    else:
                        data_out += aux_line+"\n"

                # Close file
                fo_filter.close()

            except IOError:

                # Invoke show_botton_msg() method
                msg_out = "I can't find "+file2open+" file!"
                msg_out += " finishing Filter Data request!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                return

            # Open a new file
            fo_filter = open(file2open,"w")

            # Some editing
            data_out = data_out.replace(" ,",",")
            data_out = data_out.replace(", ",",")

            # Write filtered data
            fo_filter.write(data_out)

            # Close file
            fo_filter.close()

            # Invoke show_done_message2()
            msg_out = "Filter Data"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No filtering performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define apply_joblib2poses() method
    def apply_joblib2poses(self):
        """Method to apply joblib model to a CSV file generated with pose
        energy terms"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Get scoring function file
        sf_dock_in = str(self.docking_results_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+") and SciPy..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a float,
            an integer, or a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Set up empty list
        list_of_mlr_methods = []

        # Read regression methos (mlr_method) in ml_par.csv
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            print("\nIOError! I can't find "+file2open+"!")
            return

        # Looping through input file to get mlr_methods
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                list_of_mlr_methods.append(mlr_method_in)

        # Close ml_par.csv
        fo.close()

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Correlation will be calculated using SciPy and Scikit-Learn. "
        w_msg2 += "Predicted values will be added to "+sf_dock_in+"."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Set up empty string for statistical analysis
        stats_out = ""

        # Test answer
        if result:

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Set up exp_label
            exp_label = "log("+bind_in.replace(" ","")+")"

            # Looping through list_of_mlr_methods
            for mlr_method in list_of_mlr_methods:

                # Show message
                print("\nAdding column method: ",mlr_method)

                # Assign variables related to the method strings
                model_in = "models/model_"+mlr_method+".joblib"
                new_label = mlr_method

                # Instantiate an object of JoblibModel() class
                pred = ML_APPLY.JoblibModel(project_dir_string,model_in,new_label)

                # Try to invoke bundle() method
                try:
                    # Invoke bundle() method
                    results = pred.bundle(sf_dock_in,exp_label)
                except:
                    # To handle nan
                    results = "ND,ND,ND,ND,ND,ND,ND,ND,ND,ND,ND\n"

                # Add results
                stats_out += results

            # Backup files
            # Invoke backup.make()
            backup.make(sf_dock_in,project_dir_string,project_dir_string+"backup/")
            backup.make("statistical_analysis_poses.csv",project_dir_string,project_dir_string+"backup/")

            # Open a new file fot statistical analysis of regression models
            fo_stats = open(project_dir_string+"statistical_analysis_poses.csv","w")

            # Write first line
            fo_stats.write("Method,r,p-value(r),r2,rho,p-value(rho),MSE,RMSE,Standard Deviation,RSS,F-stat\n")

            # Write all results
            fo_stats.write(stats_out)

            # Close file
            fo_stats.close()

            # Invoke show_stats_on_screen() method
            self.show_stats_on_screen("statistical_analysis_poses.csv")

            # Invoke show_done_message2()
            msg_out = "Apply All Regression Models to Docking Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No joblibs applied!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define apply_selected_joblib2xtal() method
    def apply_selected_joblib2xtal(self):
        """Method to apply a selected joblib model"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up msg_out
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file
        sf_file_in = str(self.input_score_csv_file_entry.get())

        # Invoke backup.make()
        backup.make(sf_file_in,project_dir_string,project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        map1 = tk_joblib.Model(self.program_root,self.strdir_entry,root)

        # Invoke pre_joblib_GUI() method
        map1.pre_joblib_GUI(sf_file_in,"Crystal Structures")

    # Define apply_selected_joblib2poses() method
    def apply_selected_joblib2poses(self):
        """Method to apply a selected joblib model to docking results"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up empty string
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file
        sf_dock_in = str(self.docking_results_entry.get())

        # Invoke backup.make()
        backup.make(sf_dock_in,project_dir_string,project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        map1 = tk_joblib.Model(self.program_root,self.strdir_entry,root)

        # Invoke pre_joblib_GUI() method
        map1.pre_joblib_GUI(sf_dock_in,"Docking Results")

    # Define apply_selected_joblib2vs() method
    def apply_selected_joblib2vs(self):
        """Method to apply a selected joblib model
        to virtual screening results"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up empty string
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file for virtual screening results
        sf_vs_in = str(self.input_vs_csv_file_entry.get())

        # Invoke backup.make()
        backup.make(sf_vs_in,project_dir_string,project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        map1 = tk_joblib_vs.Model(self.program_root,self.strdir_entry,root)

        # Invoke pre_joblib_GUI() method
        map1.pre_joblib_GUI(sf_vs_in,"Virtual Screening Results")

    # Define stats_joblib2poses() method
    def stats_joblib2poses(self):
        """Method to carry out bivariate analysis of regression models applied
        to docking results"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Bivariate analysis of regression models applied to docking "
        w_msg2 += "results will be performed using SciKit-Learn."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file
            sf_dock_in = str(self.docking_results_entry.get())

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Instantiate an object of DockingResults() class
            r1 = reg.DockingResults(project_dir_string,sf_dock_in,bind_in)

            # Invoke bundle() method
            r1.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS processed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Bivariate Analysis of Regression Models Applied"
            msg_out += " Docking Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No bivariate analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define stats_joblib2xtal() method
    def stats_joblib2xtal(self):
        """Method to carry out bivariate analysis of regression models applied
        to crystallographic structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Bivariate analysis of regression models applied to "
        w_msg2 += "crystallographic structures performed using SciKit-Learn."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file
            sf_file_in = str(self.input_score_csv_file_entry.get())

            # Instantiate an object of Analysis() class
            s1 = stats.Analysis(self.program_root,project_dir_string,sf_file_in,
            root)

            # Invoke bundle() method
            s1.bundle()

            # Invoke show_done_message2()
            msg_out = "Bivariate Analysis of Regression Models Applied"
            msg_out += " Docking Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No bivariate analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define scatter_xy() method
    def scatter_xy(self):
        """Method to generate scatter plots"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Read plotting parameters
        # Try to open a file
        try:
            file2open = self.program_root+"misc/data/scatter_plot_par.csv"
            fo_plot_par = open(file2open,"r")
            csv_plot_par = csv.reader(fo_plot_par)

            # Looping through csv_plot_par
            for line in csv_plot_par:
                if "#" not in line:
                    if line[0] == "data_file":
                        data_file = line[1]
                    elif line[0] == "plot_file":
                        plot_file = line[1]
                    elif line[0] == "marker_in":
                        marker_in = line[1]
                    elif line[0] == "X_col":
                        X_col = int(line[1])
                    elif line[0] == "y_col":
                        y_col = int(line[1])
                    elif line[0] == "X_label":
                        X_label = line[1]
                    elif line[0] == "y_label":
                        y_label = line[1]
                    elif line[0] == "X_tick_size":
                        X_tick_size = int(line[1])
                    elif line[0] == "y_tick_size":
                        y_tick_size = int(line[1])
                    elif line[0] == "rot_X_tick":
                        rot_X_tick = int(line[1])
                    elif line[0] == "rot_y_tick":
                        rot_y_tick = int(line[1])
                    elif line[0] == "X_size":
                        X_size = int(line[1])
                    elif line[0] == "y_size":
                        y_size = int(line[1])
                    elif line[0] == "title_in":
                        title_in = line[1]
                    elif line[0] == "title_size":
                        title_size = int(line[1])
                    elif line[0] == "scatter_color":
                        scatter_color = line[1]
                    elif line[0] == "line_color":
                        line_color = line[1]
                    elif line[0] == "dpi_in":
                        dpi_in = int(line[1])
                    elif line[0] == "reg_line":
                        reg_line = line[1]
                    elif line[0] == "include_x_lim":
                        include_x_lim = line[1]
                    elif line[0] == "x_min_in":
                        x_min_in = float(line[1])
                    elif line[0] == "x_max_in":
                        x_max_in = float(line[1])
                    elif line[0] == "include_y_lim":
                        include_y_lim = line[1]
                    elif line[0] == "y_min_in":
                        y_min_in = float(line[1])
                    elif line[0] == "y_max_in":
                        y_max_in = float(line[1])
                    elif line[0] == "include_grid":
                        include_grid = line[1]
                    elif line[0] == "grid_color":
                        grid_color = line[1]
                    elif line[0] == "grid_linestyle":
                        grid_linestyle = line[1]
                    elif line[0] == "grid_linewidth":
                        grid_linewidth = float(line[1])

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Close file
        fo_plot_par.close()

        # Instantiate an object of the ScatterPlot() class
        p1 = p_xy.ScatterPlot(project_dir_string)

        # Invoke read_csv() method
        p1.read_csv(data_file,X_col,y_col)

        # Invoke generate() method
        p1.generate(plot_file,marker_in,
                X_label,y_label,X_size,y_size,
                X_tick_size,y_tick_size,rot_X_tick,rot_y_tick,
                title_in,title_size,
                scatter_color,line_color,dpi_in,reg_line,
                include_x_lim,x_min_in,x_max_in,
                include_y_lim,y_min_in,y_max_in,
                include_grid,grid_color,grid_linestyle,grid_linewidth)

    # Define mol2pdbqt() method
    def mol2pdbqt(self):
        """Convert from mol2 to PDBQT"""

        # Import package
        from tkinter import messagebox

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = "Mol2 files will be converted to PDBQT format"
        w_msg2 += " to be used for virtual screening!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get project directory
            project_dir_string = str(self.strdir_entry.get())

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Try to open convert2pdbqt_par.csv file
            try:
                file2open = self.program_root+"misc/data/vs_par.csv"
                fo_par = open(file2open,"r")
                csv_par = csv.reader(fo_par)

                # Looping through csv_par
                for line in csv_par:
                    if "#" not in str(line):
                        if line[0] == "lig_dir":
                            lig_dir = line[1]
                        elif line[0] == "lig_in":
                            lig_in = line[1]
                        elif line[0] == "vs_dir":
                            vs_dir = line[1]
                        elif line[0] == "mol_dir":
                            mol_dir = line[1]
                        elif line[0] == "lig_root_out":
                            lig_root_out = line[1]

                # Close file
                fo_par.close()

            # Handle IOError exception
            except IOError:
                print("\nIOerror! I can't find "+file2open+" file")
                return

            # Set up vs_dir1 in the project_dir_string
            vs_dir1 = project_dir_string+vs_dir

            # Try to make dir
            try:
                # Make dir
                os.mkdir(vs_dir1)

            # Handle exception
            except:
                pass

            # Add mol_dir
            vs_dir1 += mol_dir

            # Try to make dir
            try:
                # Make dir
                os.mkdir(vs_dir1)

            # Handle exception
            except:
                pass

            # Copy mol2 file to vs_dir1
            # Check whether the specified path/file is an existing directory/file
            # or not
            origin = lig_dir+lig_in
            isfile = os.path.isfile(origin)
            print("\nCheck whether the specified path/file ",origin,
            "is an  existing directory/file or not: ",isfile)
            if isfile:
                print("\nI've found ",origin," directory/file!")
                target = vs_dir1+lig_in
                shutil.copyfile(origin,target)
                print("\n\nCopying "+lig_in+" to "+vs_dir1+"!")

            # Instantiate an object of LIGPDBQT() class
            mol = conv2pdbqt.LIGPDBQT(self.program_root,project_dir_string,
                    vs_dir1)

            # Invoke mol2split() method
            mol.mol2split(lig_in,lig_root_out)

            # Invoke pdb2pdbqt() method
            mol.pdb2pdbqt(lig_in,lig_root_out)

            # List mol2 files in vs_dir1
            from os.path import isfile, join
            myfiles = [f for f in os.listdir(vs_dir1) if isfile(join(vs_dir1,f))]

            # Looping through myfiles
            for lig in myfiles:

                # Get only .mol2 files
                if ".mol2" in lig:

                    # Try to delete mol2 files in the mol_dir
                    try:
                        os.remove(vs_dir1+lig)
                        print("\nDeleting ",lig,"...")
                    except:
                        pass

            # Invoke show_done_message2()
            msg_out = "Virtual Screening->Import Ligands"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define get_receptor_pdbqt() method
    def get_receptor_pdbqt(self):
        """Method to import receptor.pdbqt and config.txt to carry out
        virtual screenings"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = "Lowest docking RMSD config.txt and receptor coordinates"
        w_msg2 += " will be used for virtual screening!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Try to open vs_par.csv file
            try:
                file2open = self.program_root+"misc/data/vs_par.csv"
                fo_par = open(file2open,"r")
                csv_par = csv.reader(fo_par)

                # Looping through csv_par
                for line in csv_par:
                    if "#" not in str(line):
                        if line[0] == "vs_dir":
                            vs_dir = line[1]
                        elif line[0] == "config_in":
                            config_in = line[1]
                        elif line[0] == "num_modes":
                            num_modes = line[1]

                # Close file
                fo_par.close()

            # Handle IOError exception
            except IOError:
                print("\nIOError! I can't find "+file2open+" file")
                return

            # Set up vs_dir1 in the project_dir_string
            vs_dir1 = project_dir_string+vs_dir

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Set up empty lists
            pdb_list = []
            rmsd_list = []
            resolution_list = []

            # Try to open bind_###.csv file
            try:
                file2open = project_dir_string+"bind_"+bind_in+".csv"
                fo_sf = open(file2open,"r")
                csv_sf = csv.reader(fo_sf)

                # Looping through csv_sf for the first line
                for line in csv_sf:
                    break

                # Looping through csv_sf
                for line in csv_sf:
                    pdb_list.append(line[0])
                    print(line[9])
                    if "nan" in str(line[9]):
                        aux_float = 9999.99
                    elif "ND" in str(line[9]):
                        aux_float = 9999.99
                    else:
                        try:
                            aux_float = float(line[9])
                        except:
                            aux_float = 9999.99

                    # Add data to lists
                    rmsd_list.append(aux_float)
                    resolution_list.append(line[4])

                # Close file
                fo_sf.close()

                # Convert to array
                rmsd_array = np.array(rmsd_list)

                # Get the index for the minimum RMSD
                i_min = np.argmin(rmsd_array)

                # Get the PDB and resolution for minimum RMSD
                pdb_min = pdb_list[i_min]
                resolution_min = str(resolution_list[i_min])

                # Show lowest RMSD PDB access codes
                print("\nPDB for lowest RMSD: ",pdb_min)
                print("Crystallographic resolution(A): ",resolution_min)
                print("Lowest RMSD(A): ",rmsd_array[i_min])

                # Open lowest_RMSD_PDB.csv
                fo_lowest = open(project_dir_string+"lowest_RMSD_PDB.csv","w")

                # Write lowest PDB access code and resolution
                fo_lowest.write("PDB,"+pdb_min+"\n")
                fo_lowest.write("Resolution(A),"+resolution_min)

                # Close lowest_RMSD_PDB.csv
                fo_lowest.close()

                # Try to copy a file
                # Copy a file to vs_dir1
                # Check whether the specified path/file is an existing
                # directory/file or not
                origin = project_dir_string+"pdbqt/"+pdb_min+"/"+config_in
                isfile = os.path.isfile(origin)
                print("\nCheck whether the specified path/file ",origin,
                "is an  existing directory/file or not: ",isfile)
                if isfile:
                    print("\nI've found ",origin," directory/file!")
                    target = vs_dir1+"/"+config_in
                    shutil.copyfile(origin,target)
                    print("\n\nCopying "+config_in+" to "+vs_dir1+"!")

                # Try to open config.txt file
                try:
                    fo_config = open(vs_dir1+"/"+config_in,"r")
                    config_data = fo_config.readlines()

                    # Set up string
                    config_out_string = "receptor = "+vs_dir1+"receptor.pdbqt\n"

                    # Looping through config.txt data
                    for line in config_data:
                        if "center_x" in line:

                            # Get index for "="
                            i_x = line.index("=")
                            aux_center_x = line[i_x+1:]

                            # Some editing
                            center_x = aux_center_x.replace(" ","")
                            center_x = center_x.replace(",","")
                            center_x = center_x.replace("[","")
                            center_x = center_x.replace("]","")
                            center_x = center_x.replace("'","")

                            # Add center_x
                            config_out_string += "center_x = "+center_x

                        elif "center_y" in line:

                            # Get index for "="
                            i_y = line.index("=")
                            aux_center_y = line[i_y+1:]

                            # Some editing
                            center_y = aux_center_y.replace(" ","")
                            center_y = center_y.replace(",","")
                            center_y = center_y.replace("[","")
                            center_y = center_y.replace("]","")
                            center_y = center_y.replace("'","")

                            # Add center_y
                            config_out_string += "center_y = "+center_y

                        elif "center_z" in line:

                            # Get index for "="
                            i_z = line.index("=")
                            aux_center_z = line[i_z+1:]

                            # Some editing
                            center_z = aux_center_z.replace(" ","")
                            center_z = center_z.replace(",","")
                            center_z = center_z.replace("[","")
                            center_z = center_z.replace("]","")
                            center_z = center_z.replace("'","")

                            # Add center_z
                            config_out_string += "center_z = "+center_z+"\n"

                        elif "size_x" in line:

                            # Get index for "="
                            i_x = line.index("=")
                            aux_size_x = line[i_x+1:]

                            # Some editing
                            size_x = aux_size_x.replace(" ","")
                            size_x = size_x.replace(",","")
                            size_x = size_x.replace("[","")
                            size_x = size_x.replace("]","")
                            size_x = size_x.replace("'","")

                            # Add size_x
                            config_out_string += "size_x = "+size_x

                        elif "size_y" in line:

                            # Get index for "="
                            i_y = line.index("=")
                            aux_size_y = line[i_y+1:]

                            # Some editing
                            size_y = aux_size_y.replace(" ","")
                            size_y = size_y.replace(",","")
                            size_y = size_y.replace("[","")
                            size_y = size_y.replace("]","")
                            size_y = size_y.replace("'","")

                            # Add size_y
                            config_out_string += "size_y = "+size_y

                        elif "size_z" in line:

                            # Get index for "="
                            i_z = line.index("=")
                            aux_size_z = line[i_z+1:]

                            # Some editing
                            size_z = aux_size_z.replace(" ","")
                            size_z = size_z.replace(",","")
                            size_z = size_z.replace("[","")
                            size_z = size_z.replace("]","")
                            size_z = size_z.replace("'","")

                            # Add size_z
                            config_out_string += "size_z = "+size_z

                        elif "seed" in line:

                            # Get index for "="
                            i_s = line.index("=")
                            aux_seed = line[i_s+1:]

                            # Some editing
                            seed = aux_seed.replace(" ","")
                            seed = seed.replace(",","")
                            seed = seed.replace("[","")
                            seed = seed.replace("]","")
                            seed = seed.replace("'","")

                            # Add seed
                            config_out_string += "seed = "+seed+"\n"

                    # Add num_modes
                    config_out_string += "num_modes = "+num_modes

                    # Close file
                    fo_config.close()

                    # Open new config.txt file
                    fo_config = open(vs_dir1+config_in,"w")

                    # Write config_out_string
                    fo_config.write(config_out_string)

                    # Close file
                    fo_config.close()

                # Handle exception
                except IOError:
                    msg_out = "\nIOError! I can't file "+vs_dir1+"/"
                    msg_out += config_in+" file!"
                    print(msg_out)
                    return

                # Try to copy a file
                # Copy a file to vs_dir1
                # Check whether the specified path/file is an existing
                # directory/file or not
                origin = project_dir_string+"pdbqt/"+pdb_min+"/receptor.pdbqt"
                isfile = os.path.isfile(origin)
                print("\nCheck whether the specified path/file ",origin,
                "is an  existing directory/file or not: ",isfile)
                if isfile:
                    print("\nI've found ",origin," directory/file!")
                    target = vs_dir1+"receptor.pdbqt"
                    shutil.copyfile(origin,target)
                    print("\n\nCopying receptor.pdbqt to "+vs_dir1+"!")

            # Handle IOError exception
            except IOError:
                print("\nIOerror! I can't find "+file2open+" file")
                return

            # Invoke show_done_message2()
            msg_out = "Virtual Screening->Simulation->Import Receptor"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define simulation_vs() method
    def simulation_vs(self):
        """Method to carry out docking screens"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Virtual Screening with AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Show yes/no question
        w_msg1 = self.ad4_msg
        w_msg2 = " Virtual screening may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Try to open vs_par.csv file
            try:
                file2open = self.program_root+"misc/data/vs_par.csv"
                fo_par = open(file2open,"r")
                csv_par = csv.reader(fo_par)

                # Looping through csv_par
                for line in csv_par:
                    if "#" not in str(line):
                        if line[0] == "vs_dir":
                            vs_dir = line[1]
                        elif line[0] == "mol_dir":
                            mol_dir = line[1]
                        elif line[0] == "config_in":
                            config_in = line[1]

                # Close file
                fo_par.close()

            # Handle IOError exception
            except IOError:
                print("\nIOerror! I can't find "+file2open+" file")
                return

            # Set up vs_dir1 in the project_dir_string
            vs_dir1 = project_dir_string+vs_dir

            # Instantiate an object of VirtualScreening() class
            vs = dock_s.VirtualScreening(self.program_root,vs_dir1,mol_dir,
            config_in)

            # Invoke simulation() method
            vs.simulation()

            # Invoke show_done_message2()
            msg_out = "Virtual Screening->Simulation->Run"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define merge_vs() method
    def merge_vs(self):
        """Method to merge virtual screening results performed with
        AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open vs_par.csv
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo_vs_par = open(file2open,"r")
            csv_vs_par = csv.reader(fo_vs_par)

            # Looping through csv_vs_par
            for line in csv_vs_par:
                if line[0] == "vs_dir":
                    vs_dir = line[1]
                elif line[0] == "mol_dir":
                    mol_dir = line[1]
                elif line[0] == "lig_root_out":
                    lig_root_out = line[1]

            # Close file
            fo_vs_par.close()

        # Handle IOError:
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Set up vs_dir1
        vs_dir1 = project_dir_string+vs_dir+mol_dir

        # Get directories using os.listdir()
        list_all = os.listdir(vs_dir1)

        # Set up empty list
        dir_list = []

        # Looping through list_all to get directories only
        for line in list_all:

            # Get directories only
            if ".pdbqt" not in str(line):
                dir_list.append(line)

        # Get the number of structures
        n_lig = len(dir_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Show yes/no question
        w_msg1 = self.stats_msg
        w_msg2 = "There are "+str(n_lig)+" molecules in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get vs_string
            vs_string = str(self.input_vs_csv_file_entry.get())

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Try to open lowest_rmsd_pdb.csv
            try:
                file2open = project_dir_string+"lowest_RMSD_PDB.csv"
                fo_lowest_PDB = open(file2open,"r")
                csv_lowest_PDB = csv.reader(fo_lowest_PDB)

                # Looping through
                for line in csv_lowest_PDB:
                    if line[0] == "PDB":
                        pdb = line[1]
                    elif line[0] == "Resolution(A)":
                        resolution = line[1]

                # Close file
                fo_lowest_PDB

            # Handle IOError exception
            except IOError:
                print("\nI can't find "+file2open+" file!")
                return

            # Looping through dir_list
            for mol in dir_list:
                print(mol)

                # Run vina_split
                os.system(self.program_root+\
                    "misc/linux_third_party_software/vina/./vina_split --input "+\
                    vs_dir1+mol+"/poses.pdbqt --ligand "+\
                    vs_dir1+mol+"/pose_")

            # Set up header (Chain->Pose)
            #lines_out = "PDB,Ligand,Pose,Number,Resolution(A),"
            #lines_out += "Ligand Occupation Factor,"+bind_in+"(M),log("+bind_in
            #lines_out += "),p"+bind_in+",RMSD(A),Torsions"

            # Instantiate an object of MergeVS() class
            po0 = dock_s_data.MergeVS(self.program_root,project_dir_string,
            lig_root_out,vs_string)

            # invoke add_data() method
            po0.add_data(vs_dir,mol_dir,dir_list,pdb,resolution)

            # Invoke show_done_message2()
            msg_out = "Merge VS Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No statistical analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define sort_vs() method
    def sort_vs(self):
        """Method to sort virtual screening results obtained using
        AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open vs_par.csv
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo_vs_par = open(file2open,"r")
            csv_vs_par = csv.reader(fo_vs_par)

            # Looping through csv_vs_par
            for line in csv_vs_par:
                if line[0] == "vs_dir":
                    vs_dir = line[1]
                elif line[0] == "mol_dir":
                    mol_dir = line[1]
                elif line[0] == "lig_root_out":
                    lig_root_out = line[1]

            # Close file
            fo_vs_par.close()

        # Handle IOError:
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Set up vs_dir1
        vs_dir1 = project_dir_string+vs_dir+mol_dir

        # Get directories using os.listdir()
        list_all = os.listdir(vs_dir1)

        # Set up empty list
        dir_list = []

        # Looping through list_all to get directories only
        for line in list_all:

            # Get directories only
            if ".pdbqt" not in str(line):
                dir_list.append(line)

        # Get the number of structures
        n_lig = len(dir_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Show yes/no question
        w_msg1 = "Sorting Virtual Screening Results"
        w_msg2 = "There are "+str(n_lig)+" molecules in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Ready to sort VS results!"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Test answer
        if result:

            # Get vs_string
            vs_string = str(self.input_vs_csv_file_entry.get())

            # Set sorted file name string
            sorted_vs_string = vs_string.replace(".csv","")+"_sorted.csv"

            # Instantiate an object of the DataVS() class
            vs1 = tk_sorting.DataVS(self.program_root,project_dir_string,
            root,"Affinity(kcal/mol)")

            # Invoke prep_GUI() method
            vs1.prep_GUI(vs_string,sorted_vs_string)


        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No sorting performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return

    # Define sort_vs_ml() method
    def sort_vs_ml(self):
        """Method to sort virtual screening results obtained using
        AutoDock Vina after application of joblib models"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Try to open vs_par.csv
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo_vs_par = open(file2open,"r")
            csv_vs_par = csv.reader(fo_vs_par)

            # Looping through csv_vs_par
            for line in csv_vs_par:
                if line[0] == "vs_dir":
                    vs_dir = line[1]
                elif line[0] == "mol_dir":
                    mol_dir = line[1]
                elif line[0] == "lig_root_out":
                    lig_root_out = line[1]

            # Close file
            fo_vs_par.close()

        # Handle IOError:
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Set up vs_dir1
        vs_dir1 = project_dir_string+vs_dir+mol_dir

        # Get directories using os.listdir()
        list_all = os.listdir(vs_dir1)

        # Set up empty list
        dir_list = []

        # Looping through list_all to get directories only
        for line in list_all:

            # Get directories only
            if ".pdbqt" not in str(line):
                dir_list.append(line)

        # Get the number of structures
        n_lig = len(dir_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Show yes/no question
        w_msg1 = "Sorting Virtual Screening Results"
        w_msg2 = "There are "+str(n_lig)+" molecules in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Ready to sort VS results!"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Test answer
        if result:

            # Get vs_string
            vs_string = str(self.input_vs_csv_file_entry.get())

            # Set sorted file name string
            sorted_vs_string = vs_string.replace(".csv","")+"_sorted.csv"

            # Instantiate an object of the DataVS() class
            vs1 = tk_sorting.DataVS(self.program_root,project_dir_string,
            root,"RandomForestRegressorCV")

            # Invoke prep_GUI() method
            vs1.prep_GUI(vs_string,sorted_vs_string)


        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No sorting performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print("\n"+msg_out)
            return
