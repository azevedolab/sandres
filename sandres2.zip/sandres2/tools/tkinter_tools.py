#!/usr/bin/env python3
#
# Class for Graphical User Interface and to manage all SAnDReS 2.0 classes,
# methods and functions.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import os
import shutil
import sys
import time
import webbrowser
import numpy as np
import sklearn
from tkinter import *
from tools import string_tools as string_t
from tools import tkinter_project as tk_project
from tools import download_ligands as download_ligs
from tools import tkinter_bindingDB as tk_bindDB
from tools import tkinter_add_bindingDB as tk_add_bindDB
from tools import tkinter_delete_project as tk_delete_project
from tools import tkinter_downloads as tk_downloads
from tools import tkinter_messages as tk_msg
from tools import tkinter_pdbqt as tk_pdbqt
from tools import tkinter_lig as tk_lig
from tools import tkinter_descriptors as tk_descriptors
from tools import tkinter_intermol as tk_intermol
from tools import tkinter_intermol3d as tk_intermol3d
from tools import tkinter_docking_hub as tk_docking
from tools import tkinter_scoring_function as tk_scoring
from tools import tkinter_scoring_function_poses as tk_scoring_poses
from tools import tkinter_virtual_screening as tk_virtual
from tools import tkinter_joblib as tk_joblib
from tools import tkinter_joblib_vs as tk_joblib_vs
from tools import tkinter_sorting as tk_sorting
from tools import tkinter_prepare_plotting as tk_prep_plot
from tools import tkinter_rcsb as tk_rcsb
from tools import tkinter_molegro as tk_molegro
from tools import docking_vina as vina
from tools import preprocess_data as scaling
from tools import preprocess_poses as poses
from tools import preferences as prefs
from tools import check_dataset as check_data
from tools import binding_affinity as b_aff
from tools import regression_results4docking as reg
from tools import stats4models as stats
from tools import stats4models_molegro as stats_molegro
from tools import split as sp
from tools import convert2pdbqt as conv2pdbqt
from tools import docking_screen as dock_s
from tools import docking_screen_data as dock_s_data
from tools import house_cleaning as cleaning
from tools import tkinter_scatter_plot as tk_scatter_plot
from tools import bivariate_analysis_full as bi_analysis
from tools import check_binding_affinity_data as checking
from tools import update_database as update
from tools import backup_all
from MLRegMPy import ML_ACCESS
from MLRegMPy import ML_STATS
from MLRegMPy import backup

# Create root widget
# It has to be created before any other widgets and
# there can only be one root widget
root = Tk()

# define GUI() class
class GUI(object):
    """Class to show Graphical User Interface"""

    # Define constructor method
    def __init__(self,program_root):
        """Constructor method"""

        # Set up attribute
        self.program_root = program_root

        # Set up program_id
        self.program_id = "SAnDReS"

        # Get scikit-learn version
        self.sk_version = str(sklearn.__version__)

        # Set up sk_msg
        self.sk_msg = "Scikit-Learn ("+self.sk_version+")"

        # Set up ad4_msg
        self.advina_msg = "AutoDock Vina"

        # Set up adt4_msg
        self.adt4_msg = "AutoDockTools4"

        # Try to invoke About() method
        try:
            self.About()
        except:
            fo = open(self.program_root+"misc/inputs/strdir.in","w")
            fo.write("STRDIR,"+self.program_root)
            fo.close()
            print("\n\nI can't find Project Directory!"+\
            " Please use 'Find' button to browse for a new Project Directory!")
            print("\a")
            input("\nPress Enter to continue ")

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        self.win_height_type_1,self.win_y_offset_type_1,\
        _,_,\
        _,_,\
        self.spaces_in_row_2,self.spaces_in_row_3,\
        self.spaces_in_row_4,self.spaces_in_row_5,self.spaces_in_row_9,\
        self.fast_editor_txt_width,self.fast_editor_txt_height,\
        self.w,self.h,self.s_x,self.s_y = self.pr1.read_gui()

        # Type 1 GUI Window (new_win_height = 250, y_offset = 50) (250, 83)
        # Invoke tkinter_geometry() method
        _,_,self.top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_1,self.win_y_offset_type_1)

        # Set up message about the main reference for AutoDock Vina
        self.vina_ref = "\nWhen using AutoDock Vina, please cite: "
        self.vina_ref += "Trott O, Olson AJ. "
        self.vina_ref += "\nAutoDock Vina: improving the speed and accuracy of "
        self.vina_ref += "docking "
        self.vina_ref += "\nwith a new scoring function, efficient "
        self.vina_ref += "optimization, and "
        self.vina_ref += "\nmultithreading."
        self.vina_ref += "\nJ Comput Chem. 2010; 31(2): 455-461. "
        self.vina_ref += "\ndoi: 10.1002/jcc.21334. PMID: 19499576."
        self.vina_ref += "\n\n\nEberhardt J, Santos-Martins D, Tillack AF, "
        self.vina_ref += "Forli S. AutoDock Vina 1.2.0: New Docking Methods, "
        self.vina_ref += "\nExpanded Force Field, and Python Bindings. "
        self.vina_ref += "\nJ Chem Inf Model. 2021; 61(8): 3891-3898. "
        self.vina_ref += "\ndoi: 10.1021/acs.jcim.1c00203. PMID: 34278794.\n"
        self.vina_short_msg = self.vina_ref

        # Set up message about the main reference for Scikit-Learn
        self.scikit_ref = "\nWhen using Scikit-Learn, please cite: "
        self.scikit_ref += "Pedregosa F, Varoquaux G, Gramfort A, "
        self.scikit_ref += "\nMichel V, Thirion B, Grisel O, Blondel M, "
        self.scikit_ref += "Prettenhofer P, Weiss R, Dubourg V, "
        self.scikit_ref += "\nVanderplas J, Passos A, Cournapeau D, "
        self.scikit_ref += "Brucher M, Perrot M, Duchesnay E. "
        self.scikit_ref += "\nScikit-learn: machine learning in python. "
        self.scikit_ref += "\nJ Mach Learn Res. 2011; 12: 2825-2830.\n"

        # Set up message about main reference for AutoDockTools4
        self.autodocktools4_ref = "\nWhen using AutoDockTools4, please cite: "
        self.autodocktools4_ref += "Morris GM, Huey R, Lindstrom W, "
        self.autodocktools4_ref += "\nSanner MF, Belew RK, Goodsell DS, "
        self.autodocktools4_ref += "Olson AJ. "
        self.autodocktools4_ref += "\nAutoDock4 and AutoDockTools4: Automated "
        self.autodocktools4_ref += "docking with selective receptor "
        self.autodocktools4_ref += "\nflexibility. "
        self.autodocktools4_ref += "\nJ Comput Chem. 2009; 30(16): 2785-2791. "
        self.autodocktools4_ref += "\ndoi: 10.1002/jcc.21256. PMID: 19399780.\n"

        # Set up message about docking accuracy source
        self.da_ref = "\nDocking accuracy (DA1 and DA2) defined "
        self.da_ref += "in : Xavier MM, Heck GS, Avila MB, "
        self.da_ref += "\nLevin NMB, "
        self.da_ref += "Pintro VO, Carvalho NL, Azevedo WF. "
        self.da_ref += "\nSAnDReS a "
        self.da_ref += "Computational Tool for Statistical Analysis of Docking "
        self.da_ref += "Results \nand Development of Scoring Functions. \nComb "
        self.da_ref += "Chem High Throughput Screen. 2016;19(10):801-812."
        self.da_ref += "\ndoi: 10.2174/1386207319666160927111347. "
        self.da_ref += "PMID: 27686428. \n"

    # Define open_main_gui() method
    def open_main_gui(self):
        """Method open main graphical user interface"""

        # Set up global image
        global img

        # Set up main GUI title, geometry and background color
        title_m = "SAnDReS 2.0"
        root.title(title_m)
        background_color = '#%02x%02x%02x' % (240, 240, 240)
        root.geometry(self.screen_geometry_var)
        root.configure(bg=background_color)
        menu = Menu(root)

        # Create a menubar
        root.config(menu=menu)

        # Set up logo
        logo_img_01 = self.program_root+"misc/logos/program_logo_1.gif"
        logo1 = PhotoImage(file=logo_img_01)
        Label(root, image = logo1 ).grid(row = 0, column = 0, stick = W)

        # Label to insert space to get the right position of botton bar
        Label(root, text = (self.spaces_in_row_9+9)*" " ,
            fg = "black",bg="light grey",
            font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)

        # Set up project directory (self.strdir_entry)
        self.strdir_entry = self.read_strdir()

        # Set up self.docking_results_entry
        self.docking_results_entry = self.read_docking_results_csv()

        # Set up self.input_score_csv_file_entry
        self.input_score_csv_file_entry = self.read_score_results_csv()

        # Set up self.input_vs_csv_file_entry
        self.input_vs_csv_file_entry = self.read_vs_results_csv()

        # Widget to access a site
        Button(root, text=' Site ',
                command=self.go_site).grid(row=9,
                column=1, sticky=W, pady=4)

        # Widget to access RCSB PDB
        Button(root, text=' RCSB ',
                command=self.go_rcsb).grid(row=9,column=2, sticky=E)

        ########################################################################
        # Welcome Message                                                      #
        ########################################################################

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Show welcome message
        msg_out = "Welcome to SAnDReS!"

        # Invoke show_botton_msg() method
        msg1.show_botton_msg(msg_out,"black","light grey")
        print("\n"+msg_out)
        print("Statistical Analysis of Docking Results and Scoring functions\n")

        # Assign zero total_ligands
        total_ligands = 0

        # Get number of ligands in the databases
        # Try to list files in self.program_root+"misc/data/pdbqt/IC50/"
        try:
            ic50_list = os.listdir(self.program_root+"misc/data/pdbqt/IC50/")

            # Get number of ligands with IC50
            total_ligands = len(ic50_list)

        # Handle exception
        except:
            pass

        # Try to list files in self.program_root+"misc/data/pdbqt/Kd/"
        try:
            kd_list = os.listdir(self.program_root+"misc/data/pdbqt/Kd/")

            # Add the number of ligands with Kd to total_ligands
            total_ligands += len(kd_list)

        # Handle exception
        except:
            pass

        # Try ist files in self.program_root+"misc/data/pdbqt/Ki/"
        try:
            ki_list = os.listdir(self.program_root+"misc/data/pdbqt/Ki/")

            # Add the number of ligands with Ki to total_ligands
            total_ligands += len(ki_list)

        # Handle exception
        except:
            pass

        ########################################################################
        # Main Menu                                                            #
        ########################################################################

        ########################################################################
        # Setup Menu                                                           #
        ########################################################################
        tab_spaces = 5*" "
        setupmenu = Menu(menu)
        menu.add_cascade(label="Setup", menu=setupmenu)
        setupmenu.add_command(
                label="Check Ligand Databases",
                command=self.check_ligand_databases)
        setupmenu.add_separator()
        setupmenu.add_command(
                label="Download Ligand Databases (IC50, Kd, Kd)",
                command=self.download_ligand_databases)
        setupmenu.add_separator()
        setupmenu.add_command(label="BindingDB Data",
                command=self.bindingDB)
        setupmenu.add_separator()
        setupmenu.add_command(label="Project Directory",)
        setupmenu.add_command(label=tab_spaces+"Make a New Project",
                command=self.make_project_directory)
        setupmenu.add_command(
                label=tab_spaces+"Backup Current Project",
                command=self.make_project_directory_backup)
        setupmenu.add_command(
                label=tab_spaces+"Show Saved Projects",
                command=self.show_saved_project_directories)
        setupmenu.add_command(
                label=tab_spaces+"Recover a Saved Project",
                command=self.recover_saved_project_directory)
        setupmenu.add_command(
                label=tab_spaces+"Delete a Saved Project",
                command=self.delete_saved_project_directory)
        setupmenu.add_separator()
        setupmenu.add_command(label="Exit", command=self.exit_function)

        ########################################################################
        # Edit Menu                                                            #
        ########################################################################
        tab_spaces = 5*" "
        editmenu = Menu(menu)
        menu.add_cascade(label="Edit", menu=editmenu)
        editmenu.add_command(label="Manually Add Data to Ligand Databases",
                command = self.add_data_manually)
        editmenu.add_separator()
        editmenu.add_command(label="Parameters",)
        editmenu.add_command(label=tab_spaces+"AutoDockTools",
                command=self.edit_adt_parameters)
        editmenu.add_command(label=tab_spaces+"Bar Plot",
                command=self.edit_bar_plot_parameters)
        editmenu.add_command(label=tab_spaces+"Bar 3DPlot",
                command=self.edit_bar_3dplot_parameters)
        editmenu.add_command(
                label=tab_spaces+"Binding Affinity Ligand Data (IC50)",
                command=self.edit_bind_IC50_parameters)
        editmenu.add_command(
                label=tab_spaces+"Binding Affinity Ligand Data (Kd)",
                command=self.edit_bind_Kd_parameters)
        editmenu.add_command(
                label=tab_spaces+"Binding Affinity Ligand Data (Ki)",
                command=self.edit_bind_Ki_parameters)
        editmenu.add_command(
                label=tab_spaces+"Bivariate Analysis",
                command=self.edit_bivariate_parameters)
        editmenu.add_command(label=tab_spaces+"GitHub URL",
                command=self.edit_github_url)
        editmenu.add_command(label=tab_spaces+"GUI Preferences",
                command=self.edit_gui_preferences)
        editmenu.add_command(label=tab_spaces+"Ligands to Add",
                command=self.edit_add_lig_parameters)
        editmenu.add_command(label=tab_spaces+"Machine Learning",
                command=self.edit_ml_parameters)
        editmenu.add_command(label=tab_spaces+"PDBs for Training Set",
                command=self.choose_training_set)
        editmenu.add_command(label=tab_spaces+"PDBs for Test Set",
                command=self.choose_test_set)
        editmenu.add_command(label=tab_spaces+"Project Directory",
                command=self.edit_project_directory)
        editmenu.add_command(label=tab_spaces+"Protein Data Bank Download URL",
                command=self.edit_pdb_url)
        editmenu.add_command(label=tab_spaces+"RCSB Protein Data Bank URL",
                command=self.edit_rcsb_url)
        editmenu.add_command(label=tab_spaces+"Scatter Plotting",
                command = self.edit_scatter_xy)
        editmenu.add_command(label=tab_spaces+"Site URL",
                command=self.edit_site_url)
        editmenu.add_command(label=tab_spaces+"Vina",
                command=self.edit_vina_parameters)
        editmenu.add_command(label=tab_spaces+"Virtual Screening",
                command=self.edit_vs_parameters)

        ########################################################################
        # Dataset Menu                                                         #
        ########################################################################
        add_struc = "Structures "
        datamenu = Menu(menu)
        menu.add_cascade(label="Dataset", menu=datamenu)
        datamenu.add_command(label="Edit Project Summary",
            command=self.edit_summary_file)
        datamenu.add_separator()
        datamenu.add_command(label="Edit PDB Access Codes",
                command = self.edit_pdb_codes)
        datamenu.add_separator()
        datamenu.add_command(label="Unify PDB Access Codes",
                command = self.unify_pdb_codes)
        datamenu.add_separator()
        datamenu.add_command(label="Check Binding Data for Structures",
                command = self.check_pdb_codes)
        datamenu.add_separator()
        datamenu.add_command(label="Add")
        datamenu.add_command(label=tab_spaces+"Binding Affinity Data",
                command = self.ligand_data)
        datamenu.add_command(label=tab_spaces+add_struc+"(PDB)",
                command=self.add_str_pdb)
        datamenu.add_command(label=tab_spaces+add_struc+"(PDBQT)",
                command = self.add_str_pdbqt)
        datamenu.add_command(
                label=tab_spaces+add_struc+"(PDBQT) using AutoDockTools4",
                command = self.add_adt_str_pdbqt)
        datamenu.add_separator()
        datamenu.add_command(
                label="Check Directories for Current Dataset",
                command = self.check_n_pdbqt)
        datamenu.add_separator()
        datamenu.add_command(label="Check Missing PDBQT Files",
                command = self.check_missing_pdbqt)
        datamenu.add_separator()
        datamenu.add_command(label="Update Dataset",
                command = self.update_dataset)

        ########################################################################
        # Docking Hub Menu                                                     #
        ########################################################################
        one_str = "One-Click Docking with Vina "
        center_str = "(Centering: CM, EC, GC)"
        cm_str = "(Centering: CM)"
        stats_str = "Statistical Analysis of Docking Results "
        dockmenu = Menu(menu)
        menu.add_cascade(label="Docking Hub", menu = dockmenu)
        dockmenu.add_command(label="Set up Vina Parameters",
                command=self.edit_vina_parameters)
        dockmenu.add_separator()
        dockmenu.add_command(label=one_str+center_str)
        dockmenu.add_command(label=tab_spaces+"Run Simulation",
                command = self.simulation_CM_EC_GC)
        dockmenu.add_command(label=tab_spaces+stats_str,
                command = self.stats_CM_EG_GC)
        dockmenu.add_separator()
        dockmenu.add_command(label=one_str+cm_str)
        dockmenu.add_command(label=tab_spaces+"Run Simulation",
                command = self.simulation_CM)
        dockmenu.add_command(label=tab_spaces+stats_str,command = self.stats_CM)
        dockmenu.add_separator()
        dockmenu.add_command(label= stats_str+"(External Dataset)",
                command = self.external_dataset)
        dockmenu.add_separator()
        dockmenu.add_command(label="Check Unsuccessful Docking Simulations",
                command = self.check_unsuccessful_docking_simulations)

        ########################################################################
        # Scoring Function Menu                                                #
        ########################################################################
        score_f_str = "Energy Terms (Vina) for Crystal Structures"
        scorefunctionmenu = Menu(menu)
        menu.add_cascade(label="Scoring Functions", menu = scorefunctionmenu)
        scorefunctionmenu.add_command(label="Set up Vina Parameters",
                command=self.edit_vina_parameters)
        scorefunctionmenu.add_separator()
        scorefunctionmenu.add_command(label="Add",)
        scorefunctionmenu.add_command(label=tab_spaces+"Descriptors",
         command = self.add_ligand_descriptors)
        scorefunctionmenu.add_command(label=tab_spaces+score_f_str,
         command = self.xtal_with_vina)
        scorefunctionmenu.add_command(
         label=tab_spaces+"Energy Terms (Vina) for Poses "+center_str,
         command = self.pose_with_vina)
        scorefunctionmenu.add_command(
         label=tab_spaces+"Energy Terms (Vina) for Poses (Centering: CM)",
         command = self.pose_with_vina_CM)
        scorefunctionmenu.add_separator()
        scorefunctionmenu.add_command(
            label="Check Unsuccessful Scoring Function Calculations for Poses",
            command = self.check_unsuccessful_scores4poses)

        ########################################################################
        # Virtual Screening Menu                                               #
        ########################################################################
        virtualscreeningmenu = Menu(menu)
        menu.add_cascade(label="Virtual Screening", menu = virtualscreeningmenu)
        virtualscreeningmenu.add_command(
            label="Set up Virtual Screening Parameters",
            command = self.edit_vs_parameters)
        virtualscreeningmenu.add_separator()
        virtualscreeningmenu.add_command(label="Simulation",)
        virtualscreeningmenu.add_command(label=tab_spaces+"Import Ligands",
            command = self.mol2pdbqt)
        virtualscreeningmenu.add_command(label=tab_spaces+"Import Receptor",
            command = self.get_receptor_pdbqt)
        virtualscreeningmenu.add_command(label=tab_spaces+"Edit config.txt",
            command = self.edit_config_txt_4vs)
        virtualscreeningmenu.add_command(label=tab_spaces+"Run",
            command = self.simulation_vs)
        virtualscreeningmenu.add_command(
            label=tab_spaces+"Merge VS Results",
            command = self.merge_vs)
        virtualscreeningmenu.add_command(
            label=tab_spaces+"Sort VS Results",
            command = self.sort_vs)
        virtualscreeningmenu.add_separator()
        virtualscreeningmenu.add_command(label="Add BindingDB Data",
                command=self.add_bindingDB)
        virtualscreeningmenu.add_separator()
        virtualscreeningmenu.add_command(
                label="Check Unsuccessful Virtual Screening Simulations",
                command = self.check_unsuccessful_vs_simulations)

        ########################################################################
        # Machine Learning Box Menu                                            #
        ########################################################################
        auto_pdb_str = "Automatic Generation of PDBs for Training and Test Sets"
        auto_str = "Generate Training and Test Sets"
        do_str = " Docking Results"
        bivariate_str = "Bivariate Analysis of Regression Models"
        mlmenu = Menu(menu)
        menu.add_cascade(label="Machine Learning Box",
                menu = mlmenu)
        mlmenu.add_command(label="Set up Machine Learning Parameters",
            command = self.edit_ml_parameters)
        mlmenu.add_separator()
        mlmenu.add_command(label="For Modeling")
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess)
        mlmenu.add_command(label=tab_spaces+auto_pdb_str,
        command=self.pdb_training_test_xtal)
        mlmenu.add_command(label=tab_spaces+auto_str,
        command=self.training_test_xtal)
        mlmenu.add_command(label=tab_spaces+"Filter Data",
        command=self.filter_data4xtal)
        mlmenu.add_command(label=tab_spaces+"Statistical Analysis (Features)",
        command=self.vina_stat_analysis_features)
        mlmenu.add_command(label=tab_spaces+"Regression Methods",
        command=self.regression_methods)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2model)
        mlmenu.add_command(label=tab_spaces+bivariate_str,
        command=self.stats_joblib2xtal)
        ########################################################################
        mlmenu.add_separator()
        mlmenu.add_command(label="For"+do_str)
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess_p)
        mlmenu.add_command(label=tab_spaces+"Generate Training and Test Sets",
        command=self.training_test_p)
        mlmenu.add_command(label=tab_spaces+"Filter Data",
        command=self.filter_data4poses)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2poses)
        mlmenu.add_command(label=tab_spaces+bivariate_str,
        command=self.stats_joblib2poses)
        ########################################################################
        mlmenu.add_separator()
        mlmenu.add_command(label="For Virtual Screening Results")
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess_vs)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2vs)
        mlmenu.add_command(label=tab_spaces+"Sort VS Results",
            command = self.sort_vs_ml)
        ########################################################################
        mlmenu.add_separator()
        mlmenu.add_command(label="For Modeling Using Molegro Results")
        mlmenu.add_command(label=tab_spaces+"Set up Molegro Parameters",
                command=self.edit_molegro_parameters)
        mlmenu.add_command(label=tab_spaces+"Convert VS Data",
        command=self.get_molegro_data)
        mlmenu.add_command(label=tab_spaces+"Preprocess Data",
        command=self.preprocess)
        #mlmenu.add_command(label=tab_spaces+"Choose PDBs for Training Set",
        #command=self.choose_training_set)
        #mlmenu.add_command(label=tab_spaces+"Choose PDBs for Test Set",
        #command=self.choose_test_set)
        mlmenu.add_command(label=tab_spaces+auto_pdb_str,
        command=self.pdb_training_test_xtal)
        mlmenu.add_command(label=tab_spaces+auto_str,
        command=self.training_test_xtal)
        mlmenu.add_command(label=tab_spaces+"Filter Data",
        command=self.filter_data4xtal)
        mlmenu.add_command(label=tab_spaces+"Statistical Analysis (Features)",
        command=self.molegro_stat_analysis_features)
        mlmenu.add_command(label=tab_spaces+"Regression Methods",
        command=self.regression_methods)
        mlmenu.add_command(label=tab_spaces+"Apply Regression Model",
        command=self.apply_selected_joblib2model)
        mlmenu.add_command(label=tab_spaces+bivariate_str,
        command=self.stats_joblib2molegro)

        ########################################################################
        # Statistical Analysis Menu                                            #
        ########################################################################
        statsmenu = Menu(menu)
        menu.add_cascade(label="Statistical Analysis", menu=statsmenu)
        statsmenu.add_command(label="Apply Regression Model to a CSV File",
        command=self.apply_selected_joblib2csv)
        statsmenu.add_separator()
        statsmenu.add_command(label="Scatter Plot")
        statsmenu.add_command(
                label=tab_spaces+"Set up Parameters",
                command = self.par2plot)
        statsmenu.add_command(label=tab_spaces+"Edit Parameters",
                command = self.edit_scatter_xy)
        statsmenu.add_command(
                label=tab_spaces+"Generate",
                command = self.go_plotting)
        statsmenu.add_separator()
        statsmenu.add_command(label="Bivariate Analysis")
        statsmenu.add_command(label=tab_spaces+"Edit Parameters",
                command = self.edit_bivariate_parameters)
        statsmenu.add_command(
                label=tab_spaces+"Run",
                command = self.run_bivariate_analysis)
        statsmenu.add_separator()
        statsmenu.add_command(
                label="2D Plot Intermolecular Interactions",
                command = self.contact_plot)
        statsmenu.add_separator()
        statsmenu.add_command(
                label="3D Plot Intermolecular Interactions",
                command = self.contact_3dplot)

        ########################################################################
        # Help Menu                                                            #
        ########################################################################
        helpmenu = Menu(menu)
        menu.add_cascade(label="Help", menu=helpmenu)
        helpmenu.add_command(label="User Guide",
                command = self.userguide_flipbook)
        helpmenu.add_separator()
        helpmenu.add_command(label="Tutorials")
        helpmenu.add_command(label=tab_spaces+"Tutorial 1",
        command=self.tutorial_1)
        helpmenu.add_command(label=tab_spaces+"Tutorial 2",
        command=self.tutorial_2)
        helpmenu.add_command(label=tab_spaces+"Tutorial 3",
        command=self.tutorial_3)
        helpmenu.add_command(label=tab_spaces+"Tutorial 4",
        command=self.tutorial_4)
        helpmenu.add_separator()
        helpmenu.add_command(label="FAQ",
                command = self.faq_flipbook)
        helpmenu.add_separator()
        helpmenu.add_command(label="Regression Methods",
                command = self.regression_flipbook)
        helpmenu.add_separator()
        helpmenu.add_command(label="GitHub",
                command = self.go_site)

        root.mainloop()

    # Define check_ligand_databases() method
    def check_ligand_databases(self):
        """Method to check the presence of ligand databases: IC50, Kd, and Ki"""

        # Import package
        from tkinter import messagebox
        #import requests

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = self.read_strdir()

        # Assign zero to the counts
        n_ic50 = 0
        n_kd = 0
        n_ki = 0

        # Check whether IC50 directory exists
        ic50_dir = self.program_root+"misc/data/pdbqt/IC50/"
        dir_ic50_boolean = os.path.isdir(ic50_dir)
        if dir_ic50_boolean:

            # List files in self.program_root+"misc/data/pdbqt/IC50/"
            ic50_list = os.listdir(ic50_dir)

            # Get number of ligands with IC50
            n_ic50 = len(ic50_list)

        else:
            # Invoke show_botton_msg() method
            msg_out = "IC50 database is missing!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        # Check whether Kd directory exists
        kd_dir = self.program_root+"misc/data/pdbqt/Kd/"
        dir_kd_boolean = os.path.isdir(kd_dir)
        if dir_kd_boolean:

            # List files in self.program_root+"misc/data/pdbqt/Kd/"
            kd_list = os.listdir(kd_dir)

            # Get number of ligands with Kd
            n_kd = len(kd_list)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Kd database is missing!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        # Check whether Ki directory exists
        ki_dir = self.program_root+"misc/data/pdbqt/Ki/"
        dir_ki_boolean = os.path.isdir(ki_dir)
        if dir_ki_boolean:

            # List files in self.program_root+"misc/data/pdbqt/Ki/"
            ki_list = os.listdir(ki_dir)

            # Get number of ligands with Ki
            n_ki = len(ki_list)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Ki database is missing!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        # Invoke show_botton_msg() method
        msg_out = "Number of ligands with IC50: "+str(n_ic50)
        msg_out += ", Kd : "+str(n_kd)
        msg_out += ", and Ki: "+str(n_ki)
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

    # Define download_ligand_databases() method
    def download_ligand_databases(self):
        """Method to download latest ligand databases"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = "Downloading ligand databases..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Set up list of ligand databases
        ligand_database_list = ["IC50.zip","Kd.zip","Ki.zip"]

        # Show yes/no question
        w_msg1 = "PDBbind"
        w_msg2 = self.program_id
        w_msg2 += " will download experimental binding affinity data."
        w_msg2 += "\nIt may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Try to open strgit.in
            file2open = self.program_root+"misc/inputs/strgit.in"
            try:
                f_git = open(file2open,"r")
                csv_git = csv.reader(f_git)

                # Looping through csv_git
                for line in csv_git:
                    if line[0] == "giturl":
                        url_in = line[1]
                        break

                # Close file
                f_git.close()

                # Looping through ligand_database_list
                for ligand_database in ligand_database_list:

                    # Instantiate an object of Database() class
                    d1 = download_ligs.Database(self.program_root,url_in,
                        ligand_database,self.strdir_entry,root)

                    # Invoke bundle() method
                    d1.bundle()

            # Handle IOError exception
            except IOError:
                msg_out = "IOError! I can't find strgit.in file!"
                msg1.show_botton_msg(msg_out,"red","light grey")
                print(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No dowloading perfomed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define go_flipbook() method
    def go_flipbook(self,flipbook_page):
        """Method to open a flipbook"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Set up url
        #url = 'https://github.com/azevedolab/sandres'
        # Try to open strsite.in
        file2open = self.program_root+"misc/inputs/flipbook.in"
        try:
            f_site = open(file2open,"r")
            csv_site = csv.reader(f_site)

            # Looping through csv_site
            for line in csv_site:
                if line[0] == "siteurl":
                    siteurl = line[1]+str(flipbook_page)
                    break

            # Close file
            f_site.close()

        # Handle IOError exception
        except IOError:
            msg_out = "IOError! I can't find strsite.in file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

        # For MacOS
        #chrome_path = 'open -a /Applications/Google\ Chrome.app %s'

        # For Windows
        #chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'

        # For Linux
        #chrome_path = '/usr/bin/./google-chrome-stable %s'
        #chrome_path = '/opt/google/chrome/google-chrome '

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define go_site() method
    def go_site(self):
        """Method to open a web page about SAnDReS"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Set up url
        #url = 'https://github.com/azevedolab/sandres'
        # Try to open strsite.in
        file2open = self.program_root+"misc/inputs/strsite.in"
        try:
            f_site = open(file2open,"r")
            csv_site = csv.reader(f_site)

            # Looping through csv_site
            for line in csv_site:
                if line[0] == "siteurl":
                    siteurl = line[1]
                    break

            # Close file
            f_site.close()

        # Handle IOError exception
        except IOError:
            msg_out = "IOError! I can't find strsite.in file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

        # For MacOS
        #chrome_path = 'open -a /Applications/Google\ Chrome.app %s'

        # For Windows
        #chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'

        # For Linux
        #chrome_path = '/usr/bin/./google-chrome-stable %s'
        #chrome_path = '/opt/google/chrome/google-chrome '

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define go_rcsb() method
    def go_rcsb(self):
        """Method to open RCSB PDB home page """

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of RCSBPDB() class
        r1 = tk_rcsb.RCSBPDB(self.program_root,project_dir_string,root)

        # Invoke pre_rcsb_GUI() method
        r1.pre_rcsb_GUI()

    # Define show_done_message1() method
    def show_done_message1(self,chosen_method,additional_msg):
        """A method to show done message"""

        # Instantiate an object of Messages() class
        msg = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = self.program_id
        msg_out += " finished the \""+chosen_method+"\" request using "
        msg_out += additional_msg+"!"
        msg.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

    # Define show_done_message2() method
    def show_done_message2(self,chosen_method):
        """A method to show done message"""

        # Instantiate an object of Messages() class
        msg = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg() method
        msg_out = self.program_id
        msg_out += " finished the \""+chosen_method+"\" request!"
        msg.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

    # Define exit_function() method
    def exit_function(self):
        """A method to exit"""

        # Import package
        from tkinter import messagebox

        # Set up local time
        my_local_time = str(time.strftime("%Y.%m.%d_%Hh%Mmin%Ss"))

        # Show message
        print("Finishing execution on ",my_local_time)

        # Show yes/no question
        result = messagebox.askyesno("Continue?","Do you wish to finish?")

        # Test answer
        if result:
            sys.exit()
        else:
            # Show message
            print("I'm back...")

    # Define read_strdir() method
    def read_strdir(self):
        """Method to read project directory"""

        # Import package
        from tkinter import messagebox

        # Try to open misc/inputs/stdir.in file
        try:
            f_strdir = open(self.program_root+"misc/inputs/strdir.in","r")
            info_in_strdir = csv.reader(f_strdir)
        except IOError:
            print("\nI can't find file strdir.in")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find file strdir.in"+\
                              "\nPlease check project directory!")
            return

        # Looping through the input file to get the project directory
        for line in info_in_strdir:
            if line[0][0:6].upper() == "STRDIR":
                project_dir_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                sandres_line = "Unrecognizable command strdir.in"
                print(sandres_line)
                sys.exit()

        # Returns strdir
        return project_dir_string

    # Define read_docking_results_csv() method
    def read_docking_results_csv(self):
        """Method to read docking results CSV file"""

        # Import package
        from tkinter import messagebox

        # Try to open misc/inputs/strdock.in
        file2open = self.program_root+"misc/inputs/strdock.in"
        try:
            f_strdock = open(file2open,"r")
            info_in_strdock = csv.reader(f_strdock)
        except IOError:
            print("\nI can't find "+file2open+" file!")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find "+file2open+\
                              "\nPlease check directory!")
            return

        # Looping through info_in_strdock
        for line in info_in_strdock:
            if line[0] == "strdock":
                strdock_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                msg1 = "Unrecognizable command in strdock.in"
                print(msg1)
                sys.exit()

        # Returns strdock_string
        return strdock_string

    # Define read_score_results_csv() method
    def read_score_results_csv(self):
        """Method to read scoring function results CSV file"""

        # Import package
        from tkinter import messagebox

        # Try to open misc/inputs/strscore.in file
        file2open = self.program_root+"misc/inputs/strscore.in"
        try:
            f_strscore = open(file2open,"r")
            info_in_strscore = csv.reader(f_strscore)
        except IOError:
            print("\nI can't find "+file2open+" file!")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find "+file2open+\
                              "\nPlease check directory!")
            return

        # Looping through info_in_strscore
        for line in info_in_strscore:
            if line[0] == "strscore":
                strscore_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                msg1 = "Unrecognizable command in strscore.in"
                print(msg1)
                sys.exit()

        # Returns strscore_string
        return strscore_string

    # Define read_vs_results_csv() method
    def read_vs_results_csv(self):
        """Method to read vs results CSV file"""

        # Import package
        from tkinter import messagebox

        # Try to open misc/inputs/strsvs.in file
        file2open = self.program_root+"misc/inputs/strvs.in"
        try:
            f_vs = open(file2open,"r")
            info_in_strvs = csv.reader(f_vs)
        except IOError:
            print("\nI can't find "+file2open+" file!")
            print("\nPlease check directory and/or file name.")
            messagebox.showerror("IOError!",\
                             "I can't find "+file2open+\
                              "\nPlease check directory!")
            return

        # Looping through info_in_strvs
        for line in info_in_strvs:
            if line[0] == "strvs":
                strvs_string = line[1].replace(" ","")
            elif line[0][0:1] == "#":
                continue    # Do nothing
            else:
                msg1 = "Unrecognizable command in strvs.in"
                print(msg1)
                sys.exit()

        # Close file
        f_vs.close()

        # Returns strvs_string
        return strvs_string

    # Define About() method
    def About(self):
        """Method to show information about this program"""

        # String for local time
        my_local_date = str(time.strftime("%Y %m %d"))
        my_local_time = str(time.strftime("%Hh%Mmin%Ss"))

        print("\nLoading files...")
        print("\nToday's date: ",my_local_date)
        print("Local time: ",my_local_time)

        return

    # Define bindingDB() method
    def bindingDB(self):
        """Method to handle binding affinity data downloaded from the
        BindingDB"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Show yes/no question
        w_msg1 = "BindingDB"
        w_msg2 = "Downloaded SDF will filtered and binding affinity data "
        w_msg2 += "extracted!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Ready to prepare downloaded data from BindingDB!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Test answer
        if result:

            # Instantiate an object of the AffinityData() class
            lig1 = tk_bindDB.AffinityData(self.program_root,project_dir_string,
            root)

            # Invoke prep_GUI() method
            lig1.prep_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No data filtering performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define add_bindingDB() method
    def add_bindingDB(self):
        """Method to add binding affinity data downloaded from the
        BindingDB to virtual screening results"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Show yes/no question
        w_msg1 = "BindingDB"
        w_msg2 = "Downloaded binding affinity data will be added to virtual "
        w_msg2 += "screening results!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Ready to add data from BindingDB to VS results!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Test answer
        if result:

            # Set up self.input_vs_csv_file_entry
            self.input_vs_csv_file_entry = self.read_vs_results_csv()

            # Instantiate an object of the AddAffinityData() class
            lig1 = tk_add_bindDB.AddAffinityData(self.program_root,
            project_dir_string,self.input_vs_csv_file_entry,root)

            # Invoke prep_GUI() method
            lig1.prep_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No data filtering performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define edit_adt_parameters() method
    def edit_adt_parameters(self):
        """Method to edit adt_par.csv file"""

        # Try to open ml_par.csv file
        try:
            file2open = self.program_root+"misc/data/adt_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find adt_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/adt_par.csv")

    # Define edit_bar_plot_parameters() method
    def edit_bar_plot_parameters(self):
        """Method to edit bar_plot_par.csv file"""

        # Try to open ml_par.csv file
        try:
            file2open = self.program_root+"misc/data/bar_plot_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find bar_plot_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/bar_plot_par.csv")

    # Define edit_bar_3dplot_parameters() method
    def edit_bar_3dplot_parameters(self):
        """Method to edit bar_3dplot_par.csv file"""

        # Try to open ml_par.csv file
        try:
            file2open = self.program_root+"misc/data/bar_3dplot_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find bar_3dplot_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/bar_3dplot_par.csv")

    # Define edit_bind_IC50_parameters() method
    def edit_bind_IC50_parameters(self):
        """Method to edit bind_IC50.csv file"""

        # Try to open bind_IC50.csv file
        try:
            file2open = self.program_root+"misc/data/bind_IC50.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find bind_IC50.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/bind_IC50.csv")

    # Define edit_bind_Kd_parameters() method
    def edit_bind_Kd_parameters(self):
        """Method to edit bind_Kd.csv file"""

        # Try to open bind_Kd.csv file
        try:
            file2open = self.program_root+"misc/data/bind_Kd.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find bind_Kd.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/bind_Kd.csv")

    # Define edit_bind_Ki_parameters() method
    def edit_bind_Ki_parameters(self):
        """Method to edit bind_Ki.csv file"""

        # Try to open bind_Ki.csv file
        try:
            file2open = self.program_root+"misc/data/bind_Ki.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find bind_Ki.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/bind_Ki.csv")

    # Define edit_bivariate_parameters() method
    def edit_bivariate_parameters(self):
        """Method to edit bivariate_par.csv file"""

        # Try to open bivariate_par.csv file
        try:
            file2open = self.program_root+"misc/data/bivariate_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find bivariate_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/bivariate_par.csv")

    # Define edit_config_txt_4vs() method
    def edit_config_txt_4vs(self):
        """Method to edit config.txt file for virtual screening"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Try to open summary file
        try:
            fo1 = open(project_dir_string+"VS/config.txt","r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "New config.txt file created!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            fo_config = open(project_dir_string+"VS/config.txt","w")
            print(msg_out)

            # Close file
            fo_config.close()

        # Call edit_file() method
        self.edit_file(project_dir_string+"VS/","config.txt")

    # Define edit_add_lig_parameters() method
    def edit_add_lig_parameters(self):
        """Method to edit add_lig_par.csv file"""

        # Try to open add_lig_par.csv file
        try:
            file2open = self.program_root+"misc/data/add_lig_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find add_lig_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/add_lig_par.csv")

    # Define edit_ml_parameters() method
    def edit_ml_parameters(self):
        """Method to edit ml_par.csv file"""

        # Try to open ml_par.csv file
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find ml_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/ml_par.csv")

    # Define edit_molegro_parameters() method
    def edit_molegro_parameters(self):
        """Method to edit molegro_par.csv file"""

        # Try to open molegro_par.csv file
        try:
            file2open = self.program_root+"misc/data/molegro_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find molegro_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/molegro_par.csv")

    # Define edit_github_url() method
    def edit_github_url(self):
        """Method to edit strgit.in file"""

        # Try to open strpdb.in file
        try:
            file2open = self.program_root+"misc/inputs/strgit.in"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find strgit.in file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/inputs/strgit.in")

    # Define edit_gui_preferences() method
    def edit_gui_preferences(self):
        """Method to edit gui_par.csv file"""

        # Try to open gui_par.csv file
        try:
            file2open = self.program_root+"misc/data/gui_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find gui_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/gui_par.csv")

    # Define edit_project_directory() method
    def edit_project_directory(self):
        """Method to edit strdir.in file"""

        # Try to open strdir.in file
        try:
            file2open = self.program_root+"misc/inputs/strdir.in"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find strdir.in file!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/inputs/strdir.in")

    # Define edit_pdb_url() method
    def edit_pdb_url(self):
        """Method to edit strpdb.in file"""

        # Try to open strpdb.in file
        try:
            file2open = self.program_root+"misc/inputs/strpdb.in"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find strpdb.in file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/inputs/strpdb.in")

    # Define edit_rcsb_url() method
    def edit_rcsb_url(self):
        """Method to edit strrcsb.in file"""

        # Try to open strrcsb.in file
        try:
            file2open = self.program_root+"misc/inputs/strrcsb.in"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find strrcsb.in file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/inputs/strrcsb.in")

    # Define edit_scatter_xy() method
    def edit_scatter_xy(self):
        """Method to edit scatter_plot_par.csv file"""

        # Try to open scatter_plot_par.csv file
        try:
            file2open = self.program_root+"misc/data/scatter_plot_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find scatter_plot_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/scatter_plot_par.csv")

    # Define edit_summary_file() method
    def edit_summary_file(self):
        """Method to edit summary file"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Try to open summary file
        try:
            fo1 = open(project_dir_string+"summary.txt","r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "New summary.txt file created!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            fo_summary = open(project_dir_string+"summary.txt","w")
            print(msg_out)

            # Close file
            fo_summary.close()

        # Call edit_file() method
        self.edit_file(project_dir_string,"summary.txt")

    # Define edit_site_url() method
    def edit_site_url(self):
        """Method to edit strsite.in file"""

        # Try to open strpdb.in file
        try:
            file2open = self.program_root+"misc/inputs/strsite.in"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find strsite.in file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/inputs/strsite.in")

    # Define edit_vina_parameters() method
    def edit_vina_parameters(self):
        """Method to edit vina_par.csv file"""

        # Try to open vina_par.csv file
        try:
            file2open = self.program_root+"misc/data/vina_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find vina_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/vina_par.csv")

    # Define edit_vs_parameters() method
    def edit_vs_parameters(self):
        """Method to edit vs_par.csv file"""

        # Try to open vs_par.csv file
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find vs_par.csv file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call edit_file() method
        self.edit_file(self.program_root,"misc/data/vs_par.csv")

    # Define make_project_directory() method
    def make_project_directory(self):
        """Method to create a new project directory"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = self.read_strdir()

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "You are about to create the directory: "+project_dir_string
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Check whether the directory exits or not
            if os.path.isdir(project_dir_string):

                # Invoke show_botton_msg() method
                msg_out = "Error! You are trying to create a pre-existing "
                msg_out += "dir! Add a new dir in "
                msg_out += "the Project Directory"
                msg1.show_botton_msg(msg_out,"red","light grey")
                print(msg_out)

            else:

                # Try to make dir
                try:
                    os.mkdir(project_dir_string)

                # Handle exception
                except OSError:

                    # Invoke show_botton_msg() method
                    msg_out = "Error! Creation of "
                    msg_out += "the directory %s failed!"%project_dir_string
                    msg1.show_botton_msg(msg_out,"red","light grey")
                    print(msg_out)

                else:
                    # Invoke show_botton_msg() method
                    msg_out = "Successfully created "
                    msg_out += "the directory %s " % project_dir_string
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No new directory created!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define make_project_directory_backup() method
    def make_project_directory_backup(self):
        """Method to zip current project directory"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = self.read_strdir()

        # Invoke show_botton_msg() method
        msg_out = "Backing up of "+project_dir_string+"..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "You are about to backup the directory: "+project_dir_string
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Check whether the file exits or not
            file2check = project_dir_string[:len(project_dir_string)-1]
            file_exists = os.path.exists(file2check+".zip")
            if file_exists:

                # Invoke show_botton_msg() method
                msg_out = "Error! You're trying to backup a pre-existing "
                msg_out += "one! Please change current "
                msg_out += "Project Directory"
                msg1.show_botton_msg(msg_out,"red","light grey")
                print(msg_out)

            else:

                # Try to zip
                try:
                    # Zip project directory
                    output_file = project_dir_string
                    shutil.make_archive(output_file,'zip',project_dir_string)

                    # Invoke show_botton_msg() method
                    msg_out = "Successfully created a backup of "
                    msg_out += "the directory %s " % project_dir_string
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)

                # Handle exception
                except:

                    # Invoke show_botton_msg() method
                    msg_out = "Error! Backup of "
                    msg_out += "the directory %s failed!"%project_dir_string
                    msg1.show_botton_msg(msg_out,"red","light grey")
                    print(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No backup request!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define show_saved_project_directories() method
    def show_saved_project_directories(self):
        """Method to show zipped project directories"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Get project directory
        project_dir_string = self.read_strdir()

        # Create a new file
        file2create = self.program_root+"datasets/list_of_saved_projects.csv"
        fo_proj = open(file2create,"w")

        # List files in project_dir_string+"datasets/
        proj_list = os.listdir(self.program_root+"datasets/")

        # Set up empty list
        zip_list = []

        # Looping through proj_list
        for proj in proj_list:
            if ".zip" in proj:
                print(proj)
                zip_list.append(proj)

        # Check whether there are zipped file
        if len(zip_list) > 0:

            # Write first project dir
            fo_proj.write(zip_list[0])

            # Looping through zip_list
            for proj in zip_list[1:]:

                # Write project dir
                fo_proj.write(",\n"+proj)

        # Close file
        fo_proj.close()

        # Try to open list_of_saved_projects.csv file
        try:
            file2open = file2create
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError exception
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(self.strdir_entry,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

        # Call dit_file() method
        self.edit_file(self.program_root,"datasets/list_of_saved_projects.csv")

    # Define recover_saved_project_directory() method
    def recover_saved_project_directory(self):
        """Method to recover a saved project directory"""

        # Instantiate an object of the UnzipDir() class
        proj1 = tk_project.UnzipDir(self.program_root,self.strdir_entry,root)

        # Trt to unzip a saved project directory
        try:

            # Invoke pre_unzip_GUI() method
            proj1.pre_unzip_GUI()

        # Handle exception
        except:

            # Invoke show_botton_msg() method
            msg_out = "Error! Recovery of "
            msg_out += "saved project directory failed!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define delete_saved_project_directory() method
    def delete_saved_project_directory(self):
        """Method to delete a saved project directory"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of the Dir() class
        proj1 = tk_delete_project.Dir(self.program_root,project_dir_string,root)

        # Invoke pre_delete_GUI() method
        proj1.pre_delete_GUI()

    # Define edit_file() method
    def edit_file(self,dir_in,my_file_2_open):
        """Method to edit any text file"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Invoke show_botton_msg()
        msg_out = self.program_id+" opened "+my_file_2_open+" file"
        msg1.show_botton_msg(msg_out ,"black","light grey")
        print(msg_out)

        # Try to open file
        try:
            my_info_input_file = open(dir_in+my_file_2_open,"r")
        except IOError:
            print("I can't find ",dir_in+my_file_2_open)
            messagebox.showerror("IOError!", "I can't find input file "+
            dir_in+my_file_2_open+"\nPlease check input file name!")
            return

        # Define save_01() function
        def save_01():
            """Function to save edit input file content"""

            # Set up local time
            my_local_time = str(time.strftime("%Y.%m.%d_%Hh%Mmin%Ss"))

            # Get input file name
            string_input_file = str(top_inputfile_entry.get())

            # Open input file
            my_info_input_file = open(dir_in+string_input_file,"w")

            # Get input file content from txt window
            string_input_file_content = top_txt.get(0.0,END)

            # Write txt window content to input file
            my_info_input_file.write(string_input_file_content.strip())

            # Close updated input file
            my_info_input_file.close()

            # Call show_botton_msg()
            msg_out = "Done! File updated on "+my_local_time
            msg1.show_botton_msg(msg_out ,"black","light grey")
            print(msg_out)

        # Define read_01() function
        def read_01():
            """Function to read input file from edit window"""

            # Edit text
            top_txt.delete(0.0,END)

            # Get input file name from edit window
            string_input_file = str(top_inputfile_entry.get())

            # Try to open input file
            try:
                my_info_input_file = open(dir_in+string_input_file,
                "r")
            except IOError:
                print("I can't find ",dir_in+string_input_file)
                messagebox.showerror("IOError!",
                            " I can't find input file"+
                            dir_in+string_input_file+\
                            "\nPlease check input file name!")
                return

            # message_tail adds new lines to text to be show
            message_tail = "\n\n\n\n\n\n\n\n\n\n\n"

            # Read file content
            top_txt.insert(END,my_info_input_file.read()+message_tail)

            # Close input file
            my_info_input_file.close()

        # Define clear_01() function
        def clear_01():
            """Function to clear txt content in editing window"""

            top_txt.delete(0.0,END)

        # Check screen resolution
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        # Set up top_txt_geom based on screen_width
        if screen_width >= 1900:
            pass
        elif screen_width >= 1200:
            self.top_txt_geom = "880x280+0+138"
        else:
            self.top_txt_geom = "880x400+0+138"

        # Create child window
        top_txt = Toplevel()
        top_txt.title('Fast Editor')
        top_txt.geometry(self.top_txt_geom)

        # Widgets for file name
        Label(top_txt, text="File:" ).grid(row = 2,column = 0, stick = W)
        top_inputfile_entry = Entry(top_txt,width = 95) # width was 95
        top_inputfile_entry.grid(row = 2, column = 0,stick = E)
        top_inputfile_entry.insert(10,my_file_2_open)

        # Widgets for buttons
        Button(top_txt,text='Read',command=read_01).grid(row=2,column=1,
        sticky=W)
        Button(top_txt,text='Clear',command=clear_01).grid(row=2,column=1,
        sticky=E)

        Button(top_txt,text='Save',command=save_01).grid(row=3,column=1,
        sticky=W)
        Button(top_txt,text='Close',bg="red",
        command=top_txt.destroy).grid(row=3,column=1,sticky = E)

        # Widgets for txt (it was 125) (width = 120, height = 15 )
        top_scrollbar = Scrollbar(top_txt)
        top_scrollbar.grid(row=8, column = 2,sticky=W)
        top_txt = Text(top_txt,width=self.fast_editor_txt_width,
        height=self.fast_editor_txt_height,
        yscrollcommand=top_scrollbar.set)
        top_txt.grid(row=8,column=0,columnspan=2,sticky=W)
        top_scrollbar.config(command=top_txt.yview)

        # message_tail adds new lines to text to be show
        message_tail = "\n\n\n\n\n\n\n"

        # Read file content
        top_txt.insert(END,my_info_input_file.read()+message_tail)

        # Close input file
        my_info_input_file.close()

    # Define edit_pdb_codes() method
    def edit_pdb_codes(self):
        """Method to edit pdb_codes.csv"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Assign zero to number_of_pdbs
        number_of_pdbs = 0

        # To create an empty file for the first run
        # Try to open csv file
        try:
            fo1 = open(project_dir_string+"pdb_codes.csv","r")

            # Close file
            fo1.close()
        except IOError:
            print("\nIOError! I can't find file pdb_codes.csv!")
            fo2 = open(project_dir_string+"pdb_codes.csv","w")
            print("\nA new pdb_codes.csv was created!")

            # Close files
            fo2.close()

        # Instantiate an object of the Palavra class
        p1 = string_t.Palavra(project_dir_string,"pdb_codes.csv")

        # Call count_codes() method
        number_of_pdbs = p1.count_codes()

        # Call edit_file() method
        self.edit_file(project_dir_string,"pdb_codes.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Call show_botton_msg()
        msg_out = "Number of PDB files in the dataset (pdb_codes.csv): "
        msg1.show_botton_msg(msg_out+str(number_of_pdbs),"black","light grey")
        print(msg_out)

    # Define unify_pdb_codes() method
    def unify_pdb_codes(self):
        """Method to unify PDB access codes"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Set up an empty list
        pdb_list = []

        # Instantiate an object of the Palavra class
        p1 = string_t.Palavra(project_dir_string,"pdb_codes.csv")

        # Call backup_file() method
        p1.backup_file("pdb_codes.csv")

        # Call unify_pdb() method
        count_repeated_pdb,list_repeated_pdb = p1.unify_pdb("pdb_codes.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Try to open a file
        file2open = project_dir_string+"pdb_codes.csv"
        try:
            fo_pdb = open(file2open,"r")
            csv_pdb = csv.reader(fo_pdb)

            # Looping through csv_pdb
            for line in csv_pdb:
                for pdb in line:
                    pdb_str = str(pdb).replace(" ","")
                    print(pdb_str)
                    pdb_list.append(pdb_str)

            # Close file
            fo_pdb.close()

        # Handle IOError
        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out ,"red","light grey")
            print(msg_out)
            return

        # Create a new pdb_codes.csv file
        file2create = project_dir_string+"pdb_codes.csv"
        fo_pdb = open(file2create,"w")

        # Write first PDB
        fo_pdb.write(str(pdb_list[0]))

        # Looping through pdb_list
        for pdb in pdb_list[1:]:
            pdb_str = ","+str(pdb)
            fo_pdb.write(pdb_str)

        # Close file
        fo_pdb.close()

        # Invoke show_short_msg() method
        msg_out = "\nList of PDBs deleted from pdb_codes.csv: "+\
        str(list_repeated_pdb)
        msg1.show_short_msg(msg_out)

        # Show message about the number of repeated structures
        msg_out ="Done! Number of repeated PDB files: "\
        +str(count_repeated_pdb)+"."
        msg1.show_botton_msg(msg_out ,"black","light grey")
        print(msg_out)

    # Define check_pdb_codes()
    def check_pdb_codes(self):
        """"Method to check whether all structures in a dataset are present
        in the Ligand Database"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,root)

        # Set up bind_list
        bind_list = ["IC50","Kd","Ki"]

        # Looping through bind_list
        for bind_in in bind_list:

            # Instantiate an object of BindingInformation() class
            db1 = checking.BindingInformation(self.program_root,
                    project_dir_string,bind_in)

            # Invoke bundle method
            no_binding_data_list = db1.bundle()

            # Check no_binding_data_list
            if len(no_binding_data_list) > 0:

                # Show message
                msg_out1="There are missing data for this dataset!"
                msg_out2="There are missing "+bind_in+" data for this dataset!"
                msg1.show_botton_msg(msg_out1,"red","light grey")
                print(msg_out2)

            else:

                # Show message
                msg_out1 = "No missing data for this dataset!"
                msg_out2 = "No missing "+bind_in+" data for this dataset!"
                msg1.show_botton_msg(msg_out1,"black","light grey")
                print(msg_out2)

    # Define add_data_manually() method
    def add_data_manually(self):
        """Method to manually add data to Ligand Databases"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Show yes/no question
        w_msg1 = self.program_id

        w_msg2 = "You may manually add data to the Ligand Databases. "
        w_msg2 += " This new data should be in a CSV file. It is also "
        w_msg2 += "necessary to generate PDBQT files for all new ligands. "
        w_msg2 += "Parameters for this task are in the add_lig_par.csv file."
        w_msg2 += "\nDo you want to add data to Ligand Databases?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of LigandInfo()
            db1 = update.LigandInfo(self.program_root,project_dir_string,root)

            # Invoke bundle method
            db1.bundle()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No data added!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

    # Define add_str_pdb() method
    def add_str_pdb(self):
        """Method to download PDB files"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of the PDBData() class
        pdb1 = tk_downloads.PDBData(self.program_root,project_dir_string,root)

        # Invoke pdb_GUI() method
        pdb1.pdb_GUI()

    # Define ligand_data method
    def ligand_data(self):
        """Method to read ligand data from an internal database"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of the LigData() class
        lig0 = tk_lig.LigData(self.program_root,project_dir_string,root)

        # Invoke ligand_GUI() method
        lig0.ligand_GUI()

    # Define add_str_pdbqt method
    def add_str_pdbqt(self):
        """Method to add PDBQT files to the dataset.
        PDBQT format is very similar to PDB format but it includes
        partial charges ('Q') and AutoDock 4 (AD4) atom types ('T')."""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_short_msg() method
        msg_out = "\nLigand structures generated using AutoDockTools4."
        msg_out += self.autodocktools4_ref
        msg1.show_short_msg(msg_out)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = self.program_id
        w_msg2 += " will convert proteins to PDBQT format based only on "
        w_msg2 += "the experimental crystallographic atomic coordinates."
        w_msg2 += "\nNo atoms will be added to the crystallographic structures!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Dataset() class
            dataset1 = tk_pdbqt.Dataset(self.program_root,project_dir_string,
            root)

            # Invoke add_pdbqt_GUI() method
            dataset1.add_pdbqt_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No format conversion perfomed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define check_n_pdbqt() method
    def check_n_pdbqt(self):
        """Method to check the number of directories/files in the pdbqt and pdb
        directories. If n_pdbqt> n_pdb, it may update the dataset"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Get project directory
        project_dir_string = self.read_strdir()

        # It is necessary to compare the number of structures in the pdb (n_pdb)
        # and pdbqt (n_pdbqt) directories. If n_pdbqt < n_pdb, we have to update
        # the dataset removing PDB files and deleting lines with missing
        # PDB access codes from the bind_####.csv and pdb_codes.csv files.
        # It is also necessary to delete the missing structures from the pdb
        # directory.
        #
        # Try to get the number of structures (directories) in the
        # pdbqt directory
        dir2check = project_dir_string+"pdbqt/"
        try:
            pdbqt_list = os.listdir(dir2check)
            n_pdbqt = len(pdbqt_list)

        # Handle OSError exception
        except OSError:

            # Set up msg_out
            msg_out = "OSError! I can't file directory "+dir2check
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

        # Try to get the structures (PDB files) in the pdb directory
        dir2check = project_dir_string+"pdb/"
        try:
            pdb_files = os.listdir(dir2check)

        # Handle OSError exception
        except OSError:

            # Set up msg_out
            msg_out = "OSError! I can't file directory "+dir2check
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)
            return

        # Set up empty list
        pdb_list = []

        # Get PDB access codes only
        for line in pdb_files:

            # Some editing
            aux_pdb = line.replace(".pdb","")
            pdb = aux_pdb.upper()
            pdb = pdb.replace(" ","")
            pdb_list.append(pdb)

        # Get the number of structures in the pdb directory
        n_pdb = len(pdb_list)

        # Compare n_pdbqt and n_pdb
        if n_pdbqt < n_pdb:

            # Set up empty list
            missing_list = []

            # Looping through pdb_list
            for pdb in pdb_list:

                # Get missing PDB access codes
                if pdb not in pdbqt_list:
                    missing_list.append(pdb)

            # Get the number of missing PDBQT structures
            n_missing = len(missing_list)

            # Show yes/no question
            w_msg1 = self.program_id
            w_msg2 = "There are "+str(n_missing)+" missing PDBQT directories!"
            w_msg2 += "\nYou may remove these structures from the dataset."
            w_msg2 += "\nDo you wish to update the dataset?"
            result = messagebox.askyesno(w_msg1,w_msg2)

            # Test answer
            if result:

                # Invoke read_it function
                bind_in = b_aff.read_it(project_dir_string)

                # Set up csv2clean
                csv2clean = "bind_"+bind_in+".csv"

                # Instantiate an object of Remove() class
                c1 = cleaning.Remove(project_dir_string,missing_list,
                csv2clean)

                # Invoke pdb_codes() method
                c1.pdb_codes()

                # Invoke pdb_dir() method
                c1.pdb_dir()

                # Invoke data_csv() method
                c1.data_csv()

                # Invoke summary() method
                c1.summary()

                # Set up msg_out
                msg_out = "Done! "+self.program_id+" updated dataset!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            else:

                # Invoke show_botton_msg() method
                msg_out = "Done! No Dataset Update Requests!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)
                return

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! There are no missing PDBQT directories!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

    # Define add_adt_str_pdbqt method
    def add_adt_str_pdbqt(self):
        """Method to add pdbqt files to the dataset using AutoDockTools"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDockTools4..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.autodocktools4_ref)

        # Show yes/no question
        w_msg1 = self.adt4_msg
        w_msg2 = "PDBQT structures will be converted using AutoDockTools4"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Dataset() class
            dataset2 = tk_pdbqt.Dataset(self.program_root,project_dir_string,
            root)

            # Invoke add_adt_pdbqt_GUI() method
            dataset2.add_adt_pdbqt_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define check_missing_pdbqt() method
    def check_missing_pdbqt(self):
        """Method to identify missing PDBQT files after making the dataset"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of the PDBQT() class
        pdbqt1 = check_data.PDBQT(self.program_root,project_dir_string)

        # Invoke check_pqbqt() method
        missing_pdbqt = pdbqt1.check_pqbqt()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_short_msg() method
        msg_out = "\nLigand structures generated using AutoDockTools4."
        msg_out += self.autodocktools4_ref
        msg1.show_short_msg(msg_out)

        # Check whether there is missing PDBQT file
        if missing_pdbqt:

            # Set up msg_out
            msg_out = "Done! "+self.program_id+" found "
            msg_out += "missing PDBQT file(s) in this dataset! "
            msg_out += "PDB written in missing_pdbqt.csv!"
        else:

            # Set up msg_out
            msg_out = "Done! No missing PDBQT files in the dataset!"

        # Call show_botton_msg()
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

    # Define check_unsuccessful_docking_simulations() method
    def check_unsuccessful_docking_simulations(self):
        """Method to check unsuccessful docking simulations"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke read_it function
        bind_in = b_aff.read_it(project_dir_string)

        # Try to open bind_####.csv file
        csv2clean = "bind_"+bind_in+".csv"
        file2open = project_dir_string+csv2clean
        try:
            fo_bind = open(file2open,"r")
            csv_bind = csv.reader(fo_bind)

            # Backup files
            # Invoke backup.make()
            backup.make(csv2clean,project_dir_string,
            project_dir_string+"backup/")

            # Set up empty list
            missing_list = []

            # Looping through csv_bind for first line
            for line in csv_bind:
                break

            # Looping through csv_bind for the remaning lines
            for line in csv_bind:

                # Try to convert to float, if unsuccessful means that we found
                # an error during docking simulations
                try:
                    rmsd = float(line[9])

                # Handle exception
                except:
                    missing_list.append(line[0])

            # Close file
            fo_bind.close()

            # Invoke show_short_msg() method
            msg_out = "Number of structures with unsuccessful docking "
            msg_out += "simulations: "+str(len(missing_list))
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Check if there are unsuccessful docking simulations
            if len(missing_list) > 0:

                # Show yes/no question
                w_msg1 = self.program_id
                w_msg2 = "There are unsuccessful docking simulations. "
                w_msg2 += "Keep them would not affect machine-learning "
                w_msg2 += "modeling."
                w_msg2 += "\nDo you wish to remove them from the dataset?"
                result = messagebox.askyesno(w_msg1,w_msg2)

                # Test answer
                if result:

                    # Instantiate an object of Remove() class
                    c1 = cleaning.Remove(project_dir_string,missing_list,
                    csv2clean)

                    # Invoke bundle() method
                    c1.bundle()

                    # Set up msg_out
                    msg_out = "Done! "+self.program_id+" updated dataset!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)

                else:
                    # Invoke show_botton_msg() method
                    msg_out = "Done! No Update Requests!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)
                    return

        # Handle IOError exception
        except IOError:

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

    # Define check_unsuccessful_scores4poses() method
    def check_unsuccessful_scores4poses(self):
        """Method to check unsuccessful scoring function calculations
        for poses"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Get scores4pose_string
        scores4pose_string = str(self.docking_results_entry)

        # Try to open a CSV file
        csv2clean = scores4pose_string
        file2open = project_dir_string+csv2clean
        try:
            fo_bind = open(file2open,"r")
            csv_bind = csv.reader(fo_bind)

            # Backup files
            # Invoke backup.make()
            backup.make(csv2clean,project_dir_string,
            project_dir_string+"backup/")

            # Set up empty list
            missing_list = []

            # Looping through csv_bind for first line
            for line in csv_bind:
                break

            # Looping through csv_bind for the remaning lines
            for line in csv_bind:

                # Try to convert to float, if unsuccessful means that we found
                # an error during docking simulations
                try:
                    affinity = float(line[24])

                # Handle exception
                except:
                    missing_list.append(line[0])

            # Close file
            fo_bind.close()

            # Invoke show_short_msg() method
            msg_out = "Number of structures with unsuccessful "
            msg_out += "scoring function calculation: "+str(len(missing_list))
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Check if there are unsuccessful docking simulations
            if len(missing_list) > 0:

                # Show yes/no question
                w_msg1 = self.program_id
                w_msg2 = "There are unsuccessful scoring function calculations."
                w_msg2 += "\nDo you wish to delete them from the "+csv2clean
                w_msg2 +=" file?"
                result = messagebox.askyesno(w_msg1,w_msg2)

                # Test answer
                if result:

                    ############################################################
                    # Set up empty string
                    lines_out = ""

                    # Reopen CSV file
                    fo_bind = open(file2open,"r")
                    csv_bind = csv.reader(fo_bind)

                    # Looping through csv_bind for the first line
                    for line in csv_bind:

                        # Some editing
                        aux_line = str(line)
                        aux_line = aux_line.replace(", ",",")
                        aux_line = aux_line.replace(" ,",",")
                        aux_line = aux_line.replace("[","")
                        aux_line = aux_line.replace("]","")
                        aux_line = aux_line.replace("'","")
                        lines_out += aux_line+"\n"

                        break

                    # Looping through csv_bind for the remaining lines
                    for line in csv_bind:

                        # Check whether ND is in Affinity
                        aux_24 = str(line[24]).replace(" ","")
                        if "ND" not in aux_24:
                            if "nan" not in aux_24:

                                # Some editing
                                aux_line = str(line)
                                aux_line = aux_line.replace(", ",",")
                                aux_line = aux_line.replace(" ,",",")
                                aux_line = aux_line.replace("[","")
                                aux_line = aux_line.replace("]","")
                                aux_line = aux_line.replace("'","")
                                lines_out += aux_line+"\n"

                    # Close file
                    fo_bind.close()

                    # Open a new file
                    fo_new = open(file2open,"w")

                    # Write lines_out
                    fo_new.write(lines_out)

                    # Close file
                    fo_new.close()
                    ############################################################

                    # Set up msg_out
                    msg_out = "Done! "+self.program_id+" updated "+csv2clean
                    msg_out += " file!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)

                else:
                    # Invoke show_botton_msg() method
                    msg_out = "Done! No Update Requests!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)
                    return

        # Handle IOError exception
        except IOError:

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

    # Define check_unsuccessful_vs_simulations() method
    def check_unsuccessful_vs_simulations(self):
        """Method to check unsuccessful virtual screening simulations"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Get vs_string
        vs_string = str(self.input_vs_csv_file_entry)

        # Try to open a CSV file
        csv2clean = vs_string
        file2open = project_dir_string+csv2clean
        try:
            fo_bind = open(file2open,"r")
            csv_bind = csv.reader(fo_bind)

            # Backup files
            # Invoke backup.make()
            backup.make(csv2clean,project_dir_string,
            project_dir_string+"backup/")

            # Set up empty list
            missing_list = []

            # Looping through csv_bind for first line
            for line in csv_bind:
                break

            # Looping through csv_bind for the remaning lines
            for line in csv_bind:

                # Try to convert to float, if unsuccessful means that we found
                # an error during docking simulations
                try:
                    affinity = float(line[24])

                # Handle exception
                except:
                    missing_list.append(line[0])

            # Close file
            fo_bind.close()

            # Invoke show_short_msg() method
            msg_out = "Number of structures with unsuccessful "
            msg_out += "virtual screening simulations: "+str(len(missing_list))
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Check if there are unsuccessful docking simulations
            if len(missing_list) > 0:

                # Show yes/no question
                w_msg1 = self.program_id
                w_msg2 = "There are unsuccessful virtual screening simulations."
                w_msg2 += " Keep them would not affect machine-learning "
                w_msg2 += "modeling."
                w_msg2 += "\nDo you wish to delete them from the "+csv2clean
                w_msg2 +=" file?"
                result = messagebox.askyesno(w_msg1,w_msg2)

                # Test answer
                if result:

                    ############################################################
                    # Set up empty string
                    lines_out = ""

                    # Reopen CSV file
                    fo_bind = open(file2open,"r")
                    csv_bind = csv.reader(fo_bind)

                    # Looping through csv_bind for the first line
                    for line in csv_bind:

                        # Some editing
                        aux_line = str(line)
                        aux_line = aux_line.replace(", ",",")
                        aux_line = aux_line.replace(" ,",",")
                        aux_line = aux_line.replace("[","")
                        aux_line = aux_line.replace("]","")
                        aux_line = aux_line.replace("'","")
                        lines_out += aux_line+"\n"

                        break

                    # Looping through csv_bind for the remaining lines
                    for line in csv_bind:


                        # Check whether ND is in Affinity
                        aux_24 = str(line[24]).replace(" ","")
                        if "ND" not in aux_24:
                            if "nan" not in aux_24:

                                # Some editing
                                aux_line = str(line)
                                aux_line = aux_line.replace(", ",",")
                                aux_line = aux_line.replace(" ,",",")
                                aux_line = aux_line.replace("[","")
                                aux_line = aux_line.replace("]","")
                                aux_line = aux_line.replace("'","")
                                lines_out += aux_line+"\n"

                    # Close file
                    fo_bind.close()

                    # Open a new file
                    fo_new = open(file2open,"w")

                    # Write lines_out
                    fo_new.write(lines_out)

                    # Close file
                    fo_new.close()
                    ############################################################

                    # Set up msg_out
                    msg_out = "Done! "+self.program_id+" updated "+csv2clean
                    msg_out += " file!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)

                else:
                    # Invoke show_botton_msg() method
                    msg_out = "Done! No Update Requests!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                    print(msg_out)
                    return

        # Handle IOError exception
        except IOError:

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

            # Return
            return

    # Define update_dataset() method
    def update_dataset(self):
        """Method to remove structures with missing PDBQT files from
        the dataset"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Try to open missing_pdbqt.csv
        file2open = project_dir_string+"missing_pdbqt.csv"
        try:
            fo_missing = open(file2open,"r")
            csv_missing = csv.reader(fo_missing)

            # Set up empty list
            missing_list = []

            # Looping through csv_missing for the first line
            for line in csv_missing:
                break

            # Looping through csv_missing for the remaining lines
            for line in csv_missing:
                missing_list.append(line[0])

            # Get the number of missing structures
            n_pdb = len(missing_list)

            # Show yes/no question
            w_msg1 = self.program_id
            w_msg2 = "There are "+str(n_pdb)+" missing PDBQT files in "
            w_msg2 += "the dataset!"
            w_msg2 += "\nDo you wish to delete them from this dataset?"
            result = messagebox.askyesno(w_msg1,w_msg2)

            # Close file
            fo_missing.close()

            # Test answer
            if result:

                # Invoke read_it function
                bind_in = b_aff.read_it(project_dir_string)

                # Set bind_####.csv file name
                csv2clean = "bind_"+bind_in+".csv"

                # Instantiate an object of Remove() class
                c1 = cleaning.Remove(project_dir_string,missing_list,csv2clean)

                # Invoke bundle() method
                c1.bundle()

                # Set up msg_out
                msg_out = "Done! "+self.program_id+" updated dataset!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)

            else:
                # Invoke show_botton_msg() method
                msg_out = "Done! No Update Requests!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)
                return

        # Handle IOError exception
        except IOError:

            # Set up msg_out
            msg_out = "IOError! I can't find "+file2open+" file!"

            # Call show_botton_msg()
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define add_ligand_descriptors() method
    def add_ligand_descriptors(self):
        """Method to add descriptors to bind_###.csv file"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of the DescriptorData() class
        d1 = tk_descriptors.DescriptorData(self.program_root,project_dir_string,
        root)

        # Invoke descriptor_GUI() method
        d1.descriptor_GUI()

    # Define contact_plot method
    def contact_plot(self):
        """Method to generate intermolecular contact plot"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Invoke create_plots_dir() method
        self.create_plots_dir()

        # Invoke create_backup_dir() method
        self.create_backup_dir()

        # Instantiate an object of the ContactMap() class
        map1 = tk_intermol.ContactMap(self.program_root,project_dir_string,root)

        # Invoke pre_intermol_GUI() method
        map1.pre_intermol_GUI()

    # Define contact_3dplot method
    def contact_3dplot(self):
        """Method to generate intermolecular contact plot"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Invoke create_plots_dir() method
        self.create_plots_dir()

        # Invoke create_backup_dir() method
        self.create_backup_dir()

        # Instantiate an object of the ContactMap3D() class
        map3d = tk_intermol3d.ContactMap3D(self.program_root,project_dir_string,
        root)

        # Invoke pre_intermol3d_GUI() method
        map3d.pre_intermol3d_GUI()

    # Define simulation_CM_EC_GC() method
    def simulation_CM_EC_GC(self):
        """Method to run docking simulations using AutoDock Vina taking
        centering: center of mass (CM), electric center (EC), and
        geometric center GC"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "AutoDock Vina ready to go..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.advina_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += " Docking may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Simulation() class
            prot_lig1 = tk_docking.Simulation(self.program_root,
            project_dir_string,root)

            # Invoke docking_GUI() method
            prot_lig1.docking_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests for Docking Simulations!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define simulation_CM() method
    def simulation_CM(self):
        """Method to carry out docking simulations with AutoDock Vina using
        a faster approach.
        In this method we rely on one single type of centering for config.txt"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "AutoDock Vina ready to go..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.advina_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += " Docking may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Simulation() class
            prot_lig2 = tk_docking.Simulation(self.program_root,
            project_dir_string,root)

            # Invoke cm_docking_GUI() method
            prot_lig2.cm_docking_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define stats_CM() method
    def stats_CM(self):
        """Method to carry out statistical analysis of docking simulations
        performed with AutoDock Vina (single run)"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running statistical analysis of docking results..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.da_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Carrying out statistical analysis..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Test answer
        if result:

            # Set up list_lig_out
            list_lig_out = ["lig_out_mass.pdbqt"]

            # Instantiate an object of Docking() class
            lig3 = vina.Docking(self.program_root,project_dir_string,
                                list_lig_out)

            # Looping through pdb_list and run AutoDock Vina
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke check_rmsd() method
                    lig3.check_single_rmsd(pdb)

                except:
                    pass

            # Invoke show_lowest_rmsd() method
            lig3.show_lowest_rmsd()

            # Invoke choose_rmsd() method
            lig3.choose_rmsd()

            # Invoke add_results() method (WFA 2021-08-08)
            lig3.add_results()

            # Try to open vina_rmsd_results.csv
            try:
                file2open = project_dir_string+"vina_rmsd_results.csv"
                fo_stats = open(file2open,"r")
                csv_stats = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Set up empty string
            msg_stats = ""

            # Set up empty lists
            list_rmsd = []
            pdb_list_no_rmsd = []
            pdb_list_rmsd = []

            # Looping through csv_stats (first line)
            for line in csv_stats:
                # Some editing
                header_line = str(line[0])+"\t"+str(line[1])+"\t"+str(line[2])
                msg_stats += header_line+"\n"
                break

            # Looping through csv_stats
            for line in csv_stats:
                # Some editing
                if "mass" in line[1]:
                    centering = "mass     "
                elif "electric" in line[1]:
                    centering = "electric "
                else:
                    centering = str(line[1])

                line_out = str(line[0])+"\t"+centering+"\t\t"+str(line[2])
                msg_stats += line_out+"\n"

                # To get RMSD values
                if "ND" not in line[2]:
                    list_rmsd.append(float(line[2]))

            # Convert list to array
            rmsd_array = np.array(list_rmsd)

            # Calculate docking accuracy (DA1 and DA2) (Xavier et al 2016)
            # doi: 10.2174/138620731966616092711134
            n_all = np.count_nonzero(rmsd_array > 0.0)
            n_a = np.count_nonzero(rmsd_array < 2.0)
            n_b = np.count_nonzero(rmsd_array < 3.0)
            n_c = np.count_nonzero(rmsd_array < 4.0)
            if n_all != 0:
                f_a = n_a/n_all
                f_b = n_b/n_all
                f_c = n_c/n_all
                da1 = f_a + 0.5*(f_b - f_a)
                da2 = da1 + 0.25*(f_c - f_b)
            else:
                print("\nError! Number of poses is zero!")
                print("Please check dataset!")
                return

            # Add docking accuracy data
            msg_stats +="\n\nDocking accuracies\n"
            formated_da1 = "{:.3f}".format(da1)
            formated_da2 = "{:.3f}".format(da2)
            msg_stats += "DA1 = "+str(formated_da1)+"\n"
            msg_stats += "DA2 = "+str(formated_da2)+"\n"

            # Add docking RMSD average, minimum and maximum
            msg_stats += "\n\nDocking RMSD\n"
            formated_mean = "{:.3f}".format(np.mean(rmsd_array))
            msg_stats += "Mean RMSD (A) = "+str(formated_mean)+"\n"
            msg_stats += "Maximum RMSD (A) = "+str(np.max(rmsd_array))+"\n"
            msg_stats += "Minimum RMSD (A) = "+str(np.min(rmsd_array))+"\n"

            # Get the type of binding affinity
            # Set up a list
            bind_list = ["IC50","Kd","Ki"]

            # Try to open bind_####.csv file
            for bind in bind_list:
                try:
                    fo_bind = open(project_dir_string+"bind_"+bind+".csv","r")
                    print("\nBinding affinity: ",bind)

                    # Close file
                    fo_bind.close()

                    break
                except IOError:
                    pass

            # Try to open bind_###.csv
            try:
                file2open = project_dir_string+"bind_"+bind+".csv"
                fo_bind = open(file2open,"r")
                csv_bind = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Looping through csv_bind (first line)
            for line in csv_bind:
                break

            # Looping through csv_bind
            for line in csv_bind:
                try:
                    # Test to get PDB for structures with no docking results
                    if "ND" not in line[9]:
                        pdb_list_rmsd.append(line[0])
                    else:
                        pdb_list_no_rmsd.append(line[0])
                except:
                    pass

            # Add list of PDB with no docking results
            msg_stats += "\n\nNo docking results for the following PDB(s): "
            msg_stats += str(pdb_list_no_rmsd)+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_stats)

            # Write statistical analysis
            file2create = project_dir_string+"docking_summary.log"
            fo_summary = open(file2create,"w")
            fo_summary.write(msg_stats)

            # Close files
            fo_stats.close()
            fo_bind.close()
            fo_summary.close()

            # Invoke show_done_message1()
            self.show_done_message1(self.program_id,self.advina_msg)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define external_dataset() method
    def external_dataset(self):
        """Method to carry out statistical analysis of docking results
        of an external dataset generated with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.da_ref)

        # Invoke show_botton_msg() method
        msg_out = "Ready to carry out statistical analysis of docking results"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "Please set up a directory with AutoDock Vina results"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of the Simulation() class
            ext_data1 = tk_docking.Simulation(self.program_root,
            project_dir_string,root)

            # Invoke stats_GUI() method
            ext_data1.stats_GUI()

            # Invoke show_done_message1()
            self.show_done_message1(self.program_id,self.advina_msg)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define xtal_with_vina() method
    def xtal_with_vina(self):
        """Method to calculate binding energy for crystallographic position of
        the ligand with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.advina_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up list_lig_out
            list_lig_out = ["lig_out_electric.pdbqt","lig_out_geometric.pdbqt",
            "lig_out_mass.pdbqt"]

            # Instantiate an object of the EnergyTerms() class
            prot_lig1 = tk_scoring.EnergyTerms(self.program_root,
                                        project_dir_string,root,list_lig_out)

            # Invoke xtal_GUI() method
            prot_lig1.xtal_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No calculation performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define pose_with_vina() method
    def pose_with_vina(self):
        """Method to calculate binding energy terms for pose position of
        a ligand with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.advina_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up list_lig_out
            list_lig_out = ["lig_out_electric.pdbqt","lig_out_geometric.pdbqt",
            "lig_out_mass.pdbqt"]

            # Get scoring function file name from strdock.in
            scores_docking_in = self.read_docking_results_csv()

            # Instantiate an object of EnergyPose() class
            lig0 = tk_scoring_poses.EnergyPose(self.program_root,
            project_dir_string,scores_docking_in,root,list_lig_out)

            # Invoke working_GUI() method
            lig0.working_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No calculation performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define pose_with_vina_CM() method
    def pose_with_vina_CM(self):
        """Method to calculate binding energy terms for pose position of
        a ligand with AutoDock Vina with CM centering"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.vina_short_msg)

        # Show yes/no question
        w_msg1 = self.advina_msg
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up list_lig_out
            list_lig_out = ["lig_out_mass.pdbqt"]

            # Get scoring function file name from strdock.in
            scores_docking_in = self.read_docking_results_csv()

            # Instantiate an object of EnergyPose() class
            lig0 = tk_scoring_poses.EnergyPose(self.program_root,
            project_dir_string,scores_docking_in,root,list_lig_out)

            # Invoke working_GUI() method
            lig0.working_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No calculation performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define stats_CM_EG_GC() method
    def stats_CM_EG_GC(self):
        """Method to carry out statistical analysis of docking simulations
        performed with AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get PDB access using os.listdir()
        pdb_list = os.listdir(project_dir_string+"pdbqt/")

        # Get the number of structures
        n_pdb = len(pdb_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running statistical analysis of docking results..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.da_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "There are "+str(n_pdb)+" structures in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Carrying out statistical analysis..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Test answer
        if result:

            # Set up list_lig_out
            list_lig_out = ["lig_out_electric.pdbqt","lig_out_geometric.pdbqt",
            "lig_out_mass.pdbqt"]

            # Instantiate an object of Docking() class
            lig1 = vina.Docking(self.program_root,project_dir_string,
                                list_lig_out)

            # Looping through pdb_list and run AutoDock Vina
            for pdb in pdb_list:

                # Try to run docking
                try:

                    # Invoke check_rmsd() method
                    lig1.check_rmsd(pdb)

                except:
                    pass

            # Invoke show_lowest_rmsd() method
            lig1.show_lowest_rmsd()

            # Invoke choose_rmsd() method
            lig1.choose_rmsd()

            # Invoke add_results() method (WFA 2021-08-08)
            lig1.add_results()

            # Try to open vina_rmsd_results.csv
            try:
                file2open = project_dir_string+"vina_rmsd_results.csv"
                fo_stats = open(file2open,"r")
                csv_stats = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Set up empty string
            msg_stats = ""

            # Set up empty lists
            list_rmsd = []
            pdb_list_no_rmsd = []
            pdb_list_rmsd = []

            # Looping through csv_stats (first line)
            for line in csv_stats:
                # Some editing
                header_line = str(line[0])+"\t"+str(line[1])+"\t"+str(line[2])
                msg_stats += header_line+"\n"
                break

            # Looping through csv_stats
            for line in csv_stats:
                # Some editing
                if "mass" in line[1]:
                    centering = "mass     "
                elif "electric" in line[1]:
                    centering = "electric "
                else:
                    centering = str(line[1])

                line_out = str(line[0])+"\t"+centering+"\t\t"+str(line[2])
                msg_stats += line_out+"\n"

                # To get RMSD values
                if "ND" not in line[2]:
                    list_rmsd.append(float(line[2]))

            # Convert list to array
            rmsd_array = np.array(list_rmsd)

            # Calculate docking accuracy (DA1 and DA2) (Xavier et al 2016)
            # doi: 10.2174/138620731966616092711134
            n_all = np.count_nonzero(rmsd_array > 0.0)
            n_a = np.count_nonzero(rmsd_array < 2.0)
            n_b = np.count_nonzero(rmsd_array < 3.0)
            n_c = np.count_nonzero(rmsd_array < 4.0)
            if n_all != 0:
                f_a = n_a/n_all
                f_b = n_b/n_all
                f_c = n_c/n_all
                da1 = f_a + 0.5*(f_b - f_a)
                da2 = da1 + 0.25*(f_c - f_b)
            else:
                print("\nError! Number of poses is zero!")
                print("Please check dataset!")
                return

            # Add docking accuracy data
            msg_stats +="\n\nDocking accuracies\n"
            formated_da1 = "{:.3f}".format(da1)
            formated_da2 = "{:.3f}".format(da2)
            msg_stats += "DA1 = "+str(formated_da1)+"\n"
            msg_stats += "DA2 = "+str(formated_da2)+"\n"

            # Add docking RMSD average, minimum and maximum
            msg_stats += "\n\nDocking RMSD\n"
            formated_mean = "{:.3f}".format(np.mean(rmsd_array))
            msg_stats += "Mean RMSD (A) = "+str(formated_mean)+"\n"
            msg_stats += "Maximum RMSD (A) = "+str(np.max(rmsd_array))+"\n"
            msg_stats += "Minimum RMSD (A) = "+str(np.min(rmsd_array))+"\n"

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Try to open bind_###.csv
            try:
                file2open = project_dir_string+"bind_"+bind_in+".csv"
                fo_bind = open(file2open,"r")
                csv_bind = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Looping through csv_bind (first line)
            for line in csv_bind:
                break

            # Looping through csv_bind
            for line in csv_bind:
                try:
                    # Test to get PDB for structures with no docking results
                    if "ND" not in line[9]:
                        pdb_list_rmsd.append(line[0])
                    else:
                        pdb_list_no_rmsd.append(line[0])
                except:
                    pass

            # Add list of PDB with no docking results
            msg_stats += "\n\nNo docking results for the following PDB(s): "
            msg_stats += str(pdb_list_no_rmsd)+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_stats)

            # Write statistical analysis
            file2create = project_dir_string+"docking_summary.log"
            fo_summary = open(file2create,"w")
            fo_summary.write(msg_stats)

            # Close files
            fo_stats.close()
            fo_bind.close()
            fo_summary.close()

            # Invoke show_done_message1()
            self.show_done_message1("Statistical Analysis of Docking Results",
                                    self.advina_msg)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No statistical analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define preprocess() method
    def preprocess(self):
        """Method to preprocess data for machine learning modeling"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Data will be scaled."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file
            #sf_file_in = str(self.input_score_csv_file_entry)
            # Get scoring function file name from strscore.in
            sf_file_in = self.read_score_results_csv()

            # Instantiate an object of Pre_proc() class
            data1 = scaling.Pre_proc(self.program_root,project_dir_string,
            sf_file_in)

            # Invoke bundle() method
            data1.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS preprocessed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Preprocess Data"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No scaling performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define preprocess_p() method
    def preprocess_p(self):
        """Method to preprocess pose data for machine learning modeling"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Data will be scaled."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file name from strdock.in
            sf_dock_in = self.read_docking_results_csv()

            # Instantiate an object of Pre_proc() class
            data2 = poses.Pre_proc(self.program_root,project_dir_string,
            sf_dock_in)

            # Invoke bundle() method
            data2.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS preprocessed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Preprocess Data"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No scaling performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define preprocess_vs() method
    def preprocess_vs(self):
        """Method to preprocess virtual screening results
        for machine learning modeling"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Data will be scaled."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get scoring function file name from strvs.in
            sf_vs_in = self.read_vs_results_csv()

            # Instantiate an object of Pre_proc() class
            data2 = poses.Pre_proc(self.program_root,project_dir_string,
            sf_vs_in)

            # Invoke bundle() method
            data2.bundle()

            # Set up report_out message
            report_out = "\nSAnDReS preprocessed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Preprocess Data for Virtual Screening Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No scaling performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define regression_methods() method
    def regression_methods(self):
        """Method to apply regression methods available on
        https://scikit-learn.org/stable/modules/linear_model.html and
        https://xgboost.readthedocs.io/en/latest/python/python_api.html.
        Here we have access to a set of regression methods in which the target
        value is expected to be a linear combination of the features.

        """

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get scoring function file name from strscore.in
        sf_file_in = self.read_score_results_csv()

        # Check whether "_training.csv" string is in sf_file_in
        if "_training.csv" in sf_file_in:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in

        else:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in.replace(".csv","_training.csv")

        # Invoke backup.make()
        backup.make(training_sf_file_in,project_dir_string,
                project_dir_string+"backup/")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Set up variables
        # For ML_ACCESS
        mlregmpy_in = "ml_par.csv" # Parameter file

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+")..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Modeling may take several minutes."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up empty list
            list_of_mlr_methods = []

            # Read regression methods (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)
            except IOError:
                sys.exit("\nIOError! I can't find "+file2open+"!")

            # Looping through input file to get mlr_methods
            for line in csv_in:
                if "#" in line[0]:
                    continue
                elif line[0] == "mlr_method":
                    mlr_method_in = handle_hash("str",str(line[1]))
                    list_of_mlr_methods.append(mlr_method_in)

            # Close ml_par.csv
            fo.close()

            # Instantiate an object of GATE() class
            model = ML_ACCESS.GATE(self.program_root,project_dir_string,
            mlregmpy_in,training_sf_file_in)

            # Regression loop
            # Looping through list_of_mlr_methods
            for mlr_method in list_of_mlr_methods:

                # Show message
                print("Running method "+mlr_method+"...")

                # Invoke read_input() method
                model.read_input(mlr_method)

                # Invoke select_features() method
                model.select_features()

                # Invoke write_features()
                model.write_features()

                # Invoke generate() method
                model.generate()

            # Backup files
            # Invoke backup.make()
            backup.make("features.csv",
            project_dir_string+"models/",project_dir_string+"backup/")
            backup.make("scores.csv",
            project_dir_string,project_dir_string+"backup/")

            # Set up report_out message
            report_out = "New regression models written in "+\
            project_dir_string+"/models"
            report_out += "\nSAnDReS generated regression models with the "
            report_out += "following methods available in "
            report_out += "Scikit-Learn "+str(self.sk_version)+" :\n"
            for mlr_method in list_of_mlr_methods:
                report_out += str(mlr_method)+"\n"
            report_out += self.scikit_ref

            # Invoke show_done_message2()
            msg_out = "Regression Methods"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No regression performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define vina_stat_analysis_features() method
    def vina_stat_analysis_features(self):
        """Method to invoke stat_analysis_features() method for Vina
        features
        """

        # Set up features_in_csv
        features_in_csv = "vina_features_in.csv"

        # Invoke stat_analysis_features() method
        self.stat_analysis_features(features_in_csv)

    # Define molegro_stat_analysis_features() method
    def molegro_stat_analysis_features(self):
        """Method to invoke stat_analysis_features() method for Molegro
        features
        """

        # Set up features_in_csv
        features_in_csv = "molegro_features_in.csv"

        # Invoke stat_analysis_features() method
        self.stat_analysis_features(features_in_csv)

    # Define stat_analysis_features() method
    def stat_analysis_features(self,features_in_csv):
        """Method to determine to correlation between features and experimental
        binding affinity.
        List of features available in the file misc/data/###features_in.csv
        e.g.
        Torsions,Q,Average Q,C,N,O,S,F,Gauss 1,Gauss 2,Repulsion,Hydrophobic,
        Hydrogen,Torsional
        """

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get scoring function file name from strscore.in
        sf_file_in = self.read_score_results_csv()

        # Check whether "_training.csv" string is in sf_file_in
        if "_training.csv" in sf_file_in:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in

        else:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in.replace(".csv","_training.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+") and SciPy..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Correlation will be calculated using SciPy and Scikit-Learn. "
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Set up features_in_csv
        #features_in_csv = "vina_features_in.csv"

        # Test answer
        if result:

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Instantiate an object of Analysis() class
            features = ML_STATS.Analysis(self.program_root,project_dir_string,
            training_sf_file_in,features_in_csv)

            # Set up exp_label
            exp_label = "log("+bind_in.replace(" ","")+")"

            # Invoke bundle() method
            features.bundle(exp_label)

            # Invoke show_botton_msg() method
            msg_out = "Finished!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Set up report_out message
            report_out = "\nSAnDReS determined metrics using Scikit-Learn ("
            report_out += str(self.sk_version)+") and SciPy.\n"
            report_out += self.scikit_ref

            # Invoke show_botton_msg() method
            msg_out = "Done!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Try to open statistical_analysis_features.csv
            file2open =project_dir_string+training_sf_file_in.replace(".csv","")
            file2open += "_stats4features.csv"
            try:
                fo_stats = open(file2open,"r")
                stats_data = csv.reader(fo_stats)
            except IOError:
                print("\nIOError! I can't  find "+file2open+" file!")
                return

            # Set up empty string
            stats_data_lines = ""

            # Looping through stats_data (first line)
            for line in stats_data:
                break

            # Header (Feature, r, p-value, r2, rho, p-value, MSE, RMSE, RSS)
            stats_data_lines += "\tFeature\t\t r \t\tp-value \t r2 \t rho "
            stats_data_lines += "\tp-value \t MSE \t RMSE \t RSS\n"

            # Looping through stats_data
            for line in stats_data:
                line_out = "{0:>16}".format(str(line[0]))
                aux_float = "{:.3f}".format(float(line[1]))
                line_out += "\t\t\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[2]))
                line_out += "\t\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[3]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[4]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[5]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[6]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[7]))
                line_out += "\t"+str(aux_float)
                aux_float = "{:.3f}".format(float(line[8]))
                line_out += "\t"+str(aux_float)

                # Some editing
                aux_line = str(line_out).replace("[","")
                aux_line = aux_line.replace("]","")
                aux_line = aux_line.replace("'","")

                # Add line
                stats_data_lines += str(aux_line)+"\n"

            # Backup files
            # Invoke backup.make()
            file2backup = training_sf_file_in.replace(".csv","")+"_stats4features.csv"
            backup.make(file2backup,project_dir_string,
            project_dir_string+"backup/")

            # Close file
            fo_stats.close()

            # Invoke show_done_message2()
            msg_out = "Statistical Analysis (Features)"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No statistical analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define show_stats_on_screen() method
    def show_stats_on_screen(self,file_in):
        """Method to show statistical analysis on screen"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Set up report_out message
        report_out = "\nSAnDReS determined metrics using Scikit-Learn ("
        report_out += str(self.sk_version)+") and SciPy.\n"
        report_out += self.scikit_ref

        # Try to open file_in
        file2open = project_dir_string+file_in
        try:
            fo_stats = open(file2open,"r")
            stats_data = csv.reader(fo_stats)
        except IOError:
            print("\nIOError! I can't  find "+file2open+" file!")
            return

        # Set up empty string
        stats_data_lines = ""

        # Looping through stats_data (first line)
        for line in stats_data:
            break

        # Header (Feature, r, p-value, r2, rho, p-value, MSE, RMSE, RSS)
        stats_data_lines += "\t\t\tMethod\t r \tp-value \t r2 \t rho "
        stats_data_lines += "\tp-value \t MSE \t RMSE \t SD \t RSS \t "
        stats_data_lines += "F-stat\n"

        # Looping through stats_data
        for line in stats_data:
            line_out = "{0:>30}".format(str(line[0]))
            aux_float = "{:.3f}".format(float(line[1]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[2]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[3]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[4]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[5]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[6]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[7]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[8]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[9]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[10]))
            line_out += "\t"+str(aux_float)

            # Some editing
            aux_line = str(line_out).replace("[","")
            aux_line = aux_line.replace("]","")
            aux_line = aux_line.replace("'","")

            # Add line
            stats_data_lines += str(aux_line)+"\n"

        # Invoke show_short_msg() method
        msg1.show_short_msg(stats_data_lines+"\n\n"+report_out)

        # Close file
        fo_stats.close()

    # Define filter_data4xtal() method
    def filter_data4xtal(self):
        """Method to invoke filter_csv() method for sf_file_in file"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get scoring function file name from strscore.in
        sf_file_in = self.read_score_results_csv()

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(sf_file_in)

        # Check whether "_training.csv" string is in sf_file_in
        if "_training.csv" in sf_file_in:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in

        else:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in.replace(".csv","_training.csv")

        # Invoke backup.make()
        backup.make(training_sf_file_in,project_dir_string,
                project_dir_string+"backup/")

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(training_sf_file_in)

        # Set up test_sf_file_in for test set
        test_sf_file_in=training_sf_file_in.replace("_training.csv","_test.csv")

        # Invoke backup.make()
        backup.make(test_sf_file_in,project_dir_string,
                project_dir_string+"backup/")

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(test_sf_file_in)

    # Define filter_csv_xtal() method
    def filter_csv_xtal(self,file_in):
        """Method eliminate lines with nan data"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to eliminate nan from "+file_in+" file!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "SAnDReS will delete nan lines in file "
        w_msg2 += file_in+"."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up an empty string
            data_out = ""

            # Backup files
            # Invoke backup.make()
            backup.make(file_in,project_dir_string,project_dir_string+"backup/")

            # Try to open file_in
            try:
                file2open = project_dir_string+file_in
                fo_filter = open(file2open,"r")
                csv_filter = csv.reader(fo_filter)

                # Looping through csv_filter
                for line in csv_filter:
                    part_line = str(line[10:])
                    aux_line = str(line)

                    # Some editing
                    aux_line = str(aux_line).replace("[","")
                    aux_line = aux_line.replace("]","")
                    aux_line = aux_line.replace("'","")
                    aux_line = aux_line.replace(" ,",",")
                    aux_line = aux_line.replace(", ",",")
                    aux_line = aux_line.replace("\n","")

                    # Check if nan and ND are present
                    if "nan" in part_line:
                        pass
                    else:
                        data_out += aux_line+"\n"

                # Close file
                fo_filter.close()

            except IOError:

                # Invoke show_botton_msg() method
                msg_out = "I can't find "+file2open+" file!"
                msg_out += " finishing the Filter Data request!"
                msg1.show_botton_msg(msg_out,"red","light grey")
                print(msg_out)
                return

            # Open a new file
            fo_filter = open(file2open,"w")

            # Some editing
            data_out = data_out.replace(" ,",",")
            data_out = data_out.replace(", ",",")

            # Write filtered data
            fo_filter.write(data_out)

            # Close file
            fo_filter.close()

            # Invoke show_done_message2()
            msg_out = "Filter Data"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No filtering performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define choose_training_set() method
    def choose_training_set(self):
        """Method to choose PDBs for the training set"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Try to open a file
        try:
            file2open = project_dir_string+"pdb_codes_training_set.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(project_dir_string,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)
            fo2 = open(file2open,"w")
            print("\nA new "+file2open+"file was created!")

            # Close file
            fo2.close()

        # Call edit_file() method
        self.edit_file(project_dir_string,"pdb_codes_training_set.csv")

    # Define choose_test_set() method
    def choose_test_set(self):
        """Method to choose PDBs for the test set"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Try to open a file
        try:
            file2open = project_dir_string+"pdb_codes_test_set.csv"
            fo1 = open(file2open,"r")

            # Close file
            fo1.close()

        # Handle IOError
        except IOError:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(project_dir_string,root)

            # Invoke show_botton_msg() method
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)
            fo2 = open(file2open,"w")
            print("\nA new "+file2open+"file was created!")

            # Close file
            fo2.close()

        # Call edit_file() method
        self.edit_file(project_dir_string,"pdb_codes_test_set.csv")

    # Define pdb_training_test_xtal() method
    def pdb_training_test_xtal(self):
        """Method to generate PDBs for training and test datasets for
        machine learning modeling for crystal structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to generate PDBs"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "PDB access codes will be randomly created."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Test answer
        if result:

            # Get scoring function file name from strscore.in
            sf_file_in = self.read_score_results_csv()

            # Get scoring function file name from strdock.in
            sf_dock_in = self.read_docking_results_csv()

            # Read regression methods (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)
            except IOError:
                sys.exit("\nIOError! I can't find "+file2open+"!")

            # Looping through input file
            for line in csv_in:
                if "#" in line[0]:
                    continue
                elif line[0] == "test_size_in":
                    test_size_in = float(handle_hash("str",str(line[1])))
                elif line[0] == "seed_in":
                    seed_in = int(handle_hash("str",str(line[1])))

            # Close ml_par.csv
            fo.close()

            # Instantiate an object of Dataset() class
            d = sp.Dataset(project_dir_string,sf_file_in,sf_dock_in,
            test_size_in,seed_in)

            # Invoke random_pdb() method
            d.random_pdb()

            # Invoke show_done_message2()
            msg_out = "Automatic Generation of PDBs for Training and Test Sets"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No PDBs generated for training and test sets!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define training_test_xtal() method
    def training_test_xtal(self):
        """Method to generate training and test datasets for machine learning
        modeling using crystal structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to split datasets"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "Data will be divided in training and test sets."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        # Test answer
        if result:

            # Get scoring function file name from strscore.in
            sf_file_in = self.read_score_results_csv()

            # Get scoring function file name from strdock.in
            sf_dock_in = self.read_docking_results_csv()

            # Read regression methods (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)
            except IOError:
                sys.exit("\nIOError! I can't find "+file2open+"!")

            # Looping through input file
            for line in csv_in:
                if "#" in line[0]:
                    continue
                elif line[0] == "test_size_in":
                    test_size_in = float(handle_hash("str",str(line[1])))
                elif line[0] == "seed_in":
                    seed_in = int(handle_hash("str",str(line[1])))

            # Close ml_par.csv
            fo.close()

            # Instantiate an object of Dataset() class
            d = sp.Dataset(project_dir_string,sf_file_in,sf_dock_in,
            test_size_in,seed_in)

            # Invoke read_pdb_access_codes() method
            d.read_pdb_access_codes()

            # Invoke generate() method
            d.generate()

            # Invoke show_done_message2()
            msg_out = "Generate Training and Test Sets"
            self.show_done_message2(msg_out)

            # Insert training set file name
            self.input_score_csv_file_entry = self.input_score_csv_file_entry.replace(".csv","_training.csv")

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No training and test sets generated!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define training_test_p() method
    def training_test_p(self):
        """Method to generate training and test datasets for machine learning
        modeling for poses"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to split datasets"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "Docking data will be divided in training and test sets."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up empty lists
            pdb_train = []
            pdb_test = []

            # Get scoring function file name from strdock.in
            sf_dock_in = self.read_docking_results_csv()

            # Try to open pdb_codes_training_set.csv
            try:

                # For training set
                file2open = project_dir_string+"pdb_codes_training_set.csv"
                fo_train = open(file2open,"r")
                csv_train = csv.reader(fo_train)

                # Looping through csv_train
                pdb = ""
                for line1 in csv_train:
                    aux_line = str(line1)

                    # Looping through each character of the line
                    for char1 in aux_line:
                        if char1 != ",":
                            pdb += char1
                        else:
                            # Some editing 2
                            pdb = pdb.replace("[","")
                            pdb = pdb.replace("]","")
                            pdb = pdb.replace("'","")
                            pdb = pdb.replace(" ","")
                            pdb_train.append(pdb)
                            pdb = ""

                    # For the last PDB access code
                    # Some editing 2
                    pdb = pdb.replace("[","")
                    pdb = pdb.replace("]","")
                    pdb = pdb.replace("'","")
                    pdb = pdb.replace(" ","")
                    pdb_train.append(pdb)

                # Close file
                fo_train.close()

                # Show PDB access codes for the training set
                print("\nTraining set: ",pdb_train)

                # Repeat the process for the test set
                file2open = project_dir_string+"pdb_codes_test_set.csv"
                fo_test = open(file2open,"r")
                csv_test = csv.reader(fo_test)

                # Looping through csv_test
                pdb = ""
                for line1 in csv_test:
                    aux_line = str(line1)

                    # Looping through each character of the line
                    for char1 in aux_line:
                        if char1 != ",":
                            pdb += char1
                        else:
                            # Some editing 2
                            pdb = pdb.replace("[","")
                            pdb = pdb.replace("]","")
                            pdb = pdb.replace("'","")
                            pdb = pdb.replace(" ","")
                            pdb_test.append(pdb)
                            pdb = ""

                    # For the last PDB access code
                    # Some editing 2
                    pdb = pdb.replace("[","")
                    pdb = pdb.replace("]","")
                    pdb = pdb.replace("'","")
                    pdb = pdb.replace(" ","")
                    pdb_test.append(pdb)

                # Close file
                fo_test.close()

                # Show PDB access codes for the test set
                print("\nTest set: ",pdb_test)

                # Try to open sf_dock_in
                try:

                    # Open new training and test sets
                    file2create_train = project_dir_string
                    file2create_train += sf_dock_in.replace(".csv","")
                    file2create_train += "_training.csv"
                    file2create_test = project_dir_string
                    file2create_test += sf_dock_in.replace(".csv","")
                    file2create_test += "_test.csv"
                    fo_train = open(file2create_train,"w")
                    fo_test = open(file2create_test,"w")

                    # Open docking results file
                    file2open_dock = project_dir_string+sf_dock_in
                    fo_dock = open(file2open_dock,"r")
                    csv_dock = csv.reader(fo_dock)

                    # Looping through csv_dock to get header
                    for line in csv_dock:

                        # Some editing 1
                        line_out = str(line)
                        line_out = line_out.replace("[","")
                        line_out = line_out.replace("]","")
                        line_out = line_out.replace("'","")
                        line_out = line_out.replace(" ,",",") # WFA 2021-10-19
                        line_out = line_out.replace(", ",",") # WFA 2021-10-19
                        header = str(line_out)

                        # Write headers
                        fo_train.write(header+"\n")
                        fo_test.write(header+"\n")
                        break

                    # Looping through csv_dock to get the remaing line
                    for line in csv_dock:

                        # Some editing 2
                        line_out = str(line)
                        line_out = line_out.replace("[","")
                        line_out = line_out.replace("]","")
                        line_out = line_out.replace("'","")
                        line_out = line_out.replace(" ","")

                        if str(line[0]) in pdb_train:
                            fo_train.write(line_out+"\n")
                        elif str(line[0]) in pdb_test:
                            fo_test.write(line_out+"\n")
                        else:
                            msg_out = "\nI can't find PDB "+str(line[0])+ " in "
                            msg_out += "training and/or test sets!"
                            print(msg_out)

                    # Close files
                    fo_train.close()
                    fo_test.close()
                    fo_dock.close()

                # Handle IOError
                except IOError:
                    msg_out = "\nI can't find "+file2open_dock+" file!"
                    print(msg_out)
                    return

            # Handle IOError
            except IOError:
                msg_out = "\nI can't find "+file2open+" file!"
                print(msg_out)
                return

            # Invoke show_done_message2()
            msg_out = "Generate Training and Test Sets"
            self.show_done_message2(msg_out)

            # Insert training set file name
            self.docking_results_entry = \
            self.docking_results_entry.replace(".csv","_training.csv")

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No training and test sets generated!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define filter_data4poses() method
    def filter_data4poses(self):
        """Method to invoke filter_csv() method for sf_dock_in file"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Get scoring function file name from strdock.in
        sf_dock_in = self.read_docking_results_csv()

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(sf_dock_in)

        # Check whether "_training.csv" string is in sf_dock_in
        if "_training.csv" in sf_dock_in:

            # Set up training_sf_dock_in for training set
            training_sf_dock_in = sf_dock_in

        else:

            # Set up training_sf_dock_in for training set
            training_sf_dock_in = sf_dock_in.replace(".csv","_training.csv")

        # Invoke backup.make()
        backup.make(training_sf_dock_in,project_dir_string,
                project_dir_string+"backup/")

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(training_sf_dock_in)

        # Set up test_sf_dock_in for test set
        test_sf_dock_in=training_sf_dock_in.replace("_training.csv","_test.csv")

        # Invoke backup.make()
        backup.make(test_sf_dock_in,project_dir_string,
                project_dir_string+"backup/")

        # Invoke filter_csv_xtal() method
        self.filter_csv_xtal(test_sf_dock_in)

    # Define filter_csv() method
    def filter_csv(self,file_in):
        """Method eliminate lines with nan and ND data"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Ready to eliminate nan from "+file_in+" file!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "SAnDReS will delete nan lines in file "
        w_msg2 += file_in+"."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Set up an empty string
            data_out = ""

            # Backup files
            # Invoke backup.make()
            backup.make(file_in,project_dir_string,project_dir_string+"backup/")

            # Try to open file_in
            try:
                file2open = project_dir_string+file_in
                fo_filter = open(file2open,"r")
                csv_filter = csv.reader(fo_filter)

                # Looping through csv_filter
                for line in csv_filter:
                    aux_line = str(line)

                    # Some editing
                    aux_line = str(aux_line).replace("[","")
                    aux_line = aux_line.replace("]","")
                    aux_line = aux_line.replace("'","")
                    aux_line = aux_line.replace(" ,",",")
                    aux_line = aux_line.replace(", ",",")
                    aux_line = aux_line.replace("\n","")

                    # Check if nan and ND are present
                    if "nan" in aux_line or "ND" in aux_line:
                        pass
                    else:
                        data_out += aux_line+"\n"

                # Close file
                fo_filter.close()

            except IOError:

                # Invoke show_botton_msg() method
                msg_out = "I can't find "+file2open+" file!"
                msg_out += " finishing the Filter Data request!"
                msg1.show_botton_msg(msg_out,"black","light grey")
                print(msg_out)
                return

            # Open a new file
            fo_filter = open(file2open,"w")

            # Some editing
            data_out = data_out.replace(" ,",",")
            data_out = data_out.replace(", ",",")

            # Write filtered data
            fo_filter.write(data_out)

            # Close file
            fo_filter.close()

            # Invoke show_done_message2()
            msg_out = "Filter Data"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No filtering performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define apply_selected_joblib2model() method
    def apply_selected_joblib2model(self):
        """Method to apply a selected joblib model"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up msg_out
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file name from strscore.in
        sf_file_in = self.read_score_results_csv()

        # Check whether "_training.csv" string is in sf_file_in
        if "_training.csv" in sf_file_in:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in

        else:

            # Set up training_sf_file_in for training set
            training_sf_file_in = sf_file_in.replace(".csv","_training.csv")

        # Invoke backup.make()
        backup.make(training_sf_file_in,project_dir_string,
                project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        m_training = tk_joblib.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        m_training.pre_joblib_GUI(training_sf_file_in,"")

        # Set up test_sf_file_in for test set
        test_sf_file_in=training_sf_file_in.replace("_training.csv","_test.csv")

        # Invoke backup.make()
        backup.make(test_sf_file_in,project_dir_string,
                project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        m_test = tk_joblib.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        m_test.pre_joblib_GUI(test_sf_file_in,"")

    # Define apply_selected_joblib2poses() method
    def apply_selected_joblib2poses(self):
        """Method to apply a selected joblib model to docking results"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up empty string
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file
        ########################################################################

        # Get scoring function file name from strdock.in
        sf_dock_in = self.read_docking_results_csv()

        # Instantiate an object of the Model() class
        m_poses = tk_joblib.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        m_poses.pre_joblib_GUI(sf_dock_in,"Docking Results")

        # Check whether "_training.csv" string is in sf_dock_in
        if "_training.csv" in sf_dock_in:

            # Set up training_sf_dock_in for training set
            training_sf_dock_in = sf_dock_in

        else:

            # Set up training_sf_dock_in for training set
            training_sf_dock_in = sf_dock_in.replace(".csv","_training.csv")

        # Invoke backup.make()
        backup.make(training_sf_dock_in,project_dir_string,
                project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        m_training = tk_joblib.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        m_training.pre_joblib_GUI(training_sf_dock_in,"Docking Results")

        # Set up test_sf_dock_in for test set
        test_sf_dock_in=training_sf_dock_in.replace("_training.csv","_test.csv")

        # Invoke backup.make()
        backup.make(test_sf_dock_in,project_dir_string,
                project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        m_test = tk_joblib.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        m_test.pre_joblib_GUI(test_sf_dock_in,"Docking Resuls")

        ########################################################################

    # Define apply_selected_joblib2vs() method
    def apply_selected_joblib2vs(self):
        """Method to apply a selected joblib model
        to virtual screening results"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up empty string
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file name from strvs.in
        sf_vs_in = self.read_vs_results_csv()

        # Invoke backup.make()
        backup.make(sf_vs_in,project_dir_string,project_dir_string+"backup/")

        # Instantiate an object of the Model() class
        map1 = tk_joblib_vs.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        map1.pre_joblib_GUI(sf_vs_in,"Virtual Screening Results")

    # Define stats_joblib2poses() method
    def stats_joblib2poses(self):
        """Method to carry out bivariate analysis of regression models applied
        to docking results"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Bivariate analysis of regression models applied to docking "
        w_msg2 += "results will be performed using SciKit-Learn."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            ####################################################################
            # Get scoring function file name from strdock.in
            sf_dock_in = self.read_docking_results_csv()

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            ####################################################################
            # Instantiate an object of DockingResults() class
            r0 = reg.DockingResults(project_dir_string,sf_dock_in,
            bind_in)

            # Invoke bundle() method
            r0.bundle()
            ####################################################################

            # Check whether "_training.csv" string is in sf_dock_in
            if "_training.csv" in sf_dock_in:

                # Set up training_sf_dock_in for training set
                training_sf_dock_in = sf_dock_in

            else:

                # Set up training_sf_dock_in for training set
                training_sf_dock_in = sf_dock_in.replace(".csv","_training.csv")

            ####################################################################
            # Instantiate an object of DockingResults() class
            r1 = reg.DockingResults(project_dir_string,training_sf_dock_in,
            bind_in)

            # Invoke bundle() method
            r1.bundle()
            ####################################################################
            # Set up test_sf_dock_in for test set
            test_sf_dock_in = training_sf_dock_in.replace("_training.csv",
                "_test.csv")

            ####################################################################
            # Instantiate an object of DockingResults() class
            r2 = reg.DockingResults(project_dir_string,test_sf_dock_in,bind_in)

            # Invoke bundle() method
            r2.bundle()
            ####################################################################

            # Set up report_out message
            report_out = "\nSAnDReS processed data with Scikit-Learn ("
            report_out += str(self.sk_version)+").\n"
            report_out += self.scikit_ref

            # Invoke show_short_msg() method
            msg1.show_short_msg(report_out)

            # Invoke show_done_message2()
            msg_out = "Bivariate Analysis of Regression Models Applied"
            msg_out += " Docking Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No bivariate analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define stats_joblib2xtal() method
    def stats_joblib2xtal(self):
        """Method to carry out bivariate analysis of regression models applied
        to crystallographic structures"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Bivariate analysis of regression models applied to "
        w_msg2 += "crystallographic structures performed using SciKit-Learn."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            ####################################################################
            # Get scoring function file name from strscore.in
            sf_file_in = self.read_score_results_csv()

            # Check whether "_training.csv" string is in sf_file_in
            if "_training.csv" in sf_file_in:

                # Set up training_sf_file_in for training set
                training_sf_file_in = sf_file_in

            else:

                # Set up training_sf_file_in for training set
                training_sf_file_in = sf_file_in.replace(".csv","_training.csv")

            # Instantiate an object of Analysis() class
            s1 = stats.Analysis(self.program_root,project_dir_string,
            training_sf_file_in,root)

            # Invoke bundle() method
            s1.bundle()
            ####################################################################

            # Set up test_sf_file_in for test set
            test_sf_file_in = training_sf_file_in.replace("_training.csv",
                "_test.csv")

            # Instantiate an object of Analysis() class
            s2 = stats.Analysis(self.program_root,project_dir_string,
            test_sf_file_in,root)

            # Invoke bundle() method
            s2.bundle()
            ####################################################################

            # Invoke show_done_message2()
            msg_out = "Bivariate Analysis of Regression Models"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No bivariate analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define stats_joblib2molegro() method
    def stats_joblib2molegro(self):
        """Method to carry out bivariate analysis of regression models applied
        to Molegro results"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Bivariate analysis of regression models applied to "
        w_msg2 += "Molegro results performed using SciKit-Learn."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            ####################################################################
            # Get scoring function file name from strscore.in
            sf_file_in = self.read_score_results_csv()

            # Check whether "_training.csv" string is in sf_file_in
            if "_training.csv" in sf_file_in:

                # Set up training_sf_file_in for training set
                training_sf_file_in = sf_file_in

            else:

                # Set up training_sf_file_in for training set
                training_sf_file_in = sf_file_in.replace(".csv","_training.csv")

            # Instantiate an object of Analysis() class
            s1 = stats_molegro.Analysis(self.program_root,project_dir_string,
            training_sf_file_in,root)

            # Invoke bundle() method
            s1.bundle()
            ####################################################################

            # Set up test_sf_file_in for test set
            test_sf_file_in = training_sf_file_in.replace("_training.csv",
                "_test.csv")

            # Instantiate an object of Analysis() class
            s2 = stats_molegro.Analysis(self.program_root,project_dir_string,
            test_sf_file_in,root)

            # Invoke bundle() method
            s2.bundle()
            ####################################################################

            # Invoke show_done_message2()
            msg_out = "Bivariate Analysis of Regression Models"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No bivariate analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define go_plotting method
    def go_plotting(self):
        """Method to generate scatter plot"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Invoke create_plots_dir() method
        self.create_plots_dir()

        # Invoke create_backup_dir() method
        self.create_backup_dir()

        # Instantiate an object of the Scatter2D() class
        p1 = tk_scatter_plot.Scatter2D(self.program_root,project_dir_string,root)

        # Invoke pre_2d_GUI() method
        p1.pre_2d_GUI()

    # Define mol2pdbqt() method
    def mol2pdbqt(self):
        """Convert from mol2 to PDBQT"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Importing ligands for virtual screening..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Show yes/no question
        w_msg1 = self.adt4_msg
        w_msg2 = "Mol2 files will be converted to PDBQT format"
        w_msg2 += " to be used for virtual screening!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(project_dir_string,root)

            # Try to open convert2pdbqt_par.csv file
            try:
                file2open = self.program_root+"misc/data/vs_par.csv"
                fo_par = open(file2open,"r")
                csv_par = csv.reader(fo_par)

                # Looping through csv_par
                for line in csv_par:
                    if "#" not in str(line):
                        if line[0] == "lig_dir":
                            lig_dir = line[1]
                        elif line[0] == "lig_in":
                            lig_in = line[1]
                        elif line[0] == "vs_dir":
                            vs_dir = line[1]
                        elif line[0] == "mol_dir":
                            mol_dir = line[1]
                        elif line[0] == "lig_root_out":
                            lig_root_out = line[1]

                # Close file
                fo_par.close()

            # Handle IOError exception
            except IOError:
                print("\nIOerror! I can't find "+file2open+" file")
                return

            # Set up vs_dir1 in the project_dir_string
            vs_dir1 = project_dir_string+vs_dir

            # Try to make dir
            try:
                # Make dir
                os.mkdir(vs_dir1)

            # Handle exception
            except:
                pass

            # Add mol_dir
            vs_dir1 += mol_dir

            # Try to make dir
            try:
                # Make dir
                os.mkdir(vs_dir1)

            # Handle exception
            except:
                pass

            ####################################################################
            # lig_dir, lig_in, vs_dir1, self.program_root,project_dir_string,
            # lig_root_out
            ####################################################################
            # Copy mol2 file to vs_dir1
            # Check whether the specified path/file is an existing directory/file
            # or not
            origin = lig_dir+lig_in
            isfile = os.path.isfile(origin)
            print("\nCheck whether the specified path/file ",origin,
            "is an  existing directory/file or not: ",isfile)
            if isfile:
                print("\nI've found ",origin," directory/file!")
                target = vs_dir1+lig_in
                shutil.copyfile(origin,target)
                print("\n\nCopying "+lig_in+" to "+vs_dir1+"!")

            # Instantiate an object of LIGSTRUCTURE() class
            mol = conv2pdbqt.LIGSTRUCTURE(self.program_root,project_dir_string,
                    vs_dir1)

            # Invoke mol2split() method
            mol.mol2split(lig_in,lig_root_out)

            # Invoke ligand2pdbqt() method
            mol.ligand2pdbqt(lig_in,lig_root_out)

            # List mol2 files in vs_dir1
            from os.path import isfile, join
            myfiles = [f for f in os.listdir(vs_dir1) if isfile(join(vs_dir1,f))]

            # Looping through myfiles
            for lig in myfiles:

                # Get only .mol2 files
                if ".mol2" in lig:

                    # Try to delete mol2 files in the mol_dir
                    try:
                        os.remove(vs_dir1+lig)
                        print("\nDeleting ",lig,"...")
                    except:
                        pass

            ####################################################################
            # Invoke show_done_message2()
            msg_out = "Virtual Screening->Import Ligands"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define get_receptor_pdbqt() method
    def get_receptor_pdbqt(self):
        """Method to import receptor.pdbqt and config.txt to carry out
        virtual screenings"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Importing receptor structure for virtual screening..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "Lowest docking RMSD config.txt and receptor coordinates"
        w_msg2 += " will be used for virtual screening!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Try to open vs_par.csv file
            try:
                file2open = self.program_root+"misc/data/vs_par.csv"
                fo_par = open(file2open,"r")
                csv_par = csv.reader(fo_par)

                # Looping through csv_par
                for line in csv_par:
                    if "#" not in str(line):
                        if line[0] == "vs_dir":
                            vs_dir = line[1]
                        elif line[0] == "config_in":
                            config_in = line[1]
                        elif line[0] == "num_modes":
                            num_modes = line[1]

                # Close file
                fo_par.close()

            # Handle IOError exception
            except IOError:
                print("\nIOError! I can't find "+file2open+" file")
                return

            # Set up vs_dir1 in the project_dir_string
            vs_dir1 = project_dir_string+vs_dir

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Set up empty lists
            pdb_list = []
            rmsd_list = []
            resolution_list = []

            # Try to open bind_###.csv file
            try:
                file2open = project_dir_string+"bind_"+bind_in+".csv"
                fo_sf = open(file2open,"r")
                csv_sf = csv.reader(fo_sf)

                # Looping through csv_sf for the first line
                for line in csv_sf:
                    break

                # Looping through csv_sf
                for line in csv_sf:
                    pdb_list.append(line[0])
                    print(line[9])
                    if "nan" in str(line[9]):
                        aux_float = 9999.99
                    elif "ND" in str(line[9]):
                        aux_float = 9999.99
                    else:
                        try:
                            aux_float = float(line[9])
                        except:
                            aux_float = 9999.99

                    # Add data to lists
                    rmsd_list.append(aux_float)
                    resolution_list.append(line[4])

                # Close file
                fo_sf.close()

                # Convert to array
                rmsd_array = np.array(rmsd_list)

                # Get the index for the minimum RMSD
                i_min = np.argmin(rmsd_array)

                # Get the PDB and resolution for minimum RMSD
                pdb_min = pdb_list[i_min]
                resolution_min = str(resolution_list[i_min])

                # Show lowest RMSD PDB access codes
                print("\nPDB for lowest RMSD: ",pdb_min)
                print("Crystallographic resolution(A): ",resolution_min)
                print("Lowest RMSD(A): ",rmsd_array[i_min])

                # Open lowest_RMSD_PDB.csv
                fo_lowest = open(project_dir_string+"lowest_RMSD_PDB.csv","w")

                # Write lowest PDB access code and resolution
                fo_lowest.write("PDB,"+pdb_min+"\n")
                fo_lowest.write("Resolution(A),"+resolution_min)

                # Close lowest_RMSD_PDB.csv
                fo_lowest.close()

                # Try to copy a file
                # Copy a file to vs_dir1
                # Check whether the specified path/file is an existing
                # directory/file or not
                origin = project_dir_string+"pdbqt/"+pdb_min+"/"+config_in
                isfile = os.path.isfile(origin)
                print("\nCheck whether the specified path/file ",origin,
                "is an  existing directory/file or not: ",isfile)
                if isfile:
                    print("\nI've found ",origin," directory/file!")
                    target = vs_dir1+"/"+config_in
                    shutil.copyfile(origin,target)
                    print("\n\nCopying "+config_in+" to "+vs_dir1+"!")

                # Try to open config.txt file
                try:
                    fo_config = open(vs_dir1+"/"+config_in,"r")
                    config_data = fo_config.readlines()

                    # Set up string
                    config_out_string = "receptor = "+vs_dir1+"receptor.pdbqt\n"

                    # Looping through config.txt data
                    for line in config_data:
                        if "center_x" in line:

                            # Get index for "="
                            i_x = line.index("=")
                            aux_center_x = line[i_x+1:]

                            # Some editing
                            center_x = aux_center_x.replace(" ","")
                            center_x = center_x.replace(",","")
                            center_x = center_x.replace("[","")
                            center_x = center_x.replace("]","")
                            center_x = center_x.replace("'","")

                            # Add center_x
                            config_out_string += "center_x = "+center_x

                        elif "center_y" in line:

                            # Get index for "="
                            i_y = line.index("=")
                            aux_center_y = line[i_y+1:]

                            # Some editing
                            center_y = aux_center_y.replace(" ","")
                            center_y = center_y.replace(",","")
                            center_y = center_y.replace("[","")
                            center_y = center_y.replace("]","")
                            center_y = center_y.replace("'","")

                            # Add center_y
                            config_out_string += "center_y = "+center_y

                        elif "center_z" in line:

                            # Get index for "="
                            i_z = line.index("=")
                            aux_center_z = line[i_z+1:]

                            # Some editing
                            center_z = aux_center_z.replace(" ","")
                            center_z = center_z.replace(",","")
                            center_z = center_z.replace("[","")
                            center_z = center_z.replace("]","")
                            center_z = center_z.replace("'","")

                            # Add center_z
                            config_out_string += "center_z = "+center_z+"\n"

                        elif "size_x" in line:

                            # Get index for "="
                            i_x = line.index("=")
                            aux_size_x = line[i_x+1:]

                            # Some editing
                            size_x = aux_size_x.replace(" ","")
                            size_x = size_x.replace(",","")
                            size_x = size_x.replace("[","")
                            size_x = size_x.replace("]","")
                            size_x = size_x.replace("'","")

                            # Add size_x
                            config_out_string += "size_x = "+size_x

                        elif "size_y" in line:

                            # Get index for "="
                            i_y = line.index("=")
                            aux_size_y = line[i_y+1:]

                            # Some editing
                            size_y = aux_size_y.replace(" ","")
                            size_y = size_y.replace(",","")
                            size_y = size_y.replace("[","")
                            size_y = size_y.replace("]","")
                            size_y = size_y.replace("'","")

                            # Add size_y
                            config_out_string += "size_y = "+size_y

                        elif "size_z" in line:

                            # Get index for "="
                            i_z = line.index("=")
                            aux_size_z = line[i_z+1:]

                            # Some editing
                            size_z = aux_size_z.replace(" ","")
                            size_z = size_z.replace(",","")
                            size_z = size_z.replace("[","")
                            size_z = size_z.replace("]","")
                            size_z = size_z.replace("'","")

                            # Add size_z
                            config_out_string += "size_z = "+size_z

                        elif "seed" in line:

                            # Get index for "="
                            i_s = line.index("=")
                            aux_seed = line[i_s+1:]

                            # Some editing
                            seed = aux_seed.replace(" ","")
                            seed = seed.replace(",","")
                            seed = seed.replace("[","")
                            seed = seed.replace("]","")
                            seed = seed.replace("'","")

                            # Add seed
                            config_out_string += "seed = "+seed+"\n"

                    # Add num_modes
                    config_out_string += "num_modes = "+num_modes

                    # Close file
                    fo_config.close()

                    # Open new config.txt file
                    fo_config = open(vs_dir1+config_in,"w")

                    # Write config_out_string
                    fo_config.write(config_out_string)

                    # Close file
                    fo_config.close()

                # Handle exception
                except IOError:
                    msg_out = "\nIOError! I can't file "+vs_dir1+"/"
                    msg_out += config_in+" file!"
                    print(msg_out)
                    return

                # Try to copy a file
                # Copy a file to vs_dir1
                # Check whether the specified path/file is an existing
                # directory/file or not
                origin = project_dir_string+"pdbqt/"+pdb_min+"/receptor.pdbqt"
                isfile = os.path.isfile(origin)
                print("\nCheck whether the specified path/file ",origin,
                "is an  existing directory/file or not: ",isfile)
                if isfile:
                    print("\nI've found ",origin," directory/file!")
                    target = vs_dir1+"receptor.pdbqt"
                    shutil.copyfile(origin,target)
                    print("\n\nCopying receptor.pdbqt to "+vs_dir1+"!")

            # Handle IOError exception
            except IOError:
                print("\nIOerror! I can't find "+file2open+" file")
                return

            # Invoke show_done_message2()
            msg_out = "Virtual Screening->Simulation->Import Receptor"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define simulation_vs() method
    def simulation_vs(self):
        """Method to carry out docking screens"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Virtual Screening with AutoDock Vina..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Show yes/no question
        w_msg1 = self.advina_msg
        w_msg2 = " Virtual screening may take a while!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Try to open vs_par.csv file
            try:
                file2open = self.program_root+"misc/data/vs_par.csv"
                fo_par = open(file2open,"r")
                csv_par = csv.reader(fo_par)

                # Looping through csv_par
                for line in csv_par:
                    if "#" not in str(line):
                        if line[0] == "vs_dir":
                            vs_dir = line[1]
                        elif line[0] == "mol_dir":
                            mol_dir = line[1]
                        elif line[0] == "config_in":
                            config_in = line[1]

                # Close file
                fo_par.close()

            # Handle IOError exception
            except IOError:
                print("\nIOerror! I can't find "+file2open+" file")
                return

            # Set up vs_dir1 in the project_dir_string
            vs_dir1 = project_dir_string+vs_dir

            # Instantiate an object of VS()
            lig0 = tk_virtual.Screening(self.program_root,project_dir_string,
                                        vs_dir1,mol_dir,config_in,root)

            # Invoke working_GUI() method
            lig0.working_GUI()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No Requests!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define merge_vs() method
    def merge_vs(self):
        """Method to merge virtual screening results performed with
        AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Merging virtual screening results..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Try to open vs_par.csv
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo_vs_par = open(file2open,"r")
            csv_vs_par = csv.reader(fo_vs_par)

            # Looping through csv_vs_par
            for line in csv_vs_par:
                if line[0] == "vs_dir":
                    vs_dir = line[1]
                elif line[0] == "mol_dir":
                    mol_dir = line[1]
                elif line[0] == "lig_root_out":
                    lig_root_out = line[1]

            # Close file
            fo_vs_par.close()

        # Handle IOError:
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Set up vs_dir1
        vs_dir1 = project_dir_string+vs_dir+mol_dir

        # Get directories using os.listdir()
        list_all = os.listdir(vs_dir1)

        # Set up empty list
        dir_list = []

        # Looping through list_all to get directories only
        for line in list_all:

            # Get directories only
            if ".pdbqt" not in str(line):
                dir_list.append(line)

        # Get the number of structures
        n_lig = len(dir_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "There are "+str(n_lig)+" molecules in the dataset.\n"
        w_msg2 += "Merging may take a while."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Get vs_string
            vs_string = str(self.input_vs_csv_file_entry)

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Try to open lowest_rmsd_pdb.csv
            try:
                file2open = project_dir_string+"lowest_RMSD_PDB.csv"
                fo_lowest_PDB = open(file2open,"r")
                csv_lowest_PDB = csv.reader(fo_lowest_PDB)

                # Looping through
                for line in csv_lowest_PDB:
                    if line[0] == "PDB":
                        pdb = line[1]
                    elif line[0] == "Resolution(A)":
                        resolution = line[1]

                # Close file
                fo_lowest_PDB

            # Handle IOError exception
            except IOError:
                print("\nI can't find "+file2open+" file!")
                return

            # Looping through dir_list
            for mol in dir_list:
                print(mol)

                # Run vina_split
                os.system(self.program_root+\
                    "misc/linux_third_party_software/vina/./vina_split --input "+\
                    vs_dir1+mol+"/poses.pdbqt --ligand "+\
                    vs_dir1+mol+"/pose_")

            # Instantiate an object of MergeVS() class
            po0 = dock_s_data.MergeVS(self.program_root,project_dir_string,
            lig_root_out,vs_string)

            # invoke add_data() method
            po0.add_data(vs_dir,mol_dir,dir_list,pdb,resolution)

            # Invoke show_done_message2()
            msg_out = "Merge VS Results"
            self.show_done_message2(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No statistical analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define sort_vs() method
    def sort_vs(self):
        """Method to sort virtual screening results obtained using
        AutoDock Vina"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Try to open vs_par.csv
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo_vs_par = open(file2open,"r")
            csv_vs_par = csv.reader(fo_vs_par)

            # Looping through csv_vs_par
            for line in csv_vs_par:
                if line[0] == "vs_dir":
                    vs_dir = line[1]
                elif line[0] == "mol_dir":
                    mol_dir = line[1]
                elif line[0] == "lig_root_out":
                    lig_root_out = line[1]

            # Close file
            fo_vs_par.close()

        # Handle IOError:
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Set up vs_dir1
        vs_dir1 = project_dir_string+vs_dir+mol_dir

        # Get directories using os.listdir()
        list_all = os.listdir(vs_dir1)

        # Set up empty list
        dir_list = []

        # Looping through list_all to get directories only
        for line in list_all:

            # Get directories only
            if ".pdbqt" not in str(line):
                dir_list.append(line)

        # Get the number of structures
        n_lig = len(dir_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "There are "+str(n_lig)+" molecules in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Ready to sort VS results!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Test answer
        if result:

            # Get vs_string
            vs_string = str(self.input_vs_csv_file_entry)

            # Set sorted file name string
            sorted_vs_string = vs_string.replace(".csv","")+"_sorted.csv"

            # Instantiate an object of the DataVS() class
            vs1 = tk_sorting.DataVS(self.program_root,project_dir_string,
            root,"Affinity(kcal/mol)")

            # Invoke prep_GUI() method
            vs1.prep_GUI(vs_string,sorted_vs_string)


        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No sorting performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define sort_vs_ml() method
    def sort_vs_ml(self):
        """Method to sort virtual screening results obtained using
        AutoDock Vina after application of joblib models"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Try to open vs_par.csv
        try:
            file2open = self.program_root+"misc/data/vs_par.csv"
            fo_vs_par = open(file2open,"r")
            csv_vs_par = csv.reader(fo_vs_par)

            # Looping through csv_vs_par
            for line in csv_vs_par:
                if line[0] == "vs_dir":
                    vs_dir = line[1]
                elif line[0] == "mol_dir":
                    mol_dir = line[1]
                elif line[0] == "lig_root_out":
                    lig_root_out = line[1]

            # Close file
            fo_vs_par.close()

        # Handle IOError:
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Set up vs_dir1
        vs_dir1 = project_dir_string+vs_dir+mol_dir

        # Get directories using os.listdir()
        list_all = os.listdir(vs_dir1)

        # Set up empty list
        dir_list = []

        # Looping through list_all to get directories only
        for line in list_all:

            # Get directories only
            if ".pdbqt" not in str(line):
                dir_list.append(line)

        # Get the number of structures
        n_lig = len(dir_list)

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "There are "+str(n_lig)+" molecules in the dataset."
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Invoke show_botton_msg() method
        msg_out = "Ready to sort VS results!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Test answer
        if result:

            # Get scoring function file name from strvs.in
            vs_string = self.read_vs_results_csv()

            # Set sorted file name string
            sorted_vs_string = vs_string.replace(".csv","")+"_sorted.csv"

            # Instantiate an object of the DataVS() class
            vs1 = tk_sorting.DataVS(self.program_root,project_dir_string,
            root,"RandomForestRegressorCV")

            # Invoke prep_GUI() method
            vs1.prep_GUI(vs_string,sorted_vs_string)

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No sorting performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define apply_selected_joblib2csv() method
    def apply_selected_joblib2csv(self):
        """Method to apply a selected joblib model a CSV file.
        This CSV file should be in SAnDReS 2.0 format"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Try to open ml.in file
        try:
            file2open = self.program_root+"misc/data/ml.in"
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up empty string
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Invoke show_short_msg() method
            msg1.show_short_msg(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Get scoring function file name from strscore.in
        sf_csv_in = self.read_score_results_csv()
        new_sf_csv_in = sf_csv_in.replace(".csv","_ml.csv")

        # Copy sf_csv_in to new_sf_vs_in
        source = project_dir_string+sf_csv_in
        target = project_dir_string+new_sf_csv_in
        shutil.copy(source,target)

        # Instantiate an object of the Model() class
        map1 = tk_joblib_vs.Model(self.program_root,project_dir_string,root)

        # Invoke pre_joblib_GUI() method
        map1.pre_joblib_GUI(new_sf_csv_in,"CSV File")

    # Define par2plot() method
    def par2plot(self):
        """Method to generate parameters for plotting"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Invoke read_it function
        bind_in = b_aff.read_it(project_dir_string)

        # Set up inputs
        file_in = self.read_score_results_csv().replace(".csv","_test.csv")
        file_out = file_in.replace(".csv",".pdf")
        X_label = "log("+bind_in+")"
        y_label = "RandomForestRegressorCV"

        # Instantiate an object of the Par() class
        p1 = tk_prep_plot.Par(self.program_root,
                            project_dir_string,
                            file_in,
                            file_out,
                            X_label,
                            y_label,
                            root)

        # Invoke pre_parameters_GUI() method
        p1.pre_parameters_GUI()

    # Define run_bivariate_analysis() method
    def run_bivariate_analysis(self):
        """Method to carry out bivariate statistical analysis"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Define get_col() function
        def get_col(file_in,header_in):
            """Function to read header and return column number"""

            # Try to open file_in
            file2open = project_dir_string+file_in
            try:
                fo = open(file2open,"r")
                csv_in = csv.reader(fo)

                # Looping through csv_in
                for line in csv_in:
                    i = 0
                    for col in line:
                        if header_in == col.strip():
                            break
                        i += 1
                    break

                # Close file
                fo.close()

                # Return i
                return i

            # Handle IOError exception
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return None

        # Define function to handle hash in a field
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a string"""

            # Test type_in
            if type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Undefined input!")
                return None

            # Return data
            return data_out

        ########################################################################
        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Running Scikit-Learn ("+self.sk_version+") and SciPy..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.scikit_ref)

        # Show yes/no question
        w_msg1 = self.sk_msg
        w_msg2 = "Correlation will be calculated using SciPy and Scikit-Learn. "
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)
        ########################################################################

        # Test answer
        if result:

            # Invoke create_plots_dir() method
            self.create_plots_dir()

            # Invoke create_backup_dir() method
            self.create_backup_dir()

            # Try to open a file
            file2open = self.program_root+"misc/data/bivariate_par.csv"
            try:
                fo_csv = open(file2open,"r")
                csv_data = csv.reader(fo_csv)

                # Looping through csv_data
                for line in csv_data:
                    if line[0].strip() == "data_file":
                        data_file = line[1].strip()
                    elif line[0].strip() == "stats_file":
                        stats_file = line[1].strip()
                    elif line[0].strip() == "X_col_label":
                        X_col_label = line[1].strip()
                        # Invoke get_col function
                        X_col = get_col(data_file,X_col_label)
                    elif line[0].strip() == "y_col_label":
                        y_col_label = line[1].strip()
                    elif line[0].strip() == "stats_calc_features":
                        stats_calc_features = int(line[1].strip())
                    elif line[0].strip() == "stats_calc_string":
                        stats_calc_string = line[1].strip()

                # Close file
                fo_csv.close()

            # Handle IOError exception
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

            # Try to backup a file
            # Invoke backup_all.make()
            backup_all.make(stats_file,project_dir_string,
                            project_dir_string+"backup/")

            # Open a new file
            file2create = project_dir_string+stats_file
            fo_stats_calc = open(file2create,"w")

            # Write header
            stats_calc_lines_out = "Method,r,p-value,r2,rho,"
            stats_calc_lines_out += "p-value,MSE,RMSE,SD,RSS,F-stat\n"
            print(stats_calc_lines_out)
            fo_stats_calc.write(stats_calc_lines_out)

            ####################################################################
            # Carry out statistical analysis for multiple methods
            if y_col_label == "All":

                # Set up all_mlr_methods list
                all_mlr_methods = []

                # Append "Affinity" to all_mlr_methods
                all_mlr_methods.append(stats_calc_string)

                # Read regression methos (mlr_method) in ml_par.csv
                # Try to open mlr_method
                try:
                    file2open = self.program_root+"misc/data/ml_par.csv"
                    fo_ml_par = open(file2open,"r")
                    csv_ml_par = csv.reader(fo_ml_par)
                except IOError:
                    print("\nIOError! I can't find "+file2open+"!")
                    return

                # Looping through input file to get mlr_methods
                for line in csv_ml_par:
                    if "#" in line[0]:
                        continue
                    elif line[0] == "mlr_method":
                        mlr_method_in = handle_hash("str",str(line[1]))
                        all_mlr_methods.append(mlr_method_in)

                # Close file
                fo_ml_par.close()

                # Open reference_file
                file2open = project_dir_string+data_file

                # Looping through all_mlr_method
                for method in all_mlr_methods:

                    # Invoke get_col() function
                    y_col = get_col(data_file,method)

                    # Get numerical data
                    array1 =np.genfromtxt(file2open,delimiter=",",skip_header=1)
                    stats_calc_X = array1[:,X_col]
                    stats_calc_y = array1[:,y_col]

                    # Instantiate an object of Metrics() class
                    stats_calc_1 = bi_analysis.Metrics(stats_calc_X,
                                        stats_calc_y,False,stats_calc_features)

                    # Invoke bundle() method
                    corr_p,pvalue_p,r2,corr_s,pvalue_s,mse,rmse_model,s_dev,\
                        rss,f_stats,stats_results = stats_calc_1.bundle()

                    # Write results
                    stats_calc_lines_out = method+","+stats_results
                    print(stats_calc_lines_out)
                    fo_stats_calc.write(stats_calc_lines_out)

                # Invoke show_done_message2()
                msg_out = "Bivariate Analysis"
                self.show_done_message2(msg_out)

            else:

                # Set up method
                method = y_col_label

                # Open reference_file
                file2open = project_dir_string+data_file

                # Invoke get_col() function
                y_col = get_col(data_file,method)

                # Get numerical data
                array1 = np.genfromtxt(file2open,delimiter=",",skip_header=1)
                stats_calc_X = array1[:,X_col]
                stats_calc_y = array1[:,y_col]

                # Instantiate an object of Metrics() class
                stats_calc_1 = bi_analysis.Metrics(stats_calc_X,stats_calc_y,
                                                    False,stats_calc_features)

                # Invoke bundle() method
                corr_p,pvalue_p,r2,corr_s,pvalue_s,mse,rmse_model,s_dev,rss,\
                    f_stats,stats_results = stats_calc_1.bundle()

                # Write results
                stats_calc_lines_out = method+","+stats_results
                print(stats_calc_lines_out)
                fo_stats_calc.write(stats_calc_lines_out)

                # Invoke show_done_message2()
                msg_out = "Bivariate Analysis"
                self.show_done_message2(msg_out)

            # Close file
            fo_stats_calc.close()

        else:
            # Invoke show_botton_msg() method
            msg_out = "Done! No bivariate analysis performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define get_molegro_data() method
    def get_molegro_data(self):
        """Method to convert Molegro Virtual Dockers CSV file to
         SAnDReS 2.0 format"""

        # Import package
        from tkinter import messagebox

        # Get project directory
        project_dir_string = self.read_strdir()

        # Show yes/no question
        w_msg1 = self.program_id
        w_msg2 = "Molegro data will be converted to SAnDReS format."
        w_msg2 +="\nPDB codes are randomly generated for internal labeling "
        w_msg2 += "purposes only and should not be considered as representing "
        w_msg2 += "a structure deposited in the PDB!"
        w_msg2 += "\nDo you wish to continue?"
        result = messagebox.askyesno(w_msg1,w_msg2)

        # Test answer
        if result:

            # Invoke create_plots_dir() method
            self.create_plots_dir()

            # Invoke create_backup_dir() method
            self.create_backup_dir()

            # Instantiate an object of tk_molegro() class
            t1 = tk_molegro.MVDData(self.program_root,project_dir_string,root)

            # Invoke my_GUI() method
            t1.my_GUI()

        else:

            # Instantiate an object of Messages() class
            msg1 = tk_msg.Messages(project_dir_string,root)

            # Invoke show_botton_msg() method
            msg_out = "Done! No convertion performed!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)
            return

    # Define create_backup_dir()
    def create_backup_dir(self):
        """Method to create a backup/ dir"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Check whether backup directory exits
        backup_dir = project_dir_string+"backup/"
        backup_dir_boolean = os.path.isdir(backup_dir)
        if backup_dir_boolean:
            # Show message
            print("\nThere is a backup directory!")
        else:
            # Try to make dir
            try:
                # Make dir
                os.mkdir(backup_dir)

                # Show message
                print("\nSuccessfully created a backup directory!")

            # Handle exception
            except:
                pass

    # Define create_plots_dir() method
    def create_plots_dir(self):
        """Method to create plots/ dir"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Check whether plots directory exits
        plots_dir = project_dir_string+"plots/"
        plots_dir_boolean = os.path.isdir(plots_dir)
        if plots_dir_boolean:
            # Show message
            print("\nThere is a plots directory!")
        else:
            # Try to make dir
            try:
                # Make dir
                os.mkdir(plots_dir)

                # Show message
                print("\nSuccessfully created a plots directory!")

            # Handle exception
            except:
                pass

    # Define tutorial_1() method
    def tutorial_1(self):
        """Method to open a flipbook with Tutorial 1"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Tutorial 1. Cyclin-Dependent Kinase 2 with IC50 Data"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(8)

    # Define tutorial_2() method
    def tutorial_2(self):
        """Method to open a flipbook with Tutorial 2"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Tutorial 2. Molegro Virtual Docker Data"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(47)

    # Define tutorial_3() method
    def tutorial_3(self):
        """Method to open a flipbook with Tutorial 3"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Tutorial 3. Docking of One Structure"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(55)

    # Define tutorial_4() method
    def tutorial_4(self):
        """Method to open a flipbook with Tutorial 4"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Tutorial 4. Cyclin-Dependent Kinase 2 with Ki Data"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(61)

    # Define userguide_flipbook() method
    def userguide_flipbook(self):
        """Method to open a flipbook with User Guide"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "SAnDReS User Guide"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(1)

    # Define faq_flipbook() method
    def faq_flipbook(self):
        """Method to open a flipbook with FAQ"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "FAQ. Frequently Asked Questions"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(71)

    # Define regression_flipbook() method
    def regression_flipbook(self):
        """Method to open a flipbook with regression methods"""

        # Get project directory
        project_dir_string = self.read_strdir()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(project_dir_string,root)

        # Invoke show_botton_msg() method
        msg_out = "Regression Methods"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Invoke go_flipbook() method
        self.go_flipbook(84)
