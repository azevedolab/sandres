#!/usr/bin/env python3
#
# Class to prepare an input file to generate scatter plots.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Import packages
from tkinter import *
from tools import preferences as prefs
from tools import prepare_plot as prep_plt

# Define Par() class
class Par(object):
    """Class to prepare an input file to generate scatter plots"""

    # Define constructor method
    def __init__(self,program_root,dir_in,file_in,file_out,X_label,
                        y_label,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.file_in = file_in
        self.file_out = file_out
        self.X_label = X_label
        self.y_label = y_label
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define pre_parameters_GUI() method
    def pre_parameters_GUI(self):
        """Method to invoke parameters_GUI() method """

        # Invoke parameters_GUI() method
        self.parameters_GUI()

    # Define parameters_GUI() method
    def parameters_GUI(self):
        """Method to set up a GUI and invoke parameters() method"""

        # Get project directory
        project_dir_string = str(self.dir_in)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Check screen resolution
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Set up top_txt_geom based on screen_width
        if screen_width >= 1900:
            pass
        elif screen_width >= 1200:
            top_txt_geom = "880x275+0+138"
        else:
            top_txt_geom = "880x300+0+138"

        # Creates child window
        top_txt = Toplevel()
        top_txt.title("Matplotlib: Visualization with Python")
        top_txt.geometry(top_txt_geom)

        # Widget for CSV file
        Label(top_txt,text="Input CSV File:").grid(row=1,column=0,stick=W)
        self.csv_entry = Entry(top_txt,width = 35)
        self.csv_entry.grid(row = 1, column = 1,stick = E)
        self.csv_entry.insert(0,self.file_in)

        # Widget for plot file
        Label(top_txt,text="Output Plot File:").grid(row=2,column=0,stick=W)
        self.plot_entry = Entry(top_txt,width = 35)
        self.plot_entry.grid(row = 2, column = 1,stick = E)
        self.plot_entry.insert(0,self.file_out)

        # Widget for X-axis
        Label(top_txt, text="X-axis Label:" ).grid(row = 3,column = 0, stick = W)
        self.X_label_entry = Entry(top_txt,width = 35)
        self.X_label_entry.grid(row = 3, column = 1,stick = E)
        self.X_label_entry.insert(0,self.X_label)

        # Widget for y-axis
        Label(top_txt, text="Y-axis Label:" ).grid(row = 4,column = 0, stick = W)
        self.y_label_entry = Entry(top_txt,width = 35)
        self.y_label_entry.grid(row = 4, column = 1,stick = E)
        self.y_label_entry.insert(0,self.y_label)

        # Label (Insert space to get the right position of botton bar)
        Label(top_txt, text = (self.win_y_offset_type_2-35)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for parameters
        Button(top_txt,text='Apply',command=self.parameters).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define parameters() method
    def parameters(self):
        """Method to generate an input file to be used to generate scatter
        plots"""

        # Get inputs
        chosen_file_in = str(self.csv_entry.get())
        chosen_file_out = str(self.plot_entry.get())
        chosen_X_label = str(self.X_label_entry.get())
        chosen_y_label = str(self.y_label_entry.get())

        # Instantiate an object of Scatter() class
        s = prep_plt.Scatter(self.program_root,self.dir_in,
                            chosen_file_in,chosen_file_out,
                            chosen_X_label,chosen_y_label)

        # Invoke bundle() method
        s.bundle()