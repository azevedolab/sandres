# Class to execute AutoDock Vina 1.2.3 (Trott & Olson, 2010;
# Eberhardt et al., 2021) to calculate energy terms based on the atomic
# coorddinates of a protein-ligand complex obtained during a virtual screening
# simulation.
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import os
import csv
import numpy as np

# Define Energy() class
class Energy(object):
    """Class to execute AutoDock Vina 1.2.3 to calculate energy terms based on
    the atomic coorddinates of a protein-ligand complex obtained during a
    virtual screening simulation"""

    # Define constructor method
    def __init__(self,program_root,structure_receptor,structure_pose,
            dir_poses,data_out):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.structure_receptor = structure_receptor
        self.structure_pose = structure_pose
        self.dir_poses = dir_poses
        self.data_out = data_out
        self.weights = np.zeros(6,float)

        # Try to open vina_par.csv
        file2open = self.program_root+"misc/data/vina_par.csv"
        try:
            fo_par = open(file2open,"r")
            csv_par = csv.reader(fo_par)

            # Looping through csv_par
            for line in csv_par:
                if str(line[0]) == "score_only_vina":
                    self.vina_command_line = str(line[1])
                    break

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

    # Define calc() method
    def calc(self,log_f):
        """Method to calculate energy terms using AutoDock Vina 1.2.3"""

        # Get weights
        w_gauss1 = self.weights[0]
        w_gauss2 = self.weights[1]
        w_rep = self.weights[2]
        w_hydrophobic = self.weights[3]
        w_hydrogen = self.weights[4]
        w_rot = self.weights[5]

        # Run AutoDock Vina 1.2.3 for energy calculation
        # ./vina --receptor receptor.pdbqt --ligand lig.pdbqt --score_only --log log.txt
        os.system(self.program_root+\
            "misc/linux_third_party_software/vina/./vina_1.2.3 --receptor "+\
            self.structure_receptor+" --ligand "+self.structure_pose+\
            " "+self.vina_command_line+\
            " --weight_gauss1 "+str(w_gauss1)+\
            " --weight_gauss2 "+str(w_gauss2)+\
            " --weight_repulsion "+str(w_rep)+\
            " --weight_hydrophobic "+str(w_hydrophobic)+\
            " --weight_hydrogen "+str(w_hydrogen)+\
            " --weight_rot "+str(w_rot)+\
            " > "+self.dir_poses+log_f)


    # Define calc_affinity() method
    def calc_affinity(self,log_f):
        """Method to calculate affinity using AutoDock Vina 1.2.3"""

        # Run AutoDock Vina 1.2.3 for energy calculation
        # ./vina --receptor receptor.pdbqt --ligand lig.pdbqt --score_only --log log.txt
        os.system(self.program_root+\
            "misc/linux_third_party_software/vina/./vina_1.2.3 --receptor "+\
            self.structure_receptor+" --ligand "+\
            self.structure_pose+\
            " "+self.vina_command_line+\
            " > "+self.dir_poses+log_f)

    # Define gauss1() method
    def gauss1(self):
        """Method to calculate gauss1 energy term using AutoDock Vina 1.2.3 """

        # Set up self.weights array for a specific energy term
        self.weights[0] = 1.0   # Gauss 1
        self.weights[1] = 0.0   # Gauss 2
        self.weights[2] = 0.0   # Repulsion
        self.weights[3] = 0.0   # Hydrophobic
        self.weights[4] = 0.0   # Hydrogen
        self.weights[5] = 0.0   # Torsional

        # Invoke calc() method
        self.calc("gauss1.log")

    # Define gauss2() method
    def gauss2(self):
        """Method to calculate gauss2 energy term using AutoDock Vina 1.2.3 """

        # Set up self.weights array for a specific energy term
        self.weights[0] = 0.0   # Gauss 1
        self.weights[1] = 1.0   # Gauss 2
        self.weights[2] = 0.0   # Repulsion
        self.weights[3] = 0.0   # Hydrophobic
        self.weights[4] = 0.0   # Hydrogen
        self.weights[5] = 0.0   # Torsional

        # Invoke calc() method
        self.calc("gauss2.log")

    # Define repulsion() method
    def repulsion(self):
        """Method to calculate repulsion energy term using
        AutoDock Vina 1.2.3 """

        # Set up self.weights array for a specific energy term
        self.weights[0] = 0.0   # Gauss 1
        self.weights[1] = 0.0   # Gauss 2
        self.weights[2] = 1.0   # Repulsion
        self.weights[3] = 0.0   # Hydrophobic
        self.weights[4] = 0.0   # Hydrogen
        self.weights[5] = 0.0   # Torsional

        # Invoke calc() method
        self.calc("repulsion.log")

    # Define hydrophobic() method
    def hydrophobic(self):
        """Method to calculate hydrophobic energy term using
        AutoDock Vina 1.2.3 """

        # Set up self.weights array for a specific energy term
        self.weights[0] = 0.0   # Gauss 1
        self.weights[1] = 0.0   # Gauss 2
        self.weights[2] = 0.0   # Repulsion
        self.weights[3] = 1.0   # Hydrophobic
        self.weights[4] = 0.0   # Hydrogen
        self.weights[5] = 0.0   # Torsional

        # Invoke calc() method
        self.calc("hydrophobic.log")

    # Define hydrogen() method
    def hydrogen(self):
        """Method to calculate hydrogen energy term using
        AutoDock Vina 1.2.3 """

        # Set up self.weights array for a specific energy term
        self.weights[0] = 0.0   # Gauss 1
        self.weights[1] = 0.0   # Gauss 2
        self.weights[2] = 0.0   # Repulsion
        self.weights[3] = 0.0   # Hydrophobic
        self.weights[4] = 1.0   # Hydrogen
        self.weights[5] = 0.0   # Torsional

        # Invoke calc() method
        self.calc("hydrogen.log")

    # Define affinity() method
    def affinity(self):
        """Method to calculate affinity terms using AutoDock Vina 1.2.3 """

        # Invoke calc() method
        self.calc_affinity("affinity.log")

    # Define read_terms() method
    def read_terms(self):
        """Method to read energy terms"""

        # Set up an empty list
        self.list_e_terms = []

        # Set up list of files to be read
        reading_list = ["gauss1.log","gauss2.log","repulsion.log",
        "hydrophobic.log","hydrogen.log"]

        # Looping through reading_list
        for term in reading_list:

            # Try to open a file
            file2open = self.dir_poses+term
            try:
                fo_term = open(file2open,"r")
                term_lines = fo_term.readlines()

                # Looping term_lines:
                for line in term_lines:
                    if "(1) Final Intermolecular Energy    :" in str(line):

                        # Some editing
                        i_1 = str(line).index(":")
                        i_2 = str(line).index("(kcal/mol)")
                        data_line = str(line)[i_1+1:i_2]
                        data_line = data_line.replace(" ","")
                        self.list_e_terms.append(float(data_line))

                        # Close file
                        fo_term.close()
                        break

            # Handle IOError exception
            except IOError:
                print("\nIOError! I can't find "+file2open+" file!")
                return

        # For Torsional Free Energy (log(torsion + 1))
        # Try to open pose_##.pdbqt
        try:
            file2open = self.structure_pose
            fo_lig_tor = open(file2open,"r")
            lig_tor_lines = fo_lig_tor.readlines()

            # Looping through lig_tor_lines
            for line in lig_tor_lines:
                if "TORSDOF" in str(line):
                    # Try to calculate otherwise assign 0.0 to torsional term
                    try:
                        data_line = np.log10(1.0 + float(line[7:].strip()))
                        self.list_e_terms.append(data_line)
                    # Handle exception
                    except:
                        self.list_e_terms.append(0.0)

                    # Give me break
                    break

            # Close file
            fo_lig_tor.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

        # Try to open a file
        file2open = self.dir_poses+"affinity.log"
        try:
            fo_term = open(file2open,"r")
            term_lines = fo_term.readlines()

            # Looping term_lines:
            for line in term_lines:
                if "Estimated Free Energy of Binding   :" in str(line):

                    # Some editing
                    i_1 = str(line).index(":")
                    i_2 = str(line).index("(kcal/mol)")
                    data_line = str(line)[i_1+1:i_2]
                    data_line = data_line.replace(" ","")
                    self.list_e_terms.append(float(data_line))

                    # Close file
                    fo_term.close()
                    break

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

    # Define write_terms() method
    def write_terms(self):
        """Method to write energy terms in a log file with a structure based on
        the format used for log files in AutoDock Vina 1.1.2, as shown below:

Affinity: -5.52182 (kcal/mol)
Intermolecular contributions to the terms, before weighting:
    gauss 1     : 70.00551
    gauss 2     : 1170.23336
    repulsion   : 4.31803
    hydrophobic : 12.20180
    Hydrogen    : 2.00000

        """

        # Open new file
        file2create = self.data_out
        f_out = open(file2create,"w")

        # Set up data
        l_out = "Affinity: "+str(self.list_e_terms[6])+" (kcal/mol)\n"
        l_out +="Intermolecular contributions to the terms, before weighting:\n"
        l_out += "    gauss 1     : "+str(self.list_e_terms[0])+"\n"
        l_out += "    gauss 2     : "+str(self.list_e_terms[1])+"\n"
        l_out += "    repulsion   : "+str(self.list_e_terms[2])+"\n"
        l_out += "    hydrophobic : "+str(self.list_e_terms[3])+"\n"
        l_out += "    Hydrogen    : "+str(self.list_e_terms[4])+"\n"
        l_out += "    Torsional   : "+str(self.list_e_terms[5])+"\n"

        # Write data
        f_out.write(l_out)

        # Close file
        f_out.close()

    # Define bundle() method
    def bundle(self):
        """Method to calculate all energy terms of AutoDock Vina 1.2.3 scoring
        function"""

        # Invoke gauss1() method
        self.gauss1()

        # Invoke gauss2() method
        self.gauss2()

        # Invoke repulsion() method
        self.repulsion()

        # Invoke hydrophobic() method
        self.hydrophobic()

        # Invoke hydrogen() method
        self.hydrogen()

        # Invoke affinity() method
        self.affinity()

        # Invoke read_terms() method
        self.read_terms()

        # Invoke write_terms() method
        self.write_terms()