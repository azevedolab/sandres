# Import packages
import csv
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import array
import math
from os import path, mkdir
import time
import shutil
from tools import preferences as prefs

# Define Plots() class
class Plots(object):
    """Class to generate plot using Matplotlib"""

    # Define constructor method
    def __init__(self,program_root,plt_dir):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.plt_dir = plt_dir  # Project directory+"plots/" (string)

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        self.win_height_type_1,self.win_y_offset_type_1,\
        _,_,\
        _,_,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define show_version() method
    def show_version(self):
        """Method to show matplotlib version"""

        import matplotlib

        # Show matplotlib version
        print("\nCurrent Matplot Version: ",matplotlib.__version__)

    # Define generate() method
    def generate(self,x,y,
                nres,
                x_label_in,xlabel_font_size,
                y_label_in,ylabel_font_size,
                title_in,title_size_in,
                plt_bar_color,
                file_out,dpi_in):
        """Method to generate a bar plot"""

        # Import library
        import matplotlib.pyplot as plt

        # Close previously created window, if it exists
        try:
            plt.close()
        except:
            pass

        # Generate plot
        plt.bar(x,y,color=plt_bar_color)
        plt.xlabel(x_label_in,fontsize=xlabel_font_size)
        plt.ylabel(y_label_in,fontsize=ylabel_font_size)
        plt.title(title_in,fontsize=title_size_in)

        # Set up x-axis range
        plt.xlim(0,nres+2)

        # Saves plot file
        plt.savefig(self.plt_dir+file_out,dpi=float(dpi_in))