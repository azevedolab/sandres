# Class for Graphical User Interface and to manage adding binding affinity data.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
from tkinter import *
from tools import string_tools as str_tools
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import lig_database as lig_data

# Instantiate an object of the Palavra class
a1 = str_tools.Palavra("","pdb_codes.csv")

# Invoke ascii_art() method
_,pdb_ascii_art,_,_,_,_,_ = a1.ascii_art()

# Define LigData() class
class LigData(object):
    """Class to handle ligand data"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Set up PDB message
        self.ref_pdb = "\nWhen using PDB data for machine learning modeling, "
        self.ref_pdb += "please cite: Veit-Acosta M, de Azevedo Junior WF. "
        self.ref_pdb += "The Impact of Crystallographic Data for the "
        self.ref_pdb += "Development of Machine Learning Models to Predict "
        self.ref_pdb += "Protein-Ligand Binding Affinity. Curr Med Chem. 2021;"
        self.ref_pdb += " doi: 10.2174/0929867328666210210121320. "
        self.ref_pdb += "PMID: 33568025."
        self.pdb_short_msg = pdb_ascii_art+self.ref_pdb

    # Define ligand_GUI() method
    def ligand_GUI(self):
        """GUI to handle ligand information in internal datasets"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Instantiate an object of the Palavra class
        p1 = str_tools.Palavra(project_dir_string,"")

        # Invoke show_short_msg() method
        msg1.show_short_msg(self.pdb_short_msg+"\n")

        # Define functions to handle ligand data
        def ligand_ki():
            """Function to read Ki and ligand data"""

            # Invove progress_bar_ligand() method
            self.progress_bar_ligand(project_dir_string,"Ki")

        def ligand_kd():
            """Function to read Kd and ligand data"""

            # Invoke progress_bar_ligand() method
            self.progress_bar_ligand(project_dir_string,"Kd")

        def ligand_ic50():
            """Function to read IC50 and ligand data"""

            # Invoke progress_bar_ligand() method
            self.progress_bar_ligand(project_dir_string,"IC50")

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)(80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('Ligand Data')
        top_txt.geometry(top_txt_geom)

        # Widgets for binding affinity
        Label(top_txt,text="Type of Binding Affinity:"\
            ).grid(row=1,column=0,stick=W)

        # Widgets for binding affinity buttons
        Button(top_txt,text='Inhibition Constant (Ki)',
            command=ligand_ki).grid(row=2,column=0,sticky = W)
        Button(top_txt,text='Dissociation Constant (Kd)',
            command=ligand_kd).grid(row=2,column=1,sticky = W)
        Button(top_txt,text='Half-maximal Inhibitory Concentration (IC50)',
            command=ligand_ic50).grid(row=2,column=2, sticky=W)

        # Show Empty Label
        Label(top_txt, text=4*" ", font = "Arial" ).grid(row = 2,
            column = 4, stick = W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
            command=top_txt.destroy).grid(row = 3, column = 11,sticky = E)

    # Define progress_bar_ligand() method
    def progress_bar_ligand(self,dir_in,bind_in):
        """Method to read ligand data"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Instantiate an object of the Palavra class
        p1 = str_tools.Palavra(project_dir_string,"pdb_codes.csv")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke count_codes() method
        number_of_pdbs = p1.count_codes()

        # Call show_short_msg() method
        short_msg = "\nThere are "+str(number_of_pdbs)+\
        " structures in this dataset"
        msg1.show_short_msg(short_msg)

        # Invoke list_pdb() method
        pdb_list = p1.list_pdb()

        # Invoke backup_file() method
        p1.backup_file("bind_"+bind_in+".csv")

        # Invoke backup_file() method
        my_bind_log = "bind_"+bind_in+".log"
        p1.backup_file(my_bind_log)

        # Create bind_###.log file
        fo_bind_log = open(project_dir_string+my_bind_log,"w")

        # Set up empty lists
        list_of_binding = []
        list_of_actives = []

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160)(52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_3,self.win_y_offset_type_3)

        # Define append_data() function
        def append_data():

            # Invoke show_botton_msg() method
            msg_out = "Reading ligand dataset..."
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

            # Open new csv file
            fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","w")

            # Assign zero to count_ligands
            count_ligands = 0

            # Write first line
            fo_bind.write("PDB,Ligand,Chain,Number,Resolution(A),"+\
            "Ligand Occupation Factor,"+str(bind_in)+\
            "(M),log("+str(bind_in)+"),"+\
            "p"+str(bind_in)+"\n")

            # Looping through binding affinity data
            for i in range(len(pdb_list)):

                # To handle exceptions related to the Done button
                try:
                    #if number_of_pdbs != 0:
                    if count_ligands != 0:
                        pr_bar_02["value"] = i*100/count_ligands
                    else:
                        pr_bar_02["value"] = i*100
                    root.update()
                except:
                    return

                # Try to get ligand information
                try:

                    # Instantiate an object of Messages() class
                    msg2 = tk_msg.Messages(self.strdir_entry,self.root)

                    # Invoke show_botton_msg() method
                    msg_out = "SAnDReS successfully added binding affinity "
                    msg_out += "data for structure "+str(pdb_list[i])
                    msg2.show_botton_msg(msg_out,"black","light grey")

                    # Instantiate an object of the LIG() class
                    lig_obj=lig_data.LIG(self.program_root,bind_in,pdb_list[i])

                    # Invoke read_data() method
                    # (check list_of_actives, list_of_binding)
                    active,lig_chain_id,lig_pos,x_resol,lig_occ_factor,\
                    lig_binding,log_10_bind,\
                    minus_log_10_bind = lig_obj.read_data()

                    # Set up line__out
                    line__out = pdb_list[i]+","+str(active)+","+\
                    str(lig_chain_id)+","+str(lig_pos)+","+str(x_resol)+","+\
                    str(lig_occ_factor)+","+\
                    str(lig_binding)+","+\
                    str(log_10_bind)+","+\
                    str(minus_log_10_bind)
                    fo_bind.write(line__out+"\n")
                    fo_bind_log.write(line__out+"\n")
                    count_ligands += 1
                except:

                    # Instantiate an object of Messages() class
                    msg3 = tk_msg.Messages(self.strdir_entry,self.root)

                    # Invoke show_botton_msg() method
                    msg_out = "Warning! SAnDReS couldn't add binding affinity "
                    msg_out += "data for structure: "+str(pdb)+"!"
                    msg3.show_botton_msg(msg_out,"grey","white")
                    print(msg_out)

                    pass

            # Close files
            fo_bind.close()
            fo_bind_log.close()

            # Show log file content on window_txt
            msg1.read_log_file(my_bind_log)

            # Try to open binding affinity file
            try:
                fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
                my_csv = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+\
                project_dir_string+"bind_"+bind_in+".csv file!")

            # Set up empty lists for plotting
            x_resol_list = []
            log_binding = []

            # Set up the list of allowed PDBs
            for line in my_csv:
                break
            for line in my_csv:

                # Try to append resolution
                try:
                    x_resol_list.append(float(line[4]))
                except:
                    x_resol_list.append(None)

                # Try to append log_binding()
                try:
                    log_binding.append(float(line[7]))
                except:
                    log_binding.append(None)

            # Prepare labels for x_resol and log_binding
            xlabel1 = ""
            ylabel1 = "Resolution ($\AA$)"
            if bind_in == "Ki":
                xlabel2 = "Structures with K$_i$ Data"
                ylabel2 = "log$_{10}$(K$_i$)"
            elif bind_in == "Kd":
                xlabel2 = "Structures with K$_d$ Data"
                ylabel2 = "log$_{10}$(K$_d$)"
            else:
                xlabel2 = "Structures with I$_{50}$ Data"
                ylabel2 = "log$_{10}$(IC$_{50}$)"

            # Import plotting as san_plt
            from tools import plotting as san_plt

            # Instantiate an object of Plots() class
            my_plot1 = san_plt.Plots(self.program_root,project_dir_string+"plots/")

            # Call plot_two_lists() method to generate a plot for x_resol
            # and log_binding 871x340+0+40 (871,40,4.8,5.0,0.95,)
            my_plot1.plot_two_lists(0.95,
                                x_resol_list,xlabel1,6,ylabel1,
                                log_binding,xlabel2,8,ylabel2,
                                "resol_binding.pdf",
                                900,
                                "pdf",
                                "")

            # Checking PDB without binding affinity
            # Try to open binding affinity file
            try:
                fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
                my_csv = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+\
                project_dir_string+"bind_"+bind_in+".csv file!")

            # Set up an empty lists
            binding_affinity_pdb = []
            no_binding_affinity_pdb = []

            # Looping through my_csv
            for line in my_csv:
                break
            for line in my_csv:
                if str(line[0]) in pdb_list:
                    binding_affinity_pdb.append(line[0])
                else:
                    no_binding_affinity_pdb.append(line[0])

            # Open new file with PDB access codes without binding affinity
            fo_no_bind = open(project_dir_string+"no_binding_"+bind_in+".csv","w")

            # Looping through my_csv
            for line in my_csv:
                break
            for line in my_csv:
                binding_affinity_pdb.append(str(line[0]))

            # Looping through pdb_list to get those without binding data
            for pdb in pdb_list:
                if pdb in binding_affinity_pdb:
                    pass
                else:
                    no_binding_affinity_pdb.append(pdb)

            # Try to get the first PDB
            try:
                fo_no_bind.write(str(no_binding_affinity_pdb[0]))
            except:
                pass

            # try to looping through no_binding_affinity_pdb for
            # the rest of PDBs
            for pdb in no_binding_affinity_pdb[1:]:
                try:
                    fo_no_bind.write(","+str(pdb))
                except:
                    pass

            # Close files
            fo_bind.close()
            fo_no_bind.close()

            # Show message
            msg_out = "SAnDReS finished \"Add Binding Affinity Data\" request! "
            msg_out += "Number of ligands: "+str(count_ligands)
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        # Set up progress bar (pr_bar_02)
        # Create child window
        root = tk.Tk()
        root.title('Read Ligand Data')
        root.geometry(top_txt_geom) #  870x52+0+540  length = 790
        pr_bar_02 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_02.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=append_data)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()