# Class to apply a selected joblib model.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import sklearn
import csv
from tkinter import *
from tools import string_tools as string_t
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import binding_affinity as b_aff
from MLRegMPy import ML_APPLY
from MLRegMPy import backup

# Instantiate an object of the Palavra class
a1 = string_t.Palavra("","pdb_codes.csv")

# Invoke ascii_art() method
_,_,_,_,_,_,scikit_art = a1.ascii_art()

# Define Model() class
class Model(object):
    """Class to apply a selected joblib model"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Get scikit-learn version
        self.sk_version = str(sklearn.__version__)

        # Set up message about the main reference for Scikit-Learn
        self.scikit_ref = "\nWhen using Scikit-Learn, please cite: "
        self.scikit_ref += "Pedregosa F, Varoquaux G, Gramfort A, "
        self.scikit_ref += "\nMichel V, Thirion B, Grisel O, Blondel M, "
        self.scikit_ref += "Prettenhofer P, Weiss R, Dubourg V, "
        self.scikit_ref += "\nVanderplas J, Passos A, Cournapeau D, "
        self.scikit_ref += "Brucher M, Perrot M, Duchesnay E. "
        self.scikit_ref += "\nScikit-learn: machine learning in python. "
        self.scikit_ref += "\nJ Mach Learn Res. 2011; 12: 2825-2830."
        self.scikit_short_msg = self.scikit_ref

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define pre_joblib_GUI() method
    def pre_joblib_GUI(self,file_in,type_of_results):
        """Method to invoke joblib_GUI() method """

        # Set up self.type_of_results
        self.type_of_results = type_of_results

        # Invoke joblib_GUI() method
        self.joblib_GUI(file_in)

    # Define joblib_GUI() method
    def joblib_GUI(self,file_in):
        """Method to call joblib"""

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Check screen resolution
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Set up top_txt_geom based on screen_width
        if screen_width >= 1900:
            pass
        elif screen_width >= 1200:
            top_txt_geom = "880x100+0+138"
        else:
            top_txt_geom = "880x80+0+138"

        # Creates child window
        top_txt = Toplevel()
        top_txt.title('Joblib Model')
        top_txt.geometry(top_txt_geom)

        # Widget for CSV file
        Label(top_txt,text="CSV File:").grid(row=1,column=0,stick=W)
        self.csv_in = Entry(top_txt,width = 25)
        self.csv_in.grid(row = 1, column = 1,stick = E)
        self.csv_in.insert(0,file_in)

        # Widget for regression method
        Label(top_txt, text="Regression Method:" ).grid(row = 2,column = 0, stick = W)
        self.joblib_entry = Entry(top_txt,width = 25)
        self.joblib_entry.grid(row = 2, column = 1,stick = E)
        self.joblib_entry.insert(0,"All") # RandomForestRegressorCV

        # Label (Insert space to get the right position of botton bar)
        Label(top_txt, text = (self.win_y_offset_type_2-25)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Joblib
        Button(top_txt,text='Apply',command=self.pre_joblib_model).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define pre_joblib_model() method
    def pre_joblib_model(self):
        """Method to handle selection of regression methods before applying
        them to the datset"""

        # Import library
        from tkinter import messagebox

        # Get regression method
        chosen_option = str(self.joblib_entry.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Check regression method
        if chosen_option.upper() == "ALL":

            # Define function to handle hash in a field
            def handle_hash(type_in,line_in):
                """Function to handle hash in a field and returns a string"""

                # Test type_in
                if type_in == "str":
                    # Handle hash for string output
                    try:
                        index_hash = str(line_in).index("#")
                        data_out = line_in[:index_hash]
                        data_out = data_out.replace(" ","")
                    except:
                        data_out = line_in.replace(" ","")
                else:
                    # Print error message and return
                    print("\nError! Undefined input!")
                    return None

                # Return data
                return data_out

            # Set up an empty list
            all_mlr_methods = []

            # Read regression methos (mlr_method) in ml_par.csv
            # Try to open mlr_method
            try:
                file2open = self.program_root+"misc/data/ml_par.csv"
                fo_ml_par = open(file2open,"r")
                csv_ml_par = csv.reader(fo_ml_par)
            except IOError:
                print("\nIOError! I can't find "+file2open+"!")
                return

            # Looping through input file to get mlr_methods
            for line in csv_ml_par:
                if "#" in line[0]:
                    continue
                elif line[0] == "mlr_method":
                    mlr_method_in = handle_hash("str",str(line[1]))
                    all_mlr_methods.append(mlr_method_in)

            # Close file
            fo_ml_par.close()

            # Looping through regression methods
            for method2apply in all_mlr_methods:

                # Invoke joblib_model2() method
                self.joblib_model2(method2apply)

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished the \"Apply Regression Model "
            msg_out += self.type_of_results
            msg_out += "\" request!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        else:
            print("Ready to apply "+chosen_option)

            # Invoke joblib_model1() method
            self.joblib_model1(chosen_option)

    # Define joblib_model1() method
    def joblib_model1(self,mlr_method):
        """Method to apply joblib model"""

        # Import library
        from tkinter import messagebox

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Get CSV file
        sf_file_in = str(self.csv_in.get())

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # # Invoke show_botton_msg() method
        msg_out = " Applying "+mlr_method+"..."
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)

        # Ask yes/no question
        m1 = "Do you want to apply this selected joblib model ("+mlr_method+")?"
        result = messagebox.askyesno("",m1)

        # Set up header
        stats_out  = "Method,r,p-value(r),r2,rho,p-value(rho),MSE,RMSE,"
        stats_out += "Standard Deviation,RSS,F-stat\n"

        # Test answer
        if result:

            # Invoke read_it function
            bind_in = b_aff.read_it(project_dir_string)

            # Set up exp_label
            exp_label = "log("+bind_in.replace(" ","")+")"

            # Show message
            print("\nAdding column method: ",mlr_method)

            # Assign variables related to the method strings
            model_in = "models/model_"+mlr_method+".joblib"
            new_label = mlr_method

            # Instantiate an object of JoblibModel() class
            pred = ML_APPLY.JoblibModel(project_dir_string,model_in,new_label)

            # Invoke bundle() method
            results = pred.bundle(sf_file_in,exp_label)

            # Add results
            stats_out += results

            # Invoke backup.make()
            backup.make("models/model_"+mlr_method+".csv",
            project_dir_string,project_dir_string+"backup/")

            # Open a new file
            file2create =  project_dir_string+"models/"
            file2create += sf_file_in.replace(".csv","_")+mlr_method+".csv"
            fo_stats = open(file2create,"w")

            # Write stats_out
            fo_stats.write(stats_out)

            # Close file
            fo_stats.close()

            # Invoke show_stats_on_screen() method
            file2stats = "models/"+sf_file_in.replace(".csv","_")
            file2stats += mlr_method+".csv"
            self.show_stats_on_screen(file2stats)

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished the \"Apply Regression Model "
            msg_out += self.type_of_results
            msg_out += "\" request!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

        else:
            # Invoke show_botton_msg() method
            msg_out="No request to apply a selected joblib model!"
            msg1.show_botton_msg(msg_out,"black","light grey")
            print(msg_out)

    # Define joblib_model2() methods
    def joblib_model2(self,mlr_method):
        """ Method to apply joblib models in a loop"""

        # Import library
        from tkinter import messagebox

        # Set up header
        stats_out  = "Method,r,p-value(r),r2,rho,p-value(rho),MSE,RMSE,"
        stats_out += "Standard Deviation,RSS,F-stat\n"

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Get CSV file
        csv_file_in = str(self.csv_in.get())

        # Invoke read_it function
        bind_in = b_aff.read_it(project_dir_string)

        # Set up exp_label
        exp_label = "log("+bind_in.replace(" ","")+")"

        # Show message
        print("\nAdding column method: ",mlr_method)

        # Assign variables related to the method strings
        model_in = "models/model_"+mlr_method+".joblib"
        new_label = mlr_method

        # Instantiate an object of JoblibModel() class
        pred = ML_APPLY.JoblibModel(project_dir_string,model_in,new_label)

        # Invoke bundle() method
        results = pred.bundle(csv_file_in,exp_label)

        # Add results
        stats_out += results

        # Invoke backup.make()
        backup.make("models/model_"+mlr_method+".csv",project_dir_string,
        project_dir_string+"backup/")

        # Open a new file
        file2create =  project_dir_string+"models/"
        file2create += csv_file_in.replace(".csv","_")+mlr_method+".csv"
        fo_stats = open(file2create,"w")

        # Write stats_out
        fo_stats.write(stats_out)

        # Close file
        fo_stats.close()

    # Define show_stats_on_screen() method
    def show_stats_on_screen(self,file_in):
        """Method to show statistical analysis on screen"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get project directory
        project_dir_string = str(self.strdir_entry)

        # Set up report_out message
        report_out = "\nSAnDReS determined metrics using Scikit-Learn ("
        report_out += str(self.sk_version)+") and SciPy.\n"
        report_out += self.scikit_ref

        # Try to open file_in
        file2open = project_dir_string+file_in
        try:
            fo_stats = open(file2open,"r")
            stats_data = csv.reader(fo_stats)
        except IOError:
            print("\nIOError! I can't  find "+file2open+" file!")
            return

        # Set up empty string
        stats_data_lines = ""

        # Looping through stats_data (first line)
        for line in stats_data:
            break

        # Header (Feature, r, p-value, r2, rho, p-value, MSE, RMSE, RSS)
        stats_data_lines += "\t\t\tMethod\t r \tp-value \t r2 \t rho "
        stats_data_lines += "\tp-value \t MSE \t RMSE \t SD \t RSS \t "
        stats_data_lines += "F-stat\n"

        # Looping through stats_data
        for line in stats_data:
            line_out = "{0:>30}".format(str(line[0]))
            aux_float = "{:.3f}".format(float(line[1]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[2]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[3]))
            line_out += "\t\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[4]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[5]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[6]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[7]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[8]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[9]))
            line_out += "\t"+str(aux_float)
            aux_float = "{:.3f}".format(float(line[10]))
            line_out += "\t"+str(aux_float)

            # Some editing
            aux_line = str(line_out).replace("[","")
            aux_line = aux_line.replace("]","")
            aux_line = aux_line.replace("'","")

            # Add line
            stats_data_lines += str(aux_line)+"\n"

        # Invoke show_short_msg() method
        msg1.show_short_msg(stats_data_lines+"\n\n"+report_out)

        # Close file
        fo_stats.close()
