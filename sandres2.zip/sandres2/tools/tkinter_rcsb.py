#!/usr/bin/env python3
#
# Class Class to access the site of Research Collaboratory for Structural
# Bioinformatics Protein Data Bank (RCSB PDB).
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import webbrowser
from tkinter import *
from tools import preferences as prefs
from tools import tkinter_messages as tk_msg

# Define RCSBPDB() class
class RCSBPDB(object):
    """Class to access the site of Research Collaboratory for Structural
    Bioinformatics Protein Data Bank (RCSB PDB)"""

    # Define constructor method
    def __init__(self,program_root,dir_in,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define pre_rcsb_GUI() method
    def pre_rcsb_GUI(self):
        """Method to invoke rcsb_GUI() method """

        # Invoke rcsb_GUI() method
        self.rcsb_GUI()

    # Define rcsb_GUI() method
    def rcsb_GUI(self):
        """Method to set up a GUI and invoke rcsb() method"""

        # Set up url
        # Try to open strrcsb.in
        file2open = self.program_root+"misc/inputs/strrcsb.in"
        try:
            f_site = open(file2open,"r")
            csv_site = csv.reader(f_site)

            # Looping through csv_site
            for line in csv_site:
                if line[0] == "rcsburl":
                    self.url_in = line[1]
                    break

            # Close file
            f_site.close()

        # Handle IOError exception
        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title("Research Collaboratory for Structural Bioinformatics PDB")
        top_txt.geometry(top_txt_geom)

        # Widget for RCSB PDB url
        Label(top_txt,text="RCSB URL:").grid(row=1,column=0,stick=W)
        self.url_entry = Entry(top_txt,width = 35)
        self.url_entry.grid(row = 1, column = 1,stick = W)
        self.url_entry.insert(0,self.url_in)

        # Widget for PDB access code
        Label(top_txt,text="PDB Access Code:").grid(row=2,column=0,stick=W)
        self.pdb_entry = Entry(top_txt,width = 4)
        self.pdb_entry.grid(row = 2, column = 1,stick = W)
        self.pdb_entry.insert(0,"2A4L")

        # Label (Insert space to get the right position of botton bar) (25)(34)
        Label(top_txt, text = (self.win_y_offset_type_2-48)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for rcsb advanced search
        Button(top_txt,text='RCSB Advanced Search ',
        command=self.rcsb_advanced_search).grid(row=4,
        column = 1, sticky = W)

        # Widgets for rcsb
        Button(top_txt,text='Webpage',command=self.rcsb).grid(row=4,
        column = 1, sticky = E)

        # Widgets for rcsb_structure
        Button(top_txt,text='3D View',
        command=self.rcsb_structure).grid(row=4,
        column = 2, sticky = E)

        # Widgets for rcsb_electron
        #Button(top_txt,text=' Electron Density',
        #        command=self.rcsb_electron).grid(row=4,column = 3, sticky = W)

        # Widgets for rcsb_validation
        #Button(top_txt,text=' Validation',
        #        command=self.rcsb_validation).grid(row=4,column = 3, sticky = W)

        # Widgets for rcsb_sequence
        Button(top_txt,text='Sequence',
                command=self.rcsb_sequence).grid(row=4,column = 3, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = W)


    # Define rcsb_advanced_search() method
    def rcsb_advanced_search(self):
        """Method to access RCSB PDB advanced search tools"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        siteurl = chosen_url.replace("structure","search/advanced")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # For MacOS
        #chrome_path = 'open -a /Applications/Google\ Chrome.app %s'

        # For Windows
        #chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'

        # For Linux
        #chrome_path = '/usr/bin/./google-chrome-stable %s'
        #chrome_path = '/opt/google/chrome/google-chrome '

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define rcsb() method
    def rcsb(self):
        """Method to access RCSB PDB site"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        chosen_pdb = str(self.pdb_entry.get())
        siteurl = chosen_url+chosen_pdb

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define rcsb_structure() method
    def rcsb_structure(self):
        """Method to access RCSB PDB with a structure view"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        chosen_pdb = str(self.pdb_entry.get())
        siteurl = chosen_url.replace("structure","3d-view")+chosen_pdb+"/1"

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define rcsb_electron() method
    def rcsb_electron(self):
        """Method to access RCSB PDB with an electron density view"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        chosen_pdb = str(self.pdb_entry.get())
        siteurl = chosen_url.replace("structure","3d-view")+chosen_pdb
        siteurl += "?preset=electronDensityMaps"

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define rcsb_ligand() method
    def rcsb_ligand(self):
        """Method to access RCSB PDB with a ligand view"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        chosen_pdb = str(self.pdb_entry.get())
        siteurl = chosen_url.replace("structure","3d-view")+chosen_pdb
        siteurl += "?preset=ligandInteraction&label_asym_id=B"

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define rcsb_validation() method
    def rcsb_validation(self):
        """Method to access RCSB PDB with a validation report"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        chosen_pdb = str(self.pdb_entry.get())
        siteurl = chosen_url.replace("structure","3d-view")+chosen_pdb
        siteurl += "?preset=validationReport"

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)

    # Define rcsb_sequence() method
    def rcsb_sequence(self):
        """Method to access RCSB PDB and show FASTA sequence"""

        # Get inputs
        chosen_url = str(self.url_entry.get())
        chosen_pdb = str(self.pdb_entry.get())
        siteurl = chosen_url.replace("structure","fasta/entry")+chosen_pdb
        siteurl +="/display"

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Try to start Chrome
        try:
            # Start Chrome
            webbrowser.get("google-chrome").open(siteurl)

        # Handle exception
        except:

            # Show message
            msg_out = "I can't start Chrome!"
            msg_out += "Please, check Chrome installation or RCSB URL."
            msg1.show_botton_msg(msg_out,"red","light grey")
            print(msg_out)