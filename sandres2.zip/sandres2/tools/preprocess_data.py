# Import packages
from sklearn.preprocessing import MaxAbsScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import StandardScaler
import numpy as np
import csv
import shutil
import time

# Define Pre_proc() class
class Pre_proc(object):
    """Class to preprocess data for machine learning modeling"""

    # Define constructor method
    def __init__(self,program_root,dir_in,file_out):
        """Define constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.file_out = file_out

        # Try to open parameter file
        try:
            file2open = self.program_root+"misc/data/ml_par.csv"
            fo_par = open(file2open,"r")
            csv_par = csv.reader(fo_par)

            # Looping through csv_par
            for line in csv_par:
                if "#" in line[0]:
                    pass
                elif line[0] == "preprocessing":
                    self.method_in = line[1]
                #elif line[0]  == "out":
                #    self.file_out = line[1]

            # Close file
            fo_par.close()

        except IOError:
            print("\nI cant find "+file2open+" file!")
            return

    # Define scaling() method
    def scaling(self):
        """Methods for preprocessing data"""

        # Reshape X array
        self.X = np.array(self.X).reshape(-1,1)

        # Choose the method
        if self.method_in == "StandardScaler":
            # https://towardsdatascience.com/scale-standardize-or-normalize-with-scikit-learn-6ccc7d176a02
            # StandardScaler standardizes a feature by subtracting the mean and then
            # scaling to unit variance. Unit variance means dividing all the values by the
            # standard deviation. StandardScaler does not meet the strict definition of
            # scale I introduced earlier.
            # StandardScaler results in a distribution with a standard deviation equal to 1.
            # The variance is equal to 1 also,
            # because variance = standard deviation squared. And 1 squared = 1.
            # StandardScaler makes the mean of the distribution 0.
            # About 68% of the values will lie be between -1 and 1.
            #
            # https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html

            #std_scaler = StandardScaler() # StandardScaler().fit_transform()
            #X_scaled = std_scaler.fit_transform(self.X)

            scaler = StandardScaler().fit(self.X)
            scaler
            self.X_scaled = scaler.transform(self.X)

        elif self.method_in == "MaxAbsScaler":
            # Scales in a way that the training data lies within the range [-1, 1]
            # by dividing through the largest maximum value in each feature.
            # It is meant for data that is already centered at zero or sparse data.
            # https://scikit-learn.org/stable/modules/preprocessing.html

            scaler = MaxAbsScaler()
            self.X_scaled = scaler.fit_transform(self.X)

        elif self.method_in == "MinMaxScaler":
            # For each value in a feature, MinMaxScaler subtracts the minimum value in the
            # feature and then divides by the range. The range is the difference between
            # the original maximum and original minimum.
            # MinMaxScaler preserves the shape of the original distribution.
            # It doesn’t meaningfully change the information embedded in the original data.
            # Note that MinMaxScaler doesn’t reduce the importance of outliers.
            # The default range for the feature returned by MinMaxScaler is 0 to 1.
            #
            # Notice how the features are all on the same relative scale.
            # The relative spaces between each feature’s values have been maintained.
            # MinMaxScaler is a good place to start unless you know you want your
            # feature to have a normal distribution or want outliers
            # to have reduced influence.
            # https://towardsdatascience.com/scale-standardize-or-normalize-with-scikit-learn-6ccc7d176a02

            scaler = MinMaxScaler()
            self.X_scaled = scaler.fit_transform(self.X)

        elif self.method_in == "RobustScaler":
            # RobustScaler transforms the feature vector by subtracting the median and
            # then dividing by the interquartile range (75% value — 25% value).
            # Like MinMaxScaler, our feature with large values — normal-big — is now of
            # similar scale to the other features. Note that RobustScaler does not scale
            # the data into a predetermined interval like MinMaxScaler. It does not meet
            # the strict definition of scale I introduced earlier.
            # Note that the range for each feature after RobustScaler is applied is larger
            # than it was for MinMaxScaler.
            # Use RobustScaler if you want to reduce the effects of outliers,
            # relative to MinMaxScaler.

            scaler = RobustScaler()
            self.X_scaled = scaler.fit_transform(self.X)

        elif self.method_in == "Normalizer":
            # Normalizer works on the rows, not the columns! I find that very unintuitive.
            # It’s easy to miss this information in the docs.
            # By default, L2 normalization is applied to each observation so the that the
            # values in a row have a unit norm. Unit norm with L2 means that if each
            # element were squared and summed, the total would equal 1.
            # Alternatively, L1 (aka taxicab or Manhattan) normalization can be applied
            # instead of L2 normalization.

            scaler = Normalizer()
            self.X_scaled = scaler.fit_transform(self.X)

        # Show mean and standard deviation
        print("\nMethod:",self.method_in)
        #print("Mean: {0:.4f}".format(np.mean(X_scaled)))
        #print("Mean: {0:.4f}".format(X_scaled.mean(axis=0)))
        print("Mean: ",self.X_scaled.mean(axis=0))
        #print("Standard Deviation: {0:.4f}".format(np.std(X_scaled)))
        print("Standard Deviation: ",self.X_scaled.std(axis=0))

    # Define read_column()
    def read_column(self,n_col):
        """Method to read bind_####.csv file"""

        # Set up a list
        bind_list = ["IC50","Kd","Ki"]

        # Set up an empty string
        lines_out = ""

        # Try to open bind_####.csv file
        for bind in bind_list:
            try:
                fo_bind = open(self.dir_in+"bind_"+bind+".csv","r")
                print("\nBinding affinity: ",bind)

                # Close file
                fo_bind.close()

                break
            except IOError:
                pass

        # Get numerical data
        array1 = np.genfromtxt(self.dir_in+"bind_"+bind+".csv",delimiter=",",skip_header=1)
        self.X = array1[:,n_col:n_col+1]

    # Define bundle() method
    def bundle(self):
        """Method to bundle together all necessary steps to preprocess data"""

        # Set up a list
        bind_list = ["IC50","Kd","Ki"]

        # Set up empty string
        data_out = ""

        # Try to open bind_####.csv file to identify the binding type
        for bind in bind_list:
            try:
                fo_bind = open(self.dir_in+"bind_"+bind+".csv","r")

                # Close file
                fo_bind.close()

                break
            except IOError:
                pass

        # Try to open bind_###.csv file
        try:
            # Get numerical data
            array_in = np.genfromtxt(self.dir_in+"bind_"+bind+".csv",delimiter=",",
            skip_header=1)

        # Handle exceptions
        except IOError:
            msg_out = "\nIOError! I can't find "+self.dir_in
            msg_out += "bind_"+bind+".csv file!"
            print(msg_out)
            return

        # Set up number of rows and number of columns
        n_rows =  len(array_in[0:,0])
        n_cols = len(array_in[0,:])

        # Set up list of columns not to be scaled
        ex_list = [6,7,8,9,24]

        # Looping through numerial data
        for j in range(5,n_cols):
            if j not in ex_list:
                self.X = np.zeros(n_rows)
                for i in range(n_rows):
                    self.X[i] = array_in[i][j]

                # Invoke scaling() method
                self.scaling()

                # Update numerical with scaled version
                for i in range(n_rows):
                    array_in[i][j] = self.X_scaled[i]

        # Open bind_####.csv file
        fo_bind = open(self.dir_in+"bind_"+bind+".csv","r")
        csv_bind = csv.reader(fo_bind)

        # Looping through csv_bind (header)
        for line in csv_bind:
            break

        # For number of rows
        i = 0

        # Looping through csv_bind
        for line in csv_bind:

            # Some editing
            line_out = str(line[:5]).replace("[","")
            line_out = line_out.replace("]","")
            line_out = line_out.replace("'","")
            line_out = line_out.replace(" ","")

            # Looping through numerical data
            for j in range(5,n_cols):
                line_out += ","+str(array_in[i][j])
                #if j != 9:

                    # Add data to be written
                #    line_out += ","+str(array_in[i][j])

            # Update count of rows
            i += 1

            # Add complete line for output file
            data_out += line_out+"\n"

        # Set up local time
        local_time = str(time.strftime("%Y.%m.%d__%Hh%Mmin%Ss"))

        # Try to back up file before overwrite it
        try:
            origin = self.dir_in+self.file_out
            target = self.dir_in+self.file_out[:len(self.file_out)-4]+\
            "_backup"+local_time+".csv"
            shutil.copyfile(origin,target)

        except:
            pass

        # open new file
        fo_scores = open(self.dir_in+self.file_out,"w")

        # Write header
        header="PDB,Ligand,Chain,Number,Resolution(A),Ligand Occupation Factor,"
        header+=bind+"(M),log("+bind+"),p"+bind+",RMSD(A),Torsions,Q,Average Q,"
        header+="Ligand B-factor(A2),Receptor B-factor(A2),"
        header+="B-factor ratio (Ligand/Receptor),"
        header+="C,N,O,P,S,F,Cl,Br,"
        header+="Affinity(kcal/mol),Gauss 1,Gauss 2,Repulsion,Hydrophobic,"
        header+="Hydrogen\n"
        fo_scores.write(header)

        # Write data
        fo_scores.write(data_out)

        # Close file
        fo_scores.close()