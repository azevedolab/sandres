# Import packages
import csv
import os
import shutil
import numpy as np
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import protein_pdbqt as prot_pdbqt

# Class to add pdbqt files to the datset
class PDBQT(object):
    """Class to add pdbqt files to the dataset"""

    # Define constructor method
    def __init__(self,program_root,dir_in,b_lig,b_occ,bind_in,h_resol,l_resol,dataset_dir):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.b_lig = b_lig
        self.b_occ = b_occ
        self.bind_in = bind_in
        self.h_resol = h_resol
        self.l_resol = l_resol
        self.dataset_dir = dataset_dir

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        self.win_height_type_1,self.win_y_offset_type_1,\
        _,_,\
        _,_,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Invoke read_adt() method
        self.lig_option,self.receptor_option=self.pr1.read_adt()

        # Type 1 GUI Window (new_win_height = 250, y_offset = 50)
        # Invoke tkinter_geometry() method
        _,_,self.top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_1,self.win_y_offset_type_1)

    # Define pdb_access_codes() method
    def pdb_access_codes(self):
        """Method to generate a list of the PDB access codes in the dataset"""

        # Set up empty lists
        data_out_resol = []
        data_out_lig = []
        data_out_occ = []

        # Try to open binding affinity file
        try:
            fo_bind = open(self.dir_in+"bind_"+self.bind_in+".csv","r")
            data_lines = csv.reader(fo_bind)
        except IOError:
            print("\nIOError! I can't find "+\
            self.dir_in+"bind_"+self.bind_in+".csv file!")
            return None

        # Looping through data_lines to select structures within
        # resolution range
        for line in data_lines:
            break
        for line in data_lines:
            resol = float(line[4])
            if resol >= self.h_resol and resol <= self.l_resol:
                data_out_resol.append(line)

        # Unify ligand if requested
        if self.b_lig:
            print("\nUnify ligand requested!")
            lig_present = []
            for line in data_out_resol:
                if line[1] in lig_present:
                    print()
                else:
                    lig_present.append(line[1])
                    data_out_lig.append(line)
        else:
            data_out_lig = data_out_resol

        # Delete structures if occupation factor < 1.0, if requested
        if self.b_occ:
            data_out_occ = data_out_lig
        else:
            #print("\nLigands with occupation factor = 1.0!")
            for line in data_out_lig:
                if float(line[5]) >= 1.0:
                    data_out_occ.append(line)

        # Close file
        fo_bind.close()

        # Return data_out_occ
        return data_out_occ

    # Define generate_pdbqt() method
    def generate_pdbqt(self,pdb2pdbqt,lig2pdbqt,chain2pdbqt,number2pdbqt):
        """Method to generate PDBQT files for a PDB"""

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dataset_dir,self.program_root)

        # Create a directory for each structure in the dataset
        target_dir = self.dataset_dir+"/"+pdb2pdbqt
        origin_dir = self.dir_in+"pdb/"
        pdb_file = pdb2pdbqt+".pdb"
        os.mkdir(target_dir)

        # Copy file
        shutil.copyfile(origin_dir+pdb_file,target_dir+"/"+pdb_file)

        # Call split_pdb() method
        self.split_pdb(target_dir,pdb_file,lig2pdbqt,chain2pdbqt,number2pdbqt)

        # Prepare biomatrix() method. Tested for "1pf7"   # 2-mer works
        #                                        "2cc8"   # 12-mer works
        #                                        "3zxa"    # 60-mer works
        self.my_dir_in = target_dir+"/"
        pdb = pdb2pdbqt
        string_1 = "ATOM  "
        string_2 = "XXXXXX"
        output_file = "receptor.pdb"

        # Call biomatrix() method
        self.biomatrix(self.my_dir_in,pdb,string_1,string_2,output_file)

        # Set up pdb
        pdb = pdb2pdbqt+"/"

        # Set up dir_in
        #dir_in = target_dir+"/"

        # Prepare ligand
        lig_in = "lig.pdb"
        lig_out = "lig.pdbqt"

        # Set up script file
        code1_in = "prepare_ligand4.py"

        # Set up third party software folder (Linux version)
        #tps_tools = self.program_root+"misc/third_party_software_linux/"
        tps_tools = self.program_root+"misc/linux_third_party_software/"

        # Run Python script on Windows
        #os.system(tps.python25+" "+tps.tools+code1_in+' -l '+
        #self.my_dir_in+lig_in+' -Abond_hydrogens -o'+self.my_dir_in+lig_out)

        # From this part comment (#) generation of lig.pdbqt using ADT
        # (prepare_ligand4.py)

        # Try to run Python script for ligands
        try:
            # Run Python script on Linux (pythonsh prepare_ligand4.py -l lig.pdb -Abond_hydrogens)
            os.system("pythonsh "+tps_tools+code1_in+' -l '+
            self.my_dir_in+lig_in+' -'+str(self.lig_option)+' -o'+self.my_dir_in+lig_out)
        except:
            # Second try
            try:
                # Run Python script on Linux (pythonsh prepare_ligand4.py -l lig.pdb -Abond_hydrogens)
                os.system("pythonsh "+tps_tools+code1_in+' -l '+
                self.my_dir_in+lig_in+' -Ahydrogens -o'+self.my_dir_in+lig_out)
            except:
                # Invoke show_botton_msg() method
                msg_out = "Warning! Problems PDBQT(lig) for structure"+\
                pdb2pdbqt+". Use ADT."
                msg1.show_botton_msg(msg_out,"red","light grey")

        #######################################################################
        # This part copy pre-generated lig.pdbqt
        #######################################################################

        # Try copy lig.pdbqt file
        #try:
        #    lig_pdbqt = self.program_root+"misc/data/pdbqt/"+self.bind_in+"/"+pdb+"lig.pdbqt"
        #    shutil.copyfile(lig_pdbqt,target_dir+"/lig.pdbqt")
        #except:
        #    print("\nI can't copy "+lig_pdbqt+" to "+target_dir)
        #    print("Please, generate lig.pdbqt file using AutoDockTools "+
        #            "(Morris et al 2009)!")
        #    print("Morris GM, Huey R, Lindstrom W, Sanner MF, Belew RK, "+
        #            "Goodsell DS, Olson AJ.")
        #    print("AutoDock4 and AutoDockTools4: Automated docking with "+
        #            "selective receptor flexibility.")
        #    print("J Comput Chem. 2009 Dec;30(16):2785-91.")
        #    print("doi: 10.1002/jcc.21256. PMID: 19399780; PMCID: PMC2760638.")

        #######################################################################
        # This part generate receptor.pdbqt
        #######################################################################
        # Prepare receptor
        receptor_in = "receptor.pdb"
        receptor_out = "receptor.pdbqt"

        # Set up script file
        code2_in = "prepare_receptor4.py"

        # Run Python script on Windows
        #os.system(tps.python25+" "+tps.tools+code2_in+' -r '+
        #self.my_dir_in+receptor_in+' -Abond_hydrogens -o '+
        #self.my_dir_in+receptor_out)

        # Try to run Python script for receptor
        try:
            # Run Python script on Linux
            os.system("pythonsh "+tps_tools+code2_in+' -r '+
            self.my_dir_in+receptor_in+' -'+str(self.receptor_option)+' -o '+
            self.my_dir_in+receptor_out)
        except:
            # Second try
            try:
                # Run Python script on Linux
                os.system("pythonsh "+tps_tools+code2_in+' -r '+
                self.my_dir_in+receptor_in+' -Ahydrogens -o '+
                self.my_dir_in+receptor_out)
            except:
                # Invoke show_botton_msg() method
                msg_out="Warning! Problems with PDBQT(receptor) for structure"+\
                pdb2pdbqt+". Use ADT."
                msg1.show_botton_msg(msg_out,"red","light grey")

        # Instantiate an object of ProteinStructure() class (program_root,dir_in,dataset)
        #prot1 = prot_pdbqt.ProteinStructure(self.program_root,self.dir_in,target_dir+"/")

        # Invoke write_dictionary() method
        #prot1.write_dictionary()

        # Invoke write_pdbqt() method
        #prot1.write_pdbqt("receptor.pdb","receptor.pdbqt")

    # Define split_pdb() method
    def split_pdb(self,target_dir,pdb_file,lig,chain,number):
        """Method to split a pdb file"""

        # Try to open a pdb file:
        try:
            fo = open(target_dir+"/"+pdb_file)
            fo_lines = fo.readlines()
        except:
            print("\nIOError! I can't find file "+target_dir+"/"+pdb_file+"!")
            return

        # Set up lists of keywords
        list_keywords1 = ["HEADER","TITLE ","COMPND","SOURCE","KEYWDS","EXPDTA",
        "AUTHOR","REVDAT","JRNL  ","REMARK","DBREF ","SEQRES","HET   ","HETNAM",
        "FORMUL","HELIX ","SHEET ","LINK  ","SITE  "]

        list_keywords2 = ["CRYST1","ORIGX1","ORIGX2","ORIGX3","SCALE1","SCALE2",
        "SCALE2"]

        # Open new receptor and lig files
        fo_receptor = open(target_dir+"/receptor.pdb","w")
        fo_lig = open(target_dir+"/lig.pdb","w")

        # Looping through a pdb file
        for line in fo_lines:
            if line[0:6] in list_keywords1:
                fo_receptor.write(line)
            elif line[0:6] in list_keywords2:
                fo_receptor.write(line)
                fo_lig.write(line)
            elif line[0:6] == "ATOM  ":
                fo_receptor.write(line)
            elif line[0:6] == "HETATM" and lig in line:
                if line[22:26] == str(number) and line[21:22] == chain:
                    fo_lig.write(line)

        # Write "END"
        fo_receptor.write("END")
        fo_lig.write("END")

        # Close files
        fo.close()
        fo_receptor.close()
        fo_lig.close()

    # Define biomatrix()
    def biomatrix(self,dir_in,pdb,string_1,string_2,output_file):
        """Method to apply biomatrix to a structure"""

        # Set count_chains to zero
        count_chains = 0
        num_biomat = 0

        # Set up lists
        pdb_out = []
        found_chains = []
        chain_id = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N",
                    "O","P","Q","R","S","T","U","V","W","X","Y","Z"]

        # Try to open pdb file
        try:
            fo1 = open(dir_in+pdb+".pdb","r")
            pdb_lines = fo1.readlines()
        except:
            print("IOError!")

        # Open biomatrix.csv
        fo2 = open(dir_in+"biomatrix.csv","w")

        # Looping through pdb_lines to get biomatrix and write atom lines
        for line in pdb_lines:

            # To avoid terminal keywords
            if line[0:3] != "END" and line[0:6] != "CONECT" and \
                line[0:6] != "MASTER":

                # Get atomic coordinates
                if line[0:6] == string_1 or line[0:6] == string_2:

                    # Add line to pdb_out
                    pdb_out.append(line)

                    # Add current_chain to a list of chain ids (found_chains)
                    current_chain = line[21:22]
                    if current_chain not in found_chains:
                        found_chains.append(current_chain)
                        count_chains += 1

                # Get REMARKS and related
                elif line[0:6] != "ATOM  " and line[0:6] != "HETATM":

                    # Add line to pdb_out
                    pdb_out.append(line)

            # To get biomatrix
            if "REMARK 350   BIOMT" in line:
                if int(line[19:23]) > 1:
                    line_o=str(line[23:33])+","+str(line[33:43])+\
                    ","+str(line[43:53])+","+str(line[53:68])
                    fo2.write(line_o+"\n")
                    num_biomat = int(line[19:23])

        # Close files
        fo1.close()
        fo2.close()

        # Set up num_biomat subtracting identity matrix
        num_biomat = num_biomat -1

        if num_biomat > 0:

            # Try to open biomatrix.csv file
            try:
                data = np.genfromtxt(dir_in+"biomatrix.csv",delimiter=",")
            except:
                print("IOError!")
        else:
            return

        # Looping through biomatrix.csv
        for k in range(num_biomat):

            # set up zero arrays
            rot = np.zeros((3,3))
            vec = np.zeros((3,1))

            # i index for rot
            r_i = 0

            # Inner loops for rotation matrix and translation vector
            for i in range(3*k,3*(k+1)):    # (0,3) (3,6)

                # j index for rot
                r_j = 0

                # Rotation matrix
                for j in range(3):
                    rot[r_i][r_j] = data[i][j]
                    r_j += 1

                # Translation vector
                vec[r_i][0] = data[i][3]
                r_i += 1

            # Try to open pdb file
            try:
                fo1 = open(dir_in+pdb+".pdb","r")
                pdb_lines = fo1.readlines()
            except:
                print("IOError!")

            # Generate a random chain and check if it exists
            c_ind = np.random.randint(0,26)
            current_chain = chain_id[c_ind]

            while current_chain in found_chains:
                c_ind = np.random.randint(0,26)
                current_chain = chain_id[c_ind]
                count_chains += 1

                # To avoid overflow
                if count_chains > 26:
                    count_chains = 0
                    found_chains = []

            if current_chain not in found_chains:
                found_chains.append(current_chain)
                count_chains += 1

            # To avoid overflow
            if count_chains > 26:
                count_chains = 0
                found_chains = []

            # Looping through pdb_lines
            for line in pdb_lines:
                if line[0:6] == string_1 or line[0:6] == string_2:
                    xyz = np.zeros((3,1))
                    xyz_out = ""
                    for pdb_i in range(3):
                        xyz[pdb_i][0] = float(line[30+pdb_i*8:38+pdb_i*8])

                    # Apply rotation matrix (rot) and translation vector (vec)
                    result = rot.dot(xyz) + vec
                    for pdb_i in range(3):
                        x = "{:8.3f}".format(result[pdb_i][0])
                        xyz_out+=(str(x))

                    # Set up output line
                    line_o=line[:21]+current_chain+line[22:30]+xyz_out+line[54:]
                    pdb_out.append(str(line_o))

            # Add "TER"
            pdb_out.append("TER    \n")

        # Close file
        fo1.close()

        # Open new file
        fo1 = open(dir_in+output_file,"w")

        # Looping through pdb_out
        for line in pdb_out:
            fo1.write(line)

        # Write "END"
        fo1.write("END")

        # Close file
        fo1.close()
