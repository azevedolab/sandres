# https://stackoverflow.com/questions/23670178/matplotlib-3d-bar-chart-axis-issue
# Import packages
import csv
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm

# Define Plot3DBar() class
class Plot3DBar(object):
    """Class to generate 3D bar plots"""

    # Define constructor method
    def __init__(self,program_root,dir_in,par_file_in):
        """Constructor method"""

        # Assign attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.par_file_in = par_file_in

        # Set up parameter file to open
        par_2_open = self.program_root+"misc/data/"+self.par_file_in

        # Try to open parameter file (bar3dplot_par.csv)
        try:
            fo_pars = open(par_2_open,"r")
            csv_pars = csv.reader(fo_pars)
        except IOError:
            print("\nI can't find "+par_2_open+" file!")
            return

        # Looping through csv_pars
        for line in csv_pars:
            if line[0] == "xlabel_in":
                self.xlabel_in = line[1]
            elif line[0] == "xlabel_font_size":
                self.xlabel_font_size = line[1]
            elif line[0] == "ylabel_in":
                self.ylabel_in = line[1]
            elif line[0] == "ylabel_font_size":
                self.ylabel_font_size = int(line[1])
            elif line[0] == "zlabel_in":
                self.zlabel_in = line[1]
            elif line[0] == "zlabel_font_size":
                self.zlabel_font_size = int(line[1])
            elif line[0] == "plt_title_in":
                self.plt_title_in = line[1]
            elif line[0] == "bar_width_x":
                self.bar_width_x = float(line[1])
            elif line[0] == "bar_width_y":
                self.bar_width_y = float(line[1])
            elif line[0] == "title_size_in":
                self.title_size_in = int(line[1])
            elif line[0] == "tick_mark_size":
                self.tick_mark_size = int(line[1])
            elif line[0] == "fig_size_x_in":
                self.fig_size_x_in = int(line[1])
            elif line[0] == "fig_size_y_in":
                self.fig_size_y_in = int(line[1])
            elif line[0] == "plt_color":
                self.plt_color = line[1]
            elif line[0] == "dpi_in":
                self.dpi_in = int(line[1])
            elif line[0] == "file_in_mc":
                self.file_in_mc = line[1]
            elif line[0] == "file_in_sc":
                self.file_in_sc = line[1]
            elif line[0] == "file_out":
                self.file_out = line[1]

        # Close file
        fo_pars.close()

    # Define read_contacts() method
    def read_contacts(self):
        """Method to read the number of intermolecular contacts"""

        # Set up lists with amino labels
        aa3 = ["ALA","ARG","ASN","ASP","CYS","GLN","GLU","GLY","HIS","ILE",
            "LEU","LYS","MET","PHE","PRO","SER","THR","TRP","TYR","VAL"]

        self.aa1 = ["A","R","N","D","C","Q","E","G","H","I",
            "L","K","M","F","P","S","T","W","Y","V"]

        # Set up empty lists for amino acids
        res_data_mc = []
        res_data_sc = []

        # Set up arrays for intermolecular contacts
        contacts_aa_mc = np.zeros(20,dtype=int)
        contacts_aa_sc = np.zeros(20,dtype=int)

        # Set up 20x20 array
        self.result = np.arange(400).reshape((20,20))

        # Read intermolecular data
        data_mc = np.genfromtxt(self.dir_in+self.file_in_mc,delimiter=",",
        skip_header=1)
        data_sc = np.genfromtxt(self.dir_in+self.file_in_sc,delimiter=",",
        skip_header=1)

        # Get numeric data as arrays
        x_data_mc = data_mc[:,0]
        y_data_mc = data_mc[:,2]
        x_data_sc = data_sc[:,0]
        y_data_sc = data_sc[:,2]

        # Read residues in column 2
        # Try to open file_in_mc
        try:
            fo_data_mc = open(self.dir_in+self.file_in_mc,"r")
            csv_data_mc = csv.reader(fo_data_mc)
        except IOError:
            print("\nI can't find "+self.dir_in+self.file_in_mc+" file!")
            return

        # Try to open file_in_sc
        try:
            fo_data_sc = open(self.dir_in+self.file_in_sc,"r")
            csv_data_sc = csv.reader(fo_data_sc)
        except IOError:
            print("\nI can't find "+self.dir_in+self.file_in_sc+" file!")
            return

        # First line
        for line in csv_data_mc:
            break

        # Looping through csv_data
        for line in csv_data_mc:
            res_data_mc.append(str(line[1]))

        # First line
        for line in csv_data_sc:
            break

        # Looping through csv_data
        for line in csv_data_sc:
            res_data_sc.append(str(line[1]))

        # Looping through data to count contacts for main-chain atoms
        for i in range(len(contacts_aa_mc)):
            for j in range(len(x_data_mc)):
                if aa3[i] == res_data_mc[j]:
                    contacts_aa_mc[i] += y_data_mc[j]

        # Looping through data to count contacts for side-chain atoms
        for i in range(len(contacts_aa_sc)):
            for j in range(len(x_data_sc)):
                if aa3[i] == res_data_sc[j]:
                    contacts_aa_sc[i] += y_data_sc[j]

        # Looping through result
        for i in range(20):
            for j in range(20):
                self.result[i][j] = contacts_aa_mc[i] + contacts_aa_sc[j]

        # Close file
        fo_data_mc.close()
        fo_data_sc.close()

    # Define generate() method
    def generate(self,plot_boolean):
        """Method to generate bar3d plot"""

        # Close previously created window, if it exists
        try:
            plt.close()
        except:
            pass

        # Set up figure parameter
        fig=plt.figure(figsize=(self.fig_size_x_in,self.fig_size_y_in), dpi=200)
        ax=fig.add_subplot(111, projection='3d')

        # Set up tick marks
        xlabels = np.array(self.aa1)
        xpos = np.arange(xlabels.shape[0])
        ylabels = np.array(self.aa1)
        ypos = np.arange(ylabels.shape[0])

        # Set up grid
        xposM, yposM = np.meshgrid(xpos, ypos, copy=False)

        # Set up axes
        zpos=self.result
        zpos = zpos.ravel()
        dx=self.bar_width_x
        dy=self.bar_width_y
        dz=zpos
        ax.w_xaxis.set_ticks(xpos + dx/2.)
        ax.w_xaxis.set_ticklabels(xlabels)
        ax.w_yaxis.set_ticks(ypos + dy/2.)
        ax.w_yaxis.set_ticklabels(ylabels)
        ax.tick_params(axis='both',which='major',labelsize=self.tick_mark_size)
        ax.set_xlabel(self.xlabel_in,fontsize=self.xlabel_font_size)
        ax.set_ylabel(self.ylabel_in,fontsize=self.ylabel_font_size)
        ax.set_zlabel(self.zlabel_in,fontsize=self.zlabel_font_size)
        ax.set_title(self.plt_title_in,fontsize=self.title_size_in)

        # Set up plot
        # Check color definition
        if self.plt_color == "rainbow":
            values = np.linspace(0.2, 1., xposM.ravel().shape[0])
            colors = cm.rainbow(values)
            ax.bar3d(xposM.ravel(),yposM.ravel(),dz*0,dx,dy,dz,
                color=colors)
        else:
            ax.bar3d(xposM.ravel(),yposM.ravel(),dz*0,dx,dy,dz,
                color=self.plt_color)

        # Check whether to generate plot or view it
        if plot_boolean:

            # Save 3D plot
            plt.savefig(self.dir_in+"plots/"+self.file_out,dpi=self.dpi_in)
        else:

            # Show 3D plot
            plt.show()