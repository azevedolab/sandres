# Define PDBbind() class
class PDBbind(object):
    """Class to download binding affinity data from the PDBbind

    We tested this PDBbind class against the PDBbind version 2019.
    This version is based on the contents of PDB officially
    released by Jan 1st, 2019. """

    # Define constructor method
    def __init__(self,url_in,dir_in,pdb_in,bind_in):
        """Constructor method"""

        # Set up attributes
        self.url_in = url_in        # Url read from program_par.csv
        self.dir_in = dir_in        # Project directory
        self.pdb_in = pdb_in        # PDB access code
        self.bind_in = bind_in      # Type of binding affinty (Ki, Kd, or IC50)

    # Define download_binding_affinity() method (download_pdbbind)
    def download_binding_affinity(self):
        """Method to download binding data from the PDBbind"""

        # Import library
        import requests

        # Define url
        url = self.url_in+self.pdb_in.upper()

        # Get file
        myfile = requests.get(url, allow_redirects=True)

        # Open and copy downloaded file
        open(self.dir_in+self.pdb_in.upper()+'.html','wb').write(myfile.content)

    # Define read_binding_affinity()
    def read_binding_affinity(self):
        """Method to read binding affinity data from a PDBbind file (html)"""

        # Try to open binding affinity data
        try:
            fo = open(self.dir_in+self.pdb_in.upper()+'.html',"r")
        except:
            print("SAnDReS IOError! I can't find "+self.dir_in+\
            self.pdb_in.upper()+'.html file!')
            return

        # Get lines
        lines = fo.readlines()

        # Close file
        fo.close()

        # Looping through lines to get binding affinity data
        for line in lines:
            if "Affinity" in line:
                if self.bind_in in line:
                    i_bind = line.index(self.bind_in+"=") +len(self.bind_in)+1
                    i_M = (line[i_bind:]).index("M") + i_bind
                    bind_string = line[i_bind:i_M]
            elif "Ligand Name" in line and "PDB" not in line:
                i_lig = line.index("Ligand Name") + 11
                i_end = line[i_lig:].index("<td class=register>") + i_lig
                self.lig_string = line[i_lig+24:i_end+22]

        # Convert binding data to Molar
        try:
            if "m" in bind_string:
                self.bind_value = float(bind_string[:len(bind_string)-1])/1e3
            elif "u" in bind_string:
                self.bind_value = float(bind_string[:len(bind_string)-1])/1e6

            elif "n" in bind_string:
                self.bind_value = float(bind_string[:len(bind_string)-1])/1e9

            elif "p" in bind_string:
                self.bind_value = float(bind_string[:len(bind_string)-1])/1e12

            elif "f" in bind_string:
                self.bind_value = float(bind_string[:len(bind_string)-1])/1e15

            else:
                print()
        except:
            print("SAnDReS Converter Error!")
            return

        # Return ligand string (string) and binding affinity data (float)
        return self.lig_string, self.bind_value