#!/usr/bin/env python3
#
# Class to carry out docking simulation using
# AutoDock Vina (Trott & Olson, 2010; Eberhardt et al., 2021).
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
import os
import csv

class Docking_Simulation(object):
    """Class to carry out docking simulation with AutoDock Vina"""

    # Define constructor method
    def __init__(self,program_root,sim1_dir,mol_dir,config_in):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.sim1_dir = sim1_dir
        self.mol_dir = mol_dir
        self.config_in = config_in

        # Try to open vina_par.csv file
        file2open = self.program_root+"misc/data/vina_par.csv"
        try:
            fo_vina_par = open(file2open,"r")
            csv_vina_par = csv.reader(fo_vina_par)
        except IOError:
            print("\nI can't find "+file2open+" file")
            return

        # Looping through csv_vina_par
        for line in csv_vina_par:
            if line[0] == "docking_engine":
                self.docking_engine = line[1]
                break

        # Close file
        fo_vina_par.close()

    # Define simulation() method
    def simulation(self):
        """Simulation with AutoDock Vina"""

        # Set up empty string
        config_lines = ""

        # Try to open config.txt
        try:

            # Open a file
            file2open = self.sim1_dir+self.config_in
            config_lines = ""
            fo_config = open(file2open,"r")
            fo_lines = fo_config.readlines()

            # Looping through fo_lines
            for line in fo_lines:
                if "receptor" in str(line):
                    config_lines += "receptor = "+self.sim1_dir+"receptor.pdbqt\n"
                else:
                    line_out = str(line)
                    config_lines += line_out

            # Close file
            fo_config.close()

            # Open new file
            fo_config = open(file2open,"w")

            # Write lines
            fo_config.write(config_lines)

            # Close file
            fo_config.close()

        # Handle IOError exception
        except IOError:
            print("\nI can't find "+file2open+" file!")

        # Get the number of molecules
        ligs = os.listdir(self.sim1_dir+self.mol_dir)
        n_ligs = len(ligs)
        print("Number of molecules: ",n_ligs)

        # Looping through molecules
        for lig in ligs:

            print("\nRunning for ligand: ",lig)

            # Set up ligand root
            i_p = lig.index(".")
            lig_root = lig[:i_p]

            # Try to make dir
            try:
                # Make dir
                os.mkdir(self.sim1_dir+self.mol_dir+lig_root)

            # Handle exception
            except:
                pass

            # Run AutoDock Vina (vina --config conf.txt --ligand $f --out ${b}/out.pdbqt --log ${b}/log.txt)
            # ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt
            #--log ${b}/results.log
            #os.system(self.program_root+\
            #    "misc/linux_third_party_software/vina/./"+docking_engine+\
            #    " --config "+\
            #    self.sim1_dir+self.config_in+" --ligand "+\
            #    self.sim1_dir+self.mol_dir+lig+" --out "+\
            #    self.sim1_dir+self.mol_dir+lig_root+"/poses.pdbqt"+" --log "+\
            #    self.sim1_dir+self.mol_dir+lig_root+"/results.log")

            # Run AutoDock Vina (vina --config conf.txt --ligand $f --out ${b}/out.pdbqt --log ${b}/log.txt)
            # ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt
            #--log ${b}/results.log
            os.system(self.program_root+\
                "misc/linux_third_party_software/vina/./"+self.docking_engine+\
                " --config "+\
                self.sim1_dir+self.config_in+" --ligand "+\
                self.sim1_dir+self.mol_dir+lig+" --out "+\
                self.sim1_dir+self.mol_dir+lig_root+"/poses.pdbqt"+" > "+\
                self.sim1_dir+self.mol_dir+lig_root+"/results.log")

    # Define simulation4lig() method
    def simulation4lig(self,lig):
        """Run AutoDock Vina for a specific ligand"""

        # Set up empty string
        config_lines = ""

        # Try to open config.txt
        try:

            # Open a file
            file2open = self.sim1_dir+self.config_in
            config_lines = ""
            fo_config = open(file2open,"r")
            fo_lines = fo_config.readlines()

            # Looping through fo_lines
            for line in fo_lines:
                if "receptor" in str(line):
                    config_lines += "receptor = "+self.sim1_dir+"receptor.pdbqt\n"
                else:
                    line_out = str(line)
                    config_lines += line_out

            # Close file
            fo_config.close()

            # Open new file
            fo_config = open(file2open,"w")

            # Write lines
            fo_config.write(config_lines)

            # Close file
            fo_config.close()

        # Handle IOError exception
        except IOError:
            print("\nI can't find "+file2open+" file!")

        ########################################################################

        # Show ligand data
        print("\nRunning for ligand: ",lig)

        # Set up ligand root
        i_p = lig.index(".")
        lig_root = lig[:i_p]

        # Try to make dir
        try:
            # Make dir
            os.mkdir(self.sim1_dir+self.mol_dir+lig_root)

        # Handle exception
        except:
            pass

        # Run AutoDock Vina (vina --config conf.txt --ligand $f --out ${b}/out.pdbqt --log ${b}/log.txt)
        # ./vina --config config.txt --ligand $f --out ${b}/poses.pdbqt
        #--log ${b}/results.log
        os.system(self.program_root+\
            "misc/linux_third_party_software/vina/./"+self.docking_engine+\
            " --config "+\
            self.sim1_dir+self.config_in+" --ligand "+\
            self.sim1_dir+self.mol_dir+lig+" --out "+\
            self.sim1_dir+self.mol_dir+lig_root+"/poses.pdbqt"+" > "+\
            self.sim1_dir+self.mol_dir+lig_root+"/results.log")
