#!/usr/bin/env python3
#
# Class to manipulate files and strings.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
import csv
import os
from os import path, mkdir
import shutil
import time

# Define Palavra() class
class Palavra(object):
    """Class to manipulate files and strings"""

    # Constructor method
    def __init__(self,dir_in,file_in):
        """Constructor method"""

        # Set up attributes
        self.file_in = file_in
        self.dir_in = dir_in
        self.pdb = []
        self.lig = []
        self.chain = []
        self.res = []

    # Define count_codes()
    def count_codes(self):
        """Method to count PDB access codes in a CSV file"""

        # Assign zero to number_of_pdbs
        number_of_pdbs = 0

        # Try to open csv file
        try:
            fo1 = open(self.dir_in+self.file_in,"r")
            csv1 = csv.reader(fo1)
        except IOError:
            print("\nIOError! I can't find file pdb_codes.csv!")
            fo2 = open(self.dir_in+self.file_in,"w")
            return None

        # Count PDB codes
        for line in csv1:
            number_of_pdbs = len(line)
            break

        # Close file
        fo1.close()

        # Return number_of_pdbs
        return number_of_pdbs

    # Define count_pdb() method
    def count_pdb(self):
        """Method to count PDB structures"""

        # Get the number of
        n_pdb = len(self.pdb)

        return n_pdb

    # Define list_pdb() method
    def list_pdb(self):
        """Method to read pdb_codes.csv and generate a list of PDB codes"""

        # Try to open csv file
        try:
            fo1 = open(self.dir_in+self.file_in,"r")
        except IOError:
            print("\nSAnDReS IOError! I can't find file pdb_codes.csv!")
            fo2 = open(self.dir_in+self.file_in,"w")
            # Close empty file
            fo2.close()
            return None

        # Set up empty list
        pdb_list = []

        # Set up empty string
        pdb = ""

        # Looping through fo
        for line in fo1:
            for line1 in line:
                if line1 != ",":
                    pdb += line1
                else:
                    pdb_list.append(pdb)
                    pdb = ""

        # Close file
        fo1.close()

        # Get the last one
        pdb_list.append(pdb)

        # Looping through pdb_list
        for line in pdb_list:
            print(line)

        # Show number od PDBs read
        print("Number of read PDB files:",len(pdb_list))

        # Return list of PDBs
        return pdb_list

    # Define checking_dir() method
    def checking_dir(self,my_dir):
        """Method to check if a directory exists. If not, it will be created."""

        # Show directory
        print("Checking directory: ",my_dir)

        # Check if a directory exists
        if path.exists(my_dir):
            print ()
        else:
            mkdir(my_dir)

    # Define backup_file() method
    def backup_file(self,original):
        """Method to back up a file, if it exists."""

        # Call checking_dir() method
        target_dir = self.dir_in+"backup/"
        self.checking_dir(target_dir)

        # Check if file exists
        if os.path.exists(self.dir_in+original):

            # String for local time
            my_time = str(time.strftime("%Y_%m_%d_%Hh%Mmin%Ss"))

            # Some editing
            target_root = original[:len(original)-4]
            target_ext = original[len(original)-4:]
            target = target_root+"_"+my_time+target_ext

            # Show message
            print("Making backup to "+self.dir_in+target)

            # Copy file
            shutil.copyfile(self.dir_in+original,target_dir+target)

    # Define unify_pdb() method
    def unify_pdb(self,pdb_codes):
        """Method to delete repeated PDB access codes in pdb_codes"""

        # Set up empty lists
        my_pdb_list = []
        my_repeated_pdb_list = []

        # Assign zero to count_repeated_pdb
        count_repeated_pdb = 0

        # Try to open pdb_codes.csv file
        try:
            my_fo = open(self.dir_in+pdb_codes,"r")
            my_csv = csv.reader(my_fo)
        except IOError:
            print("IOError! I can't find ",self.dir_in+pdb_codes)
            print("New "+pdb_codes+" file will be generated!")
            return count_repeated_pdb,my_repeated_pdb_list

        # Looping through csv file
        for line in my_csv:
            for line1 in line:
                if line1 in my_pdb_list:
                    count_repeated_pdb += 1
                    my_repeated_pdb_list.append(line1)
                    continue
                else:
                    my_pdb_list.append(line1)

        # Close file
        my_fo.close()

        # New pdb_codes file
        my_fo = open(self.dir_in+pdb_codes,"w")
        my_pdb_out = str(my_pdb_list[0])

        # Looping through my_pdb_list
        for line in my_pdb_list[1:]:
            my_pdb_out += str(","+line)

        # Write pdb access codes
        my_fo.write(my_pdb_out)

        # Close new pdb_codes file
        my_fo.close()

        # return count_repeated_pdb,my_repeated_pdb_list
        return count_repeated_pdb,my_repeated_pdb_list

    # Define ascii_art() method
    def ascii_art(self):
        """Method to generate ASCII art based to strings generated at
        https://patorjk.com/software/taag
        (accessed on January 16, 2021)
        """
        # https://patorjk.com/software/taag/#p=display&f=Modular&t=SAnDReS
        # https://patorjk.com/software/taag/#p=display&f=Soft&t=SAnDReS
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=SAnDReS
        # https://patorjk.com/software/taag/#p=display&f=Contessa&t=SAnDReS
        # https://patorjk.com/software/taag/#p=display&f=Chunky&t=SAnDReS ***
        # https://patorjk.com/software/taag/#p=display&f=Calvin%20S&t=SAnDReS **
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=SAnDReS
        # Define opening message
        opening_message = """
███████╗ █████╗ ███╗   ██╗██████╗ ██████╗ ███████╗███████╗
██╔════╝██╔══██╗████╗  ██║██╔══██╗██╔══██╗██╔════╝██╔════╝
███████╗███████║██╔██╗ ██║██║  ██║██████╔╝█████╗  ███████╗
╚════██║██╔══██║██║╚██╗██║██║  ██║██╔══██╗██╔══╝  ╚════██║
███████║██║  ██║██║ ╚████║██████╔╝██║  ██║███████╗███████║
╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝
"""

        # Define PDB ASCII Art
        # https://patorjk.com/software/taag/#p=display&f=Standard&t=PDB
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=PDB
        pdb_ascii_art = """
██████╗ ██████╗ ██████╗
██╔══██╗██╔══██╗██╔══██╗
██████╔╝██║  ██║██████╔╝
██╔═══╝ ██║  ██║██╔══██╗
██║     ██████╔╝██████╔╝
╚═╝     ╚═════╝ ╚═════╝
        """

        # Define PDBbind ASCII Art
        # https://patorjk.com/software/taag/#p=display&f=Standard&t=PDBbind
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=PDBbind
        pdbbind_ascii_art = """
██████╗ ██████╗ ██████╗ ██████╗ ██╗███╗   ██╗██████╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗██║████╗  ██║██╔══██╗
██████╔╝██║  ██║██████╔╝██████╔╝██║██╔██╗ ██║██║  ██║
██╔═══╝ ██║  ██║██╔══██╗██╔══██╗██║██║╚██╗██║██║  ██║
██║     ██████╔╝██████╔╝██████╔╝██║██║ ╚████║██████╔╝
╚═╝     ╚═════╝ ╚═════╝ ╚═════╝ ╚═╝╚═╝  ╚═══╝╚═════╝
        """

        # Define PDB-PDBQT ASCII Art
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=PDB-%3EPDBQT
        pdb_pdbqt = """
██████╗ ██████╗ ██████╗      ██╗  ██████╗ ██████╗ ██████╗  ██████╗ ████████╗
██╔══██╗██╔══██╗██╔══██╗     ╚██╗ ██╔══██╗██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝
██████╔╝██║  ██║██████╔╝█████╗╚██╗██████╔╝██║  ██║██████╔╝██║   ██║   ██║
██╔═══╝ ██║  ██║██╔══██╗╚════╝██╔╝██╔═══╝ ██║  ██║██╔══██╗██║▄▄ ██║   ██║
██║     ██████╔╝██████╔╝     ██╔╝ ██║     ██████╔╝██████╔╝╚██████╔╝   ██║
╚═╝     ╚═════╝ ╚═════╝      ╚═╝  ╚═╝     ╚═════╝ ╚═════╝  ╚══▀▀═╝    ╚═╝
"""

        # Define Car ASCII Art
        # https://asciiart.website/index.php?art=animals/cats
        cat1_ascii_art = """


     )\-"```-,_
    /.   _     `"-._
   _`-c_/_'. `\   , `"-._
  (_.--`  '-_;-'   \     `"-.
          (_.-----'`-.._     `\._
                        `\     `\'._
                          `'.    '._'._
                             `'---, `._'-._
                                   `-._/'--'

"""


        # Define Vina
        vina_ascii_art ="""
 █████╗ ██╗   ██╗████████╗ ██████╗ ██████╗  ██████╗  ██████╗██╗  ██╗    ██╗   ██╗██╗███╗   ██╗ █████╗
██╔══██╗██║   ██║╚══██╔══╝██╔═══██╗██╔══██╗██╔═══██╗██╔════╝██║ ██╔╝    ██║   ██║██║████╗  ██║██╔══██╗
███████║██║   ██║   ██║   ██║   ██║██║  ██║██║   ██║██║     █████╔╝     ██║   ██║██║██╔██╗ ██║███████║
██╔══██║██║   ██║   ██║   ██║   ██║██║  ██║██║   ██║██║     ██╔═██╗     ╚██╗ ██╔╝██║██║╚██╗██║██╔══██║
██║  ██║╚██████╔╝   ██║   ╚██████╔╝██████╔╝╚██████╔╝╚██████╗██║  ██╗     ╚████╔╝ ██║██║ ╚████║██║  ██║
╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚═════╝  ╚═════╝  ╚═════╝╚═╝  ╚═╝      ╚═══╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝
"""
        # Define Scikit-learn
        scikit_ascii_art ="""
███████╗ ██████╗██╗██╗  ██╗██╗████████╗   ██╗     ███████╗ █████╗ ██████╗ ███╗   ██╗
██╔════╝██╔════╝██║██║ ██╔╝██║╚══██╔══╝   ██║     ██╔════╝██╔══██╗██╔══██╗████╗  ██║
███████╗██║     ██║█████╔╝ ██║   ██║█████╗██║     █████╗  ███████║██████╔╝██╔██╗ ██║
╚════██║██║     ██║██╔═██╗ ██║   ██║╚════╝██║     ██╔══╝  ██╔══██║██╔══██╗██║╚██╗██║
███████║╚██████╗██║██║  ██╗██║   ██║      ███████╗███████╗██║  ██║██║  ██║██║ ╚████║
╚══════╝ ╚═════╝╚═╝╚═╝  ╚═╝╚═╝   ╚═╝      ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝
"""

        # Return ascii_art
        return opening_message,pdb_ascii_art,\
        pdbbind_ascii_art,cat1_ascii_art,pdb_pdbqt,vina_ascii_art,\
        scikit_ascii_art


