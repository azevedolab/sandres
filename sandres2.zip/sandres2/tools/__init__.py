#!/usr/bin/python
#
###############################################################################################################
# SAnDReS 2.0.0
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
#
# SAnDReS 2.0.0 became operational on 12 January 2021 at the Computational Systems Biology Laboratory in Porto Alegre,
# RS Brazil.

# SAnDReS 2.0.0 based its overall structure on the design of SAnDReS 1.0 (Xavier et al., 2016; Bitencourt-Ferreira &
# de Azevedo, 2019) and added new features related to recent developments in machine learning and biological
# databases. Due to the constant progress of Protein Data Bank (Berman et al., 2020), SAnDReS needed to redesign its
# downloading scripts. SAnDReS 2.0.0 has an integrated interface for the automatic downloading of structural and
# affinity data. This redesigned SAnDReS focuses on binding affinity data available in PDBbind (Liu et al., 2015). We
# reached an improvement in the machine learning methods available in SAnDReS with the inclusion of random forest and
# boosting techniques. SAnDReS uses machine learning techniques available on Scikit-Learn (Pedregosa et al., 2011).
# Machine learning methods allow us to build targeted scoring functions using the energy terms implemented in
# classical scoring functions such as the ones available in AutoDock4 (Morris et al., 2009; Bitencourt-Ferreira et
# al., 2019) and AutoDock Vina (Trott & Olson, 2010). These elegant approaches permit us to explore the scoring
# function space (Heck et al., 2017), building a machine learning model (Bitencourt-Ferreira & de Azevedo, 2019)
# targeted to a specific biological system.
#
# References
# Berman, H.M.; Vallat, B.; Lawson, C.L. The data universe of structural biology. IUCrJ., 2020, 7(Pt 4), 630-638.
# doi: 10.1107/S205225252000562X   PMID: 32695409; PMCID: PMC7340255.
# Bitencourt-Ferreira, G.; de Azevedo, W.F., Jr SAnDReS: A Computational Tool for Docking. Methods Mol. Biol., 2019,
# 2053, 51-65. http://dx.doi.org/10.1007/978-1-4939-9752-7_4   PMID: 31452098
# Bitencourt-Ferreira, G.; Pintro, V.O.; de Azevedo, W.F., Jr. Docking with AutoDock4. Methods Mol. Biol., 2019, 2053,
# 125-148. http://dx.doi.org/10.1007/978-1-4939-9752-7_9   PMID: 31452103
# Bitencourt-Ferreira, G.; de Azevedo, W.F., Jr. Exploring the Scoring Function Space. Methods Mol. Biol., 2019, 2053,
# 275-281. doi: 10.1007/978-1-4939-9752-7_17   PMID: 31452111.
# Heck, G.S.; Pintro, V.O.; Pereira, R.R.; de Ávila, M.B.; Levin, N.M.B.; de Azevedo, W.F. Supervised machine learning
# methods applied to predict ligand-binding affinity. Curr. Med. Chem., 2017, 24(23), 2459-2470.
# http://dx.doi.org/10.2174/0929867324666170623092503   PMID: 28641555
# Liu, Z.; Li, Y.; Han, L.; Li, J.; Liu, J.; Zhao, Z.; Nie, W.; Liu, Y.; Wang, R. PDB-wide collection of binding data:
# current status of the PDBbind database. Bioinformatics, 2015, 31(3), 405-412.
# http://dx.doi.org/10.1093/bioinformatics/btu626   PMID: 25301850
# Morris, G.M.; Huey, R.; Lindstrom, W.; Sanner, M.F.; Belew, R.K.; Goodsell, D.S.; Olson, A.J. AutoDock4 and
# AutoDockTools4: Automated docking with selective receptor flexibility. J. Comput. Chem., 2009, 30(16), 2785-2791.
# http://dx.doi.org/10.1002/jcc.21256   PMID: 19399780
# Pedregosa, F.; Varoquaux, G.; Gramfort, A.; Michel, V.; Thirion, B.; Grisel, O.; Blondel, M.; Prettenhofer, P.;
# Weiss, R.; Dubourg, V.; Verplas, J.; Passos, A.; Cournapeau, D.; Brucher, M.; Perrot, M.; Duchesnay, E. Scikitlearn:
# Machine Learning in Python. J. Mach. Learn. Res., 2011, 12, 2825-2830.
# Trott, O.; Olson, A.J. AutoDock Vina: improving the speed and accuracy of docking with a new scoring function,
# efficient optimization, and multithreading. J. Comput. Chem., 2010, 31(2), 455-461.
# http://dx.doi.org/10.1002/jcc.21334   PMID: 19499576
# Xavier, M.M.; Heck, G.S.; Avila, M.B.; Levin, N.M.B.; Pintro, V.O.; Carvalho, N.L.; Azevedo, W.F., Jr SAnDReS a
# computational tool for statistical analysis of docking results and development of scoring functions.
# Comb. Chem. High Throughput Screen., 2016, 19(10), 801-812.
# http://dx.doi.org/10.2174/1386207319666160927111347   PMID: 27686428
#
# Current Version 2.0.0.
#
###############################################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico -
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4 and 309029/2018-0.
#
###############################################################################################################
#
# Show message about SAnDReS
print("""
Statistical Analysis of Docking Results and Scoring functions
SAnDReS 2.0.0
Developed by Dr. Walter F. de Azevedo, Jr.
""")