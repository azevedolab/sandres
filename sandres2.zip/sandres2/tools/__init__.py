#!/usr/bin/env python3
#
################################################################################
# SAnDReS 2.0.0
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
#
# SAnDReS 2.0.0 became operational on 12 January 2022 at azevedolab.net
# in Porto Alegre,RS Brazil.
#
# SAnDReS 2.0.0 is a development of SAnDReS 1.0 (Xavier et al., 2016;
# Bitencourt-Ferreira & de Azevedo, 2019). This new version added novel features
# in machine learning, docking engine, and biological databases. Due to the
# constant progress of Protein Data Bank (Berman et al., 2020), SAnDReS needed
# to redesign its downloading scripts. SAnDReS 2.0.0 has an integrated interface
# for downloading structural and affinity data. This new version uses the most
# recent regression techniques available on Scikit-Learn 1.0.2
# (Pedregosa et al., 2011). These methods permit us to build targeted scoring
# functions using the energy terms implemented in AutoDock Vina 1.2
# (Trott & Olson, 2010; Eberhardt et al., 2021) and Molegro Virtual Docker
# (Thomsen & Christensen, 2006; Bitencourt-Ferreira & de Azevedo WF; 2019).
# SAnDReS can create a machine learning model
# (Bitencourt-Ferreira & de Azevedo, 2019) specific to a protein system. In
# summary, SAnDReS 2.0.0 integrates one of the most developed docking programs
# (AutoDock Vina 1.2.3) with recent machine learning techniques available in
# Scikit-Learn 1.0.2. All this is in an integrated tool with a user-friendly
# graphical interface. This integrated computational tool allows us to create
# machine-learning models targeted to a protein system of interest.
# SAnDReS 2.0.0 is a powerful software to explore the Scoring Function Space
# (SFS) (Heck et al., 2017). This exploration of the SFS makes it possible to
# build models with superior predictive power compared to classical ones
# (Bitencourt-Ferreira et al., 2021).
#
# References
# Berman HM, Vallat B, Lawson CL. The data universe of structural biology.
# IUCrJ. 2020;7(Pt 4):630-638. doi: 10.1107/S205225252000562X.
# PMID: 32695409; PMCID: PMC7340255.
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. SAnDReS: A Computational Tool for
# Docking. Methods Mol Biol. 2019;2053:51-65. doi: 10.1007/978-1-4939-9752-7_4.
# PMID: 31452098.
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Molegro Virtual Docker for Docking.
# Methods Mol Biol. 2019;2053:149-167. doi: 10.1007/978-1-4939-9752-7_10.
# PMID: 31452104.
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019;2053:275-281. doi: 10.1007/978-1-4939-9752-7_17.
# PMID: 31452111.
#
# Bitencourt-Ferreira G, Rizzotto C, de Azevedo Junior WF. Machine
# Learning-Based Scoring Functions, Development and Applications with SAnDReS.
# Curr Med Chem. 2021;28(9):1746-1756. doi: 10.2174/0929867327666200515101820.
# PMID: 32410551.
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand- Binding
# Affinity. Curr Med Chem. 2017;24(23):2459-2470.
# doi: 10.2174/0929867324666170623092503. PMID: 28641555.
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel, O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011;12:2825-2830.
#
# Thomsen R, Christensen MH. MolDock: a new technique for high-accuracy
# molecular docking. J Med Chem. 2006;49(11):3315-21. doi: 10.1021/jm051197e.
# PMID: 16722650.
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010;31(2):455-61. doi: 10.1002/jcc.21334. PMID: 19499576;
# PMCID: PMC3041641.
#
# Xavier MM, Heck GS, Avila MB, Levin NMB, Pintro VO, Carvalho NL, Azevedo WF.
# SAnDReS a Computational Tool for Statistical Analysis of Docking Results and
# Development of Scoring Functions. Comb Chem High Throughput Screen.
# 2016;19(10):801-812. doi: 10.2174/1386207319666160927111347. PMID: 27686428.
#
################################################################################
#                                                                              #
# Current Version 2.0.0.                                                       #
#                                                                              #
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version
# and use it in the analysis of your docking results. If you have any question
# regarding SAnDReS, please feel free to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Dr. Walter F. de Azevedo Jr.
# Process Numbers: 472590/2012-0, 308883/2014-4, 309029/2018-0, and
# 306298/2022-8.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# August 12, 2023                                                              #
################################################################################
#
# Import section
import sklearn
import numpy as np
import scipy
import sys
import platform
import psutil

# System information
print("="*33, "System Info", "="*34)
uname = platform.uname()
print(f"System: {uname.system}")
print(f"Node Name: {uname.node}")
print(f"Release: {uname.release}")
print(f"Version: {uname.version}")
print(f"Processor: {uname.processor}")

# CPU information
print("="*31, "CPU Information", "="*32)
# Number of cores
print("Physical cores:", psutil.cpu_count(logical=False))
print("Total cores:", psutil.cpu_count(logical=True))
# CPU frequencies
cpufreq = psutil.cpu_freq()
print(f"Max Frequency: {cpufreq.max:.2f}Mhz")
print(f"Min Frequency: {cpufreq.min:.2f}Mhz")
print(f"Current Frequency: {cpufreq.current:.2f}Mhz")
# CPU usage
print("CPU Usage Per Core:")
for i, percentage in enumerate(psutil.cpu_percent(percpu=True, interval=1)):
    print(f"Core {i}: {percentage}%")
print(f"Total CPU Usage: {psutil.cpu_percent()}%")

# Show current version of Python, scikit-learn, NumPy, SciPy, system OS, and
# a message about MLRegMPy
#
print("="*29, "Library Information", "="*30)
print("Python version: {}".format(sys.version[0:6]))
print("Scikit-learn version: {}".format(sklearn.__version__))
print("NumPy version: {}".format(np.__version__))
print("SciPy version: {}".format(scipy.__version__))

# Show SAnDReS information
print("="*29, "SAnDReS Information", "="*30)
# Show message about SAnDReS
print("""Statistical Analysis of Docking Results and Scoring functions
SAnDReS version: 2.0.0""")

# Show references
print("="*34, "References", "="*34)
print("""
Please cite the following references if you use the SAnDReS program.

Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0: New
Docking Methods, Expanded Force Field, and Python Bindings. J Chem Inf Model.
2021 Aug 23;61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203. PMID: 34278794.

Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, Blondel M,
Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A, Cournapeau D, Brucher
M, Perrot M, Duchesnay E. Scikit-learn: Machine Learning in Python. J Mach Learn
 Res. 2011; 12: 2825–2830.

Xavier MM, Heck GS, Avila MB, Levin NMB, Pintro VO, Carvalho NL, Azevedo WF.
SAnDReS a Computational Tool for Statistical Analysis of Docking Results and
Development of Scoring Functions. Comb Chem High Throughput Screen.
2016;19(10):801-812. doi: 10.2174/1386207319666160927111347. PMID: 27686428.

""")
