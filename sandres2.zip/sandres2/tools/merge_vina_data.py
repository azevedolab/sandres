# Define merge_redock_results() function
def merge_redock_results(spec_redock_file,project_dir_string):
    """Function to merge re-docking results for all structures in the dataset"""
    
    # Import libraries
    import shutil
    import csv
    import time
    
    # Get dataset dir from fndwat.in
    print("\nDataset directory will be read from fndwat.in file\n")
    
    # Get project directory
    #project_dir_string = str(strdir_entry.get())
    
    # Set up empty lists
    my_list = []
    my_ligs = []
    my_chain = []
    my_res = []
    my_scores_all = []
    my_ensemble_all = []
    my_rmsd_all = []
    my_rmsd_local = []
    local_list = []
    aux_scores_all = []
    
    # Try to open fndwat.in
    try:
        fo0 = open(project_dir_string+"fndwat.in","r")
        csv0 = csv.reader(fo0)
    except IOError:
        print("IOError! I can't find fndwat.in file!")
        return
    
    # Try to open chklig.in
    try:
        fo1 = open(project_dir_string+"chklig.in","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("IOError! I can't find chklig.in file!")
        return
    
    # Looping through chklig.in
    for line in csv1:
        if "CHKLIG" in line:
            print(line)
            my_list.append(line[1])             # PDB string
            my_ligs.append(line[2])             # Ligand string
            my_chain.append(line[3])            # Chain string
            my_res.append(line[4])              # Ligand number
    
    # Looping through fndwat.in
    for line in csv0:
        if "WATDIR" in line:
            my_dir = line[1]
    
    # Looping through my_list
    for line in my_list:
        
        # Try to open spec_redock_file
        try:
            print("Reading ",line,"...")
            fo2 = open(my_dir+line+"\\"+spec_redock_file,"r")
            csv2 = csv.reader(fo2)
        except IOError:
            print("IOError! I can't find "+spec_redock_file+" file!")
            return
            
        # Looping through csv2 to jump first line
        for line1 in csv2:
            
            # Some editing
            first_line0 = str(line1).replace("[","")
            first_line1 = first_line0.replace("]","")
            first_line2 = first_line1.replace("\'","")
            
            # Set i to zero
            i = 0
            
            # Looping through line to get RMSD column
            for line3 in line1:
                if "RMSD" in line3:
                    rmsd_col = i
                    break
                i += 1
            break
        
        # Looping through csv2 to get second line
        for line2 in csv2:
            my_ensemble_all.append(line2)
            local_list.append(line2)
            my_rmsd_all.append(line2[rmsd_col])
            my_rmsd_local.append(float(line2[rmsd_col]))
            break
        
        # Looping through the rest
        for line2 in csv2:
            my_rmsd_local.append(float(line2[rmsd_col]))
            local_list.append(line2)
        
        # Call get_min_of_list()
        my_index_2_use =  get_min_of_list(my_rmsd_local)
        
        # Append line for which RMSD is minimum
        my_scores_all.append(local_list[my_index_2_use])
        
        # Set up empty lists
        my_rmsd_local = []
        local_list = []
        
        # Close file            
        fo2.close()
   
    # Get local time
    my_local_time = str(time.strftime("%Y_%m_%d__%Hh%Mmin%Ss"))
    
    # Try to make backup of old ensembledock_vina.csv if present
    try:
        shutil.copy2(project_dir_string+"ensembledock_vina.csv",project_dir_string+\
                     "ensembledock_"+my_local_time+".csv")
        print("\nCopying enselbledock_vina.csv to "+ "ensembledock_"+my_local_time+".csv\n")
    except:
        print("\nNo ensembledock_vina.csv file.")
        
    # Open new ensembledock_vina.csv file
    fo3 = open(project_dir_string+"ensembledock_vina.csv","w")
    
    # Try to make backup of old scores_all_vina.csv if present
    try:
        shutil.copy2(project_dir_string+"scores_all_vina.csv",project_dir_string+\
                     "scores_all_"+my_local_time+".csv")
        print("\nCopying scores_all_vina.csv to "+ "scores_all_"+my_local_time+".csv\n")
    except:
        print("\nNo scores_all_vina.csv file.")
    
    # Open new scores_all_vina.csv file
    fo4 = open(project_dir_string+"scores_all_vina.csv","w")
    
    # Close files
    fo0.close()
    fo1.close()
    
    # Call read_torsdof()
    my_torsions_in = read_torsdof(project_dir_string)
    
    # Write headers
    first_line3 = first_line2.replace(" ","")
    first_line4 = first_line3.replace("Model","Name")
    fo3.write(first_line4+",Torsions\n")
    fo4.write(first_line4+",Torsions\n")
    
    # Looping through my_ensemble_all
    i = 0
    for line in my_ensemble_all:
        
        # Do some editing
        aux_line0 = str(line[1:])
        aux_line1 = aux_line0.replace("[","")
        aux_line2 = aux_line1.replace("]","")
        aux_line3 = aux_line2.replace("'","")
        mr_res_aux = str(my_res[i]).replace(" ","")
        
        # Write line
        fo3.write("[000]"+my_ligs[i]+"_"+mr_res_aux+" ["+my_chain[i]+"],"+aux_line3+","+str(my_torsions_in[i]))
        i += 1
    
    # Looping through my_scores_all
    i = 0
    for line in my_scores_all:
        # Do some editing
        aux_line00 = str(line[1:])
        aux_line01 = aux_line00.replace("[","")
        aux_line02 = aux_line01.replace("]","")
        aux_line03 = aux_line02.replace("'","")
        mr_res_aux = str(my_res[i]).replace(" ","")
        
        # Write line
        fo4.write("[000]"+my_ligs[i]+"_"+mr_res_aux+" ["+my_chain[i]+"],"+aux_line03+","+str(my_torsions_in[i]))
        i += 1
            
    # Close files
    fo3.close()
    fo4.close()
    
    # Try to open scores_all_vina.csv
    try:
        fo4 = open(project_dir_string+"scores_all_vina.csv","r")
        csv4 = csv.reader(fo4)
    except IOError:
        print("IOError! I can't find scores_all_vina.csv file!")
        return
    
    # Set up initial value for my_index_rmsd
    my_index_rmsd = 0
    
    # Looping through ,csv4
    for line in csv4:
       
        # Get RMSD column index
        if "RMSD" in line:
            my_index_rmsd = line.index("RMSD")
        
        # Add line information without RMSD column
        aux1 = str(line[:my_index_rmsd])
        aux2 = str(line[my_index_rmsd+1:])
        # Do some editing
        aux1_1 = aux1[1:].replace("\'","")
        aux2_1 = aux2.replace("[","")
        aux2_2 = aux2_1.replace("]","")
        aux2_3 = aux2_2.replace("\'","")
        aux_scores_all.append(aux1_1[:len(aux1_1)-1]+","+aux2_3)
    
    # Close file
    fo4.close()
    
    # Open new scores_all_vina.csv file
    fo4 = open(project_dir_string+"scores_all_vina.csv","w")
    
    # Looping thorugh aux_scores_all to write new scores_all_vina.csv file
    for line in aux_scores_all:
        fo4.write(line+"\n")
    
    # Close file
    fo4.close()
    
def read_torsdof(project_dir_string):
    """Function to read TORSDOF from each pdbqt file in the dataset"""
    
    # Import library
    import csv
    
    # Set up empty lists
    my_list = []
    my_torsion_number = []
        
    # Try to open fndwat.in
    try:
        fo0 = open(project_dir_string+"fndwat.in","r")
        csv0 = csv.reader(fo0)
    except IOError:
        print("IOError! I can't find file fndwat.in!")
        return
    
    # Try to open chklig.in
    try:
        fo1 = open(project_dir_string+"chklig.in","r")
        csv1 = csv.reader(fo1)
    except IOError:
        print("IOError! I can't find file chklig.in!")
        return
    
    # Looping through chklig.in
    for line in csv1:
        if "CHKLIG" in line:
            my_list.append(line[1])             # PDB string
    
    # Looping through fndwat.in
    for line in csv0:
        if "WATDIR" in line:
            my_dir = line[1]
            break
    
    # Looping through my_list
    for line in my_list:
        
        # Try to open lig.pdbqt
        try:
            fo2 = open(my_dir+line+"\\lig.pdbqt","r")
        except IOError:
            my_message1 = "ASsiMiLaTe-Vina IOError!"
            my_message2 = "ASsiMiLaTe-Vina didn't find "+str(line)+" file in the "+str(my_dir)+" directory."
            show_warning_message_pop_up(my_message1,my_message2)
            return
        
        # Get TORSDOF data
        for line1 in fo2:
            if "TORSDOF" in line1:
                my_torsion_number.append(line1[7:])
        
        # Close file
        fo2.close()
    
    # Close files
    fo0.close()
    fo1.close()
    
    return my_torsion_number
   
def get_min_of_list(list_in):
    """Function to get the index for the minimum of a list"""
    
    # Import library
    import numpy as np
    
    # Set up an array
    my_array = np.array(list_in)
                    
    # Find the minimum for the fitness function and assigns it to max_fit
    min_in_list = np.min(my_array)
            
    # Find the position for the min_in_list in the my_array
    pos_array = np.where( my_array == min_in_list)
                
    # Get the integer for index
    my_index = int(pos_array[0][0])
    
    return my_index