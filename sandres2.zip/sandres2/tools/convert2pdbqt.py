# Class to convert a ligand file to PDBQT format using AutoDockTools4 .
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import os
from MLRegMPy import backup

# Class to add pdbqt files to the datset
class LIGSTRUCTURE(object):
    """Class to convert a ligand file to PDBQT format using AutoDockTools4 """

    # Define constructor method
    def __init__(self,program_root,dir_in,dir_out):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.dir_out = dir_out

    # Define pdb2split() method
    def pdb2split(self,pdb_in,root_out):
        """Method to split a PDB file"""

        # Try to open a file
        file2open = self.dir_out+pdb_in
        try:
            # Try to open it
            fo_pdb = open(file2open,"r")
            pdb_lines = fo_pdb.readlines()

        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            return

        # Set up boolean variable
        go_writing = True

        # Assign 1 to count_mols
        count_mols = 1

        # Open new file
        file2create = self.dir_out+root_out+str(count_mols)+".pdb"
        fo_out = open(file2create,"w")

        # Looping through pdb_lines
        for line in pdb_lines:

            if "END" in str(line):

                # Write a line
                fo_out.write(str(line))

                # Update count_mols
                count_mols += 1

                # Check go_writing
                if go_writing:

                    # Close file
                    fo_out.close()

                # Open new file
                file2create = self.dir_out+root_out+str(count_mols)+".pdb"
                fo_out = open(file2create,"w")

                # Assign True to boolean variable
                go_writing = True

            elif go_writing:

                # Write a line
                fo_out.write(str(line))

        # Close files
        fo_out.close()
        fo_pdb.close()

    # Define mol2split() method
    def mol2split(self,mol2_in,root_out):
        """Method to split a mol2 file"""

        # This first reading is to get ligand codes. This data will be
        # written ligand_codes4vs.csv file
        # Try to open a file
        file2open = self.dir_out+mol2_in
        try:
            # Try to open it
            fo_mol2 = open(file2open,"r")
            mol2data = fo_mol2.readlines()

        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            return

        # Set up boolean variable
        next_line = False

        # Set up string
        ligand_code_string = "Ligand Number,Ligand Code\n"

        # Assign zero to count_codes
        count_codes = 0

        # Looping through mol2data
        for line in mol2data:

            # Check string
            if "<TRIPOS>MOLECULE" in str(line):
                next_line = True

            elif next_line:

                # Some editing
                ligand_code = str(line)
                ligand_code = ligand_code.replace("\n","")
                ligand_code = ligand_code.replace(" ","")

                # Update count_codes
                count_codes += 1

                # Add ligand code
                ligand_code_string += str(count_codes)+","+ligand_code+"\n"

                # Set up boolean variable
                next_line = False

        # Close file
        fo_mol2.close()

        # Invoke backup.make()
        backup.make("ligand_codes4vs.csv",self.dir_in,self.dir_in+"backup/")

        # Open a new file (ligand_codes4vs.csv)
        file_ligand_codes4vs = self.dir_in+"ligand_codes4vs.csv"
        fo_ligand_codes4vs = open(file_ligand_codes4vs,"w")

        # Write ligand codes
        fo_ligand_codes4vs.write(ligand_code_string)

        # Close file
        fo_ligand_codes4vs.close()

        # Try to open a file
        file2open = self.dir_out+mol2_in
        try:
            # Try to open it
            fo_mol2 = open(file2open,"r")
            mol2_lines = fo_mol2.readlines()

        except IOError:
            msg_out = "IOError! I can't find "+file2open+" file!"
            return

        # Set up boolean variable
        go_writing = False

        # Assign zero to count_mols
        count_mols = 0

        # Looping through mol2_lines
        for line in mol2_lines:

            if "<TRIPOS>MOLECULE" in str(line):

                # Update count_mols
                count_mols += 1

                # Check go_writing
                if go_writing:

                    # Close file
                    fo_out.close()

                # Open new file
                file2create = self.dir_out+root_out+str(count_mols)+".mol2"
                fo_out = open(file2create,"w")

                # Assign True to boolean variable
                go_writing = True

                # Write a line
                fo_out.write(str(line))

            elif go_writing:

                # Write a line
                fo_out.write(str(line))

        # Close files
        fo_out.close()
        fo_mol2.close()

    # Define read_adt() method
    def read_adt(self):
        """Method to read ADT preferences.
        Please see: http://autodock.scripps.edu/faqs-help/how-to/how-to-prepare-a-ligand-file-for-autodock4

        for additional information about options"""

        # Try to open adt_par.csv
        try:
            file2open = self.program_root+"misc/data/adt_par.csv"
            fo = open(file2open,"r")
            my_csv = csv.reader(fo)

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return None,None

        # Looping through self.program_par
        for line in my_csv:
            if line[0] == "prepare_ligand4_option":
                prepare_ligand4_option = line[1]
            elif line[0]  == "prepare_receptor4_option":
                prepare_receptor4_option = line[1]

        # Close file
        fo.close()

        # Return data
        return prepare_ligand4_option,prepare_receptor4_option

    # Define ligand2pdbqt()
    def ligand2pdbqt(self,lig_in,root_out):
        """Method to convert ligand structure to PDBQT format using
         AutoDockTools4 """

        # Invoke read_adt() method
        lig_option,_=self.read_adt()

        # Set up parameters
        tps_tools = self.program_root+"misc/linux_third_party_software/"
        code1_in = "prepare_ligand4.py"

        # Get ligands
        list_files = os.listdir(self.dir_out)

        # Set up empty list
        list_ligs = []

        # Looping through list_ligs
        for lig in list_files:
            if root_out in lig:
                list_ligs.append(lig)

        # looping through list_ligs
        for lig in list_ligs:

            # Replace ".mol2" to ".pdbqt
            lig_out = lig.replace(".mol2",".pdbqt")

            # Show message
            msg_out = "\nConverting "+lig+"..."
            print(msg_out)

            # Try to run Python script for ligands
            try:
                # Run Python script on Linux (pythonsh prepare_ligand4.py -l lig.pdb -Abond_hydrogens)
                os.system("pythonsh "+tps_tools+code1_in+' -l '+
                self.dir_out+lig+' -'+str(lig_option)+' -o'+self.dir_out+lig_out)

            except:
                # Second try
                try:
                    # Run Python script on Linux (pythonsh prepare_ligand4.py -l lig.pdb -Abond_hydrogens)
                    os.system("pythonsh "+tps_tools+code1_in+' -l '+
                    self.dir_out+lig+' -Ahydrogens -o'+self.dir_out+lig_out)

                except:
                    # Show message
                    msg_out = "Warning! Problems converting to PDBQT for file "+\
                    lig+"."
                    print(msg_out)
