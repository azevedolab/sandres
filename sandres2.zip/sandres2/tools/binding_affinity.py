#!/usr/bin/env python3
#
# Function to read the type of binding affinity used in a dataset.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# August 04, 2023                                                              #
################################################################################
#
def read_it(dir_in):
    """Function to read the type of binding affinity"""

    # Set up a list of binding affinities
    bind_list = ["IC50","Kd","Ki"]

    # Set up an empty string
    lines_out = ""

    # Looping through bind_list
    for bind in bind_list:

        # Try to open bind_####.csv file
        try:
            file2open = dir_in+"bind_"+bind+".csv"
            fo_bind = open(file2open,"r")

            # Close file
            fo_bind.close()

            break

        # Handle IOError exception
        except IOError:
            pass

    # Return the type of binding affinity
    return bind