# Import packages
import csv
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import array
import math
from os import path, mkdir
import time
import shutil
from tools import preferences as prefs

# Define Plots() class
class Plots(object):
    """Class to generate plot using Matplotlib"""

    # Define constructor method
    def __init__(self,program_root,plt_dir):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.plt_dir = plt_dir  # Project directory+"plots/" (string)

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        self.win_height_type_1,self.win_y_offset_type_1,\
        _,_,\
        _,_,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define show_version() method
    def show_version(self):
        """Method to show matplotlib version"""

        import matplotlib

        # Show matplotlib version
        print("\nCurrent Matplot Version: ",matplotlib.__version__)

    # Define plot_two_lists() method
    def plot_two_lists(self,t_s,list_1,xlab1,
                                x_label_size,ylab1,
                                list_2,xlab2,y_label_size,ylab2,
                                plt_file,
                                plt_resol,
                                plt_format,
                                plt_marker):
        """Generate simple scatter plots

            s_x: move figure to x coordinate (new center of the figure) (float),
            s_y: move figure to y coordinate (new center of the figure) (float),
            w: width in inches (float),
            h: height in inches (float),
            t_s: adjust (float),
            list_1: list for plot 1,
            xlab1: string for x-axis (string),
            x_label_size: size of ticks (x-axis) (integer),
            ylab1: string for y-axis (string),
            list_2: list for plot 2,
            xlab2: string for x-axis (string),
            y_label_size: size of ticks (x-axis) (integer),
            ylab2: string for y-axis (string),
            plt_file: file name (with extension defining format) (string),
            plt_resol: resolution in dpi (integer),
            plt_format: plot format (string),
            plt_marker: plot maker (string)
            """

        # Close previously created window, if it exists
        try:
            plt.close()
        except:
            pass

        # Show plot directory
        print("Checking directory: ",self.plt_dir)

        # Check if plot directory exists
        if path.exists(self.plt_dir):
            print ("\nDirectory exists!")
        else:
            mkdir(self.plt_dir)
            print ("\nNew directory:",self.plt_dir)

        # Check if file exists
        if path.exists(self.plt_dir+plt_file):

            # Show message
            print("\nFile "+self.plt_dir+plt_file+" exists!")

            # String for local time
            my_time = str(time.strftime("%Y_%m_%d_%Hh%Mmin%Ss"))

            # Some editing
            target_root = plt_file[:len(plt_file)-4]
            target_ext = plt_file[len(plt_file)-4:]
            target = target_root+"_"+my_time+target_ext
            target_dir = self.plt_dir.replace("plot/","backup/")

            # Show message
            print("Making backup to "+self.plt_dir+target)

            # Copy file
            shutil.copyfile(self.plt_dir+plt_file,target_dir+target)

        # Define tick_significant_figures() function
        def tick_significant_figures(a_n):
            rounded_number="{0:.2g}".format(a_n)
            return str(rounded_number)

        # Set up arrays
        y1 = np.array(list_1)
        y2 = np.array(list_2)
        x = array.array('i',(i for i in range(1,len(list_1)+1 )))

        # Set up subplot
        fig = plt.figure(figsize=(self.w,self.h))           # Size in inches
        plt.rcParams['xtick.labelsize'] = x_label_size      # Tick size
        plt.rcParams['ytick.labelsize'] = y_label_size      # Tick size
        fig.canvas.manager.window.move(self.s_x,self.s_y)   # Coordinates in pixels
        fig.subplots_adjust(top=t_s)                        # Adjust subplots

        # Set up tick_spacing
        if len(x) < 20:
            tick_spacing = 1
        elif len(x) > 50:
            tick_spacing = 10
        elif len(x) > 100:
            tick_spacing = 20
        elif len(x) > 500:
            tick_spacing = 100
        elif len(x) > 2000:
            tick_spacing = 200
        elif len(x) > 4000:
            tick_spacing = 400
        elif len(x) > 10000:
            tick_spacing = 1000
        elif len(x) > 20000:
            tick_spacing = 2000
        else:
            tick_spacing = 5

        # Set up subplot 1
        ax1 = fig.add_subplot(211)
        ax1.set_xlabel(xlab1)
        ax1.set_xlim(-int(tick_spacing/2),len(x)+tick_spacing)
        ax1.set_ylabel(ylab1)
        #ax1.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
        line, = ax1.plot(x, y1, color='black',marker=plt_marker)

        # Set up subplot 2
        ax2 = fig.add_subplot(212)
        fmt = ticker.FuncFormatter(lambda y, pos: tick_significant_figures(y))
        ax2.yaxis.set_major_formatter(fmt)
        ax2.set_xlabel(xlab2)
        ax2.set_xlim(-int(tick_spacing/2),len(x)+tick_spacing)
        ax2.set_ylabel(ylab2)
        #ax2.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
        line, = ax2.plot(x, y2, color='black',marker=plt_marker)

        # Show plots
        #plt.show()

        # Generate plot figure
        #plt.savefig(self.plt_dir+plt_file, dpi=plt_resol, format=plt_format)
        plt.savefig(self.plt_dir+plt_file, format=plt_format)

    # Define plot_one_list() method
    def plot_one_list(self,t_s,list_1,xlab1,x_label_size,ylab1,
                                y_label_size,
                                plt_file,
                                plt_resol,
                                plt_format,
                                plt_marker):
        """Generate simple scatter plots

            s_x: move figure to x coordinate (new center of the figure) (float),
            s_y: move figure to y coordinate (new center of the figure) (float),
            w: width in inches (float),
            h: height in inches (float),
            t_s: adjust (float),
            list_1: list for plot 1,
            xlab1: string for x-axis (string),
            x_label_size: size of ticks (x-axis) (integer),
            ylab1: string for y-axis (string),
            y_label_size: size of ticks (y-axis) (integer),
            plt_file: file name (with extension defining format) (string),
            plt_resol: resolution in dpi (integer),
            plt_format: plot format (string),
            plt_marker: plot maker (string)
            """

        # Close previously created window, if it exists
        try:
            plt.close()
        except:
            print()

        # Show plot directory
        print("Checking directory: ",self.plt_dir)

        # Check if plot directory exists
        if path.exists(self.plt_dir):
            print ("\nDirectory exists!")
        else:
            mkdir(self.plt_dir)
            print ("\nNew directory:",self.plt_dir)

        # Check if file exists
        if path.exists(self.plt_dir+plt_file):

            # Show message
            print("\nFile "+self.plt_dir+plt_file+" exists!")

            # String for local time
            my_time = str(time.strftime("%Y_%m_%d_%Hh%Mmin%Ss"))

            # Some editing
            target_root = plt_file[:len(plt_file)-4]
            target_ext = plt_file[len(plt_file)-4:]
            target = target_root+"_"+my_time+target_ext
            target_dir = self.plt_dir.replace("plot/","backup/")

            # Show message
            print("Making backup to "+self.plt_dir+target)

            # Copy file
            shutil.copyfile(self.plt_dir+plt_file,target_dir+target)

        # Define tick_significant_figures() function
        def tick_significant_figures(a_n):
            rounded_number="{0:.2g}".format(a_n)
            return str(rounded_number)

        # Set up arrays
        y1 = np.array(list_1)
        x = array.array('i',(i for i in range(1,len(list_1)+1 )))

        # Set up subplots
        fig = plt.figure(figsize=(self.w,self.h))       # Size in inches
        plt.rcParams['xtick.labelsize'] = x_label_size  # Tick size
        plt.rcParams['ytick.labelsize'] = y_label_size  # Tick size
        fig.canvas.manager.window.move(self.s_x,self.s_y) # Coordinates in pixels
        fig.subplots_adjust(top=t_s)                    # Adjust subplots

        # Set up tick_spacing
        if len(x) < 20:
            tick_spacing = 1
        elif len(x) > 50:
            tick_spacing = 10
        elif len(x) > 100:
            tick_spacing = 20
        elif len(x) > 500:
            tick_spacing = 100
        elif len(x) > 2000:
            tick_spacing = 200
        elif len(x) > 4000:
            tick_spacing = 400
        elif len(x) > 10000:
            tick_spacing = 1000
        elif len(x) > 20000:
            tick_spacing = 2000
        else:
            tick_spacing = 5

        # Set up subplot 1
        ax1 = fig.add_subplot(111) # (211)
        ax1.set_xlabel(xlab1)
        ax1.set_ylabel(ylab1)
        #ax1.xaxis.set_major_locator(ticker.MultipleLocator(tick_spacing))
        line, = ax1.plot(x, y1, color='black',marker=plt_marker)
        fmt = ticker.FuncFormatter(lambda y, pos: tick_significant_figures(y))
        ax1.yaxis.set_major_formatter(fmt)

        # Show plots
        plt.show()

        # Generate plot figure
        plt.savefig(self.plt_dir+plt_file, dpi=plt_resol, format=plt_format)
