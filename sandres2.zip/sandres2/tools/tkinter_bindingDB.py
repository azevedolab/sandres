#!/usr/bin/env python3
#
# Class to handle binding affinity data downloaded from BindingDB.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import packages
from tkinter import *
from tools import bindingDB as bindDB
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs

# Define AffinityData() class
class AffinityData(object):
    """Class to handle binding affinity data downloaded from BindingDB"""

    # Define constructor method
    def __init__(self,program_root,dir_in,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.root = root

        # Set up message about the main reference for BindingDB
        self.bindingDB_ref = "\nWhen using BindingDB data, please cite: "
        self.bindingDB_ref = "Gilson MK, Liu T, Baitaluk M, Nicola G, Hwang L, "
        self.bindingDB_ref = "Chong J. BindingDB in 2015: A public database "
        self.bindingDB_ref = "for medicinal chemistry, computational chemistry "
        self.bindingDB_ref = "and systems pharmacology. "
        self.bindingDB_ref = "\nNucleic Acids Res. 2015; 44(D1):D1045-53."
        self.bindingDB_short_msg = self.bindingDB_ref

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

    # Define prep_GUI() method
    def prep_GUI(self):
        """Method to invoke sorting_GUI() method """

        # Invoke input_GUI() method
        self.input_GUI()

    # Define input_GUI() method
    def input_GUI(self):
        """Method to call bindingDB"""

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Check screen resolution
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Set up top_txt_geom based on screen_width
        if screen_width >= 1900:
            pass
        elif screen_width >= 1200:
            top_txt_geom = "880x100+0+138"
        else:
            top_txt_geom = "880x80+0+138"

        # Creates child window
        top_txt = Toplevel()
        top_txt.title('BindingDB')
        top_txt.geometry(top_txt_geom)

        # Widget for BindingDB SDF
        Label(top_txt,text="BindingDB SDF:").grid(row=1,column=0,stick=W)
        self.sdf_in = Entry(top_txt,width = 30)
        self.sdf_in.grid(row = 1, column = 1,stick = E)
        self.sdf_in.insert(0,"cdk2_ic50.sdf")

        # Widget for BindingDB TSV
        Label(top_txt,text="BindingDB TSV:").grid(row=2,column=0,stick=W)
        self.tsv_in = Entry(top_txt,width = 30)
        self.tsv_in.grid(row = 2, column = 1,stick = E)
        self.tsv_in.insert(0,"cdk2_ic50.tsv")

        # Widget for binding affinity type
        Label(top_txt,text="Binding Affinity:" ).grid(row = 3,column = 0,stick=W)
        self.bind_in = Entry(top_txt,width = 30)
        self.bind_in.grid(row = 3, column = 1,stick = E)
        self.bind_in.insert(0,"IC50")

        # Widget for option
        Label(top_txt,text="Option:" ).grid(row = 4,column = 0,stick=W)
        self.option_in = Entry(top_txt,width = 30)
        self.option_in.grid(row = 4, column = 1,stick = E)
        self.option_in.insert(0,"Clean")

        # Label (Insert space to get the right position of botton bar) -25 -28
        Label(top_txt, text = (self.win_y_offset_type_2-31)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=4, column=3, sticky=W)

        # Widgets for Joblib
        Button(top_txt,text='Prepare',command=self.do_it).grid(row=4,
        column = 4, sticky = W)

        # Widgets for Close button
        Button(top_txt, text=' Close', bg = "red",
        command=top_txt.destroy).grid(row = 4, column = 5,sticky = E)

    # Define do_it() method
    def do_it(self):
        """Method to filter BindingDB data"""

        # Import library
        from tkinter import messagebox

        # Get binding affinity type
        chosen_bind_in = str(self.bind_in.get())

        # Get sdf_in
        chosen_sdf_in = str(self.sdf_in.get())
        sdf_out = chosen_sdf_in.replace(".sdf","_out.sdf")

        # Get tsv_in
        chosen_tsv_in = str(self.tsv_in.get())

        # Get option_in
        chosen_option_in = str(self.option_in.get())

        # Define output
        csv_data = "affinity_BindingDB_"+chosen_bind_in+".csv"

        # Assign an empty string to vs_in
        vs_in = ""

        # Instantiate an object of Ligand() class
        b1 =bindDB.Ligand(self.program_root,self.dir_in,chosen_sdf_in,
                            chosen_bind_in,chosen_tsv_in,csv_data,vs_in,
                            chosen_option_in,sdf_out)

        # Invoke read_sdf() method
        b1.read_sdf()

        # Invoke get_id() method
        list_id = b1.get_id()

        # Invoke change_ligand_id() method
        b1.change_ligand_id()

        # Invoke get_binding_affinity() method
        b1.get_binding_affinity()

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.dir_in,self.root)

        # Invoke show_botton_msg() method
        msg_out = "Done! SAnDReS prepared BindingDB data "
        msg_out += "for machine learning modeling!"
        msg1.show_botton_msg(msg_out,"black","light grey")
        print(msg_out)