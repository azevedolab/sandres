# Class to carry out statistical analysis of the docking results obtained
# using AutoDock Vina (Trott & Olson, 2010; Eberhardt et al., 2021).
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import numpy as np
import csv
import os
import shutil

# Define Stats() class
class Stats(object):
    """Class to hand PDBQT files for ligand and receptor structures and
    carry out statistical analysis of docking simulations using AutoDock Vina"""

    # Define constructor method
    def __init__(self,program_root,dir_in,ligand_in,ligand_out):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.ligand_in = ligand_in
        self.ligand_out = ligand_out

        # Set up empty lists
        self.lowest_rmsd = []
        self.lowest_list = []
        self.lowest_pdb = []

    # Define remove_results() method
    def remove_results(self,pdb,file_in1,file_in2,file_in3):
        """Method to delete previously created files"""

        # Set up list2delete
        list2delete = [file_in1,file_in2,file_in3]

        # Looping through list2delete
        for file_in in list2delete:
            #file2delete = self.dir_in+"pdbqt/"+pdb+"/"+file_in
            file2delete = self.dir_in+pdb+"/"+file_in

            # Try to delete
            try:
                os.remove(file2delete)
            except:
                pass

    # Define read_xtal_xyz() method
    def read_xtal_xyz(self,pdb,pdb_in):
        """Method to read a PDB file and return atomic coordinates
        and atom types"""

        # Set up empty lists
        x = []
        y = []
        z = []
        atom_list = []

        # Try to open a PDB file
        #file2open = self.dir_in+"pdbqt/"+pdb+"/"+pdb_in
        file2open = self.dir_in+pdb+"/"+pdb_in
        try:
            fo_str = open(file2open,"r")
            str_lines = fo_str.readlines()
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            print(msg_out)
            return atom_list,x,y,z

        # Looping through str_lines
        for line in str_lines:

            # Select lines starting with "HETATM" or "ATOM  "
            if line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
                atom_string0 = line[77:].replace(" ","")
                atom_string1 = atom_string0.replace("\n","")
                atom_list.append(atom_string1)

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)

        # Close file
        fo_str.close()

        # Return arrays
        return atom_list,x_a,y_a,z_a

    # Define read_xtal_pdbqt() method
    def read_xtal_pdbqt(self,pdb):
        """Method to read a PDBQT file and return atomic coordinates and
        atomic charges"""

        # Set up empty lists
        x = []
        y = []
        z = []
        list_charges = []

        # Try to open ligand PDBQT file
        #file2open = self.dir_in+"pdbqt/"+pdb+"/"+self.ligand_in
        file2open = self.dir_in+pdb+"/"+self.ligand_in
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()

        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            print(msg_out)
            return x,y,z

        # Looping through lig_lines
        for line in lig_lines:

            # Select lines starting with "HETATM" or "ATOM  "
            if line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
                list_charges.append(float(line[69:76]))

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)
        charges = np.array(list_charges)

        # Close file
        fo_lig.close()

        # Return arrays
        return charges,x_a,y_a,z_a

    # Define read_reference_xyz() method
    def read_reference_xyz(self,pdb,lig_in):
        """Method to read a reference ligand PDBQT file and return atomic
        coordinates"""

        # Set up empty lists
        x = []
        y = []
        z = []

        # Try to open ligand PDBQT file
        #file2open = self.dir_in+"pdbqt/"+pdb+"/"+lig_in
        file2open = self.dir_in+pdb+"/"+lig_in
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            print(msg_out)
            return x,y,z

        # Looping through lig_lines
        for line in lig_lines:

            # Select lines starting with "HETATM" or "ATOM  "
            if line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)

        # Close file
        fo_lig.close()

        # Return arrays
        return x_a,y_a,z_a

    # Define read_pose_xyz() method
    def read_pose_xyz(self,pdb,pose_in,pose_number):
        """Method to read a pose PDBQT file and return atomic coordinates"""

        # Set up empty lists
        x = []
        y = []
        z = []

        # Assign False to model_boolean
        model_boolean = False

        # Try to open ligand PDBQT file
        #file2open = self.dir_in+"pdbqt/"+pdb+"/"+pose_in
        file2open = self.dir_in+pdb+"/"+pose_in
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()
        except IOError:
            msg_out = "\nI can't find "+file2open+" file!"
            print(msg_out)
            return x,y,z

        # Looping through lig_lines
        for line in lig_lines:
            if  line[:6] == "MODEL " and int(line[6:]) == pose_number:
                model_boolean = True
            elif model_boolean and line[:6] == "ENDMDL":
                model_boolean = False
            elif model_boolean and line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)

        # Close file
        fo_lig.close()

        # Return arrays
        return x_a,y_a,z_a

    # Define rmsd() method
    def rmsd(self,pdb,results_file,x1,y1,z1,x2,y2,z2):
        """Method to calculate docking rmsd and read binding affinity
        energy for the lowest energy pose"""

        # Try to open PDBQT file with docking poses
        #file2open = self.dir_in+"pdbqt/"+pdb+"/"+self.ligand_out
        file2open = self.dir_in+pdb+"/"+self.ligand_out
        try:
            fo_poses = open(file2open, "r")
            pdbqt_lines = fo_poses.readlines()
        except:
            print("\nI can't find "+file2open+" file!")
            return

        # Read pose binding affinity energy
        for line in pdbqt_lines:
            if "REMARK VINA RESULT:" in line:
                binding_energy = float(line[20:29])
                break

        # Close PDBQT file
        fo_poses.close()

        # Number of elements in x1 array
        n = len(x1)

        # Assign zero to sum_d
        sum_d = 0.0

        # Calculate distance and sum them all
        for i in range(n):
            d = (x1[i]-x2[i])**2 + (y1[i]-y2[i])**2 + (z1[i]-z2[i])**2
            sum_d += d

        # Calculate RMSD
        r = np.sqrt(sum_d/n)

        # Write RMSD and pose binding affinity energy
        #pdb_dir = self.dir_in+"pdbqt/"+pdb+"/"
        pdb_dir = self.dir_in+pdb+"/"
        fo = open(pdb_dir+results_file,"w")
        line_out = "RMSD,"+str(r)
        fo.write(line_out)

        # Close file
        fo.close()

    # Define show_rmsd() method
    def show_rmsd(self,pdb,x1,y1,z1,x2,y2,z2):
        """Method to calculate docking rmsd and show results on screen"""

        # Number of elements in x1 array
        n = len(x1)

        # Assign zero to sum_d
        sum_d = 0.0

        # Calculate distance and sum them all
        for i in range(n):
            d = (x1[i]-x2[i])**2 + (y1[i]-y2[i])**2 + (z1[i]-z2[i])**2
            sum_d += d

        # Calculate RMSD
        r = np.sqrt(sum_d/n)

        # Show RMSD
        print("\n RMSD (A) for structure "+pdb+": {:.3f}".format(r))

    # Define check_single_rmsd() method
    def check_single_rmsd(self,pdb):
        """Method to read docking rmsd"""

        # Set up empty lists
        centering_method = []
        docking_list = []

        # Set up rmsd_list with three files to check
        rmsd_list = ["vina_results_mass.csv"]

        # Check all results
        for file_in in rmsd_list:

            # Try to open a file
            #file2open = self.dir_in+"pdbqt/"+pdb+"/"+file_in
            file2open = self.dir_in+pdb+"/"+file_in
            try:
                fo_rmsd = open(file2open,"r")
                csv_rmsd = csv.reader(fo_rmsd)
            except IOError:
                msg_out = "\nI can't find "+file2open+" file!"
                print(msg_out)

            # Looping through rmsd_lines
            for line in csv_rmsd:
                if line[0] == "RMSD":
                    docking_list.append(float(line[1]))
                    centering_method.append(file_in[13:len(file_in)-4])

            # Close file
            fo_rmsd.close()

        # Set up array
        rmsd_array = np.array(docking_list)

        # Find lowest RMSD and related energy
        self.lowest_rmsd.append(np.amin(rmsd_array))
        i_lowest = np.argmin(rmsd_array)
        self.lowest_list.append(centering_method[i_lowest])
        self.lowest_pdb.append(pdb)

    # Define check_rmsd() method
    def check_rmsd(self,pdb):
        """Method to select which docking result generated the lowest rmsd"""

        # Set up empty lists
        centering_method = []
        docking_list = []

        # Set up rmsd_list with three files to check
        rmsd_list = ["vina_results_mass.csv","vina_results_geometric.csv",
                    "vina_results_electric.csv"]

        # Check all results
        for file_in in rmsd_list:

            # Try to open a file
            #file2open = self.dir_in+"pdbqt/"+pdb+"/"+file_in
            file2open = self.dir_in+pdb+"/"+file_in
            try:
                fo_rmsd = open(file2open,"r")
                csv_rmsd = csv.reader(fo_rmsd)
            except IOError:
                msg_out = "\nI can't find "+file2open+" file!"
                print(msg_out)

            # Looping through rmsd_lines
            for line in csv_rmsd:
                if line[0] == "RMSD":
                    docking_list.append(float(line[1]))
                    centering_method.append(file_in[13:len(file_in)-4])

            # Close file
            fo_rmsd.close()

        # Set up array
        rmsd_array = np.array(docking_list)

        # Find lowest RMSD and related energy
        self.lowest_rmsd.append(np.amin(rmsd_array))
        i_lowest = np.argmin(rmsd_array)
        self.lowest_list.append(centering_method[i_lowest])
        self.lowest_pdb.append(pdb)

    # Define show_lowest_rmsd() method
    def show_lowest_rmsd(self):
        """Method to show a list of the lowest RMSD after running all docking
        simulations"""

        # Header
        lines_out = "PDB,Centering Method,RMSD(A)\n"

        # Looping through all PDB structures
        for i in range(len(self.lowest_rmsd)):
            lines_out += self.lowest_pdb[i]+","+self.lowest_list[i]+\
            ",{:.3f}".format(self.lowest_rmsd[i])+"\n"

        # Open new file
        file2open = self.dir_in+"vina_rmsd_results.csv"
        fo_final_results = open(file2open,"w")

        # Write RMSD results
        fo_final_results.write(lines_out)

        # Close file
        fo_final_results.close()

    # Define clean_dir()
    def clean_dir(self):
        """Method to delete temporary files"""

        # Try to open a file
        file2open = self.dir_in+"vina_rmsd_results.csv"

        try:
            fo_final_results = open(file2open,"r")
            csv_results = csv.reader(fo_final_results)
        except:
            print("\nI can't find "+file2open+" file!")

        # Show message
        print("\nDeleting temporary files.")

        # Set up list
        list_centering = ["mass","geometric","electric"]

        # Looping through csv_results
        for line in csv_results:
            break

        # Looping through csv_results
        for line in csv_results:
            pdb = line[0]
            for centering in list_centering:
                file_in1 = "config_"+centering+".txt"
                file_in2 = "lig_out_"+centering+".pdbqt"
                file_in3 = "vina_results_"+centering+".csv"
                self.remove_results(pdb,file_in1,file_in2,file_in3)

        # Close file
        fo_final_results.close()

        # Show message
        print("\nDone!")

    # Define bundle() method (statistical analysis)
    def bundle(self,pdb):
        """Method to carry out statistical analysis of docking results"""

        # Invoke read_reference_xyz() method
        x1,y1,z1 = self.read_reference_xyz(pdb,self.ligand_in)

        # Set up file name
        results_file = "vina_results.csv"

        # Invoke read_pose_xyz() method
        x2,y2,z2 = self.read_pose_xyz(pdb,self.ligand_out,1)

        # Invoke rmsd() method
        self.rmsd(pdb,results_file,x1,y1,z1,x2,y2,z2)
