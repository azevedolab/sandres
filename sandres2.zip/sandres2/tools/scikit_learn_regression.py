# Function to run regression methods available in scikit-learn.
#
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import section
import os
import shutil
from tools import tkinter_messages as tk_msg
from tools import binding_affinity as b_aff
import warnings

# Ignore warnings
warnings.filterwarnings('ignore')

# Define run_all() function
def run_all(root,project_dir_string,mode_in):
    """Function to run all steps necessary to generate regression models
        using Scikit-Learn"""

    # Instantiate an object of Messages() class
    msg1 = tk_msg.Messages(project_dir_string,root)

    # Invoke read_it function
    bind_in = b_aff.read_it(project_dir_string)

    # Set up sf_csv_in
    sf_csv_in = "bind_"+bind_in+".csv"

    # Copy sf_csv_in to new_sf_sim_in
    source = project_dir_string+sf_csv_in
    target = project_dir_string+"scores4xtal.csv"
    shutil.copy(source,target)

    # Set up misc_dir
    misc_dir = "./misc/data/"

    # Try to run mlr.py with python3 command
    try:
        # Command to run mlr.py
        cmd_line = "python3 mlr.py "+misc_dir+"mlr.in "+mode_in
        cmd_line += " > "+project_dir_string+"mlr.log &"
        os.system(cmd_line)

    # Handle exception
    except:
        # Try to run mlr.py with python command
        try:
            # Command to run mlr.py
            cmd_line = "python mlr.py "+misc_dir+"mlr.in "+mode_in
            cmd_line += " > "+project_dir_string+"mlr.log &"
            os.system(cmd_line)
        except:
            msg_out = "Error! Check Python installation!"
            print(msg_out)

    else:
        # Invoke show_botton_msg() method
        msg_out = "Done! No regression modeling performed!"
        print(msg_out)
        return

    # Invoke show_botton_msg() method
    msg_out = "Done! SAnDReS finished regression methods"
    msg1.show_botton_msg(msg_out,"black","light grey")
    print(msg_out)