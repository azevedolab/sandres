# Import packages
from tkinter import *
from tools import tkinter_messages as tk_msg
from tools import preferences as prefs
from tools import contacts3d as con3d

# Define ContactMap3D() class
class ContactMap3D(object):
    """Class to create a contact map in 3D"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Define ascii_art
        # https://patorjk.com/software/taag/#p=display&f=ANSI%20Shadow&t=2D-Plot
        self.art_3D_plot = """
██████╗ ██████╗       ██████╗ ██╗      ██████╗ ████████╗
╚════██╗██╔══██╗      ██╔══██╗██║     ██╔═══██╗╚══██╔══╝
 █████╔╝██║  ██║█████╗██████╔╝██║     ██║   ██║   ██║
 ╚═══██╗██║  ██║╚════╝██╔═══╝ ██║     ██║   ██║   ██║
██████╔╝██████╔╝      ██║     ███████╗╚██████╔╝   ██║
╚═════╝ ╚═════╝       ╚═╝     ╚══════╝ ╚═════╝    ╚═╝
 """

    # Define pre_intermol3d_GUI() method
    def pre_intermol3d_GUI(self):
        """Method to invoke intermol_GUI() method """

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() message
        msg_out = "Ready to generate 3D-plots using Matplotlib!"
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Call show_short_msg() method
        msg_out = self.art_3D_plot+"\nUsing Matplotlib available at "
        msg_out += "https://matplotlib.org/"
        msg1.show_short_msg(msg_out)

        # Invoke intermol3d_GUI() method
        self.intermol3d_GUI()

    # Define intermol3d_GUI() method
    def intermol3d_GUI(self):
        """Method to call intermol"""

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = \
        self.pr1.tkinter_geometry(self.screen_geometry_var,
        self.win_height_type_2,self.win_y_offset_type_2)

        # Creates child window
        top_txt = Toplevel()
        top_txt.title('Matplotlib mplot3d Toolkit')
        top_txt.geometry(top_txt_geom)

        # Widgets for 3D View
        Button(top_txt,text=' 3D-View ',command=self.call_intermol3d_view).grid(row=4,
        column = 1, sticky = W)

        # Widgets for Plot
        Button(top_txt,text=' Plot ',command=self.call_intermol3d_plot).grid(row=4,
        column = 2, sticky = E)

        # Label (Insert space to get the right position of botton bar)
        Label(top_txt, text = (self.win_y_offset_type_2+5)*" " ,
            fg = "black",
            font = "Helvetica 10 bold italic" ).grid(row=5, column=4, sticky=W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
        command=top_txt.destroy).grid(row = 5, column = 5,sticky = E)

    # Define call_intermol3d_plot() method
    def call_intermol3d_plot(self):
        """Method to generate 3D plot"""

        # Import library
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Set up boolean variable
        plot_boolean = False

        # Ask yes/no question
        msg_out = "Do you want to generate 3D intermolecular contact plot?"
        result = messagebox.askyesno("",msg_out)

        # Test answer
        if result:

            # Set up boolean variable
            plot_boolean = True

            # Instantiate an object of Inter3DMolContact() class
            map3d = con3d.Inter3DMolContact(self.program_root,
            project_dir_string)

            # Invoke plot3d_data() method
            map3d.plot3d_data(plot_boolean)

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished \"Add 3D Plot\" request!"
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Invoke show_short_msg() method
            msg1.show_short_msg(self.art_3D_plot+"\nDone!\n")

        else:

            # Invoke show_botton_msg() method
            msg_out="No request for generating 3D plot for intermolecular contacts!"
            msg1.show_botton_msg(msg_out,"black","light grey")

    # Define call_intermol3d_view() method
    def call_intermol3d_view(self):
        """Method to call view 3D plot"""

        # Import library
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Set up boolean variable
        plot_boolean = True

        # Ask yes/no question
        result = messagebox.askyesno("","Do you want to view 3D intermolecular contact plot?")

        if result:

            # Set up boolean variable
            plot_boolean = False

            # Instantiate an object of Inter3DMolContact() class
            map3d = con3d.Inter3DMolContact(self.program_root,
            project_dir_string)

            # Invoke plot3d_data() method
            map3d.plot3d_data(plot_boolean)

            # Invoke show_botton_msg() method
            msg_out = "SAnDReS finished \"Add 3D Plot\" request!"
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Invoke show_short_msg() method
            msg1.show_short_msg(self.art_3D_plot+"\nDone!\n")

        else:

            # Invoke show_botton_msg() method
            msg_out="No request for viewing 3D plot for intermolecular contacts!"
            msg1.show_botton_msg(msg_out,"black","light grey")