#!/usr/bin/env python3
#
# Class to generate a scatter plot, and find the best fit polynommial equation.
# Data for arrays x and y are read from a CSV file
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import os
import numpy as np
import matplotlib.pyplot as plt
from tools import backup_all

# Define ScatterPlot() class
class ScatterPlot(object):

    # Define constructor method
    def __init__(self,dir_in):
        """Constructor method"""

        # Set up attribute
        self.dir_in = dir_in

    # Define read_csv() method
    def read_csv(self,data_file,X_col,y_col):
        """Method to read two columns in a CSV file
        If follows the list of parameters of this method:

        data_file: string for a CSV input file
        X_col: integer for the number of the column for x-axis
        y_col: integer for the number of the column for y-axis

        """

        # Reads CSV file
        my_csv = np.genfromtxt(self.dir_in+data_file,delimiter=",",
                                skip_header=1)

        # Gets each column from CSV file
        self.X = my_csv[:,X_col]
        self.y = my_csv[:,y_col]

    # Define generate() method
    def generate(self,plot_file,marker_in,
                X_label,y_label,X_size,y_size,
                X_tick_size,y_tick_size,rot_X_tick,rot_y_tick,
                title_in,title_size,
                scatter_color,line_color,dpi_in,reg_line,
                include_x_lim,x_min_in,x_max_in,
                include_y_lim,y_min_in,y_max_in,
                include_grid,grid_color,grid_linestyle,grid_linewidth,
                go_2dview):
        """Method to generate a scatter plot for data in a CSV file.
        If follows the list of parameters of this method:

        data_file: string for a CSV input file
        plot_file: string for the output scatter plot
        marker_in: string for the type of point used for the scatter plot.

                   Examples:
                    "."     point
                    ","     pixel
                    "o"     circle
                    "v"     triangle_down
                    "^"     triangle_up
                    "<"     triangle_left
                    ">"     triangle_right
                    "1"     tri_down
                    "2"     tri_up
                    "3"     tri_left
                    "4"     tri_right
                    "8"     octagon
                    "s"     square
                    "p"     pentagon
                    "P"     plus (filled)
                    "*"     star
                    "h"     hexagon1
                    "H"     hexagon2
                    "+"     plus
                    "x"     x
                    "X"     x (filled)
                    "D"     diamond
                    "d"     thin_diamond
                    "|"     vline
                    "_"     hline

                   Complete list available at
                   https://matplotlib.org/stable/api/markers_api.html

        X_label: string for a label used in the x-axis
        y_label: string for a label used in the y-axis
        X_size: integer for the font size in the label of x-axis
        y_size: integer for the font size in the label of y-axis
        X_tick_size: integer for the font size in the tick marks of x-axis
        y_tick_size: integer for the font size in the tick marks of y-axis
        rot_X_tick: integer for the rotation in the tick marks of x-axis
        rot_y_tick: integer for the rotation in the tick marks of y-axis
        title_in: string for the title of the plot
        title_size: integer for the font size of the title
        scatter_color: string used to choose the color of the points
        line_color: string used to choose the color of the regression line
        dpi_in: integer for the plot resolution
        reg_line: string for inclusion of regression line in the plot
        include_x_lim: string for inclusion of limits in the x-axis
        x_min_in: float for the minimum value in the x-axis
        x_max_in: float for the maximum value in the x-axis
        include_y_lim: string for inclusion of limits in the y-axis
        y_min_in: float for the minimum value in the y-axis
        y_max_in: float for the maximum value in the y-axis
        include_grid: string for inclusion of grid lines
        grid_color: string for grid color
        grid_linestyle: string for grid line style (supported values are '-',
                                                    '--', '-.', ':', 'None',
                                                     ' ', '', 'solid',
                                                     'dashed', 'dashdot',
                                                      'dotted')
        grid_linewidth: float for line width in the grid
        go_2dview: string, if "On" generates view only otherwise plot

        """

        # Try to make dir (plots/)
        try:
            # Make dir
            os.mkdir(self.dir_in+"plots/")

        # Handle exception
        except:
            pass

        # Try to make dir (backup/)
        try:
            # Make dir
            os.mkdir(self.dir_in+"backup/")

        # Handle exception
        except:
            pass

        # Invoke backup_all.make()
        backup_all.make(plot_file,self.dir_in+"plots/",self.dir_in+"backup/")

        # Check reg_line
        if reg_line.upper() == "ON":

            # Least-squares polynomial fitting
            z = np.polyfit(self.X,self.y,1)
            p = np.poly1d(z)

            # Check include_x_lim
            if include_x_lim.upper() == "ON":

                # Include limits in the x array
                new_X = np.append(self.X,[x_min_in,x_max_in])

                # Plot line
                plt.plot(new_X,p(new_X),color=line_color)

            else:

                # Plot line
                plt.plot(self.X,p(self.X),color=line_color)

        # Generates plot plt.xlim(0, 10)
        plt.scatter(self.X,self.y,marker=marker_in,color=scatter_color)

        # Check include_x_lim
        if include_x_lim.upper() == "ON":
            plt.xlim(x_min_in,x_max_in)

        # Check include_y_lim
        if include_y_lim.upper() == "ON":
            plt.ylim(y_min_in,y_max_in)

        # Check include_grid
        if include_grid.upper() == "ON":
            plt.grid(color = grid_color, linestyle = grid_linestyle,
            linewidth = grid_linewidth)

        # Set up plot
        plt.xlabel(X_label,fontsize=X_size)
        plt.ylabel(y_label,fontsize=y_size)
        plt.xticks(fontsize=X_tick_size,rotation=rot_X_tick)
        plt.yticks(fontsize=y_tick_size,rotation=rot_y_tick)
        plt.title(title_in,fontsize=title_size)

        # Check go_2dview
        if go_2dview.upper() == "ON":

            # Shows plot
            plt.show()
        else:

            # Saves plot on png file
            plt.savefig(self.dir_in+"plots/"+plot_file,dpi=dpi_in)