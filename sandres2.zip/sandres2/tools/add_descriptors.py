# Import packages
import csv
from tools import string_tools as str_tools

# Define Descriptor class
class Descriptor(object):
    """Class to add descriptor columns to bind_###.csv file"""

    # Define constructor method
    def __init__(self,program_root,dir_in,bind_in):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.bind_in = bind_in

        self.dataset_dir = self.dir_in+"pdbqt"

    # Define check_rmsd_data() method
    def check_rmsd_data(self):
        """Method to check the presence of RMSD column in
        bind_####.csv file"""

        # Try to open bind_####.csv file
        file2open = self.dir_in+"bind_"+str(self.bind_in)+".csv"
        try:
            fo_rmsd = open(file2open,"r")
            csv_rmsd = csv.reader(fo_rmsd)

            # Looping through csv_rmsd
            for line in csv_rmsd:
                if "RMSD" in str(line):
                    # Close file
                    fo_rmsd.close()
                    break
                else:
                    # Close file
                    fo_rmsd.close()

                    # Set up an empty string
                    lines_out = ""

                    # Open a file
                    fo_rmsd = open(file2open,"r")
                    csv_rmsd = csv.reader(fo_rmsd)

                    # Add "RMSD()" to the header
                    for line in csv_rmsd:
                        tmp_line = str(line)
                        tmp_line = tmp_line.replace("[","")
                        tmp_line = tmp_line.replace("]","")
                        tmp_line = tmp_line.replace("'","")
                        tmp_line = tmp_line.replace("\n","")
                        lines_out += tmp_line+",RMSD(A)\n"
                        break

                    # Looping through csv_rmsd to add "ND"
                    for line in csv_rmsd:
                        tmp_line = str(line)
                        tmp_line = tmp_line.replace("[","")
                        tmp_line = tmp_line.replace("]","")
                        tmp_line = tmp_line.replace("'","")
                        tmp_line = tmp_line.replace("\n","")
                        lines_out += tmp_line+",ND\n"

                    # Close file
                    fo_rmsd.close()

                    # Backup file
                    # Instantiate an object of the Palavra() class
                    p1 = str_tools.Palavra(self.dir_in,"pdb_codes.csv")

                    # Invoke backup_file() method
                    p1.backup_file("bind_"+self.bind_in+".csv")

                    # Open a new bind_####.csv file
                    fo_rmsd = open(file2open,"w")

                    # Write data
                    fo_rmsd.write(lines_out)

                    # Close file
                    fo_rmsd.close()

        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")
            return

    # Define read_all_data() method
    def read_all_data(self):
        """Method to read bind_###.csv data"""

        # Invoke check_rmsd_data() method
        self.check_rmsd_data()

        # Try to open bind_###.csv file
        file2open = self.dir_in+"bind_"+str(self.bind_in)+".csv"
        try:
            fo_all_data = open(file2open,"r")
            csv_all_data = csv.reader(fo_all_data)
        except IOError:
            print("IOError! I can't find "+file2open+" file!")
            return

        # Try to open missing_pdbqt.csv file
        try:
            fo_missing_pdbqt = open(self.dir_in+"missing_pdbqt.csv","r")
            csv_missing_pdbqt = csv.reader(fo_missing_pdbqt)

            # Set up an empty list
            missing_pdbqt = []

            # Looping through csv_missing_pdbqt
            for line1 in csv_missing_pdbqt:
                missing_pdbqt.append(line1[0])

        # Handle exception
        except IOError:
            print("IOError! I can't find missing_pdbqt.csv file!")
            fo_missing_pdbqt = open(self.dir_in+"missing_pdbqt.csv","w")

            # Set up an empty list
            missing_pdbqt = []

        # Set up an empty list
        self.lines_out = []

        # Assign zero to count_lig
        count_ligs = 0

        # Looping through csv_all_data
        for line2 in csv_all_data:

            # Header
            if "PDB" in line2[0]:
                header_1 = str(line2)
                header_1 += ",Torsions,Q,Average Q,Ligand B-factor(A2)"
                header_1 += ",Receptor B-factor(A2)"
                header_1 += ",B-factor ratio (Ligand/Receptor)"
                header_1 += ",C,N,O,P,S,F,Cl,Br\n"
                self.lines_out.append(header_1)

            # The remaing lines
            elif not line2[0] in missing_pdbqt[1:]:
                num_tor = self.read_lig_torsion(str(line2[0]))
                total_q = self.calc_lig_charge(str(line2[0]))
                averg_q = self.calc_lig_average_charge(str(line2[0]))
                averg_b_lig = self.calc_average_bfactor(str(line2[0]),"lig.pdbqt")
                averg_b_receptor = self.calc_average_bfactor(str(line2[0]),"receptor.pdbqt")

                # For bfactor_ratio
                if averg_b_receptor != 0.0:
                    bfactor_ratio = averg_b_lig/averg_b_receptor
                else:
                    bfactor_ratio = 1.0

                n_c, n_n, n_o, n_p, n_s, n_f, n_cl, n_br = \
                self.calc_lig_atoms(str(line2[0]))
                print(line2[0],num_tor,total_q,averg_q,averg_b_lig,
                averg_b_receptor,bfactor_ratio,
                n_c, n_n, n_o, n_p, n_s, n_f, n_cl, n_br)
                count_ligs += 1
                aux = str(line2)
                aux += ","+str(num_tor)+","+str(total_q)+","+str(averg_q)
                aux += ","+str(averg_b_lig)+","+str(averg_b_receptor)
                aux += ","+str(bfactor_ratio)
                aux += ","+str(n_c)+","+str(n_n)+","+str(n_o)+","+str(n_p)
                aux += ","+str(n_s)+","+str(n_f)+","+str(n_cl)+","+str(n_br)
                self.lines_out.append(aux+"\n")

        # Show number of ligands in the bind_###.csv file
        print("\nNumber of ligands: ",count_ligs)

        # Close files
        fo_all_data.close()
        fo_missing_pdbqt.close()

    # Define read_lig_torsion() method
    def read_lig_torsion(self,pdb):
        """Method to read number of torsion angles in a pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_lig = open(self.dataset_dir+"/"+pdb+"/lig.pdbqt")
            lig_lines = fo_lig.readlines()
        except IOError:
            print("IOError! I can't find lig.pdbqt file!")
            return None

        # Assign None to torsions
        torsions = None

        # Get torsion
        for line in lig_lines:
            if "TORSDOF" in line:
                torsions = int(line[7:])

        # Close file
        fo_lig.close()

        # Return torsions
        return torsions

    # Define calc_lig_charge() method
    def calc_lig_charge(self,pdb):
        """Method to calculate total charge in a pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_lig = open(self.dataset_dir+"/"+pdb+"/lig.pdbqt","r")
            lig_lines = fo_lig.readlines()
        except IOError:
            print("IOError! I can't find lig.pdbqt file!")
            return None

        # Assign zero to total_charge
        total_charge = 0.0

        # Get total_charge
        for line in lig_lines:
            if "ATOM  " in line or "HETATM" in line:
                total_charge += float(line[67:76])

        # Close file
        fo_lig.close()

        # Return total_charge
        return total_charge

    # Define calc_average_bfactor() method
    def calc_average_bfactor(self,pdb,pdbqt):
        """Method to calculate average B-factor in a pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_pdbqt = open(self.dataset_dir+"/"+pdb+"/"+pdbqt,"r")
            pdbqt_lines = fo_pdbqt.readlines()
        except IOError:
            print("IOError! I can't find PDBQT file!")
            return None

        # Assign zero to total_bfactor
        total_bfactor = 0.0

        # Assign zero to count_atoms
        count_atoms = 0

        # Get B-factor
        for line in pdbqt_lines:
            if "ATOM  " in line or "HETATM" in line:
                total_bfactor += float(line[61:66])
                count_atoms += 1

        # Calculate average bfactor
        if count_atoms > 0:
            average_bfactor = total_bfactor/count_atoms
        else:
            average_bfactor = 0.0

        # Close file
        fo_pdbqt.close()

        # Return average_bfactor
        return average_bfactor

    # Define calc_lig_average_charge() method
    def calc_lig_average_charge(self,pdb):
        """Method to calculate average charge in a pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_lig = open(self.dataset_dir+"/"+pdb+"/lig.pdbqt","r")
            lig_lines = fo_lig.readlines()
        except IOError:
            print("IOError! I can't find lig.pdbqt file!")
            return None

        # Assign zero to total_charge
        total_charge = 0.0

        # Assign zero to count_atoms
        count_atoms = 0

        # Get total_charge and count_atoms
        for line in lig_lines:
            if "ATOM  " in line or "HETATM" in line:
                total_charge += float(line[67:76])
                count_atoms += 1

        # Calculate average charge
        if count_atoms > 0:
            average_charge = total_charge/count_atoms
        else:
            average_charge = 0.0

        # Close file
        fo_lig.close()

        # Return average_charge
        return average_charge

    # Define calc_lig_atoms() method
    def calc_lig_atoms(self,pdb):
        """Method to calculate the number of C, N, O,.. in a pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_lig = open(self.dataset_dir+"/"+pdb+"/lig.pdbqt","r")
            lig_lines = fo_lig.readlines()
        except IOError:
            print("IOError! I can't find lig.pdbqt file!")
            return None,None,None,None,None,None,None,None

        # Assign zero to n_c, n_n
        n_c = 0
        n_n = 0
        n_o = 0
        n_p = 0
        n_s = 0
        n_f = 0
        n_cl = 0
        n_br = 0

        # Get number of atoms
        for line in lig_lines:
            if "ATOM  " in line or "HETATM" in line:
                if "C" in line[13:14]:
                    n_c += 1
                elif "N" in line[13:14]:
                    n_n += 1
                elif "O" in line[13:14]:
                    n_o += 1
                elif "P" in line[13:14]:
                    n_p += 1
                elif "S" in line[13:14]:
                    n_s += 1
                elif "F" in line[13:14]:
                    n_f += 1
                elif "CL" in line[13:15]:
                    n_cl += 1
                elif "BR" in line[13:15]:
                    n_br += 1

        # Close file
        fo_lig.close()

        # Return number of atoms
        return n_c, n_n, n_o, n_p, n_s, n_f, n_cl, n_br

    # Define write_all_data() method
    def write_all_data(self):
        """Method to write new bind_###.csv data"""

        # Instantiate an object of the Palavra class
        p1 = str_tools.Palavra(self.dir_in,"pdb_codes.csv")

        # Invoke backup_file() method
        p1.backup_file("bind_"+self.bind_in+".csv")

        # Open new bind_###.csv file
        fo_new_bind = open(self.dir_in+"bind_"+str(self.bind_in)+".csv","w")

        # Looping through self.lines_out
        for line in self.lines_out:

            # Some editing
            data_out = str(line)
            data_out = data_out.replace("[","")
            data_out = data_out.replace("]","")
            data_out = data_out.replace("'","")
            print(data_out)
            fo_new_bind.write(data_out)

        # Close file
        fo_new_bind.close()