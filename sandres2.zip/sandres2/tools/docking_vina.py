#!/usr/bin/env python3
#
# Class to carry out protein-ligand docking simulations with
# AutoDock Vina (Trott & Olson, 2010; Eberhardt et al., 2021).
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# October 14, 2023                                                             #
################################################################################
#
# Import packages and atomic mass dictionary
import numpy as np
import csv
import os
import shutil
from tools import atomic_masses as atm_masses
from tools import score_only_vina123 as vina123
from tools import binding_affinity as b_aff
from MLRegMPy import backup

# Define Docking() class
class Docking(object):
    """Class to handle PDBQT files for ligand and receptor structures and
    carry out docking simulations using AutoDock Vina"""

    # Define constructor method
    def __init__(self,program_root,dir_in,list_lig_out):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.list_lig_out = list_lig_out

        # Set up empty lists
        self.lowest_rmsd = []
        self.lowest_list = []
        self.lowest_pdb = []

        # Try to open vina_par.csv file
        file2open = self.program_root+"misc/data/vina_par.csv"
        try:
            fo_vina_par = open(file2open,"r")
            csv_vina_par = csv.reader(fo_vina_par)
        except IOError:
            print("\nI can't find "+file2open+" file")
            return

        # Looping through csv_vina_par
        for line in csv_vina_par:
            if line[0] == "centering":
                self.centering = line[1]
            elif line[0] == "lig_pdb":
                self.lig_pdb = line[1]
            elif line[0] == "receptor":
                self.receptor_in = line[1]
            elif line[0] == "ligand":
                self.ligand_in = line[1]
            elif line[0] == "size_x":
                self.size_x = float(line[1])
            elif line[0] == "size_y":
                self.size_y = float(line[1])
            elif line[0] == "size_z":
                self.size_z = float(line[1])
            elif line[0] == "seed":
                self.random_seed = int(line[1])
            elif line[0] == "exhaustiveness":
                self.exhaustiveness = int(line[1])
            elif line[0] == "num_modes":
                self.num_modes = int(line[1])
            elif line[0] == "out":
                self.ligand_out = line[1]
            elif line[0] == "docking_engine":
                self.docking_engine = line[1]

        # Close file
        fo_vina_par.close()

    # Define remove_results() method
    def remove_results(self,pdb,file_in1,file_in2):
        """Method to delete previously created files"""

        # Set up list2delete
        list2delete = [file_in1,file_in2]

        # Looping through list2delete
        for file_in in list2delete:
            file2delete = self.dir_in+"pdbqt/"+pdb+"/"+file_in

            # Try to delete
            try:
                os.remove(file2delete)
            except:
                pass

    # Define read_xtal_xyz() method
    def read_xtal_xyz(self,pdb,pdb_in):
        """Method to read a PDB file and return atomic coordinates
        and atom types"""

        # Set up empty lists
        x = []
        y = []
        z = []
        atom_list = []

        # Try to open a PDB file
        file2open = self.dir_in+"pdbqt/"+pdb+"/"+pdb_in
        try:
            fo_str = open(file2open,"r")
            str_lines = fo_str.readlines()

        # Handle exception
        except IOError:
            return atom_list,x,y,z

        # Looping through str_lines
        for line in str_lines:

            # Select lines starting with "HETATM" or "ATOM  "
            if line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
                atom_string0 = line[77:].replace(" ","")
                atom_string1 = atom_string0.replace("\n","")
                atom_list.append(atom_string1)

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)

        # Close file
        fo_str.close()

        # Return arrays
        return atom_list,x_a,y_a,z_a

    # Define read_xtal_pdbqt() method
    def read_xtal_pdbqt(self,pdb):
        """Method to read a PDBQT file and return atomic coordinates and
        atomic charges"""

        # Set up empty lists
        x = []
        y = []
        z = []
        list_charges = []

        # Try to open ligand PDBQT file
        file2open = self.dir_in+"pdbqt/"+pdb+"/"+self.ligand_in
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()

        # Handle exception
        except IOError:
            return x,y,z

        # Looping through lig_lines
        for line in lig_lines:

            # Select lines starting with "HETATM" or "ATOM  "
            if line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))
                list_charges.append(float(line[69:76]))

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)
        charges = np.array(list_charges)

        # Close file
        fo_lig.close()

        # Return arrays
        return charges,x_a,y_a,z_a

    # Define read_reference_xyz() method
    def read_reference_xyz(self,pdb,lig_in):
        """Method to read a reference ligand PDBQT file and return atomic
        coordinates"""

        # Set up empty lists
        x = []
        y = []
        z = []

        # Try to open ligand PDBQT file
        file2open = self.dir_in+"pdbqt/"+pdb+"/"+lig_in
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()

        # Handle exception
        except IOError:
            return x,y,z

        # Looping through lig_lines
        for line in lig_lines:

            # Select lines starting with "HETATM" or "ATOM  "
            if line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)

        # Close file
        fo_lig.close()

        # Return arrays
        return x_a,y_a,z_a

    # Define extract_pose_pdbqt() method
    def extract_pose_pdbqt(self,pdb,centering):
        """Method to extract PDBQT pose files from a docking result
        PDBQT file. We use vina_split i.e
        ./vina_split --input lig_out_electric.pdbqt

        ./vina_split --input lig_out_electric.pdbqt --ligand pose_electric_
        """

        # Set up PDB directory
        pdb_dir = self.dir_in+"pdbqt/"+pdb+"/"

        # Get root file nane
        root_lig_out = self.ligand_out.replace(".pdbqt","")

        # Run vina_split
        os.system(self.program_root+\
            "misc/linux_third_party_software/vina/./vina_split --input "+\
            pdb_dir+root_lig_out+"_"+centering+".pdbqt --ligand "+\
            pdb_dir+"pose_"+centering+"_")

    # Define read_pose_xyz() method
    def read_pose_xyz(self,pdb,pose_in,pose_number):
        """Method to read a pose PDBQT file and return atomic coordinates"""

        # Set up empty lists
        x = []
        y = []
        z = []

        # Assign False to model_boolean
        model_boolean = False

        # Try to open ligand PDBQT file
        file2open = self.dir_in+"pdbqt/"+pdb+"/"+pose_in
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()

        # Handle exception
        except IOError:
            return x,y,z

        # Looping through lig_lines
        for line in lig_lines:
            if  line[:6] == "MODEL " and int(line[6:]) == pose_number:
                model_boolean = True
            elif model_boolean and line[:6] == "ENDMDL":
                model_boolean = False
            elif model_boolean and line[:6] == "HETATM" or line[:6] == "ATOM  ":
                x.append(float(line[30:38]))
                y.append(float(line[38:46]))
                z.append(float(line[46:54]))

        # Set up arrays
        x_a = np.array(x)
        y_a = np.array(y)
        z_a = np.array(z)

        # Close file
        fo_lig.close()

        # Return arrays
        return x_a,y_a,z_a

    # Define rmsd() method
    def rmsd(self,pdb,results_file,x1,y1,z1,x2,y2,z2):
        """Method to calculate docking rmsd and read binding affinity
        energy for the lowest energy pose"""

        # Try to open PDBQT file with docking poses
        file2open = self.dir_in+"pdbqt/"+pdb+"/"+self.ligand_out
        try:
            fo_poses = open(file2open, "r")
            pdbqt_lines = fo_poses.readlines()

        # Handle exception
        except:
            return

        # Read pose binding affinity energy
        for line in pdbqt_lines:
            if "REMARK VINA RESULT:" in line:
                binding_energy = float(line[20:29])
                break

        # Close PDBQT file
        fo_poses.close()

        # Number of elements in x1 array
        n = len(x1)

        # Assign zero to sum_d
        sum_d = 0.0

        # Calculate distance and sum them all
        for i in range(n):
            d = (x1[i]-x2[i])**2 + (y1[i]-y2[i])**2 + (z1[i]-z2[i])**2
            sum_d += d

        # Calculate RMSD
        r = np.sqrt(sum_d/n)

        # Write RMSD and pose binding affinity energy
        pdb_dir = self.dir_in+"pdbqt/"+pdb+"/"
        fo = open(pdb_dir+results_file,"w")
        line_out = "RMSD,"+str(r)
        fo.write(line_out)

        # Close file
        fo.close()

    # Define show_rmsd() method
    def show_rmsd(self,pdb,x1,y1,z1,x2,y2,z2):
        """Method to calculate docking rmsd and show results on screen"""

        # Number of elements in x1 array
        n = len(x1)

        # Assign zero to sum_d
        sum_d = 0.0

        # Calculate distance and sum them all
        for i in range(n):
            d = (x1[i]-x2[i])**2 + (y1[i]-y2[i])**2 + (z1[i]-z2[i])**2
            sum_d += d

        # Calculate RMSD
        r = np.sqrt(sum_d/n)

        # Assign RMSD to a string
        str_rmsd = "{:.3f}".format(r)

        # Return RMSD
        return str_rmsd

    # Define geometric_center() method
    def geometric_center(self,x,y,z):
        """Method to calculate geometric center for a ligand"""

        # Calculate geometric center
        x_g = np.sum(x)/len(x)
        y_g = np.sum(y)/len(y)
        z_g = np.sum(z)/len(z)

        # Returm geometric center coordinates
        return x_g,y_g,z_g

    # Define center_of_charge() method
    def center_of_charge(self,charges,x,y,z):
        """Method to calculate center of electric charge for a ligand"""

        # Assign zero to total_charges
        total_charges = 0.0

        # Absolute value of charges
        charges = np.absolute(charges)

        # Set up arrays
        x_a = np.zeros(len(x))
        y_a = np.zeros(len(y))
        z_a = np.zeros(len(z))

        # Looping through coordinates and list of atoms
        for i in range(len(charges)):

            # Update arrays
            x_a[i] += charges[i]*x[i]
            y_a[i] += charges[i]*y[i]
            z_a[i] += charges[i]*z[i]

            # Update total_charges
            total_charges += charges[i]

        # To avoid total_charges = zero
        if total_charges > 0.0:

            # Calculate center of charge
            x_cc = np.sum(x_a)/total_charges
            y_cc = np.sum(y_a)/total_charges
            z_cc = np.sum(z_a)/total_charges

        else:
            x_cc = x[0]
            y_cc = y[0]
            z_cc = z[0]
            print("\nTotal charge = ",total_charge)
            print("It will be used the coordinates: ",x_cc,y_cc,z_cc)


        # Return coordinates of the center of charge
        return x_cc,y_cc,z_cc

    # Define center_of_mass() method
    def center_of_mass(self,atom_list,x,y,z):
        """Method to calculate center of mass for a structure based on
        the atomic coordinates"""

        # Assign zero to mass
        total_mass = 0.0

        # Set up arrays
        x_a = np.zeros(len(x))
        y_a = np.zeros(len(y))
        z_a = np.zeros(len(z))

        # Looping through coordinates and list of atoms
        for i in range(len(atom_list)):

            # Read the atomic mass for each atom in the list (atom_list)
            mass_atm = atm_masses.m_a[atom_list[i]]

            # Update arrays
            x_a[i] += mass_atm*x[i]
            y_a[i] += mass_atm*y[i]
            z_a[i] += mass_atm*z[i]

            # Update total_mass
            total_mass += mass_atm

        # To avoid total_mass = zero
        if total_mass > 0.0:

            # Calculate center of mass
            x_cm = np.sum(x_a)/total_mass
            y_cm = np.sum(y_a)/total_mass
            z_cm = np.sum(z_a)/total_mass

        else:
            x_cm = x[0]
            y_cm = y[0]
            z_cm = z[0]
            print("\nTotal charge = ",total_mass)
            print("It will be used the coordinates: ",x_cm,y_cm,z_cm)

        # Return coordinates of the center of mass
        return x_cm,y_cm,z_cm

    # Define write_config() method
    def write_config(self,pdb,receptor,ligand,center_x,center_y,center_z,
                    size_x,size_y,size_z,random_seed,lig_out,config_in):
        """Method to write a config.txt file to run AutoDock Vina
            receptor = receptor.pdbqt
            ligand = lig.pdbqt
            center_x = 102.002
            center_y = 100.42
            center_z = 79.601
            size_x = 12.0
            size_y = 12.0
            size_z = 12.0
            seed = 271828
            out = lig_out.pdbqt
        """

        # Set up PDB directory
        pdb_dir = self.dir_in+"pdbqt/"+pdb+"/"

        # Open new config.txt file
        file2open = pdb_dir+config_in
        fo_config = open(file2open,"w")

        # Set up docking parameters for config.txt file
        line_out = "receptor = "+pdb_dir+receptor+"\n"
        line_out += "ligand = "+pdb_dir+ligand+"\n"
        line_out += "center_x = {:.3f}".format(center_x)+"\n"
        line_out += "center_y = {:.3f}".format(center_y)+"\n"
        line_out += "center_z = {:.3f}".format(center_z)+"\n"
        line_out += "size_x = "+str(size_x)+"\n"
        line_out += "size_y = "+str(size_y)+"\n"
        line_out += "size_z = "+str(size_z)+"\n"
        line_out += "exhaustiveness = "+str(self.exhaustiveness)+"\n"
        line_out += "num_modes = "+str(self.num_modes)+"\n"
        line_out += "seed = "+str(random_seed)+"\n"
        line_out += "out = "+pdb_dir+lig_out

        # Show and write line_out
        fo_config.write(line_out)

        # Close file
        fo_config.close()

    # Define simulation() method
    def simulation(self,pdb,config_in):
        """Method to carry out protein-ligand docking simulation using
        AutoDock Vina"""

        # Get centering method
        i1 = config_in.index("_")
        i2 = config_in.index(".")
        centering_in_config = config_in[i1+1:i2]

        # Show messages
        msg_out = "\nRunning AutoDock Vina for structure: "+pdb
        print(msg_out)
        print("Centering method: "+centering_in_config)

        # Set up PDB directory
        pdb_dir = self.dir_in+"pdbqt/"+pdb+"/"

        # WFA 2021-11-07
        # Check whether there is previously generated docking result.
        # If there is docking result, simulation is omitted
        # Path
        path = pdb_dir+"vina_simulation_"+centering_in_config+".log"

        # Check whether the
        # specified path is
        # an existing file
        isFile = os.path.isfile(path)
        if isFile:
            msg_out = "\nI've found previous docking results! "
            msg_out += "Omitting simulation for "+path
            print(msg_out)
        else:
            # Run AutoDock Vina 1.2.3
            os.system(self.program_root+\
                "misc/linux_third_party_software/vina/./"+self.docking_engine+\
                " --config "+\
                pdb_dir+config_in+" > "+pdb_dir+"vina_simulation_"+\
                centering_in_config+".log")

    # Define mass() method
    def mass(self,pdb,atom_list,config_in,results_file,x0,y0,z0):
        """Method to run docking simulation with taking center of mass as
        the center in the config file"""

        # Invoke read_reference_xyz() method
        x1,y1,z1 = self.read_reference_xyz(pdb,self.ligand_in)

        # Invoke center_of_mass() method
        x_c,y_c,z_c = self.center_of_mass(atom_list,x0,y0,z0)

        # Invoke write_config() method
        self.write_config(pdb,self.receptor_in,self.ligand_in,x_c,y_c,z_c,
        self.size_x,self.size_y,self.size_z,self.random_seed,self.ligand_out,
        config_in)

        # Invoke simulation() method
        self.simulation(pdb,config_in)

        # Invoke read_pose_xyz() method
        x2,y2,z2 = self.read_pose_xyz(pdb,self.ligand_out,1)

        # Invoke rmsd() method
        self.rmsd(pdb,results_file,x1,y1,z1,x2,y2,z2)

    # Define geometric() method
    def geometric(self,pdb,config_in,results_file,x0,y0,z0):
        """Method to run docking simulation taking geometric center as
        the center in the config.txt file"""

        # Invoke read_reference_xyz() method
        x1,y1,z1 = self.read_reference_xyz(pdb,self.ligand_in)

        # Invoke geometric_center() method
        x_c,y_c,z_c = self.geometric_center(x1,y1,z1)

        # Invoke write_config() method
        self.write_config(pdb,self.receptor_in,self.ligand_in,x_c,y_c,z_c,
        self.size_x,self.size_y,self.size_z,self.random_seed,self.ligand_out,
        config_in)

        # Invoke simulation() method
        self.simulation(pdb,config_in)

        # Invoke read_pose_xyz() method
        x2,y2,z2 = self.read_pose_xyz(pdb,self.ligand_out,1)

        # Invoke rmsd() method
        self.rmsd(pdb,results_file,x1,y1,z1,x2,y2,z2)

    # Define electric() method
    def electric(self,pdb,config_in,results_file,x0,y0,z0):
        """Method to run docking simulation taking charge center as center
        in config file"""

        # Invoke read_xtal_pdbqt() method
        charges,x1,y1,z1 = self.read_xtal_pdbqt(pdb)

        # Invoke center_of_charge() method
        x_c,y_c,z_c = self.center_of_charge(charges,x1,y1,z1)

        # Invoke write_config() method
        self.write_config(pdb,self.receptor_in,self.ligand_in,x_c,y_c,z_c,
        self.size_x,self.size_y,self.size_z,self.random_seed,self.ligand_out,
        config_in)

        # Invoke simulation() method
        self.simulation(pdb,config_in)

        # Invoke read_pose_xyz() method
        x2,y2,z2 = self.read_pose_xyz(pdb,self.ligand_out,1)

        # Invoke rmsd() method
        self.rmsd(pdb,results_file,x1,y1,z1,x2,y2,z2)

    # Define all() method
    def all(self,pdb,atom_list,x0,y0,z0):
        """Method to run docking simulation taking all centering schemes"""

        # Set up file names
        config_in = "config_mass.txt"
        self.ligand_out = "lig_out_mass.pdbqt"
        results_file = "vina_results_mass.csv"

        # Invoke remove_results()
        self.remove_results(pdb,"config_mass.txt",
        "vina_results_mass.csv")

        # Invoke mass() method
        self.mass(pdb,atom_list,config_in,results_file,x0,y0,z0)

        # Set up file names
        config_in = "config_geometric.txt"
        self.ligand_out = "lig_out_geometric.pdbqt"
        results_file = "vina_results_geometric.csv"

        # Invoke remove_results()
        self.remove_results(pdb,"config_geometric.txt",
        "vina_results_geometric.csv")

        # Invoke geometric() method
        self.geometric(pdb,config_in,results_file,x0,y0,z0)

        # Set up file names
        config_in = "config_electric.txt"
        self.ligand_out = "lig_out_electric.pdbqt"
        results_file = "vina_results_electric.csv"

        # Invoke remove_results()
        self.remove_results(pdb,"config_electric.txt",
        "vina_results_electric.csv")

        # Invoke electric() method
        self.electric(pdb,config_in,results_file,x0,y0,z0)

    # Define check_single_rmsd() method
    def check_single_rmsd(self,pdb):
        """Method to read docking rmsd"""

        # Set up empty lists
        centering_method = []
        docking_list = []

        # Set up rmsd_list with three files to check
        rmsd_list = ["vina_results_mass.csv"]

        # Check all results
        for file_in in rmsd_list:

            # Try to open a file
            file2open = self.dir_in+"pdbqt/"+pdb+"/"+file_in
            try:
                fo_rmsd = open(file2open,"r")
                csv_rmsd = csv.reader(fo_rmsd)

            # Handle exception
            except IOError:
                print()
                pass

            # Looping through rmsd_lines
            for line in csv_rmsd:
                if line[0] == "RMSD":
                    docking_list.append(float(line[1]))
                    centering_method.append(file_in[13:len(file_in)-4])

            # Close file
            fo_rmsd.close()

        # Set up array
        rmsd_array = np.array(docking_list)

        # Find lowest RMSD and related energy
        self.lowest_rmsd.append(np.amin(rmsd_array))
        i_lowest = np.argmin(rmsd_array)
        self.lowest_list.append(centering_method[i_lowest])
        self.lowest_pdb.append(pdb)

    # Define check_rmsd() method
    def check_rmsd(self,pdb):
        """Method to select which docking result generated the lowest rmsd"""

        # Set up empty lists
        centering_method = []
        docking_list = []

        # Set up rmsd_list with three files to check
        rmsd_list = ["vina_results_mass.csv","vina_results_geometric.csv",
                    "vina_results_electric.csv"]

        # Check all results
        for file_in in rmsd_list:

            # Try to open a file
            file2open = self.dir_in+"pdbqt/"+pdb+"/"+file_in
            try:
                fo_rmsd = open(file2open,"r")
                csv_rmsd = csv.reader(fo_rmsd)

            # Handle exception
            except IOError:
                print()

            # Looping through rmsd_lines
            for line in csv_rmsd:
                if line[0] == "RMSD":
                    docking_list.append(float(line[1]))
                    centering_method.append(file_in[13:len(file_in)-4])

            # Close file
            fo_rmsd.close()

        # Set up array
        rmsd_array = np.array(docking_list)

        # Find lowest RMSD and related energy
        self.lowest_rmsd.append(np.amin(rmsd_array))
        i_lowest = np.argmin(rmsd_array)
        self.lowest_list.append(centering_method[i_lowest])
        self.lowest_pdb.append(pdb)

    # Define show_lowest_rmsd() method
    def show_lowest_rmsd(self):
        """Method to show a list of the lowest RMSD after running all docking
        simulations"""

        # Header
        lines_out = "PDB,Centering Method,RMSD(A)\n"

        # Looping through all PDB structures
        for i in range(len(self.lowest_rmsd)):
            lines_out += self.lowest_pdb[i]+","+self.lowest_list[i]+\
            ",{:.3f}".format(self.lowest_rmsd[i])+"\n"

        # Open new file
        file2open = self.dir_in+"vina_rmsd_results.csv"
        fo_final_results = open(file2open,"w")

        # Write RMSD results
        fo_final_results.write(lines_out)

        # Close file
        fo_final_results.close()

    # Define choose_rmsd() method
    def choose_rmsd(self):
        """Method to choose the scheme that generates the lowest RMSD"""

        # Try to open a file
        file2open = self.dir_in+"vina_rmsd_results.csv"
        try:
            fo_final_results = open(file2open,"r")
            csv_results = csv.reader(fo_final_results)

        # Handle exception
        except:
            print()

        # Show message
        print("\nChoosing the best RMSD centering method:")

        # Looping through csv_results
        for line in csv_results:
            break

        # Looping through csv_results
        for line in csv_results:
            pdb = line[0]

            if line[1] == "mass":

                centering = "mass"
                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/config_"+\
                    centering+".txt"
                    target = self.dir_in+"pdbqt/"+pdb+"/config.txt"
                    shutil.copyfile(origin,target)

                except:
                    pass

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/lig_out_"+centering+\
                    ".pdbqt"
                    target = self.dir_in+"pdbqt/"+pdb+"/lig_out.pdbqt"
                    shutil.copyfile(origin,target)

                except:
                    pass

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/vina_results_"+\
                    centering+".csv"
                    target = self.dir_in+"pdbqt/"+pdb+"/vina_results.csv"
                    shutil.copyfile(origin,target)

                except:
                    pass

            elif line[1] == "geometric":

                centering = "geometric"

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/config_"+\
                    centering+".txt"
                    target = self.dir_in+"pdbqt/"+pdb+"/config.txt"
                    shutil.copyfile(origin,target)

                except:
                    pass

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/lig_out_"+centering+\
                    ".pdbqt"
                    target = self.dir_in+"pdbqt/"+pdb+"/lig_out.pdbqt"
                    shutil.copyfile(origin,target)

                except:
                    pass

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/vina_results_"+\
                    centering+".csv"
                    target = self.dir_in+"pdbqt/"+pdb+"/vina_results.csv"
                    shutil.copyfile(origin,target)

                except:
                    pass

            elif line[1] == "electric":

                centering = "electric"

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/config_"+\
                    centering+".txt"
                    target = self.dir_in+"pdbqt/"+pdb+"/config.txt"
                    shutil.copyfile(origin,target)

                except:
                    pass

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/lig_out_"+centering+\
                    ".pdbqt"
                    target = self.dir_in+"pdbqt/"+pdb+"/lig_out.pdbqt"
                    shutil.copyfile(origin,target)

                except:
                    pass

                try:
                    origin = self.dir_in+"pdbqt/"+pdb+"/vina_results_"+\
                    centering+".csv"
                    target = self.dir_in+"pdbqt/"+pdb+"/vina_results.csv"
                    shutil.copyfile(origin,target)

                except:
                    pass

            else:
                return

        # Close file
        fo_final_results.close()

    # Define clean_dir()
    def clean_dir(self):
        """Method to delete temporary files"""

        # Try to open a file
        file2open = self.dir_in+"vina_rmsd_results.csv"

        try:
            fo_final_results = open(file2open,"r")
            csv_results = csv.reader(fo_final_results)

        # Handle exception
        except:
            print()

        # Show message
        print("\nDeleting temporary files.")

        # Set up list
        list_centering = ["mass","geometric","electric"]

        # Looping through csv_results
        for line in csv_results:
            break

        # Looping through csv_results
        for line in csv_results:
            pdb = line[0]
            for centering in list_centering:
                file_in1 = "config_"+centering+".txt"
                #file_in2 = "lig_out_"+centering+".pdbqt"
                file_in2 = "vina_results_"+centering+".csv"
                self.remove_results(pdb,file_in1,file_in2)

        # Close file
        fo_final_results.close()

        # Show message
        print("\nDone!")

    # Define add_results() method
    def add_results(self):
        """Method to add docking results generated with AutoDock Vina to
        bind_####.csv file"""

        # Invoke read_it function
        bind_in = b_aff.read_it(self.dir_in)

        # Set up an empty string
        lines_out = ""

        # Open bind_####.csv file
        fo_bind = open(self.dir_in+"bind_"+bind_in+".csv","r")
        csv_bind = csv.reader(fo_bind)

        # Looping through csv_bind (header)
        for line1 in csv_bind:
            break

        # Looping through csv_bind (header)
        for line1 in csv_bind:

            # Try to open vina_rmsd_results.csv file
            file2open = self.dir_in+"vina_rmsd_results.csv"
            try:
                fo_vina = open(file2open,"r")
                csv_vina = csv.reader(fo_vina)

            # Handle exception
            except IOError:
                return

            # Get PDB access code from bind_####.csv file
            pdb = line1[0].replace(" ","")

            # Assign "ND" to string variable
            docking_rmsd = "ND"

            # Looping through csv_vina (header)
            for line2 in csv_vina:
                break

            # Looping through csv_vina
            for line2 in csv_vina:

                # Check if PDB access is in the file
                if pdb == line2[0].replace(" ",""):

                    # Get docking_rmsd
                    docking_rmsd = line2[2]

                    break

            # Some editing
            aux_line = str(line1[:9]).replace(" ","") # Up to pKi,pKd,..
            aux_line = aux_line.replace("[","")
            aux_line = aux_line.replace("]","")
            aux_line = aux_line.replace("\'","")
            lines_out += aux_line+","+docking_rmsd+"\n"

            # Close file
            fo_vina.close()

        # Close bind_####.csv file
        fo_bind.close()

        # Invoke backup.make(source file,source directory,target directory)
        backup.make("bind_"+bind_in+".csv",self.dir_in,self.dir_in+"backup/")

        # Open bind_####.csv file
        fo_bind = open(self.dir_in+"bind_"+bind_in+".csv","w")

        # Write header
        header_out = "PDB,Ligand,Chain,Number,Resolution(A),"
        header_out += "Ligand Occupation Factor,"+bind_in+"(M),"
        header_out += "log("+bind_in+"),p"+bind_in+",RMSD(A)\n"
        fo_bind.write(header_out)

        # Write results
        fo_bind.write(lines_out)

        # Close file
        fo_bind.close()

    # Define fast_bundle() method
    def fast_bundle(self,pdb):
        """Method to prepare config.txt file and carry out
        protein-ligand docking simulation using AutoDock Vina engine.
        In this method we rely on one type of centering for config.txt"""

        # Invoke read_xtal_xyz() method
        atom_list,x0,y0,z0 = self.read_xtal_xyz(pdb,self.lig_pdb)

        # Set up file names
        config_in = "config_mass.txt"
        self.ligand_out = "lig_out_mass.pdbqt"
        results_file = "vina_results_mass.csv"

        # Invoke remove_results()
        self.remove_results(pdb,"config_mass.txt","vina_results_mass.csv")

        # Invoke mass() method
        self.mass(pdb,atom_list,config_in,results_file,x0,y0,z0)

    # Define bundle() method
    def bundle(self,pdb):
        """Method to prepare config.txt file and carry out
        protein-ligand docking simulation using AutoDock Vina engine"""

        # Invoke read_xtal_xyz() method
        atom_list,x0,y0,z0 = self.read_xtal_xyz(pdb,self.lig_pdb)

        # Check self.centering
        if self.centering == "mass":

            # Set up file names
            config_in = "config_mass.txt"
            self.ligand_out = "lig_out_mass.pdbqt"
            results_file = "vina_results_mass.csv"

            # Invoke remove_results()
            self.remove_results(pdb,"config_mass.txt","vina_results_mass.csv")

            # Invoke mass() method
            self.mass(pdb,atom_list,config_in,results_file,x0,y0,z0)

        elif self.centering == "geometric":

            # Set up file names
            config_in = "config_geometric.txt"
            self.ligand_out = "lig_out_geometric.pdbqt"
            results_file = "vina_results_geometric.csv"

            # Invoke remove_results()
            self.remove_results(pdb,"config_geometric.txt",
            "vina_results_geometric.csv")

            # Invoke geometric() method
            self.geometric(pdb,config_in,results_file,x0,y0,z0)

        elif self.centering == "electric":

            # Set up file names
            config_in = "config_electric.txt"
            self.ligand_out = "lig_out_electric.pdbqt"
            results_file = "vina_results_electric.csv"

            # Invoke remove_results()
            self.remove_results(pdb,"config_electric.txt",
            "vina_results_electric.csv")

            # Invoke electric() method
            self.electric(pdb,config_in,results_file,x0,y0,z0)

        elif self.centering == "all":

            # Invoke all() method
            self.all(pdb,atom_list,x0,y0,z0)

        else:
            return

    # Define write_pose() method
    def write_pose(self,pdb):
        """Method to generate pose.pdbqt file"""

        # Try to open ligand PDBQT file
        file2open = self.dir_in+"pdbqt/"+pdb+"/lig_out.pdbqt"
        try:
            fo_lig = open(file2open,"r")
            lig_lines = fo_lig.readlines()

        # Handle exception
        except IOError:
            return

        # Open new ligand PDBQT file
        file2write = self.dir_in+"pdbqt/"+pdb+"/pose.pdbqt"
        fo_pose = open(file2write,"w")

        # Looping through lig_lines
        for line in lig_lines:

            # Select lines
            if line[:7] != "TORSDOF" and line[:7] != "MODEL 1" and \
               line[:19] != "REMARK VINA RESULT:":
                fo_pose.write(line)
            elif line[:7] == "TORSDOF":
                fo_pose.write(line)
                break

        # Close files
        fo_lig.close()
        fo_pose.close()

    # Define pose_energy() method
    def pose_energy(self,pdb,centering,i):
        """Method to calculate energy terms of poses using AutoDock Vina"""

        # Set up PDB directory
        pdb_dir_in = self.dir_in+"pdbqt/"+pdb+"/"

        # Set up a_str
        a_str = centering+"_"+str(i)

        # Set up parameters
        receptor_in = "receptor.pdbqt"
        lig_in = "pose_"+a_str+".pdbqt"
        data_out = "result_"+a_str+".log"

        # Show message
        msg_out = "\nCalculating energy for pose "+str(i)+" in the PDB "+pdb
        msg_out += " using centering "+centering+"..."
        print(msg_out,end="")

        # Instantiate an object of Energy() class
        e1 = vina123.Energy(self.program_root,pdb_dir_in,receptor_in,
                lig_in,data_out)

        # Invoke bundle() method
        # Here is where the magic occurs (WFA 2023/05/23)
        e1.bundle()

        # Show message
        print("Done!")

    # Define energy() method
    def energy(self,pdb):
        """Method to calculate protein-ligand binding energy terms using
        AutoDock Vina for crystallographic coordinates.
        No docking simulations!"""

        # Set up PDB directory
        pdb_dir_in = self.dir_in+"pdbqt/"+pdb+"/"

        # Set up parameters
        receptor_in = "receptor.pdbqt"
        lig_in = "lig.pdbqt"
        data_out = "crystal.log"

        # Try to instantiate an object of Energy class
        try:

            # Show message
            print("\nCalculating energy terms for "+pdb+"...",end="")

            # Instantiate an object of Energy() class
            e1 = vina123.Energy(self.program_root,pdb_dir_in,receptor_in,
                    lig_in,data_out)

            # Invoke bundle() method
            e1.bundle()

            # Show message
            print("Done!")

        # Handle exception
        except:

            # WFA 2023/10/14
            print()

    # Define read_pose_energy() method
    def read_pose_energy(self,pdb,centering,i):
        """Method to add protein-ligand binding energy terms using
        AutoDock Vina to bind_####.csv file"""

        # Try to open result_####_#.log file
        a_str = centering+"_"+str(i)
        file2open = self.dir_in+"pdbqt/"+pdb+"/"+"result_"+a_str+".log"
        try:
            fo_log = open(file2open,"r")
            data_lines = fo_log.readlines()

        # Handle exception
        except IOError:
            self.energy = "None"
            self.gauss1 = "None"
            self.gauss2 = "None"
            self.repulsion = "None"
            self.hydrophobic = "None"
            self.hydrogen = "None"
            self.torsional = "None"

        # Looping through data_lines
        for line in data_lines:
            if "Affinity:" in line:
                i_1 = str(line).index(":")
                i_2 = str(line).index("(")
                self.energy = str(line)[i_1+1:i_2]
                self.energy = self.energy.replace(" ","")
                self.energy = self.energy.replace("\n","")
            elif "gauss 1"  in line:
                i_1 = str(line).index(":")
                self.gauss1 = str(line)[i_1+1:]
                self.gauss1 = self.gauss1.replace(" ","")
                self.gauss1 = self.gauss1.replace("\n","")
            elif "gauss 2"  in line:
                i_1 = str(line).index(":")
                self.gauss2 = str(line)[i_1+1:]
                self.gauss2 = self.gauss2.replace(" ","")
                self.gauss2 = self.gauss2.replace("\n","")
            elif "repulsion"  in line:
                i_1 = str(line).index(":")
                self.repulsion = str(line)[i_1+1:]
                self.repulsion = self.repulsion.replace(" ","")
                self.repulsion = self.repulsion.replace("\n","")
            elif "hydrophobic"  in line:
                i_1 = str(line).index(":")
                self.hydrophobic = str(line)[i_1+1:]
                self.hydrophobic = self.hydrophobic.replace(" ","")
                self.hydrophobic = self.hydrophobic.replace("\n","")
            elif "Hydrogen"  in line:
                i_1 = str(line).index(":")
                self.hydrogen = str(line)[i_1+1:]
                self.hydrogen = self.hydrogen.replace(" ","")
                self.hydrogen = self.hydrogen.replace("\n","")
            elif "Torsional"  in line:
                i_1 = str(line).index(":")
                self.torsional = str(line)[i_1+1:]
                self.torsional = self.torsional.replace(" ","")
                self.torsional = self.torsional.replace("\n","")

        # Close file
        fo_log.close()

    # Define add_energy() method
    def add_energy(self):
        """Method to add protein-ligand binding energy terms using
        AutoDock Vina to bind_####.csv file"""

        # Show message
        msg_out="Reading energy for crystallographic position of the ligands..."
        print("\n"+msg_out)

        # Invoke read_it function
        bind_in = b_aff.read_it(self.dir_in)

        # Set up an empty string
        lines_out = ""

        # Invoke backup.make(source file,source directory,target directory)
        backup.make("bind_"+bind_in+".csv",self.dir_in,self.dir_in+"backup/")

        # Open bind_####.csv file
        fo_bind = open(self.dir_in+"bind_"+bind_in+".csv","r")
        csv_bind = csv.reader(fo_bind)

        # Looping through csv_bind (header)
        for line2 in csv_bind:
            break

        # Looping through csv_bind
        for line2 in csv_bind:

            # Some editing
            aux_line = str(line2[:24]).replace(" ","")
            aux_line = aux_line.replace("[","")
            aux_line = aux_line.replace("]","")
            aux_line = aux_line.replace("\'","")
            lines_out += aux_line+","

            # Get PDB access code
            pdb = line2[0].replace(" ","")

            # Try to open crystal.log file
            file2open = self.dir_in+"pdbqt/"+pdb+"/"+"crystal.log"
            try:
                fo_log = open(file2open,"r")
                data_lines = fo_log.readlines()

            # Handle exception
            except IOError:
                energy = "None"
                gauss1 = "None"
                gauss2 = "None"
                repulsion = "None"
                hydrophobic = "None"
                hydrogen = "None"
                torsional = "None"

            # Looping through data_lines
            for line in data_lines:
                if "Affinity:" in line:
                    i_1 = str(line).index(":")
                    i_2 = str(line).index("(")
                    energy = str(line)[i_1+1:i_2]
                    energy = energy.replace(" ","")
                    energy = energy.replace("\n","")
                elif "gauss 1"  in line:
                    i_1 = str(line).index(":")
                    gauss1 = str(line)[i_1+1:]
                    gauss1 = gauss1.replace(" ","")
                    gauss1 = gauss1.replace("\n","")
                elif "gauss 2"  in line:
                    i_1 = str(line).index(":")
                    gauss2 = str(line)[i_1+1:]
                    gauss2 = gauss2.replace(" ","")
                    gauss2 = gauss2.replace("\n","")
                elif "repulsion"  in line:
                    i_1 = str(line).index(":")
                    repulsion = str(line)[i_1+1:]
                    repulsion = repulsion.replace(" ","")
                    repulsion = repulsion.replace("\n","")
                elif "hydrophobic"  in line:
                    i_1 = str(line).index(":")
                    hydrophobic = str(line)[i_1+1:]
                    hydrophobic = hydrophobic.replace(" ","")
                    hydrophobic = hydrophobic.replace("\n","")
                elif "Hydrogen"  in line:
                    i_1 = str(line).index(":")
                    hydrogen = str(line)[i_1+1:]
                    hydrogen = hydrogen.replace(" ","")
                    hydrogen = hydrogen.replace("\n","")
                elif "Torsional"  in line:
                    i_1 = str(line).index(":")
                    torsional = str(line)[i_1+1:]
                    torsional = torsional.replace(" ","")
                    torsional = torsional.replace("\n","")

            # Close file
            fo_log.close()

            # Add energy data to lines_out
            lines_out += energy+","+gauss1+","+gauss2+","+repulsion+","
            lines_out += hydrophobic+","+hydrogen+","+torsional+"\n"

        # Close file
        fo_bind.close()

        # Open bind_####.csv file
        fo_bind = open(self.dir_in+"bind_"+bind_in+".csv","w")

        # Write header
        header_out = "PDB,Ligand,Chain,Number,Resolution(A),"
        header_out+="Ligand Occupation Factor,"+bind_in+"(M),log("+bind_in+"),p"
        header_out += bind_in+",RMSD(A),Torsions,Q,Average Q,"
        header_out += "Ligand B-factor(A2),Receptor B-factor(A2),"
        header_out += "B-factor ratio (Ligand/Receptor),"
        header_out += "C,N,O,P,S,F,Cl,Br,"
        header_out += "Affinity(kcal/mol),Gauss 1,Gauss 2,Repulsion,"
        header_out += "Hydrophobic,Hydrogen,Torsional\n"
        fo_bind.write(header_out)

        # Write results
        fo_bind.write(lines_out)

        # Close file
        fo_bind.close()

    # Define add_data4pdb() method
    def add_data4pdb(self,scores_docking_in,pdb,bind_in,n_poses):
        """Method to add docking results and energy terms to a CSV file"""

        # Re-open a file for docking results
        file2reopen1 = self.dir_in+"vina_all_rmsd_results.csv"
        fo_all_rmsd = open(file2reopen1,"a")

        # Re-open a file for docking scoring results
        file2reopen2 = self.dir_in+scores_docking_in
        fo_all_docking = open(file2reopen2,"a")

        # Reading docking results cycle
        pdb_list = os.listdir(self.dir_in+"pdbqt/")

        ########################################################################
        # Try to open bind_####.csv file to read one line related to a PDB
        try:
            file2open = self.dir_in+"bind_"+bind_in+".csv"
            fo_bind_in = open(file2open,"r")
            csv_bind_in = csv.reader(fo_bind_in)

        # Handle exception
        except:
            return

        # Looping through csv_bind_in
        for line in csv_bind_in:
            if line[0] == pdb:
                csv_bind_line = line
                break

        # Close bind_####.csv file
        fo_bind_in.close()

        # try to open config.txt WFA 2023/05/23
        try:
            config_in = self.program_root+"misc/data/vina_par.csv"
            fo_config = open(config_in,"r")
            fo_config_lines = fo_config.readlines()
        except IOError:
            msg_out = "\nIOError! I can't find "+config_in
            print(msg_out)
            return

        # Looping through fo_config_lines
        for line in fo_config_lines:
            aux_line = str(line)
            if "num_modes =" in aux_line:
                i_ref = aux_line.index(":")
                n_poses = int(aux_line[i_ref+1:])
                break

        # Close file
        fo_config.close()

        # Show message
        print("\n\nNumber of poses: ",n_poses)

        # Looping through self.list_lig_out
        for lig in self.list_lig_out:

            # Get centering
            centering = lig[:len(lig)-6].replace("lig_out_","")

            # Invoke extract_poses() method
            self.extract_pose_pdbqt(pdb,centering)

            # Try to read reference ligand
            try:

                # Invoke read_reference_xyz() method
                x1,y1,z1 = self.read_reference_xyz(pdb,self.ligand_in)

            # Handle exception
            except:
                break
        ########################################################################
            # Try to read poses to calculate features based on their atomic
            # coordinates

            # Looping through pose
            for i in range(1,n_poses+1):

                try:
                    # Invoke read_pose_xyz() method
                    x2,y2,z2 = self.read_pose_xyz(pdb,lig,i)

                    # Invoke show_rmsd
                    rmsd = self.show_rmsd(pdb,x1,y1,z1,x2,y2,z2)

                    # Invoke pose_energy() method
                    self.pose_energy(pdb,centering,i)

                    # Invoke read_pose_energy() method
                    self.read_pose_energy(pdb,centering,i)

                    # Assign data to docking_lines_out
                    line_out1 = str(pdb)+","+centering+","+str(i)
                    line_out1 += ","+rmsd+","+self.energy+","+self.gauss1
                    line_out1 += ","+self.gauss2+","+self.repulsion
                    line_out1 += ","+self.hydrophobic+","+self.hydrogen
                    line_out1 += ","+self.torsional

                    # Some editing
                    line_out1 = line_out1.replace(" ,",",")
                    line_out1 = line_out1.replace(", ",",")
                    line_out2 = str(csv_bind_line[:9])+","+rmsd+","
                    line_out2 += str(csv_bind_line[10:24])+","
                    line_out2 += self.energy+","+self.gauss1
                    line_out2 += ","+self.gauss2+","+self.repulsion
                    line_out2 += ","+self.hydrophobic+","+self.hydrogen
                    line_out2 += ","+self.torsional

                    # Some editing
                    line_out2 = line_out2.replace("[","")
                    line_out2 = line_out2.replace("]","")
                    line_out2 = line_out2.replace("'","")
                    line_out2 = line_out2.replace(" ,",",")
                    line_out2 = line_out2.replace(", ",",")

                    # Write a line
                    fo_all_rmsd.write(line_out1+"\n")

                    # Write a line
                    fo_all_docking.write(line_out2+"\n")
        ########################################################################
                # Handle exception
                except:

                    # Assign data to docking_lines_out
                    line_out1 = str(pdb)+","+centering+","+str(i)
                    line_out1 += ",ND,ND,ND,ND,ND,ND,ND,ND"

                    line_out2 = str(csv_bind_line[:9])+",ND,"
                    line_out2 += str(csv_bind_line[10:24])
                    line_out2 += ",ND,ND,ND,ND,ND,ND,ND"

                    # Some editing
                    line_out2 = line_out2.replace("[","")
                    line_out2 = line_out2.replace("]","")
                    line_out2 = line_out2.replace("'","")
                    line_out2 = line_out2.replace(" ,",",")
                    line_out2 = line_out2.replace(", ",",")

                    # Write a line
                    fo_all_rmsd.write(line_out1+"\n")

                    # Write a line
                    fo_all_docking.write(line_out2+"\n")

                    break
        ########################################################################
        # Close files
        #fo_all_rmsd.close()
        #fo_all_docking.close()

