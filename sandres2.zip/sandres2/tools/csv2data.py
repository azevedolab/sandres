#!/usr/bin/env python3
#
# Class to get the header of a CSV file.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import package
import csv

# Define Header() class
class Header(object):
    """Class to read the header of a CSV file"""

    # Define constructor method
    def __init__(self,dir_in,file_in):
        """Constructor method"""

        # Define attributes
        self.dir_in = dir_in
        self.file_in = file_in

    # Define get_string() method
    def get_string(self):
        """Method to get header as a string"""

        # Try to open a CSV file
        file2open = self.dir_in+self.file_in
        try:
            fo_csv = open(file2open,"r")
            csv_in = csv.reader(fo_csv)

            # Looping through csv_in
            for line in csv_in:

                # Some editing
                header_out = str(line)
                header_out = header_out.replace(", ",",")
                header_out = header_out.replace(" ,",",")
                header_out = header_out.replace("'","")
                header_out = header_out.replace("[","")
                header_out = header_out.replace("]","")
                header_out = header_out.replace("\n","")

                # Give me a break
                break

            # Close file
            fo_csv.close()

            # Return string
            return header_out

        # Handle IOError exception
        except IOError:
            msg_out = "\nIOError! I can't find "+file2open+" file!"
            print(msg_out)

            # Return empty string
            return ""

    # Define get_list() method
    def get_list(self):
        """Method to get header as a list"""

        # Assign an empty list to header_out
        header_out = []

        # Try to open a CSV file
        file2open = self.dir_in+self.file_in
        try:
            fo_csv = open(file2open,"r")
            csv_in = csv.reader(fo_csv)

            # Looping through csv_in
            for line1 in csv_in:

                # Looping through line1
                for line2 in line1:

                    # Some editing
                    line_out = str(line2)
                    line_out = line_out.replace(" ","")
                    line_out = line_out.replace("'","")
                    line_out = line_out.replace("\n","")

                    # Add to list
                    header_out.append(line_out)

                # Give me a break
                break

            # Close file
            fo_csv.close()

            # Return string
            return header_out

        # Handle IOError exception
        except IOError:
            msg_out = "\nIOError! I can't find "+file2open+" file!"
            print(msg_out)

            # Return empty list
            return header_out