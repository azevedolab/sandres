#!/usr/bin/env python3
#
# Function to read target variable (target_in) in mlr.in file.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# August 04, 2023                                                              #
################################################################################
#
# Import section
import csv
def read_it():
    """Function to read the target variable in mlr.in file"""

    # Try to open mlr.in file
    try:
        file2open = "./misc/data/mlr.in"
        fo_mlr = open(file2open,"r")
        csv_mlr = csv.reader(fo_mlr)

    # Handle IOError exception
    except IOError:
        msg_out = "\nI can't find "+file2open+" file!"
        return None

    # Looping through csv_mlr
    for line in csv_mlr:
        if line[0].strip() == "target_in":
            target_in = line[1].strip()
            break

    # Close file
    fo_mlr.close()

    # Return target_in
    return target_in