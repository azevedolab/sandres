#!/usr/bin/env python3
#
# Class to read program and GUI parameters.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Import package
import csv

# Define Parameter() class
class Parameter(object):
    """Class to read program and GUI parameters"""

    # Constructor method
    def __init__(self,program_root):
        """Constructor method"""

        # Set up attribute
        self.program_root = program_root

    # Define read_gui method
    def read_gui(self):
        """Method to read gui_par.csv and return parameters necessary for
        Tkinter.

        It follows the list of parameters:

        screen_geometry_var: screen geometry

        All numbers are in pixels

         870x260+0+430
         |    |  |  |__ y coordinate to locate window (win_y_coord)
         |    |  |
         |    |  |__ x coordinate to locate window (win_x_coord)
         |    |
         |    |__height (win_height)
         |
         |___width (win_width)

        window_txt_width: width of the text window in the main GUI (integer)
        window_txt_height: height of the text window in the main GUI (integer)
        widget_entry_main_width: number of spaces that defines the positioning
                                in the main GUI (integer)
        s_x: move figure to x coordinate (new center of the figure) (float)
        s_y: move figure to y coordinate (new center of the figure) (float)
        w: width in inches (float)
        h: height in inches (float)

        """

        # Handle screen issues
        # DELL Inspiron (1366x768)
        # Try to open gui_par.csv
        try:
            fo_gui_par = open(self.program_root+"misc/data/gui_par.csv","r")
            csv_gui_par = csv.reader(fo_gui_par)
        except IOError:
            # Show message
            msg_out = "IOError! I can't find file misc/data/gui_par.csv!"
            print(msg_out)
            return None,None,None,None,None,None,None,None

        # Looping through csv_gui_par
        for line in csv_gui_par:
            if "#" in str(line):
                pass
            elif line[0] == "screen_geometry":
                screen_geometry_var = str(line[1])
            elif line[0] == "window_txt_width":
                window_txt_width = int(line[1])
            elif line[0] == "window_txt_height":
                window_txt_height = int(line[1])
            elif line[0] == "widget_entry_main_width":
                widget_entry_main_width = int(line[1])
            elif line[0] == "win_height_type_1":
                win_height_type_1 = int(line[1])
            elif line[0] == "win_y_offset_type_1":
                win_y_offset_type_1 = int(line[1])
            elif line[0] == "win_height_type_2":
                win_height_type_2 = int(line[1])
            elif line[0] == "win_y_offset_type_2":
                win_y_offset_type_2 = int(line[1])
            elif line[0] == "win_height_type_3":
                win_height_type_3 = int(line[1])
            elif line[0] == "win_y_offset_type_3":
                win_y_offset_type_3 = int(line[1])
            elif line[0] == "spaces_in_row_2":
                spaces_in_row_2 = int(line[1])
            elif line[0] == "spaces_in_row_3":
                spaces_in_row_3 = int(line[1])
            elif line[0] == "spaces_in_row_4":
                spaces_in_row_4 = int(line[1])
            elif line[0] == "spaces_in_row_5":
                spaces_in_row_5 = int(line[1])
            elif line[0] == "spaces_in_row_9":
                spaces_in_row_9 = int(line[1])
            elif line[0] == "fast_editor_txt_width":
                fast_editor_txt_width = int(line[1])
            elif line[0] == "fast_editor_txt_height":
                fast_editor_txt_height = int(line[1])
            elif line[0] == "w":
                w = float(line[1])
            elif line[0] == "h":
                h = float(line[1])
            elif line[0] == "s_x":
                s_x = int(line[1])
            elif line[0] == "s_y":
                s_y = int(line[1])

        # Close file
        fo_gui_par.close()

        # Return parameters
        return screen_geometry_var,window_txt_width,window_txt_height,\
        widget_entry_main_width,\
        win_height_type_1,win_y_offset_type_1,\
        win_height_type_2,win_y_offset_type_2,\
        win_height_type_3,win_y_offset_type_3,\
        spaces_in_row_2,spaces_in_row_3,\
        spaces_in_row_4,spaces_in_row_5,spaces_in_row_9,\
        fast_editor_txt_width,fast_editor_txt_height,\
        w,h,s_x,s_y

    # Define tkinter_geometry() method
    def tkinter_geometry(self,screen_geometry_var,new_win_height,y_offset):
        """Method to generate geometric parameters for Tkinter package"""

        # Set up screen geometry based on screen_geometry_var
        #
        # All numbers are in pixels
        #
        # 870x260+0+430
        # |    |  |  |__ y coordinate to locate window (win_y_coord)
        # |    |  |
        # |    |  |__ x coordinate to locate window (win_x_coord)
        # |    |
        # |    |__height (win_height)
        # |
        # |___width (win_width)

        # Set up geometric parameter for window
        i_x = screen_geometry_var.index("x")
        i_plus_1 = screen_geometry_var.index("+")
        i_plus_2 = screen_geometry_var[i_plus_1+1:].index("+")
        win_width = int(screen_geometry_var[:i_x])
        win_height = int(screen_geometry_var[i_x+1:i_plus_1])
        win_x_coord = int(screen_geometry_var[i_plus_1+1:i_plus_1+i_plus_2+1])
        win_y_coord = int(screen_geometry_var[i_plus_1+i_plus_2+2:])
        new_win_width = win_width           # Suggested value: 870
        new_win_x_coord  = win_x_coord      # Suggested value: 0
        new_win_y_coord = win_y_coord + win_height + y_offset
        gui_geom = str(new_win_width)+"x"+str(new_win_height)+"+"+\
                   str(new_win_x_coord)+"+"+str(new_win_y_coord)

        # Return win_width,win_y_coord,gui_geom
        return win_width,win_y_coord,gui_geom


    # Define read_adt() method
    def read_adt(self):
        """Method to read ADT preferences.
        Please see: http://autodock.scripps.edu/faqs-help/how-to/how-to-prepare-a-ligand-file-for-autodock4

        for additional information about options"""

        # Try to open pdbqt_par.csv
        try:
            fo = open(self.program_root+"misc/data/pdbqt_par.csv","r")
            my_csv = csv.reader(fo)

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find misc/data/pdbqt_par.csv file.")
            return None,None

        # Looping through self.program_par
        for line in my_csv:
            if line[0] == "prepare_ligand4_option":
                prepare_ligand4_option = line[1]
            elif line[0]  == "prepare_receptor4_option":
                prepare_receptor4_option = line[1]

        # Close file
        fo.close()

        # Return data
        return prepare_ligand4_option,prepare_receptor4_option
