# Import packages
import os
import shutil
import csv
import numpy as np
from tkinter import *
from tools import string_tools as string_t
from tools import tkinter_messages as tk_msg
from tools import add_pdbqt as add_str
from tools import preferences as prefs

# Instantiate an object of the Palavra class
a1 = string_t.Palavra("","pdb_codes.csv")

# Invoke ascii_art() method
_,_,_,_,pdb_pdbqt,_,_ = a1.ascii_art()

# Define Dataset() class
class Dataset(object):
    """Class to create a dataset"""

    # Define constructor method
    def __init__(self,program_root,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.strdir_entry = strdir_entry
        self.root = root

        # Instantiate an object of Parameter class
        self.pr1 = prefs.Parameter(self.program_root)

        # Invoke read_gui() method
        self.screen_geometry_var,self.window_txt_width,self.window_txt_height,\
        self.widget_entry_main_width,\
        _,_,\
        self.win_height_type_2,self.win_y_offset_type_2,\
        self.win_height_type_3,self.win_y_offset_type_3,\
        _,_,\
        _,_,_,\
        _,_,\
        self.w,self.h,self.s_x,self.s_y =\
        self.pr1.read_gui()

        # Invoke read_program() method
        #_,_,self.dataset_var = self.pr1.read_program()

    # Define add_pdbqt_GUI() method
    def add_pdbqt_GUI(self):
        """GUI to generate dataset"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() message
        msg_out = "Ready to generate PDBQT files..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the Palavra class
        #p1 = string_t.Palavra(project_dir_string,"")

        # Define pdbqt_structures() function
        def pdbqt_structures():
            """Function to add PDBQT structures"""

            # Call backup_file() method
            #p1.backup_file(self.dataset_var)

            # Set up dataset_dir
            dataset_dir = project_dir_string+"pdbqt"

            # Try to create new directory for PDBQT structures
            try:
                # Create dataset dir
                os.mkdir(dataset_dir)
            except:

                # Try to remove dir
                try:

                    # Remove dataset dir
                    os.rmdir(dataset_dir)

                # Handle exception
                except:

                    # Show yes/no question
                    result = messagebox.askyesno("Continue?",
                    "Do you wish to remove old PDBQT files?")

                    # Test answer
                    if result:
                        shutil.rmtree(dataset_dir, ignore_errors=True)
                    else:
                        return

                # Create dataset dir
                os.mkdir(dataset_dir)

            # Read data
            h_resol = float(h_resol_entry.get())
            l_resol = float(l_resol_entry.get())
            bind_in =str(binding_affinity_list[int(binding_affinity_var.get())])
            occ_selection = str(yes_no_list_1[int(occupaction_factor_var.get())])

            # Check selection of occ_selection
            if occ_selection == "Yes":
                b_occ = True
            else:
                b_occ = False

            lig_selection = str(yes_no_list_2[int(ligand_var.get())])

            # Check selection of lig_selection
            if lig_selection == "Yes":
                b_lig = True
            else:
                b_lig = False

            # Instantiate an object of PDBQT class
            data1 = add_str.PDBQT(self.program_root,project_dir_string,
            b_lig,b_occ,bind_in,h_resol,l_resol,dataset_dir)

            # Call pdb_access_codes to get codes for the dataset
            list_pdb_access_codes = data1.pdb_access_codes()

            # Call progress_bar_pdbqt() method
            self.progress_bar_pdbqt(data1)

        # Assign initial value and states to variables
        bind_in = "Ki"
        b_occ = True
        b_lig = False

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50) (80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('PDBQT Structures')
        top_txt.geometry(top_txt_geom)

        # Widgets for binding affinity
        Label(top_txt,text="Binding affinity data:").grid(row = 1,
        column = 0, stick = W)
        binding_affinity_var  = IntVar()

        # Set list for output formats available at matplotlib
        binding_affinity_list = ["Ki","Kd","IC50"]

        # Define my_sel1() function
        def my_sel1():
            """Function to show selection of binding affinity"""
            selection=str(binding_affinity_list[int(binding_affinity_var.get())])
            bind_in = selection

        # Looping through binding affinity
        for i in range(len(binding_affinity_list)):
            rad = Radiobutton(top_txt, text = binding_affinity_list[i],
            value = i, variable=binding_affinity_var, command = my_sel1)
            rad.grid(row = 2,column = i+2, stick = W)

        # Widgets for occupation factor
        Label(top_txt, text="Keep occupation factor < 1.0 ?" ).grid(row = 1,
        column = 5, stick = W)
        occupaction_factor_var  = IntVar()

        # Set list of "Yes" and "No"
        yes_no_list_1 = ["Yes","No"]

        # Define my_sel2() function
        def my_sel2():
            """Function to show yes and no options"""
            selection = str(yes_no_list_1[int(occupaction_factor_var.get())] )

            # Check selection
            if selection == "Yes":
                b_occ = True
            else:
                b_occ = False

        # Looping through list of "Yes" and "No"
        for i in range(len(yes_no_list_1)):
            rad = Radiobutton(top_txt, text =yes_no_list_1[i], value = i,
            variable=occupaction_factor_var, command = my_sel2)
            rad.grid(row = 2,column = i+6, stick = W)

        # Widgets for ligands
        Label(top_txt, text="Unify ligands?" ).grid(row = 1,column = 8, stick = W)
        ligand_var  = IntVar()

        # Set list of "No" and "Yes"
        yes_no_list_2 = ["No","Yes"]

        def my_sel3():
            """Function to show yes and no options"""
            selection = str(yes_no_list_2[int(ligand_var.get())] )

            # Check selection
            if selection == "Yes":
                b_lig = True
            else:
                b_lig = False

        # Looping through list of "No" and "Yes"
        for i in range(len(yes_no_list_2)):
            rad = Radiobutton(top_txt, text =yes_no_list_2[i], value = i,
            variable=ligand_var, command = my_sel3)
            rad.grid(row = 2,column = i+9, stick = W)

        # Try to open binding affinity file
        try:
            fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
            data_lines = csv.reader(fo_bind)

        # Handle exception
        except IOError:

            # Retry to open as bind_in = "IC50"
            bind_in = "IC50"
            try:
                fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
                data_lines = csv.reader(fo_bind)

            # Handle exception
            except IOError:

                # Retry to open as bind_in = "Kd"
                bind_in = "Kd"
                try:
                    fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
                    data_lines = csv.reader(fo_bind)

                # Handle exception
                except IOError:

                    # Show messages
                    print("\nIOError! I can't find "+
                    project_dir_string+"bind_"+bind_in+".csv file!")
                    msg_out ="No data for generation of dataset!"
                    msg1.show_botton_msg(msg_out,"red","light grey")
                    return

        # Set up empty list for crystallographic resolution
        x_resol_list = []

        # Looping through data_lines
        for line in data_lines:
            break
        for line in data_lines:
            x_resol_list.append(float(line[4]))

        # Convert to array
        x_resol_array = np.array(x_resol_list)

        # Get highest an lowest resolution values
        h_resol = np.min(x_resol_array)
        l_resol = np.max(x_resol_array)

        # Close file
        fo_bind.close()

        # Widget for highest resolution
        Label(top_txt, text="Highest resolution ("+"\u212B"+"):" ).grid(row = 3,
        column = 0, stick = W, pady = 4)
        h_resol_entry = Entry(top_txt,width = 4)
        h_resol_entry.grid(row = 3, column = 0,stick = E, pady = 4)
        h_resol_entry.insert(10,str(h_resol))

        # Widget for lowest resolution
        Label(top_txt, text="Lowest resolution ("+"\u212B"+"):" ).grid(row = 3,
        column = 5, stick = W, pady = 4)
        l_resol_entry = Entry(top_txt,width = 4)
        l_resol_entry.grid(row = 3, column = 5,stick = E, pady = 4)
        l_resol_entry.insert(1,str(l_resol))

        # Widgets for Make button
        Button(top_txt, text='Add',
        command=pdbqt_structures).grid(row = 3, column = 7,sticky = W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
        command=top_txt.destroy).grid(row = 3, column = 8,sticky = W)

    # Define progress_bar_pdbqt() method
    def progress_bar_pdbqt(self,data1):
        """Method to generate PDBQT files with a progress bar"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Call pdb_access_codes method to get codes for the dataset
        list_pdb_access_codes = data1.pdb_access_codes()

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the Palavra class
        #p1 = string_t.Palavra(project_dir_string,"")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Define pdbqt() function
        def pdbqt():
            """Function to looping through the structures available in the
            dataset to generate PDBQT files"""

            # Invoke show_short_msg() method
            msg1.show_short_msg(pdb_pdbqt+"Generating PDBQT files for "+
            "structures in the dataset...\n")

            # Get the number_of_pdbs
            number_of_pdbs = len(list_pdb_access_codes)

            # Assign initial values to counters
            count_ = 0
            i = 1

            # Set up empty list
            no_pdbqt = []

            # Looping through the list of PDB codes used in the dataset
            for line in list_pdb_access_codes:

                # Call generate_pdbqt method for PDB access code in the dataset
                data1.generate_pdbqt(line[0],line[1],line[2],line[3])

                # To handle exceptions related to the Done button
                try:
                    if count_ != 0:
                        pr_bar_03["value"] = i*100/number_of_pdbs
                    root.update()
                except:
                    return

                # Add 1 to i
                i += 1
                count_ += 1

                # Check if PDBQT files exist
                if os.path.exists(data1.my_dir_in+"receptor.pdbqt") and \
                os.path.exists(data1.my_dir_in+"lig.pdbqt"):

                    # Show message about the generation of the PDBQT files
                    msg_out = "PDBQT files generated for structure "+line[0]+"!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                else:
                    # Show message for structures with problems in the generation
                    # of PDBQT files
                    print(
                    "\nProblems in the generation of PDBQT files for structure "+
                    line[0]+"!")
                    print("Please update dataset or generate PDBQT files using "+
                    "AuntoDockTool4!\n")
                    no_pdbqt.append(line[0])

            # Show message
            msg_out = "SAnDReS finished \"Add Structures (PDBQT)\" request! "
            msg_out += "Number of structures: "
            msg_out += str(number_of_pdbs-len(no_pdbqt))
            msg1.show_botton_msg(msg_out,"black","light grey")

            # Invoke show_short_msg() method
            msg1.show_short_msg(pdb_pdbqt+"Done!\n")

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160) (52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_3,self.win_y_offset_type_3)

        # Set up progress bar (pr_bar_03)
        # Create child window
        root = tk.Tk()
        root.title('Generate PDBQT files')
        root.geometry(top_txt_geom) # 870x52+0+540 ('870x50+0+430') length = 790
        pr_bar_03 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_03.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=pdbqt)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()

    # Define add_adt_pdbqt_GUI() method
    def add_adt_pdbqt_GUI(self):
        """GUI to generate dataset using AutoDockTools4"""

        # Import package
        from tkinter import messagebox

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Invoke show_botton_msg() message
        msg_out = "Ready to generate PDBQT files using AutoDockTools4..."
        msg1.show_botton_msg(msg_out,"black","light grey")

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the Palavra class
        #p1 = string_t.Palavra(project_dir_string,"")

        # Define pdbqt_structures() function
        def pdbqt_structures():
            """Function to add PDBQT structures using AutoDockTools4"""

            # Call backup_file() method
            #p1.backup_file(self.dataset_var)

            # Set up dataset_dir
            dataset_dir = project_dir_string+"pdbqt"

            # Try to create new directory for PDBQT structures
            try:
                # Create dataset dir
                os.mkdir(dataset_dir)
            except:

                # Try to remove dir
                try:

                    # Remove dataset dir
                    os.rmdir(dataset_dir)

                # Handle exception
                except:

                    # Show yes/no question
                    result = messagebox.askyesno("Continue?",
                    "Do you wish to remove old PDBQT files?")

                    # Test answer
                    if result:
                        shutil.rmtree(dataset_dir, ignore_errors=True)
                    else:
                        return

                # Create dataset dir
                os.mkdir(dataset_dir)

            # Read data
            h_resol = float(h_resol_entry.get())
            l_resol = float(l_resol_entry.get())
            bind_in =str(binding_affinity_list[int(binding_affinity_var.get())])
            occ_selection = str(yes_no_list_1[int(occupaction_factor_var.get())])

            # Check selection of occ_selection
            if occ_selection == "Yes":
                b_occ = True
            else:
                b_occ = False

            lig_selection = str(yes_no_list_2[int(ligand_var.get())])

            # Check selection of lig_selection
            if lig_selection == "Yes":
                b_lig = True
            else:
                b_lig = False

            # Instantiate an object of PDBQT class
            data2 = add_str.PDBQT(self.program_root,project_dir_string,
            b_lig,b_occ,bind_in,h_resol,l_resol,dataset_dir)

            # Call pdb_access_codes to get codes for the dataset
            list_pdb_access_codes = data2.pdb_access_codes()

            # Call progress_bar_adt_pdbqt() method
            self.progress_bar_adt_pdbqt(data2)

        # Assign initial value and states to variables
        bind_in = "Ki"
        b_occ = True
        b_lig = False

        # Type 2 GUI Window (new_win_height = 80, y_offset = 50) (80,83)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_2,self.win_y_offset_type_2)

        # Create child window
        top_txt = Toplevel()
        top_txt.title('PDBQT Structures')
        top_txt.geometry(top_txt_geom)

        # Widgets for binding affinity
        Label(top_txt,text="Binding affinity data:").grid(row = 1,
        column = 0, stick = W)
        binding_affinity_var  = IntVar()

        # Set list for output formats available at matplotlib
        binding_affinity_list = ["Ki","Kd","IC50"]

        # Define my_sel1() function
        def my_sel1():
            """Function to show selection of binding affinity"""
            selection=str(binding_affinity_list[int(binding_affinity_var.get())])
            bind_in = selection

        # Looping through binding affinity
        for i in range(len(binding_affinity_list)):
            rad = Radiobutton(top_txt, text = binding_affinity_list[i],
            value = i, variable=binding_affinity_var, command = my_sel1)
            rad.grid(row = 2,column = i+2, stick = W)

        # Widgets for occupation factor
        Label(top_txt, text="Keep occupation factor < 1.0 ?" ).grid(row = 1,
        column = 5, stick = W)
        occupaction_factor_var  = IntVar()

        # Set list of "Yes" and "No"
        yes_no_list_1 = ["Yes","No"]

        # Define my_sel2() function
        def my_sel2():
            """Function to show yes and no options"""
            selection = str(yes_no_list_1[int(occupaction_factor_var.get())] )

            # Check selection
            if selection == "Yes":
                b_occ = True
            else:
                b_occ = False

        # Looping through list of "Yes" and "No"
        for i in range(len(yes_no_list_1)):
            rad = Radiobutton(top_txt, text =yes_no_list_1[i], value = i,
            variable=occupaction_factor_var, command = my_sel2)
            rad.grid(row = 2,column = i+6, stick = W)

        # Widgets for ligands
        Label(top_txt, text="Unify ligands?" ).grid(row = 1,column = 8, stick = W)
        ligand_var  = IntVar()

        # Set list of "No" and "Yes"
        yes_no_list_2 = ["No","Yes"]

        def my_sel3():
            """Function to show yes and no options"""
            selection = str(yes_no_list_2[int(ligand_var.get())] )

            # Check selection
            if selection == "Yes":
                b_lig = True
            else:
                b_lig = False

        # Looping through list of "No" and "Yes"
        for i in range(len(yes_no_list_2)):
            rad = Radiobutton(top_txt, text =yes_no_list_2[i], value = i,
            variable=ligand_var, command = my_sel3)
            rad.grid(row = 2,column = i+9, stick = W)

        # Try to open binding affinity file
        try:
            fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
            data_lines = csv.reader(fo_bind)
        except IOError:
            print("\nIOError! I can't find "+
            project_dir_string+"bind_"+bind_in+".csv file!")

            # Retry to open as bind_in = "IC50"
            bind_in = "IC50"
            try:
                fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
                data_lines = csv.reader(fo_bind)
            except IOError:
                print("\nIOError! I can't find "+
                project_dir_string+"bind_"+bind_in+".csv file!")

                # Retry to open as bind_in = "Kd"
                bind_in = "Kd"
                try:
                    fo_bind = open(project_dir_string+"bind_"+bind_in+".csv","r")
                    data_lines = csv.reader(fo_bind)
                except IOError:

                    # Show messages
                    print("\nIOError! I can't find "+
                    project_dir_string+"bind_"+bind_in+".csv file!")
                    msg_out ="No data for generation of dataset!"
                    msg1.show_botton_msg(msg_out,"red","light grey")
                    return

        # Set up empty list for crystallographic resolution
        x_resol_list = []

        # Looping through data_lines
        for line in data_lines:
            break
        for line in data_lines:
            x_resol_list.append(float(line[4]))

        # Convert to array
        x_resol_array = np.array(x_resol_list)

        # Get highest an lowest resolution values
        h_resol = np.min(x_resol_array)
        l_resol = np.max(x_resol_array)

        # Close file
        fo_bind.close()

        # Widget for highest resolution
        Label(top_txt, text="Highest resolution ("+"\u212B"+"):" ).grid(row = 3,
        column = 0, stick = W, pady = 4)
        h_resol_entry = Entry(top_txt,width = 4)
        h_resol_entry.grid(row = 3, column = 0,stick = E, pady = 4)
        h_resol_entry.insert(10,str(h_resol))

        # Widget for lowest resolution
        Label(top_txt, text="Lowest resolution ("+"\u212B"+"):" ).grid(row = 3,
        column = 5, stick = W, pady = 4)
        l_resol_entry = Entry(top_txt,width = 4)
        l_resol_entry.grid(row = 3, column = 5,stick = E, pady = 4)
        l_resol_entry.insert(1,str(l_resol))

        # Widgets for Make button
        Button(top_txt, text='Add',
        command=pdbqt_structures).grid(row = 3, column = 7,sticky = W)

        # Widgets for Close button
        Button(top_txt, text='Close', bg = "red",
        command=top_txt.destroy).grid(row = 3, column = 8,sticky = W)

    # Define progress_bar_adt_pdbqt() method
    def progress_bar_adt_pdbqt(self,data2):
        """Method to generate PDBQT files with a progress bar"""

        # Import packages
        import tkinter as tk
        from tkinter import ttk

        # Call pdb_access_codes method to get codes for the dataset
        list_pdb_access_codes = data2.pdb_access_codes()

        # Get project directory
        project_dir_string = str(self.strdir_entry.get())

        # Instantiate an object of the Palavra class
        #p1 = string_t.Palavra(project_dir_string,"")

        # Instantiate an object of Messages() class
        msg1 = tk_msg.Messages(self.strdir_entry,self.root)

        # Define autodocktools_pdbqt() function
        def autodocktools_pdbqt():
            """Function to looping through the structures available in the
            dataset to generate PDBQT files using AutoDockTools4"""

            # Invoke show_short_msg() method
            msg1.show_short_msg(pdb_pdbqt+"Generating PDBQT files for "+
            "structures in the dataset...\n")

            # Get the number_of_pdbs
            number_of_pdbs = len(list_pdb_access_codes)

            # Assign initial values to counters
            count_ = 0
            i = 1

            # Set up empty list
            no_pdbqt = []

            # Looping through the list of PDB codes used in the dataset
            for line in list_pdb_access_codes:

                # Call generate_adt_pdbqt method for PDB access code in the dataset
                data2.generate_adt_pdbqt(line[0],line[1],line[2],line[3])

                # To handle exceptions related to the Done button
                try:
                    if count_ != 0:
                        pr_bar_04["value"] = i*100/number_of_pdbs
                    root.update()
                except:
                    return

                # Add 1 to i
                i += 1
                count_ += 1

                # Check if PDBQT files exist
                if os.path.exists(data2.my_dir_in+"receptor.pdbqt") and \
                os.path.exists(data2.my_dir_in+"lig.pdbqt"):

                    # Show message about the generation of the PDBQT files
                    msg_out = "PDBQT files generated for structure "+line[0]+"!"
                    msg1.show_botton_msg(msg_out,"black","light grey")
                else:
                    # Show message for structures with problems in the generation
                    # of PDBQT files
                    print(
                    "\nProblems in the generation of PDBQT files for structure "+
                    line[0]+"!")
                    print("Please update dataset or generate PDBQT files using "+
                    "AuntoDockTool4!\n")
                    no_pdbqt.append(line[0])

            # Show message
            msg_out = "SAnDReS finished \"Add Structures (PDBQT) with ADT4\" "
            msg_out += "request! Number of structures: "+\
            str(number_of_pdbs-len(no_pdbqt))
            msg1.show_botton_msg(msg_out,"black","light grey")

        # Type 3 GUI Window (new_win_height = 52, y_offset = 160) (52,193)
        # Invoke tkinter_geometry() method
        win_width,win_y_coord,top_txt_geom = self.pr1.tkinter_geometry(self.screen_geometry_var,self.win_height_type_3,self.win_y_offset_type_3)

        # Set up progress bar (pr_bar_04)
        # Create child window
        root = tk.Tk()
        root.title('Generate PDBQT files using AutoDockTools4')
        root.geometry(top_txt_geom) # 870x52+0+540 ('870x50+0+430') length = 790
        pr_bar_04 = ttk.Progressbar(root, length=win_width-80, cursor='spider',
                        mode="determinate",
                        orient=tk.HORIZONTAL)
        pr_bar_04.grid(row=1,column=1)
        btn = ttk.Button(root,text="Start",command=autodocktools_pdbqt)
        btn.grid(row=1,column=0)
        btn = ttk.Button(root,text="Done",command=root.destroy)
        btn.grid(row=2,column=0)
        root.mainloop()