# Class to analyze virtual screening results generated using
# AutoDock Vina (Trott & Olson, 2010; Eberhardt et al., 2021).
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010; 31(2):455-61. doi: 10.1002/jcc.21334.
# PMID: 19499576; PMCID: PMC3041641.
#
# Eberhardt J, Santos-Martins D, Tillack AF, Forli S. AutoDock Vina 1.2.0:
# New Docking Methods, Expanded Force Field, and Python Bindings.
# J Chem Inf Model. 2021; 61(8):3891-3898. doi: 10.1021/acs.jcim.1c00203.
# PMID: 34278794.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import packages
import csv
import os
from tools import binding_affinity as b_aff
from tools import score_only_vina123_vs as vina123_vs
from MLRegMPy import backup

# Define MergeVS() class
class MergeVS(object):
    """Class to analyze virtual screening results genereated using
    AutoDock Vina"""

    # Define constructor method
    def __init__(self,program_root,dir_in,lig_root_out,vs_string):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.lig_root_out = lig_root_out
        self.vs_string = vs_string

    # Define calc_pose_charge() method
    def calc_pose_charge(self,pose):
        """Method to calculate total charge in a pose pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_pose = open(pose,"r")
            pose_lines = fo_pose.readlines()
        except IOError:
            print("\nIOError! I can't find "+pose+" file!")
            return None

        # Assign zero to total_charge
        total_charge = 0.0

        # Get total_charge
        for line in pose_lines:
            if "ATOM  " in line or "HETATM" in line:
                total_charge += float(line[67:76])

        # Close file
        fo_pose.close()

        # Return total_charge
        return total_charge

    # Define calc_pose_average_charge() method
    def calc_pose_average_charge(self,pose):
        """Method to calculate average charge in a pose pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_pose = open(pose,"r")
            pose_lines = fo_pose.readlines()
        except IOError:
            print("IOError! I can't find "+pose+" file!")
            return None

        # Assign zero to total_charge
        total_charge = 0.0

        # Assign zero to count_atoms
        count_atoms = 0

        # Get total_charge and count_atoms
        for line in pose_lines:
            if "ATOM  " in line or "HETATM" in line:
                total_charge += float(line[67:76])
                count_atoms += 1

        # Calculate average charge
        if count_atoms > 0:
            average_charge = total_charge/count_atoms
        else:
            average_charge = 0.0

        # Close file
        fo_pose.close()

        # Return average_charge
        return average_charge

    # Define calc_average_bfactor() method
    def calc_average_bfactor(self,pdbqt):
        """Method to calculate average B-factor in a pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_pdbqt = open(pdbqt,"r")
            pdbqt_lines = fo_pdbqt.readlines()
        except IOError:
            print("IOError! I can't find PDBQT file!")
            return None

        # Assign zero to total_bfactor
        total_bfactor = 0.0

        # Assign zero to count_atoms
        count_atoms = 0

        # Get B-factor
        for line in pdbqt_lines:
            if "ATOM  " in line or "HETATM" in line:
                total_bfactor += float(line[61:66])
                count_atoms += 1

        # Calculate average bfactor
        if count_atoms > 0:
            average_bfactor = total_bfactor/count_atoms
        else:
            average_bfactor = 0.0

        # Close file
        fo_pdbqt.close()

        # Return average_bfactor
        return average_bfactor

    # Define calc_pose_atoms() method
    def calc_pose_atoms(self,pose):
        """Method to calculate the number of C, N, O,.. in a pose pdbqt file"""

        # Try to open pdbqt file
        try:
            fo_lig = open(pose,"r")
            lig_lines = fo_lig.readlines()
        except IOError:
            print("IOError! I can't find "+pose+" file!")
            return None,None,None,None,None,None,None,None

        # Assign zero to n_c, n_n
        n_c = 0
        n_n = 0
        n_o = 0
        n_p = 0
        n_s = 0
        n_f = 0
        n_cl = 0
        n_br = 0

        # Get number of atoms
        for line in lig_lines:
            if "ATOM  " in line or "HETATM" in line:
                if "C" in line[13:14]:
                    n_c += 1
                elif "N" in line[13:14]:
                    n_n += 1
                elif "O" in line[13:14]:
                    n_o += 1
                elif "P" in line[13:14]:
                    n_p += 1
                elif "S" in line[13:14]:
                    n_s += 1
                elif "F" in line[13:14]:
                    n_f += 1
                elif "CL" in line[13:15]:
                    n_cl += 1
                elif "BR" in line[13:15]:
                    n_br += 1

        # Close file
        fo_lig.close()

        # Return number of atoms
        return n_c, n_n, n_o, n_p, n_s, n_f, n_cl, n_br

    # Define read_pose_energy() method
    def read_pose_energy(self,log_file):
        """Method to add protein-ligand binding energy using
        AutoDock Vina"""

        print("Log file: ",log_file)

        # Try to open result_####_#.log file
        file2open = log_file
        try:
            fo_log = open(file2open,"r")
            data_lines = fo_log.readlines()
        except IOError:
            print("\nI can't find "+file2open+"!")
            self.energy = "None"
            self.gauss1 = "None"
            self.gauss2 = "None"
            self.repulsion = "None"
            self.hydrophobic = "None"
            self.hydrogen = "None"
            self.torsional = "None"

        # Looping through data_lines
        for line in data_lines:
            if "Affinity:" in line:
                i_1 = str(line).index(":")
                i_2 = str(line).index("(")
                self.energy = str(line)[i_1+1:i_2]
                self.energy = self.energy.replace(" ","")
                self.energy = self.energy.replace("\n","")
            elif "gauss 1"  in line:
                i_1 = str(line).index(":")
                self.gauss1 = str(line)[i_1+1:]
                self.gauss1 = self.gauss1.replace(" ","")
                self.gauss1 = self.gauss1.replace("\n","")
            elif "gauss 2"  in line:
                i_1 = str(line).index(":")
                self.gauss2 = str(line)[i_1+1:]
                self.gauss2 = self.gauss2.replace(" ","")
                self.gauss2 = self.gauss2.replace("\n","")
            elif "repulsion"  in line:
                i_1 = str(line).index(":")
                self.repulsion = str(line)[i_1+1:]
                self.repulsion = self.repulsion.replace(" ","")
                self.repulsion = self.repulsion.replace("\n","")
            elif "hydrophobic"  in line:
                i_1 = str(line).index(":")
                self.hydrophobic = str(line)[i_1+1:]
                self.hydrophobic = self.hydrophobic.replace(" ","")
                self.hydrophobic = self.hydrophobic.replace("\n","")
            elif "Hydrogen"  in line:
                i_1 = str(line).index(":")
                self.hydrogen = str(line)[i_1+1:]
                self.hydrogen = self.hydrogen.replace(" ","")
                self.hydrogen = self.hydrogen.replace("\n","")
            elif "Torsional"  in line:
                i_1 = str(line).index(":")
                self.torsional = str(line)[i_1+1:]
                self.torsional = self.torsional.replace(" ","")
                self.torsional = self.torsional.replace("\n","")

        # Close file
        fo_log.close()

    # Define add_data() method
    def add_data(self,vs_dir,mol_dir,dir_list,pdb,resolution):
        """Method to add VS results and energy terms to a CSV file"""

        # Invoke backup.make()
        backup.make("vina_all_vs_results.csv",self.dir_in,self.dir_in+"backup/")

        # Open a new file for VS results
        file2create1 = self.dir_in+"vina_all_vs_results.csv"
        fo_all_vs = open(file2create1,"w")

        # Open a file for full VS results
        file2create2 = self.dir_in+self.vs_string
        fo_full_vs = open(file2create2,"w")

        # Invoke read_it function
        bind_in = b_aff.read_it(self.dir_in)

        # Set up header_1
        header_1 = "PDB,Ligand,Code,Pose,Resolution(A),"
        header_1 += "Torsions,Affinity(kcal/mol),"
        header_1 += "Gauss 1,Gauss 2,Repulsion,Hydrophobic,Hydrogen,Torsional\n"

        # Set up header_2
        header_2 = "PDB,Ligand,Code,Pose,Resolution(A),"
        header_2 += "Ligand Occupation Factor,"+bind_in+"(M),log("+bind_in+"),"
        header_2 += "p"+bind_in+",RMSD(A),Torsions,Q,Average Q,"
        header_2 += "Ligand B-factor(A2),Receptor B-factor(A2),"
        header_2 += "B-factor ratio (Ligand/Receptor),"
        header_2 += "C,N,O,P,S,F,Cl,Br,"
        header_2 += "Affinity(kcal/mol),"
        header_2 += "Gauss 1,Gauss 2,Repulsion,Hydrophobic,Hydrogen,Torsional\n"

        # PDB,Ligand,Chain,Number,Resolution(A),Ligand Occupation Factor,Kd(M),log(Kd),pKd,RMSD(A),
        # Torsions,Q,Average Q,Ligand B-factor(A2),Receptor B-factor(A2),
        # B-factor ratio (Ligand/Receptor),C,N,O,P,S,F,Cl,Br,Affinity(kcal/mol),
        # Gauss 1,Gauss 2,Repulsion,Hydrophobic,Hydrogen

        # Write header_1
        fo_all_vs.write(header_1)

        # Write header_2
        fo_full_vs.write(header_2)

        # Looping through dir_list (
        for mol in dir_list:

            # Show message
            print("Reading "+str(mol)+" directory...")

            # Try to read number of torsions in a PDBQT file
            try:
                pdbqt_file = self.dir_in+vs_dir+mol_dir+mol+".pdbqt"
                fo_pdbqt_file = open(pdbqt_file,"r")
                lines_pdbqt_file = fo_pdbqt_file.readlines()

                # Looping through lines_pdbqt_file
                for line in lines_pdbqt_file:
                    if "TORSDOF" in str(line):
                        # Some editing
                        torsions = line[7:]
                        torsions = torsions.replace("\n","")
                        break

                # Close file
                fo_pdbqt_file.close()

            # Handle IOError exception
            except IOError:
                print("\nI can't find "+pdbqt_file+" file!")
                return

            # Try to open ligand_codes4vs.csv file
            try:
                file_ligand_codes4vs = self.dir_in+"ligand_codes4vs.csv"
                fo_ligand_codes4vs = open(file_ligand_codes4vs,"r")
                csv_ligand_codes4vs = csv.reader(fo_ligand_codes4vs)

                # Looping through csv_ligand_codes4vs (skip first line)
                for line in csv_ligand_codes4vs:
                    break

                # Looping through csv_ligand_codes4vs
                for line in csv_ligand_codes4vs:

                    # Some editing
                    aux_str = str(line[0])
                    aux_str = aux_str.replace(" ","")
                    lig_with_number = self.lig_root_out+aux_str

                    # Get ligand code
                    if lig_with_number == str(mol):
                        ligand_code_out = line[1]
                        break

                # Close file
                fo_ligand_codes4vs.close()

            # Handle IOError exception
            except IOError:
                print("\nI can't find "+file_ligand_codes4vs+" file!")
                return

            # Read pose file names
            dir2check = self.dir_in+vs_dir+mol_dir+mol
            dir_lig = self.dir_in+vs_dir+mol_dir
            file_list = os.listdir(dir2check)

            # Get additional descriptors to add to VS results
            lig_pdbqt2open = self.dir_in+vs_dir+mol_dir+mol+".pdbqt"
            receptor_pdbqt2open = self.dir_in+vs_dir+"receptor.pdbqt"
            pose_q = str(self.calc_pose_charge(lig_pdbqt2open))
            pose_avg_q = str(self.calc_pose_average_charge(lig_pdbqt2open))
            pose_bfactor_f = self.calc_average_bfactor(lig_pdbqt2open)
            pose_bfactor = str(pose_bfactor_f)
            receptor_bfactor_f = self.calc_average_bfactor(receptor_pdbqt2open)
            receptor_bfactor = str(receptor_bfactor_f)
            n_c, n_n, n_o, n_p, n_s, n_f, n_cl, n_br = \
            self.calc_pose_atoms(lig_pdbqt2open)

            # Determine bfactor_ratio
            if receptor_bfactor_f > 0.0:
                bfactor_ratio = str(pose_bfactor_f/receptor_bfactor_f)
            else:
                bfactor_ratio = "0.0"

            # Set up an empty list
            pose_list = []

            # Looping through file_list
            for f in file_list:
                if "pose_" in f:
                    pose_list.append(f)

            # Try to read poses to calculate energy
            for pose in pose_list:

                # Set up directories and file for energy calculation
                dir_rec = self.dir_in+vs_dir
                receptor_in = "receptor.pdbqt"
                dir_poses = dir2check

                # Show information
                print("\nLigand: ",mol)
                structure_receptor = dir_rec+receptor_in
                print("Receptor: ",structure_receptor)
                structure_pose = dir_poses+"/"+pose
                print("Pose: ",structure_pose)
                a_pose = pose.replace(".pdbqt","")
                log_file = dir_poses+"/"+"result_"+a_pose+".log"
                print("Log file: ",log_file)

                # Try to open pose
                try:
                    pose2open = dir_poses+"/"+pose
                    fo_pose = open(pose2open,"r")
                    pose_lines = fo_pose.readlines()

                    # Looping through pose_lines to RMSD(lb)
                    for line in pose_lines:

                        # Get RMSD(lb)
                        if "REMARK VINA RESULT:" in str(line):

                            # Some editing
                            aux_line_1 = str(line)
                            aux_line_2 = aux_line_1[33:41]
                            aux_line_2 = aux_line_2.replace(" ","")
                            aux_line_2 = aux_line_2.replace("'","")
                            aux_line_2 = aux_line_2.replace("[","")
                            aux_line_2 = aux_line_2.replace("]","")
                            aux_line_2 = aux_line_2.replace("\n","")
                            rmsd_lb = float(aux_line_2)
                            break

                    # Close file
                    fo_pose.close()

                # Handle IOError exception
                except IOError:
                    print("\nIOError! I can't find "+pose2open+" file!")
                    return

                # Try to remove old log files
                try:
                    os.remove(log_file)
                except:
                    pass

                ################################################################

                # Try to instantiate an object of Energy class
                try:

                    # Instantiate an object of Energy() class
                    e1 = vina123_vs.Energy(self.program_root,structure_receptor,
                            structure_pose,dir_poses+"/",log_file)

                    # Invoke bundle() method
                    e1.bundle()

                # Handle exception
                except:

                    # Show message
                    msg_out ="\nError during energy calculation for pose: "+pose
                    print(msg_out)

                ################################################################

                # Run AutoDock Vina for energy calculation
                #./vina --receptor receptor.pdbqt --ligand lig.pdbqt --score_only --log log.txt
                #os.system(self.program_root+\
                #    "misc/linux_third_party_software/vina/./"+docking_engine+\
                #    " --receptor "+\
                #    dir_rec+receptor_in+" --ligand "+\
                #    dir_poses+"/"+pose+" --score_only > "+\
                #    log_file)

                # Invoke read_pose_energy() method
                self.read_pose_energy(log_file)

                # Set up line_out_1
                line_out_1 = pdb+","+mol+","+ligand_code_out
                line_out_1 += ","+pose.replace(".pdbqt","")+","+resolution
                line_out_1 += ","+torsions
                line_out_1 += ","+self.energy+","+self.gauss1+","+self.gauss2
                line_out_1 += ","+self.repulsion+","+self.hydrophobic
                line_out_1 += ","+self.hydrogen+","+self.torsional+"\n"


                # Set up line_out_2
                line_out_2 = pdb+","+mol+","+ligand_code_out
                line_out_2 += ","+pose.replace(".pdbqt","")+","+resolution
                line_out_2 += ",1.0,ND,ND,ND,"+str(rmsd_lb)
                line_out_2 += ","+torsions+","+pose_q+","+pose_avg_q
                line_out_2 += ","+pose_bfactor+","+receptor_bfactor
                line_out_2 += ","+bfactor_ratio
                line_out_2 += ","+str(n_c)+","+str(n_n)+","+str(n_o)
                line_out_2 += ","+str(n_p)+","+str(n_s)+","+str(n_f)
                line_out_2 += ","+str(n_cl)+","+str(n_br)
                line_out_2 += ","+self.energy+","+self.gauss1+","+self.gauss2
                line_out_2 += ","+self.repulsion+","+self.hydrophobic
                line_out_2 += ","+self.hydrogen+","+self.torsional+"\n"

                # Write line_out_1
                fo_all_vs.write(line_out_1)

                # Write line_out_2
                fo_full_vs.write(line_out_2)

        # Close files
        fo_all_vs.close()
        fo_full_vs.close()