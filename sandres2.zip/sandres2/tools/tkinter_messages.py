# Class to show messages.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Import package
from tkinter import *

# define Messages() class
class Messages(object):
    """Class to show messages"""

    # Define constructor method
    def __init__(self,strdir_entry,root):
        """Constructor method"""

        # Set up attributes
        self.strdir_entry = strdir_entry
        self.root = root

    # Define show_short_msg() method
    def show_short_msg(self,msg2show):
        """Method to show short message"""

        print(msg2show)

    # Define show_botton_msg() method
    def show_botton_msg(self,input_2_show,color1,color2):
        """Method to show message on the botton bar"""

        # Check screen resolution
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Set up h_limit based on screen_width
        if screen_width >= 1900:
            h_limit = 102
        elif screen_width >= 1200:
            h_limit = 92
        else:
            h_limit = 82

        # Clear Label (it was 180) (80) (90)
        Label(self.root, text = h_limit*"|" ,fg = color1,bg=color2,
          font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)

        # The strip() method removes any leading (spaces at the beginning)
        # and trailing (spaces at the end) characters
        output_message1 = input_2_show.strip()

        # To handle different lengths (it was 50, 100)
        len_string = len(output_message1)
        if len_string < 40:
            number_spaces = 40 - len_string
            output_message2 = output_message1+number_spaces*"|"
        elif len_string < h_limit:
            output_message2 = output_message1+"|"
        else:
            output_message2 = output_message1[:h_limit]

        # Creates Label
        Label(self.root, text = output_message2 ,fg = color1,bg=color2,
            font = "Helvetica 10 bold italic" ).grid(row=9, column=0, sticky=W)

    # Define read_log_file() method
    def read_log_file(self,my_log_file):
        """Method to read log file"""

        # Import package
        from tkinter import messagebox

        # Call clear_txt()
        self.clear_txt()

        # Get new project directory
        project_dir_string = str(self.strdir_entry)

        # Try to open  input file
        try:
            my_info_log_file = open(project_dir_string+my_log_file,"r")
        except IOError:
            print("IOError! I can't find ",project_dir_string+my_log_file)
            print("Please update project directory as your needs!")
            messagebox.showerror("IOError!", "I can't find file "+
                project_dir_string+my_log_file+" \nPlease check directory name!")
            return

        # Close input file
        my_info_log_file.close()

    # Define clear_txt() method
    def clear_txt(self):
        """Nethod to clear txt content. Do nothing!"""

        # Do nothing
