Original bind_Ki.csv file (3762 ligands) from SAnDReS 2.0 and casf-2016.csv file with PDB
to be removed from bind_Ki.csv. 
