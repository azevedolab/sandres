# Define make()
def make(file_in,origin,target):
    """ Backup a specified file in a target directory"""

    # Import packages
    import os
    import time
    import shutil

    # Assign local time to local_time variable
    local_time = str(time.strftime("%Y_%m_%d_%Hh%Mmin%Ss"))

    # Check whether the specified path/file is an existing directory/file
    # or not
    origin = origin+file_in
    isfile = os.path.isfile(origin)
    print("\nCheck whether the specified path/file ",origin,
    "is an  existing directory/file or not: ",isfile)
    if isfile:
        print("\nI've found ",origin," directory/file!")
        i_root = file_in.index(".")
        root_file_in = file_in[:i_root]
        target = target+root_file_in+"_"+local_time+".csv"
        shutil.copyfile(origin,target)
        print("\n\nBacking up ",target,"!")