# Import packages
import os
import sys
import shutil
import time
import csv
import numpy as np
from tools import binding_affinity as b_aff
from MLRegMPy import scikit_regression_methods_v2_0_8 as pol1

# Define GATE() class
class GATE(object):
    """Class to read input data and carry out machine-learning regression"""

    # Define Constructor method
    def __init__(self,program_root,dir_in,input_file_in,out):
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.input_file_in = input_file_in
        self.out = out

    # Define generate() method
    def generate(self):
        """ Method to generate regression models"""

        # Invoke read_csv() method
        my_input_file_name, my_first_line, my_x_axis_label, num_var, x,y = \
        self.read_csv()

        # Show data
        print("X-axis label: ",my_x_axis_label)
        print("File name: ",my_input_file_name)

        # Invoke filter_data
        my_indep_variables,z = self.filter_data(x,y,num_var)

        # Instantiate an object of pol1 class
        m1 = pol1.Multvar_reg_modeling(self.program_root,self.dir_in,
        self.ml_parameters,num_var,y,z,'y',
        my_indep_variables,self.my_mlr_method_in)

        # Invoke summary method
        _,my_model_coefs,_,my_R2,_,my_R2_adj,my_sd,my_rho,my_rho_p,_,_,_,_ = \
        m1.summary()

    # Define read_csv() method
    def read_csv(self):
        """Method to read a CSV file"""

        # Assign number of independevt varables (features) to var
        var = self.n_features

        # Try to open scoring function file
        file2open = self.dir_in+self.scoring_function_file
        try:
            csv_in = open(file2open,"r")
            get_csv_lines = csv.reader(csv_in)
        except IOError:
            print("\nIOError!I can't find ",file2open," file!")
            return

        # Read CSV file first line only
        for line in get_csv_lines:
            x_axis_label = line[var]
            break

        # Close file
        csv_in.close()

        # Read CSV file and skips first line
        csv_data = np.genfromtxt (file2open, delimiter=",", skip_header = 1)

        # Get each column from CSV file
        y = csv_data[:,var]
        x = csv_data[:,0:var]

        # Return data
        return file2open,line,x_axis_label, var, x,y

    # Define filter_data() method
    def filter_data(self,x,y,var):
        """Method to filter data"""

        # Define numbers of rows and columns
        columns = var
        rows = len(y)

        # Set up a matrix
        z = np.array([[0]*columns]*rows,float)  # np.array([[0]*column]*row,float)

        # looping through x to get independent variable columns
        for i in range(rows):
            for j in range(columns):
                z[i,j] = x[i,j]

        # Looping through to create a list with independent variables
        my_indep_variables = []
        for i in range(columns):
            my_indep_variables.append("x"+str(i+1))

        # Retun my_indep_variables,z
        return my_indep_variables,z

    # Define write_features()
    def write_features(self):
        """Method to read features and write them in features.csv"""

        # Assign local time to local_time variable
        local_time = str(time.strftime("%Y_%m_%d_%Hh%Mmin%Ss"))

        # Read first line to get headers
        # Try to open scoring function file to get the headers
        file2open = self.dir_in+self.scoring_function_file
        try:
            csv_in_d = open(file2open,"r")
            get_csv_lines_d = csv.reader(csv_in_d)
        except IOError:
            print("\nIOError!I can't find ",file2open," file!")
            return

        # Read CSV file first line only
        for line in get_csv_lines_d:
            features = line
            break

        # Close file
        csv_in_d.close()

        # Check whether the specified path is an existing directory or not
        self.path4models = self.dir_in+"models/"
        isdir = os.path.isdir(self.path4models)
        if isdir:
            print("\nI've found ",self.path4models," directory!")
        else:
            # Create the directory self.dir_in+"models/"
            os.mkdir(self.path4models)
            print("\n",self.path4models," directory has been created!")

        # Check whether the specified path/file is an existing directory/file
        # or not
        self.path_and_file = self.path4models+"features.csv"
        #isfile = os.path.isfile(self.path_and_file)
        #print("\nCheck whether the specified path/file ",self.path_and_file,
        #"is an  existing directory/file or not: ",isfile)
        #if isfile:
        #    print("\nI've found ",self.path_and_file," directory/file!")
        #    origin = self.path_and_file
        #    target = self.path4models+"features_"+local_time+".csv"
        #    shutil.copyfile(origin,target)

        # Open features.csv
        fo1_d = open(self.path_and_file,"w")

        # Write first descriptor
        fo1_d.write(features[0])

        # Write the rest of features
        for line in features[1:self.n_features]:
            fo1_d.write(","+line)

        # Close file
        fo1_d.close()

    # Define select_features()
    def select_features(self):
        """Method to select features to be used in the regression modeling"""

        # Try to open scoring function file
        try:
            file2open = self.dir_in+self.out
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            print("IOError! I can't find "+file2open+" file!")
            sys.exit()

        # Set up empty lists
        features_index = []
        features_found = []
        features_out = []

        # Looping through csv_in (first line)
        for line in csv_in:
            i = 0
            sentinel_var = True

            # While loop
            while sentinel_var:
                try:
                    if line[i] in self.list_features_and_target:
                        print(line[i])
                        features_found.append(line[i])
                        features_index.append(i)
                    i += 1
                except:
                    sentinel_var = False
                    break
            break

        # Some indexing
        target_index = features_found.index(self.target_in)
        print(self.target_in,features_index[target_index])
        not_a_feature = features_index[target_index]
        target_col = features_index[target_index]

        # Exclude target (index)
        for col in features_index:
            if int(col) != int(not_a_feature):
                features_out.append(int(col))

        # Exclude target (label)
        lines_out = ""
        for line in features_found:
            if line != self.target_in:
                lines_out += line+","

        # Add target label
        lines_out += "Experimental\n"

        # Looping through csv_in (remaining lines)
        for line1 in csv_in:
            for col in features_out:
                lines_out += str(line1[col])+","
            lines_out += str(line1[target_col])+"\n"

        # Close file
        fo.close()

        # Open new file
        scores_ml = self.dir_in+self.scoring_function_file
        fo = open(scores_ml,"w")

        # Write data
        fo.write(lines_out)

        # Close file
        fo.close()

    # Define read_input()
    def read_input(self,reg_method):
        """Read input data"""

        # Set up a regression method
        self.my_mlr_method_in = reg_method

        # Define function to handle hash in a field (float or integer or string)
        def handle_hash(type_in,line_in):
            """Function to handle hash in a field and returns a float,
            an integer, or a string"""

            # Test type_in
            if type_in == "float":
                # Handle hash for float output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = float(line_in[:index_hash])
                except:
                    data_out = float(line_in)
            elif type_in == "int":
                # Handle hash for integer output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = int(line_in[:index_hash])
                except:
                    data_out = int(line_in)
            elif type_in == "str":
                # Handle hash for string output
                try:
                    index_hash = str(line_in).index("#")
                    data_out = line_in[:index_hash]
                    data_out = data_out.replace(" ","")
                except:
                    data_out = line_in.replace(" ","")
            else:
                # Print error message and return
                print("\nError! Not defined type of number!")
                return None

            # Return data
            return data_out

        # Try to open input file
        try:
            file2open = self.program_root+"misc/data/"+self.input_file_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            print("IOError! I can't find "+file2open+" file!")
            return

        # Set up empty list
        self.list_features_and_target = []

        # Looping through input file
        for line in csv_in:
            if line[0] == "#":
                continue
            #elif line[0] == "out":
            #    self.out = handle_hash("str",str(line[1]))
            elif line[0] == "ml_parameters":
                self.ml_parameters = handle_hash("str",str(line[1]))
            elif line[0] == "scoring_function_file":
                self.scoring_function_file = handle_hash("str",str(line[1]))
            elif line[0] == "n_features":
                self.n_features =  handle_hash("int",line[1])
            elif line[0] == "features_in":
                for i in range(self.n_features):     # WFA 2021-11-05 self.n_features+1
                    aux_str = line[i+1]
                    self.list_features_and_target.append(aux_str)
            #elif line[0] == "target_in":
            #    self.target_in = line[1]

        # Get target_in
        # Invoke read_it function
        self.target_in = "log("+b_aff.read_it(self.dir_in)+")"

        # Add target to list_features
        self.list_features_and_target.append(self.target_in)

        # Check whether all parameters have been read
        print("\nParameters read from input file:")
        try:
            print("Parameters for regression read from: ",self.ml_parameters)
            #print("Scoring function file: ",self.out)
            print("Output scoring function file: ",self.scoring_function_file)
            print("Project directory: ",self.dir_in)
            print("Regression method: ",self.my_mlr_method_in)
            print("Number of features: ",self.n_features)
            #print("Features: ",self.list_features_and_target)
        except:
            sys.exit("\nError! Missing input parameters. Please check "+self.input_file_in+" file!")

        # Close file
        fo.close()
