#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define ElasticNet() class
class ElasticNet(object):
    """Class to carry out ElasticNet regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : {array-like}, shape (n_samples, n_features). Training data.
        y                       : array-like, shape (n_samples,) or (n_samples, n_targets)
                                Target values

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : Independent term in decision function. Set to 0.0 if fit_intercept = False.
       model.coef_              : Coefficients of the regression model (mean of distribution)
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_ElasticNet() method
    def ml_scikit_ElasticNet(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ElasticNet
        """

        # Import packages
        from sklearn.linear_model import ElasticNetCV
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.ElasticNetCV.html
        #
        # string_reg_method = ElasticNetCV
        #
        #
        # l1_ratio: float or array of floats, optional
        # float between 0 and 1 passed to ElasticNet (scaling between l1 and l2
        # penalties).
        # For l1_ratio = 0 the penalty is an L2 penalty. For l1_ratio = 1 it is
        # an L1 penalty.
        # For 0 < l1_ratio < 1, the penalty is a combination of L1 and L2.....
        #
        # fit_intercept: boolean
        # whether to calculate the intercept for this model.
        # If set to false, no intercept will be used in calculations (i.e. data
        # is expected to be centered).
        #
        # normalize: boolean, optional, default False
        # This parameter is ignored when fit_intercept is set to False.
        # If True, the regressors X will be normalized before regression by
        # subtracting the mean and dividing by the l2-norm.
        #
        # precompute: True | False | ‘auto’ | array-like
        # Whether to use a precomputed Gram matrix to speed up calculations. If
        # set to 'auto' let us decide.
        # The Gram matrix can also be passed as argument.
        #
        # max_iter: int, optional
        # The maximum number of iterations
        #
        # tol: float, optional
        # The tolerance for the optimization: if the updates are smaller than
        # tol, the optimization code checks the dual gap for optimality and
        # continues until it is smaller than tol.
        #
        # cv: int, cross-validation generator or an iterable, optional
        # Determines the cross-validation splitting strategy. Possible inputs
        # for cv are:
        # None, to use the default 5-fold cross-validation,
        # integer, to specify the number of folds.
        # CV splitter,
        # An iterable yielding (train, test) splits as arrays of indices.
        # For integer/None inputs, KFold is used.
        #
        # copy_X: boolean, optional, default True
        # If True, X will be copied; else, it may be overwritten.
        #
        # n_jobs: int or None, optional (default=None)
        # Number of CPUs to use during the cross validation. None means 1
        # unless in a joblib.parallel_backend context.
        # -1 means using all processors.
        #
        # positive: bool, optional
        # When set to True, forces the coefficients to be positive.
        #
        # random_state:int, RandomState instance or None, optional, default=None
        # The seed of the pseudo random number generator that selects a random
        # feature to update.
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random. Used when selection == ‘random’.
        #
        # selection: str, default ‘cyclic’
        # If set to ‘random’, a random coefficient is updated every iteration
        # rather than looping over features sequentially
        # by default.
        # This (setting to ‘random’) often leads to significantly faster
        # convergence especially when tol is higher than 1e-4.

        # Show message
        print("\nElastic Net Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "ElasticNet":

                # For l1_ratio_min
                l1_ratio_min = float(line[1])

                # For l1_ratio_max
                l1_ratio_max = float(line[2])

                # For num_samples
                num_samples = int(line[3])

                # For fit_in
                if line[4] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For norm_in
                if line[5] == "True":
                    norm_in = True
                else:
                    norm_in = False

                # For pre_in
                if line[6] == "True":
                    pre_in = True
                else:
                    pre_in = False

                # For max_in
                max_in = int(line[7])

                # For tol_in
                tol_in = float(line[8])

                # For cv_in
                cv_in = int(line[9])

                # For copy_in
                if line[10] == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For njobs_in
                njobs_in = int(line[11])

                # For pos_in
                if line[12] == "True":
                    pos_in = True
                else:
                    pos_in = False

                # For self.rand_in
                if line[13] == "None":
                    self.rand_in = None
                else:
                    self.rand_in = int(line[13])

                # For sel_in
                sel_in = str(line[14])

                # Finish loop
                break

        # Close file
        fo.close()

        # Set up l1_ratio_array
        # Based on https://docs.scipy.org/doc/numpy-1.15.1/reference/generated/numpy.logspace.html
        l1_ratio_array = np.logspace(l1_ratio_min, l1_ratio_max, num_samples)

        # Show summary
        print("Regression method: ",line[0])
        l_out = "Array of l1 ratios to try "
        print(l_out+"(minimum l1 ratio): {:.5e}".format(np.min(l1_ratio_array)))
        print(l_out+"(maximum l1 ratio): {:.5e}".format(np.max(l1_ratio_array)))
        print(l_out+"(number of samples): {}".format(num_samples))
        print("Fit intercept? "+line[4])
        print("Normalize? "+line[5])
        print("Pre compute? "+line[6])
        print("Maximum number of iterations = {}".format(max_in))
        print("Copy x array? "+line[10])
        print("Tolerance for the optimization = {:.5e}".format(tol_in))
        print("Force the coefficients to be positive? "+line[12])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[9])
        print("Method for coefficient: ",sel_in)
        print("Random seed = "+str(self.rand_in))

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of ElastivNetCV() class
        model = ElasticNetCV(
                l1_ratio = l1_ratio_array,  # l1_ratio: float or array of floats, optional
                fit_intercept = fit_in,     # fit_intercept: boolean
                normalize = norm_in,        # normalize: boolean, optional, default False
                precompute = pre_in,        # precompute: True | False | ‘auto’ | array-like
                max_iter = max_in,          # max_iter: int, optional
                tol = tol_in,               # tol: float, optional
                cv = cv_in,                 # cv: int, cross-validation generator or an iterable, optional
                copy_X = copy_in,           # copy_X: boolean, optional, default True
                n_jobs = njobs_in,          # n_jobs: int or None, optional (default=None). -1 means using all
                positive = pos_in,          # positive: bool, optional
                random_state = self.rand_in,# random_state: int, RandomState instance or None, optional,
                selection = sel_in          # selection: str, default ‘cyclic’
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_