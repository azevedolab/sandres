#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define BaggingRegressorCV() class
class BaggingRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_BaggingRegressorCV() method
    def ml_scikit_BaggingRegressorCV(self):
        """
        Method to generate a multiple regression model using
        BaggingRegressorCV
        """

        # Import packages
        from sklearn.ensemble import BaggingRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.BaggingRegressorCV.html
        #
        # string_reg_method = BaggingRegressor
        #
        #
        # base_estimator: object, default=None
        # The base estimator to fit on random subsets of the dataset. If None,
        # then the base estimator is a DecisionTreeRegressor.
        # It could be base_estimator=SVR().
        #
        # n_estimators: int, default=10
        # The number of base estimators in the ensemble.
        #
        # max_samples: int or float, default=1.0
        # The number of samples to draw from X to train each base estimator
        # (with replacement by default, see bootstrap for more details).
        # If int, then draw max_samples samples.
        # If float, then draw max_samples * X.shape[0] samples.
        #
        # max_features: int or float, default=1.0
        # The number of features to draw from X to train each base estimator
        # (without replacement by default, see bootstrap_features for more
        # details).
        # If int, then draw max_features features.
        # If float, then draw max_features * X.shape[1] features.
        #
        # bootstrap: bool, default=True
        # Whether samples are drawn with replacement. If False, sampling
        # without replacement is performed.
        #
        # bootstrap_features: bool, default=False
        # Whether features are drawn with replacement.
        #
        # oob_score: bool, default=False
        # Whether to use out-of-bag samples to estimate the generalization
        # score.
        # Only available if bootstrap=True.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit and
        # add more estimators to the ensemble, otherwise, just fit a whole new
        # ensemble.
        #
        # n_jobs: int, default=None
        # The number of jobs to run in parallel for both fit and predict. None
        # means 1 unless in a joblib.parallel_backend context. -1 means using
        # all processors.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls the random resampling of the original dataset (sample wise
        # and feature wise). If the base estimator accepts a random_state
        # attribute, a different seed is generated for each instance in the
        # ensemble. Pass an int for reproducible output across multiple
        # function calls.
        #
        # verbose: int, default=0
        # Controls the verbosity when fitting and predicting.

        # Show message
        print("\nBagging Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "BaggingRegressorCV":

                # For base_estimator_in
                list_base_estimator = ["SVR()",
                            "DummyRegressor()",
                            "CustomSVR(gamma='scale')",
                            "KNeighborsRegressor()",
                            "Ridge()"]
                if line[1] == "None":
                    base_estimator_in = None
                elif line[1] in list_base_estimator:
                    base_estimator_in = line[1]
                else:
                    print("\nIOError! Undefined string ",line[1])
                    print("You may include it in ML_BaggingRegressorCV.py")
                    return

                # For n_estimators_in
                n_estimators_in = int(line[2])

                # For max_samples_in
                if line[3] == "None":
                    max_samples_in = None
                elif "." in str(line[3]):
                    max_samples_in = float(line[3])
                else:
                    max_samples_in = int(line[3])

                # For max_features_in
                if "." in str(line[4]):
                    max_features_in = float(line[4])
                else:
                    max_features_in = int(line[4])

                # For bootstrap_in
                if line[5] == "True":
                    bootstrap_in = True
                else:
                    bootstrap_in = False

                # For bootstrap_features_in
                if line[6] == "True":
                    bootstrap_features_in = True
                else:
                    bootstrap_features_in = False

                # For oob_score_in
                if line[7] == "True":
                    oob_score_in = True
                else:
                    oob_score_in = False

                # For warm_start_in
                if line[8] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For n_jobs_in
                if line[9] == "None":
                    n_jobs_in = None
                else:
                    n_jobs_in = int(line[9])

                # For random_state_in
                if line[10] == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[10])

                # For verbose_in
                verbose_in = int(line[11])

                # For cv_in (set value to 5)
                cv_in = int(line[12])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("The base estimator to fit on random subsets of the dataset: ",
        line[1])
        print("Number of base estimators in the ensemble: ",line[2])
        print("Number of samples to draw from X to train each base estimator: ",
        line[3])
        print("Number of features to draw from X to train each base estimator: ",
        line[4])
        print("Whether samples are drawn with replacement: ", line[5])
        print("Whether features are drawn with replacement: ", line[6])
        line_out7 = "Whether to use out-of-bag samples to estimate the "
        line_out7 += "generalization error: "
        print(line_out7,line[7])
        line_out8 = "When set to True, reuse the solution of the previous call "
        line_out8 += "to fit and add more estimators to the ensemble: "
        print(line_out8,line[8])
        print("Number of jobs to run in parallel for both fit and predict: ",
        line[9])
        print("Controls the random resampling of the original dataset: ",
        line[10])
        print("Verbosity level: ",line[11])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of BaggingRegressor class
        ############################################################################
        model = BaggingRegressor(
            base_estimator=base_estimator_in,   # base_estimator: object, default=None
            n_estimators=n_estimators_in,   # n_estimators: int, default=10
            max_samples=max_samples_in,     # max_samples: int or float, default=1.0
            max_features=max_features_in,   # max_features: int or float, default=1.0
            bootstrap=bootstrap_in,         # bootstrap: bool, default=True
            bootstrap_features=bootstrap_features_in,   # bootstrap_features: bool, default=False
            oob_score=oob_score_in,         # oob_score: bool, default=False
            warm_start=warm_start_in,       # warm_start: bool, default=False
            n_jobs=n_jobs_in,               # n_jobs: int, default=None
            random_state=random_state_in,   # random_state: int, RandomState instance or None, default=None
            verbose=verbose_in              # verbose: int, default=0
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model