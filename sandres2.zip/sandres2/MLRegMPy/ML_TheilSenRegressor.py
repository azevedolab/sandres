#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define TheilSenRegressor() class
class TheilSenRegressor(object):
    """Class to carry out regression with TheilSenRegressor

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : numpy array of shape [n_samples, n_features]. Training data
        y                       : numpy array of shape [n_samples]
                                Target values

    Outputs
       rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float. Estimated intercept of regression model.
       model.coef_              : array, shape = (n_features). Coefficients of the regression model (median of distribution).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_TheilSenRegressor() method
    def ml_scikit_TheilSenRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TheilSenRegressor
        """

        # Import packages
        from sklearn.linear_model import TheilSenRegressor
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.TheilSenRegressor.html
        #
        # string_reg_method = TheilSenRegressor
        #
        #
        # fit_intercept: boolean, optional, default True
        # Whether to calculate the intercept for this model. If set to false, no
        # intercept will be used in calculations.
        #
        # copy_X: boolean, optional, default True
        # If True, X will be copied; else, it may be overwritten.
        #
        # max_subpopulation: int, optional, default 1e4
        # Instead of computing with a set of cardinality ‘n choose k’,
        # where n is the number of samples and k is the number of subsamples
        # (at least number of features), consider only a stochastic
        # subpopulation of a given maximal size if ‘n choose k’ is larger than
        # max_subpopulation.
        # For other than small problem sizes this parameter will determine
        # memory usage and runtime if n_subsamples is not changed.
        #
        # n_subsamples: int, optional, default None
        # Number of samples to calculate the parameters. This is at least the
        # number of features (plus 1 if fit_intercept=True)
        # and the number of samples as a maximum. A lower number leads to a
        # higher breakdown point and a low efficiency
        # while a high number leads to a low breakdown point and a high
        # efficiency.
        # If None, take the minimum number of subsamples leading to maximal
        # robustness.
        # If n_subsamples is set to n_samples, Theil-Sen is identical to least
        # squares.
        #
        # max_iter: int, optional, default 300
        # Maximum number of iterations for the calculation of spatial median.
        #
        # tol: float, optional, default 1.e-3
        # Tolerance when calculating spatial median.
        #
        # random_state:int, RandomState instance or None, optional, default None
        # A random number generator instance to define the state of the random
        # permutations generator.
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random.
        #
        # n_jobs: int or None, optional (default=None)
        # Number of CPUs to use during the cross validation.
        # None means 1 unless in a joblib.parallel_backend context. -1 means
        # using all processors.
        #
        # verbose: boolean, optional, default False
        # Verbose mode when fitting the model.

        # Show message
        print("\nTheil Sen Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "TheilSenRegressor":

                # For fit_in
                if line[1].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For copy_in
                if line[2].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For max_subpopulation_in
                max_subpopulation_in = int(line[3].strip())

                # For n_subsamples_in
                try:
                    n_subsamples_in = int(line[4].strip())
                except:
                    n_subsamples_in = None

                # For max_in
                max_in = int(line[5].strip())

                # For tol_in
                tol_in = float(line[6].strip())

                # For rand_in
                try:
                    rand_in = int(line[7].strip())
                except:
                    rand_in = None

                # For n_jobs_in
                try:
                    n_jobs_in = int(line[8].strip())
                except:
                    n_jobs_in = None

                # For verbose_in
                if line[9].strip() == "True":
                    verbose_in = True
                else:
                    verbose_in = False

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Fit intercept? "+line[1])
        print("Copy x array? "+line[2])
        print("Maximal size of subpopulation: {}".format(max_subpopulation_in))
        print("Number of samples to calculate the parameters: ",line[4])
        print("Maximum number of iterations: {}".format(max_in))
        print("Tolerance: {:.5e}".format(tol_in))
        print("A random number generator instance: ",rand_in)
        print("Number of CPUs to use during the cross validation: ",line[8])
        print("Verbose mode when fitting the model: ",line[9])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of TheilSenRegressor class
        model = TheilSenRegressor(
                fit_intercept=fit_in,                   # fit_intercept: boolean, optional, default True
                copy_X=copy_in,                         # copy_X: boolean, optional, default True
                max_subpopulation=max_subpopulation_in, # max_subpopulation: int, optional, default 1e4
                n_subsamples=n_subsamples_in,           # n_subsamples: int, optional, default None
                max_iter=max_in,                        # max_iter: int, optional, default 300
                tol=tol_in,                             # tol: float, optional, default 1.e-3
                random_state=rand_in,                   # random_state: int, RandomState instance or None
                n_jobs=n_jobs_in,                       # n_jobs: int or None, optional (default=None)
                verbose=verbose_in                      # verbose: boolean, optional, default False
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Check whether rand_in == None for MDM
        if str(rand_in) == "None":
            rand_in = 1123581321

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_