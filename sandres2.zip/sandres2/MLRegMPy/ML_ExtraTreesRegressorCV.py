#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Define ExtraTreesRegressorCV() class
class ExtraTreesRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_ExtraTreesRegressorCV() method
    def ml_scikit_ExtraTreesRegressorCV(self):
        """
        Method to generate a multiple regression model using
        ExtraTreesRegressorCV
        """

        # Import packages
        from sklearn.ensemble import ExtraTreesRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.ExtraTreesRegressor.html
        #
        # string_reg_method = ExtraTreesRegressor
        #
        #
        # n_estimators: int, default=100
        # The number of trees in the forest.
        # Changed in version 0.22: The default value of n_estimators changed
        # from 10 to 100 in 0.22.
        #
        # criterion: {“mse”, “mae”}, default=”mse”
        # The function to measure the quality of a split. Supported criteria are
        # “mse” for the mean squared error, which is equal to variance reduction
        # as feature selection
        # criterion, and “mae” for the mean absolute error.
        # New in version 0.18: Mean Absolute Error (MAE) criterion.
        #
        # max_depth: int, default=None
        # The maximum depth of the tree. If None, then nodes are expanded until
        # all leaves are pure
        # or until all leaves contain less than min_samples_split samples.
        #
        # min_samples_split: int or float, default=2
        # The minimum number of samples required to split an internal node:
        # If int, then consider min_samples_split as the minimum number.
        # If float, then min_samples_split is a fraction and
        # ceil(min_samples_split * n_samples)
        # are the minimum number of samples for each split.
        # Changed in version 0.18: Added float values for fractions.
        #
        # min_samples_leaf: int or float, default=1
        # The minimum number of samples required to be at a leaf node. A split
        # point at any depth will only be considered if it leaves at least
        # min_samples_leaf training samples
        # in each of the left and right branches. This may have the effect of
        # smoothing the model, especially in regression.
        # If int, then consider min_samples_leaf as the minimum number.
        # If float, then min_samples_leaf is a fraction and
        # ceil(min_samples_leaf * n_samples)
        # are the minimum number of samples for each node.
        # Changed in version 0.18: Added float values for fractions.
        #
        # min_weight_fraction_leaf: float, default=0.0
        # The minimum weighted fraction of the sum total of weights
        # (of all the input samples)
        # required to be at a leaf node. Samples have equal weight when
        # sample_weight is not provided.
        #
        # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
        # The number of features to consider when looking for the best split:
        # If int, then consider max_features features at each split.
        # If float, then max_features is a fraction and
        # round(max_features*n_features)
        # features are considered at each split.
        # If “auto”, then max_features=n_features.
        # If “sqrt”, then max_features=sqrt(n_features).
        # If “log2”, then max_features=log2(n_features).
        # If None, then max_features=n_features.
        # Note: the search for a split does not stop until at least one valid
        # partition of the node samples is found, even if it requires to
        # effectively inspect more than max_features features.
        #
        # max_leaf_nodes: int, default=None
        # Grow trees with max_leaf_nodes in best-first fashion. Best nodes are
        # defined as relative reduction in impurity. If None then unlimited
        # number of leaf nodes.
        #
        # min_impurity_decrease: float, default=0.0
        # A node will be split if this split induces a decrease of the impurity
        # greater than or equal to this value.
        # The weighted impurity decrease equation is the following:
        # N_t / N * (impurity - N_t_R / N_t * right_impurity
        #            - N_t_L / N_t * left_impurity)
        # where N is the total number of samples, N_t is the number of samples at
        # the current node, N_t_L is the number of samples in the left child,
        # and N_t_R is the number of samples in the right child.
        # N, N_t, N_t_R and N_t_L all refer to the weighted sum, if sample_weight
        # is passed.
        #
        # bootstrap: bool, default=True
        # Whether bootstrap samples are used when building trees.
        # If False, the whole dataset is used to build each tree.
        #
        # oob_score: bool, default=False
        # Whether to use out-of-bag samples to estimate the generalization score.
        # Only available if bootstrap=True.
        #
        # n_jobs: int, default=None
        # The number of jobs to run in parallel. fit, predict, decision_path and
        # apply are all parallelized over the trees. None means 1 unless in a
        # joblib.parallel_backend context. -1 means using all processors.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls 3 sources of randomness:
        # the bootstrapping of the samples used when building trees
        # (if bootstrap=True)
        # the sampling of the features to consider when looking for the best
        # split at each node (if max_features < n_features)
        # the draw of the splits for each of the max_features
        #
        # verbose: int, default=0
        # Controls the verbosity when fitting and predicting.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit and
        # add more estimators to the ensemble, otherwise, just fit a whole new
        # forest. See the Glossary.
        #
        # ccp_alpha: non-negative float, default=0.0
        # Complexity parameter used for Minimal Cost-Complexity Pruning.
        # The subtree with the largest cost complexity that is smaller than
        # ccp_alpha will be chosen.
        # By default, no pruning is performed. See Minimal Cost-Complexity
        # Pruning for details.
        #
        # max_samples: int or float, default=None
        # If bootstrap is True, the number of samples to draw from X to train
        # each base estimator.
        # If None (default), then draw X.shape[0] samples.
        # If int, then draw max_samples samples.
        # If float, then draw max_samples * X.shape[0] samples.
        # Thus, max_samples should be in the interval (0, 1).

        # Show message
        print("\nExtra-Trees Regressor with Cross-Validation")
        print("Regression parameters read from ml.csv")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "ExtraTreesRegressorCV":

                # For n_estimators_in
                n_estimators_in = int(line[1].strip())

                # For criterion_in
                list_criteria = ["squared_error","absolute_error"]
                if line[2].strip() in list_criteria:
                    criterion_in = line[2].strip()
                else:
                    criterion_in = "squared_error"
                    print("Unrecognizable input!")

                # For max_depth_in
                try:
                    max_depth_in = int(line[3].strip())
                except:
                    max_depth_in = None

                # For min_samples_split_in
                if "." in str(line[4].strip()):
                    min_samples_split_in = float(line[4].strip())
                else:
                    min_samples_split_in = int(line[4].strip())

                # For min_samples_leaf_in
                if "." in str(line[5].strip()):
                    min_samples_leaf_in = float(line[5].strip())
                else:
                    min_samples_leaf_in = int(line[5].strip())

                # For min_weight_fraction_leaf_in
                min_weight_fraction_leaf_in = float(line[6].strip())

                # For max_features_in
                list_max_features = ["auto","sqrt","log2"]
                if line[7].strip() in list_max_features:
                    max_features_in = line[7].strip()
                elif line[7].strip() == "None":
                    max_features_in = None
                elif "." in str(line[7].strip()):
                    max_features_in = float(line[7].strip())
                else:
                    max_features_in = int(line[7].strip())

                # For max_leaf_nodes_in
                if line[8].strip() == "None":
                    max_leaf_nodes_in = None
                else:
                    max_leaf_nodes_in = int(line[8].strip())

                # For min_impurity_decrease_in
                min_impurity_decrease_in = float(line[9].strip())

                # For bootstrap_in
                if line[10].strip() == "True":
                    bootstrap_in = True
                else:
                    bootstrap_in = False

                # For oob_score_in
                if line[11].strip() == "True":
                    oob_score_in = True
                else:
                    oob_score_in = False

                # For n_jobs_in
                if line[12].strip() == "None":
                    n_jobs_in = None
                else:
                    n_jobs_in = int(line[12].strip())

                # For random_state_in
                if line[13].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[13].strip())

                # For verbose_in
                verbose_in = int(line[14].strip())

                # For warm_start_in
                if line[15].strip() == "True":
                    warm_start_in = True
                elif line[15].strip() == "False":
                    warm_start_in = False
                else:
                    warm_start_in = False
                    print("Unrecognizable input!")

                # For ccp_alpha_in
                ccp_alpha_in = float(line[16].strip())

                # For max_samples_in
                if line[17].strip() == "None":
                    max_samples_in = None
                elif "." in str(line[17].strip()):
                    max_samples_in = float(line[17].strip())
                else:
                    max_samples_in = int(line[17].strip())

                # For cv_in (set value to 5)
                cv_in = int(line[18].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.csv
        print("Regression method: ",line[0])
        print("Number of trees in the forest: {}".format(n_estimators_in))
        print("Function to measure the quality of a split: ",line[2])
        print("Maximum depth of the tree: ",line[3])
        line_out4 = "Minimum number of samples required to split an "
        line_out4 += "internal node: "
        print(line_out4,line[4])
        print("Minimum number of samples required to be at a leaf node: ",
        line[5])
        print("Minimum weighted fraction of the sum total of weights: ",line[6])
        print("Number of features to consider when looking for the best split:",
        line[7])
        print("Grow trees with max_leaf_nodes in best-first fashion: ",line[8])
        print("Minimum impurity decrease: ",line[9])
        print("Whether bootstrap samples are used when building trees: ",
        line[10])
        line_out11 = "Whether to use out-of-bag samples to estimate the "
        line_out11 += "generalization score: "
        print(line_out11,line[11])
        print("Number of jobs to run in parallel: ",line[12])
        line_out13 = "Controls both the randomness of the bootstrapping of "
        line_out13 += "the samples: "
        print(line_out13,line[13])
        print("Controls the verbosity when fitting and predicting: ",line[14])
        print("When set to True, reuse the solution of the previous call: ",
        line[15])
        print("Complexity parameter used for Minimal Cost-Complexity Pruning: ",
        line[16])
        line_out17 = "If bootstrap is True, the number of samples to draw from "
        line_out17 += "X to train each base estimator: "
        print(line_out17,line[17])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[18])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of ExtraTreesRegressor class
        ############################################################################
        model = ExtraTreesRegressor(
            n_estimators=n_estimators_in,   # n_estimators: int, default=100
            criterion=criterion_in,         # criterion: {“mse”, “mae”}, default=”mse”
            max_depth=max_depth_in,         # max_depth: int, default=None
            min_samples_split=min_samples_split_in,    # min_samples_split: int or float, default=2
            min_samples_leaf=min_samples_leaf_in,      # min_samples_leaf: int or float, default=1
            min_weight_fraction_leaf=min_weight_fraction_leaf_in,   # min_weight_fraction_leaf: float, default=0.0
            max_features=max_features_in,   # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
            max_leaf_nodes=max_leaf_nodes_in,          # max_leaf_nodes: int, default=None
            min_impurity_decrease=min_impurity_decrease_in,
            bootstrap=bootstrap_in,         # bootstrap: bool, default=True
            oob_score=oob_score_in,         # oob_score: bool, default=False
            n_jobs=n_jobs_in,               # n_jobs: int, default=None
            random_state=random_state_in,   # random_state: int, RandomState instance or None, default=None
            verbose=verbose_in,             # verbose: int, default=0
            warm_start=warm_start_in,       # warm_start: bool, default=False
            ccp_alpha=ccp_alpha_in,         # ccp_alpha: non-negative float, default=0.0
            max_samples=max_samples_in      # max_samples: int or float, default=None
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model