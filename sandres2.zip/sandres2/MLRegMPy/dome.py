#!/usr/bin/env python3
#
# Function to carry out statistical analysis of the predictive performance of
# features.
# It uses metrics indicated by Walsh et al. 2021.
#
# Reference:
#
# Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
# Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
# recommendations for supervised machine learning validation in biology. Nat
# Methods. 2021 Oct;18(10):1122-1127.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# Import section
import numpy as np

# Define metrics() function
def metrics(rmse_array,mae_array,r2_array,rho_array):
    """Function to calculate DOME statistical analysis"""

    # Define cal_Euclidean_dist function
    def cal_Euclidean_dist(p1,p2):
        """Function to calculate Euclidean distance for two points in in an
        N-dimensional space"""

        # Calculate Euclidean distance using linalg.norm()
        dist = np.linalg.norm(p1 - p2)

        # Return Euclidean distance
        return dist

    # Calculate Euclidean distances
    # For dist_DOME_array, we have this space composed of
    # RMSE (root mean squared error), MAE (mean absolute error),
    # and R2 (coefficient of determination). Our goal is to evaluate the
    # distance of a machine-learning model from an ideal model with the
    # following coordinates:  RMSE = 0.0, MAE = 0.0, and R2 =1.0.
    p1 = np.array([rmse_array,mae_array,r2_array])
    p2 = np.array([0.0,0.0,1.0])
    dist_DOME_array = cal_Euclidean_dist(p1,p2)

    # For dist_EDOMEr2_array, we have this space composed of
    # r2 (square Pearson correlation),
    # RMSE (root mean squared error), MAE (mean absolute error),
    # and R2 (coefficient of determination). Our goal is to evaluate the
    # distance of a machine-learning model from an ideal model with the
    # following coordinates:  r2 = 1.0, RMSE = 0.0,
    # MAE = 0.0, and R2 =1.0.
    p1 = np.array([r2_array,rmse_array,mae_array,r2_array])
    p2 = np.array([1.0,0.0,0.0,1.0])
    dist_EDOMEr2_array = cal_Euclidean_dist(p1,p2)

    # For dist_EDOMErho_array, we have this space composed of
    # rho (Spearman rank correlation),
    # RMSE (root mean squared error), MAE (mean absolute error),
    # and R2 (coefficient of determination). Our goal is to evaluate the
    # distance of a machine-learning model from an ideal model with the
    # following coordinates:  rho = 1.0, RMSE = 0.0,
    # MAE = 0.0, and R2 =1.0.
    p1 = np.array([rho_array,rmse_array,mae_array,r2_array])
    p2 = np.array([1.0,0.0,0.0,1.0])
    dist_EDOMErho_array = cal_Euclidean_dist(p1,p2)

    # For dist_EDOME_array, we have this space composed of
    # r2 (square Pearson correlation), rho (Spearman rank correlation),
    # RMSE (root mean squared error), MAE (mean absolute error),
    # and R2 (coefficient of determination). Our goal is to evaluate the
    # distance of a machine-learning model from an ideal model with the
    # following coordinates:  r2 = 1.0, rho = 1.0, RMSE = 0.0,
    # MAE = 0.0, and R2 =1.0.
    p1 = np.array([r2_array,rho_array,rmse_array,mae_array,r2_array])
    p2 = np.array([1.0,1.0,0.0,0.0,1.0])
    dist_EDOME_array = cal_Euclidean_dist(p1,p2)

    # Show message
    msg_o = "\n\n\n\n\nStatistical analysis"
    msg_o += "\n\nMetrics based on: "
    msg_o += "Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; "
    msg_o += "ELIXIR Machine Learning Focus Group; Harrow J, Psomopoulos "
    msg_o += "FE, Tosatto SCE. DOME: recommendations for supervised "
    msg_o += "machine learning validation in biology. Nat Methods. 2021 "
    msg_o += "Oct;18(10):1122-1127. \n"
    print(msg_o)

    # Return results
    return dist_DOME_array,dist_EDOMEr2_array,dist_EDOMErho_array,dist_EDOME_array

