#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define KernelRidge() class
class KernelRidge(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_KernelRidge() method
    def ml_scikit_KernelRidge(self):
        """
        Method to generate a multiple regression model using
        KernelRidge
        """

        # Import packages
        from sklearn.kernel_ridge import KernelRidge
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.kernel_ridge.KernelRidge.html
        #
        # Additional material related to scikit-learn
        # https://www.educative.io/blog/scikit-learn-cheat-sheet-classification-regression-methods
        #
        # string_reg_method = KernelRidge
        #
        #
        # alpha: float or array-like of shape (n_targets,), default=1.0
        # Regularization strength; must be a positive float. Regularization
        # improves the conditioning of the problem and reduces the variance of
        # the estimates. Larger values specify stronger regularization. Alpha
        # corresponds to 1 / (2C) in other linear models such as
        # LogisticRegression or LinearSVC. If an array is passed, penalties are
        # assumed to be specific to the targets. Hence they must correspond in
        # number. See Ridge regression and classification for formula.
        #
        # kernel: string or callable, default=”linear”
        # Kernel mapping used internally. This parameter is directly passed to
        # pairwise_kernel. If kernel is a string, it must be one of the metrics
        # in pairwise.PAIRWISE_KERNEL_FUNCTIONS. If kernel is “precomputed”,
        # X is assumed to be a kernel matrix. Alternatively, if kernel is a
        # callable function, it is called on each pair of instances (rows) and
        # the resulting value recorded. The callable should take two rows from
        # X as input and return the corresponding kernel value as a single
        # number. This means that callables from sklearn.metrics.pairwise are
        # not allowed, as they operate on matrices, not single samples. Use the
        # string identifying the kernel instead.
        #
        # gamma: float, default=None
        # Gamma parameter for the RBF, laplacian, polynomial, exponential
        # chi2 and sigmoid kernels. Interpretation of the default value is
        # left to the kernel; see the documentation for
        # sklearn.metrics.pairwise. Ignored by other kernels.
        #
        # degree: float, default=3.0
        # Degree of the polynomial kernel. Ignored by other kernels.
        #
        # coef0: float, default=1.0
        # Zero coefficient for polynomial and sigmoid kernels. Ignored by other kernels.
        #
        # kernel_params: mapping of string to any, default=None
        # Additional parameters (keyword arguments) for kernel function passed as callable object.

        # Show message
        print("\nKernel Ridge Regression (KRR)")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "KernelRidge":

                # For alpha_in
                try:
                    alpha_in = float(line[1].strip())
                    if alpha_in < 0.0: # It has to be > 0.0
                        print("\nAlpha should be a positive float!")
                        alpha_in = 1.0

                # Handle exceptions (it accepts arrays)
                except:
                    alpha_in = np.array(line[1].strip())

                # For kernel_in (worked for:linear,poly,polynomial,rbf,
                # laplacian,sigmoid, and cosine)
                # Original list: "precomputed","linear","additive_chi2","chi2",
                # "poly","polynomial","rbf","laplacian","sigmoid","cosine"
                list_kernel = ["linear","poly","polynomial","rbf","laplacian",
                "sigmoid","cosine"]
                if line[2].strip() in list_kernel:
                    kernel_in = line[2].strip()
                else:
                    kernel_in = "linear"
                    print("Unrecognizable input!")

                # For gamma_in
                if line[3].strip() == "None":
                    gamma_in = None
                else:
                    gamma_in = float(line[3].strip())

                # For degree_in
                degree_in = float(line[4].strip())

                # For coef0_in
                coef0_in = float(line[5].strip())

                # For kernel_params_in
                if line[6].strip() == "None":
                    kernel_params_in = None
                else:
                    kernel_params_in = line[6].strip()

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Regularization strength: ",line[1])
        print("Kernel mapping used internally: ",line[2])
        line_out3 = "Gamma parameter for the RBF, laplacian, polynomial, "
        line_out3 += "exponential chi2 and sigmoid kernels: "
        print(line_out3,line[3])
        print("Degree of the polynomial kernel: ", line[4])
        print("Zero coefficient for polynomial and sigmoid kernels: ",line[5])
        print("Additional parameters for kernel function: ",line[6])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of KernelRidge class
        ############################################################################
        model = KernelRidge(
            alpha=alpha_in,                     # alpha: float or array-like of shape (n_targets,), default=1.0
            kernel=kernel_in,                   # kernel: string or callable, default=”linear”
            gamma=gamma_in,                     # gamma: float, default=None
            degree=degree_in,                   # degree: float, default=3.0
            coef0=coef0_in,                     # coef0: float, default=1.0
            kernel_params=kernel_params_in      # kernel_params: mapping of string to any, default=None
            )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return model