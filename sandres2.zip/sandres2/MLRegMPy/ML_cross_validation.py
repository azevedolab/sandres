#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Class for cross-validation loop
#
# Define ValidationLoop() class
class ValidationLoop(object):
    """Class to cross-validate a regression model. It uses Kfold class to build
    a n fold cross-validation loop and test the generalization ability of
    a regression model"""

    # Define constructor method
    def __init__(self,model,X,y,cv_in):
        """Constructor method"""

        # Set up attributes
        self.model = model
        self.X = X
        self.y = y
        self.cv_in = cv_in

    # Define build() method
    def build(self):
        """Method to set up k-fold class.
        Kfold class to build a n fold cross-validation loop and test the
        generalization ability of regression. With cross-validation, we
        generally obtain a more conservative estimate(that is, the error is
        larger).
        The cross-validation estimate is a better estimate of how well we
        could generalize to predict on unseen data.

        Reference:
        Coelho LP, Richert W. (2015) Building Machine Learning Systems with
        Python. 2nd ed. Packt Publishing Ltd. Birmingham UK. 301 pp.
        See page 162 (Cross-validation for regression)"""

        # Import packages
        from sklearn.model_selection import KFold, cross_val_score
        from sklearn.metrics import mean_squared_error
        from warnings import simplefilter
        import numpy as np

        # Set up k-fold class
        #kf = KFold(n_splits=self.cv_in, shuffle=True, random_state=1123)
        kf = KFold(n_splits=self.cv_in)

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Set up an array
        p = np.zeros_like(self.y)

        # Looping through kf.split()
        for train,test in kf.split(self.X):

            # Generate regression model
            self.model.fit(self.X[train], self.y[train])

            # Assign predicted values for internal test set
            p[test] = self.model.predict(self.X[test])

        # Show RMSE for test set
        rmse_cv = np.sqrt(mean_squared_error(p, self.y))
        msg_out = "\nRMSE on n-fold CV for test set: {:.2}".format(rmse_cv)
        print(msg_out)

        # Show average coefficient of determination using 5-fold crossvalidation
        scores = cross_val_score(self.model,self.X,self.y,cv=kf)
        m1 = "Average coefficient of determination using n-fold crossvalidation"
        print("\n"+m1+":",np.mean(scores))

        # Return model
        return self.model