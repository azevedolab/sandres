#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define GaussianProcessRegressor() class
class GaussianProcessRegressor(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_GaussianProcessRegressor() method
    def ml_scikit_GaussianProcessRegressor(self):
        """
        Method to generate a multiple regression model using
        GaussianProcessRegressor
        """

        # Import packages
        from sklearn.gaussian_process import GaussianProcessRegressor
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.gaussian_process.GaussianProcessRegressor.html
        #
        # string_reg_method = GaussianProcessRegressor
        #
        #
        # kernel: kernel instance, default=None
        # The kernel specifying the covariance function of the GP. If None is
        # passed, the kernel ConstantKernel(1.0,
        # constant_value_bounds="fixed" * RBF(1.0, length_scale_bounds="fixed")
        # is used as default. Note that the kernel hyperparameters are optimized
        # during fitting unless the bounds are marked as “fixed”.
        #
        # alpha: float or ndarray of shape (n_samples,), default=1e-10
        # Value added to the diagonal of the kernel matrix during fitting.
        # This can prevent a potential numerical issue during fitting, by
        # ensuring that the calculated values form a positive definite matrix.
        # It can also be interpreted as the variance of additional Gaussian
        # measurement noise on the training observations. Note that this is
        # different from using a WhiteKernel. If an array is passed, it must
        # have the same number of entries as the data used for fitting and is
        # used as datapoint-dependent noise level. Allowing to specify the
        # noise level directly as a parameter is mainly for convenience and for
        # consistency with Ridge.
        #
        # optimizer: “fmin_l_bfgs_b” or callable, default=”fmin_l_bfgs_b”
        # Can either be one of the internally supported optimizers for
        # optimizing the kernel’s parameters, specified by a string, or an
        # externally defined optimizer passed as a callable.
        # Per default, the ‘L-BGFS-B’ algorithm from scipy.optimize.minimize
        # is used. If None is passed, the kernel’s parameters are kept fixed.
        # Available internal optimizers are: "fmin_l_bfgs_b"
        #
        # n_restarts_optimizer: int, default=0
        # The number of restarts of the optimizer for finding the kernel’s
        # parameters which maximize the log-marginal likelihood. The first run
        # of the optimizer is performed from the kernel’s initial parameters,
        # the remaining ones (if any) from thetas sampled log-uniform randomly
        # from the space of allowed theta-values. If greater than 0, all bounds
        # must be finite. Note that n_restarts_optimizer == 0 implies that one
        # run is performed.
        #
        # normalize_y: bool, default=False
        # Whether the target values y are normalized, the mean and variance of
        # the target values are set equal to 0 and 1 respectively. This is
        # recommended for cases where zero-mean, unit-variance priors are used.
        # Note that, in this implementation, the normalisation is reversed
        # before the GP predictions are reported.
        #
        # copy_X_train: bool, default=True
        # If True, a persistent copy of the training data is stored in the
        # object. Otherwise, just a reference to the training data is stored,
        # which might cause predictions to change if the data is modified
        # externally.
        #
        # random_state: int, RandomState instance or None, default=None
        # Determines random number generation used to initialize the centers.
        # Pass an int for reproducible results across multiple function calls.
        # See :term: Glossary <random_state>.

        # Show message
        print("\nGaussian Process Regression (GPR)")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "GaussianProcessRegressor":

                # For kernel_in
                if line[1] == "None":
                    kernel_in = None
                else:
                    kernel_in = line[1]

                # For alpha_in
                alpha_in = float(line[2])

                # For optimizer_in
                if line[3] == "None":
                    optimizer_in = None
                else:
                    optimizer_in = line[3]

                # For n_restarts_optimizer_in
                n_restarts_optimizer_in = int(line[4])

                # For normalize_y_in
                if line[5] == "True":
                    normalize_y_in = True
                else:
                    normalize_y_in = False

                # For copy_X_train_in
                if line[6] == "True":
                    copy_X_train_in = True
                else:
                    copy_X_train_in = False

                # For random_state_in
                if line[7] == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[7])

                # For cv_in (set value to 5)
                cv_in = int(line[8])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        line_out1 = "Kernel specifying the covariance function of the "
        line_out1 += "Gaussian process: "
        print(line_out1,line[1])
        line_out2 = "Value added to the diagonal of the kernel matrix during "
        line_out2 += "fitting: "
        print(line_out2,line[2])
        print("Optimizer for optimizing the kernel’s parameters: ", line[3])
        print("Number of restarts of the optimizer: ",line[4])
        print("Whether the target values y are normalized: ",line[5])
        line_out6 = "If True, a persistent copy of the training data is "
        line_out6 += "stored in the object: "
        print(line_out6,line[6])
        print("Random number generation used to initialize the centers: ",
        line[7])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of GaussianProcessRegressor class
        ############################################################################
        model = GaussianProcessRegressor(
            kernel=kernel_in,                   # kernel: kernel instance, default=None
            alpha=alpha_in,                     # alpha: float or ndarray of shape (n_samples,), default=1e-10
            optimizer=optimizer_in,             # optimizer: “fmin_l_bfgs_b” or callable, default=”fmin_l_bfgs_b”
            n_restarts_optimizer=n_restarts_optimizer_in,   # n_restarts_optimizer: int, default=0
            normalize_y=normalize_y_in,         # normalize_y: bool, default=False
            copy_X_train=copy_X_train_in,       # copy_X_train: bool, default=True
            random_state=random_state_in       # random_state: int, RandomState instance or None, default=None
            )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return model