#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define Ridge() class
class Ridge(object):
    """Class to carry out Ridge regression with cross-validation

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : ndarray of shape (n_samples, n_features). Training data.
                                If using GCV, will be cast to float64 if necessary.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_targets)
                                Target values. Will be cast to X’s dtype if necessary.

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or ndarray of shape (n_targets,). Independent term in decision function.
                                Set to 0.0 if fit_intercept = False.
       model.coef_              : ndarray of shape (n_features) or (n_targets, n_features). Weight vector(s).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_Ridge() method
    def ml_scikit_Ridge(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.RidgeCV
        """

        # Import packages
        from sklearn.linear_model import RidgeCV
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.RidgeCV.html
        #
        # string_reg_method = Ridge
        #
        # alphas: ndarray of shape (n_alphas,), default=(0.1, 1.0, 10.0)
        # Array of alpha values to try. Regularization strength; must be a
        # positive float.
        # Regularization improves the conditioning of the problem and reduces
        # the variance of the estimates.
        # Larger values specify stronger regularization. Alpha corresponds to
        # C^-1 in other linear models such as LogisticRegression or LinearSVC.
        # If using generalized cross-validation, alphas must be positive.
        #
        # fit_intercept: bool, default=True
        # Whether to calculate the intercept for this model.
        # If set to false, no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # normalize: bool, default=False
        # This parameter is ignored when fit_intercept is set to False.
        # If True, the regressors X will be normalized before regression by
        # subtracting the mean and dividing by the l2-norm.
        # If you wish to standardize, please use
        # sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # cv: int, cross-validation generator or an iterable, optional
        # Determines the cross-validation splitting strategy. Possible inputs
        # for cv are:
        # None, to use the efficient Leave-One-Out cross-validation
        # (also known as Generalized Cross-Validation).
        # integer, to specify the number of folds.
        # CV splitter,
        # An iterable yielding (train, test) splits as arrays of indices.
        # For integer/None inputs, if y is binary or multiclass,
        # sklearn.model_selection.StratifiedKFold is used, else,
        # sklearn.model_selection.KFold is used.
        #
        # gcv_mode: {None, ‘auto’, ‘svd’, eigen’}, optional
        # Flag indicating which strategy to use when performing Generalized
        # Cross-Validation. Options are:
        # 'auto' : use 'svd' if n_samples > n_features, otherwise use 'eigen'
        # 'svd' : force use of singular value decomposition of X when X is
        # dense, eigenvalue decomposition of X^T.X when X is sparse.
        # 'eigen' : force computation via eigendecomposition of X.X^T
        # The ‘auto’ mode is the default and is intended to pick the cheaper
        # option of the two depending on
        # the shape of the training data.

        # Show message
        print("\nRidge Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "Ridge":

                # For alpha_0
                alpha_0 = float(line[1])

                # For alpha_1
                alpha_1 = float(line[2])

                # For num_samples
                num_samples = int(line[3])

                # For fit_in
                if line[4] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For norm_in
                if line[5] == "True":
                    norm_in = True
                else:
                    norm_in = False

                # For cv_in (set value to 5)
                cv_in = int(line[6])

                # For gcv_mode_in
                gcv_mode_in = line[7]

                # For self.rand_in (for MDM file)
                self.rand_in = int(line[8])

                # Finish loop
                break

        # Close file
        fo.close()

        # Set up alphas_ array
        # Based on https://docs.scipy.org/doc/numpy-1.15.1/reference/generated/numpy.logspace.html
        alphas_ = np.logspace(alpha_0, alpha_1, num_samples)

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        line_out1 = "Array of alpha values to try "
        print(line_out1+"(minimum alpha): {:.5f}".format(np.min(alphas_)))
        print(line_out1+"(maximum alpha): {:.5f}".format(np.max(alphas_)))
        print(line_out1+"(number of samples): {}".format(num_samples))
        print("Fit intercept? "+line[4])
        print("Normalize? "+line[5])
        print("Kfold class to build a N-fold cross-validation loop. N: ",
        line[6])
        print("Generalized Cross-Validation mode: ",gcv_mode_in)

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of RidgeCV() class
        model = RidgeCV(
                alphas = alphas_,       # alphas: ndarray of shape (n_alphas,), default=(0.1, 1.0, 10.0)
                fit_intercept = fit_in, # fit_intercept: bool, default=True
                normalize = norm_in,    # normalize: bool, default=False
                cv = cv_in,             # cv: int, cross-validation generator or an iterable, optional
                gcv_mode = gcv_mode_in  # gcv_mode: {None, ‘auto’, ‘svd’, eigen’}, optional
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_