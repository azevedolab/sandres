#!/usr/bin/python
#
# Here we have regression methods implemented using scikit-learn library
# (Pedregosa et al., 2011)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the development of the programs SAnDReS (Xavier et al., 2016)
# and Taba (da Silva et al., 2020).
# These methods are usefull for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019).
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019; 2053: 275–281.
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, Blondel M,
# Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A, Cournapeau D,
# Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning in Python.
# J Mach Learn Res, 2011, 12, 2825–2830.
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin,
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and
# Development  of  Scoring Functions.
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347
#
###############################################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico -
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################

# Define HuberRegressorCV() class
class HuberRegressorCV(object):
    """Class to carry out HuberRegressorCV

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : array-like, shape (n_samples, n_features)
                                Training vector, where n_samples in the number of samples and n_features is the number of features.
        y                       : array-like, shape (n_samples,)
                                Target vector relative to X.

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float. Bias.
       model.coef_              : array, shape (n_features,). Features got by optimizing the Huber loss.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_HuberRegressorCV() method
    def ml_scikit_HuberRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.HuberRegressorCV
        """

        # Import packages
        from sklearn.linear_model import HuberRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.HuberRegressor.html
        #
        # string_reg_method = HuberRegressorCV
        #
        #
        # epsilon: float, greater than 1.0, default 1.35
        # The parameter epsilon controls the number of samples that should be
        # classified as outliers.
        # The smaller the epsilon, the more robust it is to outliers.
        #
        # max_iter: int, default 100
        # Maximum number of iterations that scipy.optimize.minimize
        # (method="L-BFGS-B") should run for.
        #
        # alpha: float, default 0.0001
        # Regularization parameter.
        #
        # warm_start: bool, default False
        # This is useful if the stored attributes of a previously used model has
        # to be reused.
        # If set to False, then the coefficients will be rewritten for every
        # call to fit.
        #
        # fit_intercept: bool, default True
        # Whether or not to fit the intercept. This can be set to False if the
        # data is already centered around the origin.
        #
        # tol: float, default 1e-5
        # The iteration will stop when max{|proj g_i | i = 1, ..., n} <= tol
        # where pg_i is the i-th component of the projected gradient.

        # Show message
        print("\nHuber Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "HuberRegressorCV":

                # For epsilon_in
                epsilon_in = float(line[1])

                # For max_in
                max_in = int(line[2])

                # For alpha_in
                alpha_in = float(line[3])

                # For warm_start_in
                if line[4] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For fit_in
                if line[5] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For tol_in
                tol_in = float(line[6])

                # For cv_in
                cv_in = int(line[7])

                # For self.rand_in
                self.rand_in = int(line[8])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        line_out1 = "Parameter epsilon controls the number of samples that "
        line_out1 += "should be classified as outliers"
        print(line_out1+": {:.5e}".format(epsilon_in))
        print("Maximum number of iterations: {}".format(max_in))
        print("Regularization parameter (alpha): {:.5e}".format(alpha_in))
        print("Warm start? ",line[4])
        print("Fit intercept? "+line[5])
        print("Tolerance: {:.5e}".format(tol_in))

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of HuberRegressor class
        model = HuberRegressor(
                epsilon=epsilon_in,         # epsilon: float, greater than 1.0, default 1.35
                max_iter=max_in,            # max_iter: int, default 100
                alpha=alpha_in,             # alpha: float, default 0.0001
                warm_start=warm_start_in,   # warm_start: bool, optional
                fit_intercept=fit_in,       # fit_intercept: bool, default True
                tol=tol_in,                 # tol: float, default 1e-5
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_