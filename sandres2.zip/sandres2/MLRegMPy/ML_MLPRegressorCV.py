#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define MLPRegressorCV() class
class MLPRegressorCV(object):
    """Class to carry out regression with MLPRegressor
    Multi-layer Perceptron Regressor

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_MLPRegressorCV() method
    def ml_scikit_MLPRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.neural_network.MLPRegressor
        """

        # Import packages
        from sklearn.neural_network import MLPRegressor
        from sklearn import preprocessing
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPRegressor.html
        #
        # string_reg_method = MLPRegressorCV
        #
        #
        # hidden_layer_sizes: tuple, length = n_layers - 2, default=(100,)
        # The ith element represents the number of neurons in the ith hidden
        # layer.
        #
        # activation: {‘identity’, ‘logistic’, ‘tanh’, ‘relu’}, default=’relu’
        # Activation function for the hidden layer.
        # ‘identity’, no-op activation, useful to implement linear bottleneck,
        # returns f(x) = x
        # ‘logistic’, the logistic sigmoid function, returns
        # f(x) = 1 / (1 + exp(-x)).
        # ‘tanh’, the hyperbolic tan function, returns f(x) = tanh(x).
        # ‘relu’, the rectified linear unit function, returns f(x) = max(0, x)
        #
        # solver: {‘lbfgs’, ‘sgd’, ‘adam’}, default=’adam’
        # The solver for weight optimization.
        # ‘lbfgs’ is an optimizer in the family of quasi-Newton methods.
        # ‘sgd’ refers to stochastic gradient descent.
        # ‘adam’ refers to a stochastic gradient-based optimizer proposed by
        # Kingma, Diederik, and Jimmy Ba
        # Note: The default solver ‘adam’ works pretty well on relatively large
        # datasets (with thousands of training samples or more)
        # in terms of both training time and validation score.
        # For small datasets, however, ‘lbfgs’ can converge faster and perform
        # better.
        #
        # alpha: float, default=0.0001
        # L2 penalty (regularization term) parameter.
        #
        # batch_size: int, default=’auto’
        # Size of minibatches for stochastic optimizers.
        # If the solver is ‘lbfgs’, the classifier will not use minibatch.
        # When set to “auto”, batch_size=min(200, n_samples)
        #
        # learning_rate:{‘constant’,‘invscaling’,‘adaptive’}, default=’constant’
        # Learning rate schedule for weight updates.
        # ‘constant’ is a constant learning rate given by ‘learning_rate_init’.
        # ‘invscaling’ gradually decreases the learning rate learning_rate_ at
        # each time step ‘t’ using
        # an inverse scaling exponent of ‘power_t’.
        # effective_learning_rate = learning_rate_init / pow(t, power_t)
        # ‘adaptive’ keeps the learning rate constant to ‘learning_rate_init’
        # as long as training loss keeps decreasing.
        # Each time two consecutive epochs fail to decrease training loss by
        # at least tol,
        # or fail to increase validation score by at least tol if
        # ‘early_stopping’ is on, the current learning rate is divided by 5.
        #
        # learning_rate_init: double, default=0.001
        # The initial learning rate used. It controls the step-size in updating
        # the weights. Only used when solver=’sgd’ or ‘adam’.
        #
        # power_t: double, default=0.5
        # The exponent for inverse scaling learning rate. It is used in
        # updating effective learning rate
        # when the learning_rate is set to ‘invscaling’. Only used when
        # solver=’sgd’.
        #
        # max_iter: int, default=200
        # Maximum number of iterations. The solver iterates until convergence
        # (determined by ‘tol’) or this number of iterations.
        # For stochastic solvers (‘sgd’, ‘adam’), note that this determines the
        # number of epochs (how many times each data point will be used),
        # not the number of gradient steps.
        #
        # shuffle: bool, default=True
        # Whether to shuffle samples in each iteration. Only used when
        # solver=’sgd’ or ‘adam’.
        # Only used when solver=’sgd’.
        #
        # random_state: int, RandomState instance or None, default=None
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random.
        #
        # tol: float, default=1e-4
        # Tolerance for the optimization.
        # When the loss or score is not improving by at least tol for
        # n_iter_no_change consecutive iterations,
        # unless learning_rate is set to ‘adaptive’, convergence is considered
        # to be reached and training stops.
        #
        # verbose: bool, default=False
        # Whether to print progress messages to stdout.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit as
        # initialization, otherwise, just erase the previous solution.
        #
        # momentum: float, default=0.9
        # Momentum for gradient descent update. Should be between 0 and 1.
        # Only used when solver=’sgd’.
        #
        # nesterovs_momentum: boolean, default=True
        # Whether to use Nesterov’s momentum. Only used when solver=’sgd’
        # and momentum > 0.
        #
        # early_stopping: bool, default=False
        # Whether to use early stopping to terminate training when validation
        # score is not improving.
        # If set to true, it will automatically set aside 10% of training data
        # as validation and terminate training
        # when validation score is not improving by at least tol
        # for n_iter_no_change consecutive epochs.
        # Only effective when solver=’sgd’ or ‘adam’
        #
        # validation_fraction: float, default=0.1
        # The proportion of training data to set aside as validation set for
        # early stopping.
        # Must be between 0 and 1.
        # Only used if early_stopping is True
        #
        # beta_1: float, default=0.9
        # Exponential decay rate for estimates of first moment vector in adam,
        # should be in [0, 1).
        # Only used when solver=’adam’
        #
        # beta_2: float, default=0.999
        # Exponential decay rate for estimates of second moment vector in adam,
        # should be in [0, 1).
        # Only used when solver=’adam’
        #
        # epsilon: float, default=1e-8
        # Value for numerical stability in adam. Only used when solver=’adam’
        #
        # n_iter_no_change: int, default=10
        # Maximum number of epochs to not meet tol improvement.
        # Only effective when solver=’sgd’ or ‘adam’
        #
        # max_fun: int, default=15000
        # Only used when solver=’lbfgs’.
        # Maximum number of function calls.
        # The solver iterates until convergence (determined by ‘tol’), number
        # of iterations reaches max_iter,
        # or this number of function calls.
        # Note that number of function calls will be greater than or equal to
        # the number of iterations for the MLPRegressorCV.

        # Show message
        print("\nMulti-layer Perceptron Regressor with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "MLPRegressorCV":

                # For hidden_layer_size_in
                try:
                    hidden_layer_size_in = int(line[1].strip())
                # Handle exception
                except:
                    hidden_layer_size_in = line[1].strip()

                # For activation_in
                list_activation = ["identity","logistic","tanh","relu"]
                if line[2].strip() in list_activation:
                    activation_in = line[2].strip()
                else:
                    activation_in = "relu"
                    print("Unrecognizable input!")

                # For solver_in
                list_solver = ["lbfgs","sgd","adam"]
                if line[3].strip() in list_solver:
                    solver_in = line[3].strip()
                else:
                    solver_in = "adam"
                    print("Unrecognizable input!")

                # For alpha_in
                alpha_in = float(line[4].strip())

                # For batch_size_in
                try:
                    batch_size_in = int(line[5].strip())
                except:
                    batch_size_in = "auto"

                # For learning_rate_in
                list_learning_rate = ["constant","invscaling","adaptive"]
                if line[6].strip() in list_learning_rate:
                    learning_rate_in = line[6].strip()
                else:
                    learning_rate_in = "constant"
                    print("Unrecognizable input!")

                # For learning_rate_init_in
                learning_rate_init_in = float(line[7].strip())

                # For power_t_in
                power_t_in = float(line[8].strip())

                # For max_in
                max_in = int(line[9].strip())

                # For shuffle_in
                if line[10].strip() == "True":
                    shuffle_in = True
                else:
                    shuffle_in = False

                # For rand_in
                try:
                    rand_in = int(line[11].strip())
                except:
                    rand_in = None

                # For tol_in
                tol_in = float(line[12].strip())

                # For ver_in
                if line[13].strip() == "True":
                    ver_in = True
                else:
                    ver_in = False

                # For warm_start_in
                if line[14].strip() == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For momentum_in
                momentum_in = float(line[15].strip())

                # For nesterovs_momentum_in
                if line[16].strip() == "True":
                    nesterovs_momentum_in = True
                else:
                    nesterovs_momentum_in = False

                # For early_stopping_in
                if line[17].strip() == "True":
                    early_stopping_in = True
                else:
                    early_stopping_in = False

                # For validation_fraction_in
                validation_fraction_in = float(line[18].strip())

                # For beta_1_in
                beta_1_in = float(line[19].strip())

                # For beta_2_in
                beta_2_in = float(line[20].strip())

                # For epsilon_in
                epsilon_in = float(line[21].strip())

                # For n_iter_no_change_in
                n_iter_no_change_in = int(line[22].strip())

                # For max_fun_in
                max_fun_in = int(line[23].strip())

                # For cv_in
                cv_in = int(line[24].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Number of hidden layers: {}".format(hidden_layer_size_in))
        print("Activation function for the hidden layer: ",line[2])
        print("The solver for weight optimization: ",line[3])
        print("L2 penalty parameter: {:.5e}".format(alpha_in))
        print("Size of minibatches for stochastic optimizers: ",line[5])
        print("Learning rate schedule for weight updates: ",line[6])
        line_out7 = "Initial learning rate used"
        print(line_out7+": {:.5e}".format(learning_rate_init_in))
        line_out8 = "Exponent for inverse scaling learning rate"
        print(line_out8+": {:.5e}".format(power_t_in))
        print("Maximum number of iterations: {}".format(max_in))
        print("Whether to shuffle samples in each iteration: ",line[10])
        print("Random state: ",line[11])
        print("Tolerance for the optimization: {:.5e}".format(tol_in))
        print("Verbose : ",line[13])
        print("Warm start? ",line[14])
        line_out15 = "Momentum for gradient descent update"
        print(line_out15+": {:.5e}".format(momentum_in))
        print("Whether to use Nesterov’s momentum: ",line[16])
        line_out17 = "Whether to use early stopping to terminate training when "
        print(line_out17+"validation score is not improving: ",line[17])
        line_out18 = "Proportion of training data to set aside as validation "
        print(line_out18+"set for early stopping: ",line[18])
        line_out19 = "Exponential decay rate for estimates of first moment "
        print(line_out19+"vector in adam, should be in [0, 1): ",line[19])
        line_out20 = "Exponential decay rate for estimates of second moment "
        print(line_out20+"vector in adam, should be in [0, 1): ",line[20])
        print("Value for numerical stability in adam: ",line[21])
        print("Maximum number of epochs to not meet tol improvement: ",line[22])
        print("Maximum number of function calls (solver=’lbfgs’): ",line[23])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[24])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of MLPRegressor class
        model = MLPRegressor(
            hidden_layer_sizes = (hidden_layer_size_in,),   # hidden_layer_sizes: tuple, length = n_layers - 2, default=(100,)
            activation = activation_in,                     # activation: {‘identity’, ‘logistic’, ‘tanh’, ‘relu’}, default=’relu’
            solver=solver_in,                               # solver: {‘lbfgs’, ‘sgd’, ‘adam’}, default=’adam’
            alpha=alpha_in,                                 # alpha: float, default=0.0001
            batch_size=batch_size_in,                       # batch_size: int, default=’auto’
            learning_rate=learning_rate_in,                 # learning_rate: {‘constant’, ‘invscaling’, ‘adaptive’}, default=’constant’
            learning_rate_init=learning_rate_init_in,       # learning_rate_init: double, default=0.001
            power_t=power_t_in,                             # power_t: double, default=0.5
            max_iter = max_in,                              # max_iter: int, default=200
            shuffle=shuffle_in,                             # shuffle: bool, default=True
            random_state=rand_in,                           # random_state: int, RandomState instance or None, default=None
            tol=tol_in,                                     # tol: float, default=1e-4
            verbose=ver_in,                                 # verbose: bool, default=False
            warm_start=warm_start_in,                       # warm_start: bool, default=False
            momentum=momentum_in,                           # momentum: float, default=0.9
            nesterovs_momentum=nesterovs_momentum_in,       # nesterovs_momentum: boolean, default=True
            early_stopping=early_stopping_in,               # early_stopping: bool, default=False
            validation_fraction = validation_fraction_in,   # validation_fraction: float, default=0.1
            beta_1=beta_1_in,                               # beta_1: float, default=0.9
            beta_2=beta_2_in,                               # beta_2: float, default=0.999
            epsilon=epsilon_in,                             # epsilon: float, default=1e-8
            n_iter_no_change=n_iter_no_change_in,           # n_iter_no_change: int, default=10
            max_fun=max_fun_in                              # max_fun: int, default=15000
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model