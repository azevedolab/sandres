#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define LassoLarsIC() class
class LassoLarsIC(object):
    """Class to carry out LassoLarsIC regression
    Least Angle Regression model a.k.a. LAR

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : array-like of shape (n_samples, n_features). Training data.
        y                       : array-like of shape (n_samples,) or (n_samples, n_targets)
                                Target values.

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or array-like of shape (n_targets,)
                                Independent term in decision function.
       model.coef_              : array-like of shape (n_features,) or (n_targets, n_features)
                                Parameter vector (w in the formulation formula).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_LassoLarsIC() method
    def ml_scikit_LassoLarsIC(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLarsIC
        """

        # Import packages
        from sklearn.linear_model import LassoLarsIC
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LassoLarsIC.html
        #
        # string_reg_method = LassoLarsIC
        #
        #
        # criterion: {"bic","aic"}, default="aic"
        # The type of criterion to use.
        #
        # fit_intercept: bool, default=True
        # Whether to calculate the intercept for this model. If set to false,
        # no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # verbose: bool or int, default=False
        # Sets the verbosity amount
        #
        # normalize: bool, default=True
        # This parameter is ignored when fit_intercept is set to False.
        # If True, the regressors X will be normalized before
        # regression by subtracting the mean and dividing by the l2-norm.
        # If you wish to standardize, please use
        # sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # precompute: bool, "auto" or array-like , default="auto"
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # If set to 'auto' let us decide.
        # The Gram matrix can also be passed as argument.
        #
        # max_iter: int, default=500
        # Maximum number of iterations to perform. Can be used for early
        # stopping.
        #
        # eps: float, default=np.finfo(float).eps
        # The machine-precision regularization in the computation of the
        # Cholesky diagonal factors.
        # Increase this for very ill-conditioned systems. Unlike the tol
        # parameter in some iterative
        # optimization-based algorithms, this parameter does not control the
        # tolerance of the optimization.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # positive: bool, default=False
        # Restrict coefficients to be >= 0. Be aware that you might want to
        # remove fit_intercept which is set True by default. Under the positive
        # restriction the model coefficients do not converge to the
        # ordinary-least-squares solution for small values of alpha. Only
        # coefficients up to the smallest alpha value
        # (alphas_[alphas_ > 0.].min() when fit_path=True) reached by the
        # stepwise Lars-Lasso algorithm are typically in congruence with the
        # solution of the coordinate descent Lasso estimator. As a consequence
        # using LassoLarsIC only makes sense for problems where a sparse
        # solution is expected and/or reached.

        # Show message
        print("\nLasso Model Fit with Lars Using BIC or AIC for Model Selection")
        print("AIC is the Akaike information criterion and BIC is the Bayes Information criterion")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "LassoLarsIC" and line[0] != "LassoLassoLarsIC":

                # For criterion_in
                list_criteria = ["bic","aic"]
                if line[1] in list_criteria:
                    criterion_in = line[1]
                else:
                    print("\nIOError! Undefined string ",line[1])
                    return

                # For fit_intercept_in
                if line[2] == "True":
                    fit_intercept_in = True
                else:
                    fit_intercept_in = False

                # For verbose_in
                if line[3] == "True":
                    verbose_in = True
                elif line[3] == "False":
                    verbose_in = False
                else:
                    verbose_in = int(line[3])

                # For normalize_in
                if line[4] == "True":
                    normalize_in = True
                else:
                    normalize_in = False

                # For precompute_in
                if line[5] == "True":
                    precompute_in = True
                elif line[4] == "False":
                    precompute_in = False
                else:
                    precompute_in = line[5]

                # For max_iter_in
                max_iter_in = int(line[6])

                # For eps_in
                eps_in = float(line[7])

                # For copy_X_in
                if line[8] == "True":
                    copy_X_in = True
                else:
                    copy_X_in = False

                # For positive_in
                if line[9] == "True":
                    positive_in = True
                else:
                    positive_in = False

                # For cv_in
                cv_in = int(line[10])

                # For self.rand_in
                self.rand_in = int(line[11])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Criterion to use: ",line[1])
        print("Fit intercept? "+line[2])
        print("Verbosity amount: ",line[3])
        print("Normalize? "+line[4])
        print("Pre compute? "+line[5])
        print("Maximum number of iterations to perform: ",line[6])
        line_out7 = "Machine-precision regularization in the computation of "
        line_out7 += "the Cholesky diagonal factors: "
        print(line_out7,line[7])
        print("Copy X array? ", line[8])
        print("Restrict coefficients to be >= 0: ",line[9])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of LassoLarsIC class
        model = LassoLarsIC(
                criterion=criterion_in,         # criterion: {"bic","aic"}, default="aic"
                fit_intercept=fit_intercept_in, # fit_intercept: bool, default=True
                verbose=verbose_in,             # verbose: bool or int, default=False
                normalize=normalize_in,         # normalize: bool, default=True
                precompute=precompute_in,       # precompute: bool, "auto" or array-like , default="auto"
                max_iter=max_iter_in,           # max_iter: int, default=500
                eps=eps_in,                     # eps: float, default=np.finfo(float).eps
                copy_X=copy_X_in,               # copy_X: boolean, optional, default True
                positive=positive_in            # positive: bool, default=False
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_