#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Define KNeighborsRegressorCV() class
class KNeighborsRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_KNeighborsRegressorCV() method
    def ml_scikit_KNeighborsRegressorCV(self):
        """
        Method to generate a multiple regression model using
        KNeighborsRegressorCV
        """

        # Import packages
        from sklearn.neighbors import KNeighborsRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsRegressor.html
        #
        # string_reg_method = KNeighborsRegressorCV
        #
        # n_neighbors: int, default=5
        # Number of neighbors to use by default for kneighbors queries.
        #
        # weights: {"uniform","distance"} or callable, default="uniform"
        # weight function used in prediction. Possible values:
        # "uniform" : uniform weights. All points in each neighborhood are
        # weighted equally.
        # "distance" : weight points by the inverse of their distance. in this
        # case, closer neighbors of a query point will have a greater influence
        # than neighbors which are further away.
        # [callable] : a user-defined function which accepts an array of
        # distances, and returns an array of the same shape containing the
        # weights.
        # Uniform weights are used by default.
        #
        # algorithm: {"auto","ball_tree","kd_tree","brute"}, default="auto"
        # Algorithm used to compute the nearest neighbors:
        # "ball_tree" will use BallTree
        # "kd_tree" will use KDTree
        # "brute" will use a brute-force search.
        # "auto" will attempt to decide the most appropriate algorithm based on
        # the values passed to fit method.
        # Note: fitting on sparse input will override the setting of this
        # parameter, using brute force.
        #
        # leaf_size: int, default=30
        # Leaf size passed to BallTree or KDTree. This can affect the speed of
        # the construction and query, as well as the memory required to store
        # the tree. The optimal value depends on the nature of the problem.
        #
        # p: int, default=2
        # Power parameter for the Minkowski metric. When p = 1, this is
        # equivalent to using manhattan_distance (l1), and euclidean_distance
        # (l2) for p = 2. For arbitrary p, minkowski_distance (l_p) is used.
        #
        # metric: str or callable, default="minkowski"
        # The distance metric to use for the tree. The default metric is
        # minkowski, and with p=2 is equivalent to the standard Euclidean
        # metric. See the documentation of DistanceMetric for a list of
        # available metrics. If metric is “precomputed”, X is assumed to be a
        # distance matrix and must be square during fit. X may be a sparse
        # graph, in which case only “nonzero” elements may be considered
        # neighbors.
        #
        # metric_params: dict, default=None
        # Additional keyword arguments for the metric function.
        #
        # n_jobs: int, default=None
        # The number of parallel jobs to run for neighbors search. None means
        # 1 unless in a joblib.parallel_backend context. -1 means using all
        # processors. See Glossary for more details. Doesn’t affect fit method.

        # Show message
        print("\nRegression Based on K-Nearest Neighbors")
        print("Regression parameters read from ml.csv")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "KNeighborsRegressorCV":

                # For n_neighbors_in
                n_neighbors_in = int(line[1].strip())

                # For weights_in
                list_weights = ["uniform","distance"]
                if line[2].strip() in list_weights:
                    weights_in = line[2].strip()
                else:
                    weights_in = "uniform"
                    print("Unrecognizable input!")

                # For algorithm_in
                list_algorithm = ["auto","ball_tree","kd_tree","brute"]
                if line[3] in list_algorithm:
                    algorithm_in = line[3].strip()
                else:
                    algorithm_in = "auto"
                    print("Unrecognizable input!")

                # For leaf_size_in
                leaf_size_in = int(line[4].strip())

                # For p_in
                p_in = int(line[5].strip())

                # For metric_in
                metric_in = line[6].strip()

                # For metric_params_in
                if line[7].strip() == "None":
                    metric_params_in = None
                else:
                    metric_params_in = line[7].strip()

                # For n_jobs_in
                if line[8].strip() == "None":
                    n_jobs_in = None
                else:
                    n_jobs_in = int(line[8].strip())

                # For cv_in
                cv_in = int(line[9].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.csv
        print("Regression method: ",line[0])
        line_out1 = "Number of neighbors to use by default for kneighbors "
        line_out1 += "queries: "
        print(line_out1,line[1])
        print("Weight function used in prediction: ",line[2])
        print("Algorithm used to compute the nearest neighbors: ",line[3])
        print("Leaf size passed to BallTree or KDTree: ",line[4])
        print("Power parameter for the Minkowski metric: ",line[5])
        print("Distance metric to use for the tree: ",line[6])
        print("Additional keyword arguments for the metric function: ",line[7])
        print("Number of parallel jobs to run for neighbors search: ",line[8])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[9])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of KNeighborsRegressor class
        ############################################################################
        model = KNeighborsRegressor(
            n_neighbors=n_neighbors_in,     # n_neighbors: int, default=5
            weights=weights_in,             # weights: {"uniform","distance"} or callable, default="uniform"
            algorithm=algorithm_in,         # algorithm: {"auto","ball_tree","kd_tree","brute"}, default="auto"
            leaf_size=leaf_size_in,         # leaf_size: int, default=30
            p=p_in,                         # p: int, default=2
            metric=metric_in,               # metric: str or callable, default="minkowski"
            metric_params=metric_params_in, # metric_params: dict, default=None
            n_jobs=n_jobs_in                # n_jobs: int, default=None
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model