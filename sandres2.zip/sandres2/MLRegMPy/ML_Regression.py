#!/usr/bin/env python3
#
# This class generates regression models
#
################################################################################
# Machine Learning Regression Methods in Python (MLRegMPy)                     #
################################################################################
#
# MLRegMPy has supervised machine-learning techniques implemented using the
# scikit-learn library (Pedregosa et al., 2011)
# (https://scikit-learn.org/stable/modules/linear_model.html). It employs
# CSV files (bind_###.csv and pdb_codes.csv) with prediction results and takes
# them as features to build a machine-learning model targeted to a system of
# interest. MLRegMpy is an open-source machine-learning library that supports
# 54 supervised learning methods.
# Dr. Walter F. de Azevedo, Jr.
# (https://www.scopus.com/authid/detail.uri?authorId=7006435557) developed this
# code which is the main machine-learning engine used in the programs
# SAnDReS (Xavier et al., 2016), Taba (da Silva et al., 2020), and
# SFSXplorer (https://github.com/azevedolab/SFSXplorer). MLRegMPy explores the
# scoring function space concept (Ross et al., 2013; Heck et al., 2017;
# Bitencourt-Ferreira & de Azevedo, 2019b) to develop computational models
# targeted to specific protein systems. Although the development focused on
# scoring functions to predict protein-ligand interactions, this program can
# build supervised machine-learning models for any application. MLRegMPy
# relies on the metrics recommended by Walsh et al., 2021 to evaluate the
# predictive performance of the models created using scikit-learn. The
# explore-sfs and user-defined options of MLRegMPy allow the generation of
# several models through the combination features. After the modeling step,
# MLRegMPy returns the best model based on solid statistical analysis.
# We have three options to run MLRegMPy. One named explore-sfs aims to explore
# the scoring function space (SFS) by selecting the features with the best
# predictive performance. The user chooses the criterion
# (criterion_in,r2 in the file ml.in) to define the top-ranked features
# (e.g., r, r2, rho, RMSE, MAE, and R2). MLRegMPy creates combinations of the
# top-ranked features and tests them all. To run MLRegMPy for the explore-sfs
# option, type the following commands in a Linux terminal:
# python3 mlr.py mlr.in explore > mlr.log &
#
# The user-defined option focuses on a set of features defined by the user.
# MLRegMPy generates combinations of variables and tests them all. Taking the
# total number of inputs (ud_n_set_in,15 in the file ml.in) as 15 and creating
# models with eight variables (ud_n_features_in,8 in the file ml. in) will
# result in C15,8 equations (6435 regression models). To run MLRegMPy for the
# user-defined option, type the following commands in a Linux terminal:
# python3 mlr.py mlr.in user-defined > mlr.log &
#
# The last option aims to generate one regression model named single-model. We
# may use this option taking the best model developed using either explore-sfs
# or user-defined options. Use the following commands to run this option:
# python3 mlr.py mlr.in single-model > mlr.log &
#
#
# References:
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281. DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69–73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, Blondel
# M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A, Cournapeau D,
# Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning in Python. J
# Mach Learn Res. 2011; 12: 2825–2830. arXiv:1201.0490
#
# Ross GA, Morris GM, Biggin PC. One Size Does Not Fit All: The Limits of
# Structure-Based Models in Drug Discovery. J Chem Theory Comput. 2013; 9(9):
# 4266–4274. doi: 10.1021/ct4004228. PMID: 24124403; PMCID: PMC3793897.
#
# Walsh I, Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR Machine
# Learning Focus Group; Harrow J, Psomopoulos FE, Tosatto SCE. DOME:
# recommendations for supervised machine learning validation in biology. Nat
# Methods. 2021; 18(10): 1122–1127. doi: 10.1038/s41592-021-01205-4.
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Number: 306298/2022-8.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2024                                                             #
################################################################################
#
# To run MLRegMPy
#
# python3 mlr.py mlr.in single-model > mlr.log &
# or
# python3 mlr.py mlr.in explore-sfs > mlr.log &
# or
# python3 mlr.py mlr.in user-defined > mlr.log &
# or
# python3 mlr.py mlr.in plot > mlr.log &
# or
# python3 mlr.py mlr.in prepare-data4ml > mlr.log &
#
################################################################################
#
# Import section
from MLRegMPy import ML_ACCESS
from MLRegMPy import ML_APPLY
from MLRegMPy import statistical_analysis as regression_metrics
from MLRegMPy import preprocess_data as scaling
from MLRegMPy import split as sp
from MLRegMPy import binding_affinity as b_aff
from tools import target_variable as target_var
import sys
import csv
import os
import shutil
import warnings

# Ignore warnings
warnings.filterwarnings('ignore')

################################################################################
# Define function to handle hash in a field (float or integer or string)
def handle_hash(type_in,line_in):
    """Function to handle hash in a field and returns a string"""

    # Test type_in
    if type_in == "str":
        # Handle hash for string output
        try:
            index_hash = str(line_in).index("#")
            data_out = line_in[:index_hash]
            data_out = data_out.replace(" ","")
        except:
            data_out = line_in.replace(" ","")
    else:
        # Print error message and return
        print("\nError! Undefined input!")
        return None

    # Return data
    return data_out

################################################################################

################################################################################
# Define fix_str_01() function
def fix_str_01(number_in,number_char_in,char2add):
    """Function to fix the number of characters by adding a defined
    number of characters to the left.
    e.g., 1 -> 00001"""

    # Convert to string
    str_in = str(number_in)

    # fix the number of characters in a string
    while len(str_in) < number_char_in+1:
        str_in = char2add+str_in

    # Return string
    return str_in
################################################################################

################################################################################
# Define Modeling() class
class Modeling(object):
    """Class to generate regression models"""

    # Define constructor method
    def __init__(self,
                program_root,               # Program root dir where mlr.py is
                mode_in,                    # Valid keywords: single-model, explore-sfs, user-defined, prep, scaling, random1, random2, filter, stats1, reg, apply...
                project_dir_string,         # Dir where the dataset is
                sf_file_in,                 # Indicate scores4xtal.csv file
                mlregmpy_in,                # Indicate ml_par.csv file
                preprocessing_in,           # Scaling method (e.g., StandardScaler)
                ml_parameters_in,           # Specify machine-learning methods (e.g., ml.csv)
                scoring_function_file_in,   # Specify internal file with initial dataset (e.g., scores.csv)
                target_in,                  # Target variable (e.g, pIC50)
                test_size_in,               # Float with fraction used for test set (e.g., 0.3)
                seed_in,                    # Integer used in the generation of random numbers (e.g., 271828)
                criterion_in,               # Metrics used for sorting features (e.g., r2)
                ml_criterion_in,            # Metrics used for sorting machine-learning models (e.g., r2) (explore option)
                data4criterion_in,          # Dataset used for sorting (e.g., test) (explore option)
                s_n_features_in,            # Integer used for number of features used to generate regression models (e.g, 8)
                s_features_in,              # Features used to generate regression models (string)
                x_n_set_in,                 # Integer for number of features used in the explore option
                x_n_features_in,            # Integer used for number of features used to generate regression models (e.g, 8) (explore option)
                ud_n_set_in,                # Integer for number of features used in the user-defined option
                ud_n_features_in,           # Integer used  for number of features used to generate regression models (e.g, 8) for used-defined option
                ud_features_in,             # Features used to generate regression models for used-defined option (string)
                plot2d_file,                # String with csv file name
                plot2d_title,               # String with plot title
                plot2d_title_size,          # Font size for title (integer)
                plot2d_metrics_x,           # Column header for x-axis (string)
                plot2d_metrics_y,           # Column header for y-axis (string)
                plot2d_bar,                 # Column header for side bar
                plot2d_x_axis_label,        # String for x-axis
                plot2d_y_axis_label,        # String for y-axis
                plot2d_bar_label,           # Sring for bar
                plot2d_bar_size,            # Font size for bar title (integer)
                plot2d_x_axis_size,         # Font size for x-axis label (integer)
                plot2d_y_axis_size,         # Font size for y-axis label (integer)
                plot2d_x_axis_min,          # Minimum value for x-axis (float)
                plot2d_x_axis_max,          # Maximum value for x-axis (float)
                plot2d_y_axis_min,          # Minimum value for y-axis (float)
                plot2d_y_axis_max,          # Maximum value for y-axis (float)
                plot2d_cmap_color,          # String with color scheme for bar
                plot2d_marker,              # Plot marker (e.g, o)
                plot2d_marker_edge,         # Plot edge on or off
                plot2d_dpi,                 # Plot resolution (integer)
                plot2d_alpha,               # Transparency
                plot2d_grid):               # Plot grid on or off
        """Constructor method"""

        # Define attributes
        self.program_root = program_root
        self.project_dir_string = project_dir_string
        self.mlregmpy_in = mlregmpy_in
        self.sf_file_in = sf_file_in                    # e.g., scores4xtal.csv
        self.mode_in = mode_in
        self.preprocessing_in = preprocessing_in
        self.ml_parameters_in = ml_parameters_in
        self.scoring_function_file_in = scoring_function_file_in
        self.s_n_features_in = s_n_features_in
        self.s_features_in = s_features_in
        self.target_in = target_in
        self.test_size_in = test_size_in
        self.seed_in = seed_in
        self.criterion_in = criterion_in
        self.x_n_features_in = x_n_features_in
        self.data4criterion_in = data4criterion_in
        self.x_n_set_in = x_n_set_in
        self.ml_criterion_in = ml_criterion_in
        self.ud_n_features_in = ud_n_features_in
        self.ud_n_set_in = ud_n_set_in
        self.ud_features_in = ud_features_in #self.ud_n_features_in
        self.plot2d_file = plot2d_file
        self.plot2d_title = plot2d_title
        self.plot2d_title_size = plot2d_title_size
        self.plot2d_metrics_x = plot2d_metrics_x
        self.plot2d_metrics_y = plot2d_metrics_y
        self.plot2d_bar = plot2d_bar
        self.plot2d_x_axis_label = plot2d_x_axis_label
        self.plot2d_y_axis_label = plot2d_y_axis_label
        self.plot2d_bar_label = plot2d_bar_label
        self.plot2d_bar_size = plot2d_bar_size
        self.plot2d_x_axis_size = plot2d_x_axis_size
        self.plot2d_y_axis_size = plot2d_y_axis_size
        self.plot2d_x_axis_min = plot2d_x_axis_min
        self.plot2d_x_axis_max = plot2d_x_axis_max
        self.plot2d_y_axis_min = plot2d_y_axis_min
        self.plot2d_y_axis_max = plot2d_y_axis_max
        self.plot2d_cmap_color = plot2d_cmap_color
        self.plot2d_marker = plot2d_marker
        self.plot2d_marker_edge = plot2d_marker_edge
        self.plot2d_dpi = plot2d_dpi
        self.plot2d_alpha = plot2d_alpha
        self.plot2d_grid = plot2d_grid

    # Define get_data() method
    def get_data(self):
        """Method to read a CSV file and select columns to generate a
        scatter plot"""

        # Import section
        import numpy as np

        # Read CSV file
        # Try to open a CSV file
        file2open = self.project_dir_string+self.plot2d_file
        try:
            fo_data = open(file2open,"r")
            csv_data = csv.reader(fo_data)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through csv_data for first line
        for line in csv_data:
            for i,line1 in enumerate(line):
                if line1.strip() == self.plot2d_metrics_x:
                    i_x = i
                elif line1.strip() == self.plot2d_metrics_y:
                    i_y = i
                elif line1.strip() == self.plot2d_bar:
                    i_z = i
            break

        # Close file
        fo_data.close()

        # Read CSV file
        my_csv = np.genfromtxt (file2open, delimiter=",", skip_header = 1)

        # Get each column from CSV file
        self.x1 = my_csv[:,i_x] # e.g., RMSE
        self.y1 = my_csv[:,i_y] # e.g., R2
        self.z1 = my_csv[:,i_z] # e.g., DOME

    # Define create() method to generate plot
    def create(self):
        """Method to generate a scatter plot"""

        # Import section
        import matplotlib.pyplot as plt
        from matplotlib import cm

        # Bar colors
        colors = self.z1

        # Check grid option
        if self.plot2d_grid.upper() == "ON":
            plt.grid(alpha=0.3)

        # Define cmap
        if self.plot2d_cmap_color == "rainbow":
            # Define edge
            if self.plot2d_marker_edge.upper() == "ON":
                plt.scatter(self.x1, self.y1, marker=self.plot2d_marker,
                                alpha=self.plot2d_alpha,c=colors,
                                edgecolor="black", cmap=cm.rainbow)
            else:
                plt.scatter(self.x1, self.y1, marker=self.plot2d_marker,
                                alpha=self.plot2d_alpha,c=colors,
                                cmap=cm.rainbow)

        else:
            # Define edge
            if self.plot2d_marker_edge.upper() == "ON":
                plt.scatter(self.x1, self.y1, marker=self.plot2d_marker,
                alpha=self.plot2d_alpha,c=colors, edgecolor="black",
                cmap=self.plot2d_cmap_color)
            else:
                plt.scatter(self.x1, self.y1, marker=self.plot2d_marker,
                alpha=self.plot2d_alpha,c=colors, cmap=self.plot2d_cmap_color)

        # Include a bar
        cbar = plt.colorbar()

        # Deal with rho
        if self.plot2d_x_axis_label == "rho":
            self.plot2d_x_axis_label = r"$\rho$"
        elif self.plot2d_y_axis_label == "rho":
            self.plot2d_y_axis_label = r"$\rho$"

        # Deal with r2
        if self.plot2d_x_axis_label == "r2":
            self.plot2d_x_axis_label = r"$r^2$"
        elif self.plot2d_y_axis_label == "r2":
            self.plot2d_y_axis_label = r"$r^2$"

        # Deal with R2
        if self.plot2d_x_axis_label == "R2":
            self.plot2d_x_axis_label = r"$R^2$"
        elif self.plot2d_y_axis_label == "R2":
            self.plot2d_y_axis_label = r"$R^2$"

        # Labels
        plt.title(self.plot2d_title,fontsize=self.plot2d_title_size)
        plt.xlabel(self.plot2d_x_axis_label,fontsize=self.plot2d_x_axis_size)
        plt.ylabel(self.plot2d_y_axis_label,fontsize=self.plot2d_y_axis_size)
        plt.xlim(self.plot2d_x_axis_min,self.plot2d_x_axis_max)
        plt.ylim(self.plot2d_y_axis_min,self.plot2d_y_axis_max)
        cbar.set_label(self.plot2d_bar_label,fontsize=self.plot2d_bar_size)

        # Set up plot file name
        plot_file = self.project_dir_string+self.plot2d_file.replace(".csv",
                                                                        ".pdf")
        # Save plot on pdf file (or .tiff, .jpg, .png)
        plt.savefig(plot_file, dpi=self.plot2d_dpi)

        # Show plot
        plt.show()

    # Define filter_csv_xtal() method
    def filter_csv_xtal(self,file_in):
        """Method eliminate lines with nan data"""

        # Set up an empty string
        data_out = ""

        # Try to open file_in
        try:
            file2open = self.project_dir_string+file_in
            fo_filter = open(file2open,"r")
            csv_filter = csv.reader(fo_filter)

            # Looping through csv_filter
            for line in csv_filter:
                part_line = str(line[10:])
                aux_line = str(line)

                # Some editing
                aux_line = str(aux_line).replace("[","")
                aux_line = aux_line.replace("]","")
                aux_line = aux_line.replace("'","")
                aux_line = aux_line.replace(" ,",",")
                aux_line = aux_line.replace(", ",",")
                aux_line = aux_line.replace("\n","")

                # Check if nan and ND are present
                if "nan" in part_line:
                    pass
                else:
                    data_out += aux_line+"\n"

            # Close file
            fo_filter.close()

        except IOError:
            # Show message
            msg_out = "I can't find "+file2open+" file!"
            msg_out += " finishing the Filter Data request!"
            print(msg_out)

        # Open a new file
        fo_filter = open(file2open,"w")

        # Some editing
        data_out = data_out.replace(" ,",",")
        data_out = data_out.replace(", ",",")

        # Write filtered data
        fo_filter.write(data_out)

        # Close file
        fo_filter.close()

        # Show message
        msg_out = "\nData filtered!"
        print(msg_out)

    # Define joblib_model2() methods
    def joblib_model2(self,csv_file_in,mlr_method):
        """Method to apply joblib models in a loop"""

        # Feature	r	p-value1	r2	rho	p-value2	MSE	RMSE	RSS	MAE	R2	DOME	EDOMEr2	EDOMErho	EDOME
        # Set up header
        stats_out  = "Method,r,p-value(r),r2,rho,p-value(rho),MSE,RMSE,"
        stats_out += "RSS,MAE,R2,DOME,EDOMEr2,EDOMErho,EDOME\n"

        # Invoke read_it function
        bind_in = b_aff.read_it(self.project_dir_string)

        # Call target_variable function (WFA 2023/08/04)
        exp_label = target_var.read_it()

        # Show message
        print("\nAdding column method: ",mlr_method)

        # Assign variables related to the method strings
        model_in = "models/model_"+mlr_method+".joblib"
        new_label = mlr_method

        # Instantiate an object of JoblibModel() class WFA 2023/08/07
        pred = ML_APPLY.JoblibModel(self.project_dir_string,model_in,new_label)

        # Invoke bundle() method WFA 2023/08/07
        results = pred.bundle(csv_file_in,exp_label)

        # Add results
        stats_out += results

        # Open a new file
        file2create =  self.project_dir_string+"models/"
        file2create += csv_file_in.replace(".csv","_")+mlr_method+".csv"
        fo_stats = open(file2create,"w")

        # Write stats_out
        fo_stats.write(stats_out)

        # Close file
        fo_stats.close()

    # Define data_scaling() method
    def data_scaling(self,dir_in,data_file_in):
        """Method to carry out scaling of the dataset"""

        # Scaling
        # preprocess data for machine learning modeling
        #
        # Instantiate an object of Pre_proc() class
        data1 = scaling.Pre_proc(self.program_root,dir_in,data_file_in)

        # Invoke bundle() method
        data1.bundle()

        # Show message
        msg_out = "Finished the \"Data preprocessing with Scikit-Learn "
        msg_out += "\" request!"
        print(msg_out)

    # Define randomize1() method
    def randomize1(self,dir_in,data_file_in,par_in):
        """Method to randomize PDB access codes"""

        # Part to randomly select PDBs for training and test datasets for
        # machine learning modeling for crystal structures
        #
        # Read regression methods (mlr_method) in self.mlregmp y_in
        # (e.g., ml_par.csv).
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through input file
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "test_size_in":
                test_size_in = float(handle_hash("str",str(line[1])))
            elif line[0] == "seed_in":
                seed_in = int(handle_hash("str",str(line[1])))

        # Close file
        fo.close()

        # Instantiate an object of Dataset() class
        d1 = sp.Dataset(dir_in,data_file_in," ",test_size_in,seed_in)

        # Invoke random_pdb() method
        d1.random_pdb()

        # Show message
        msg_out = "Finished the \"Generate Training and Test Sets for PDBs"
        msg_out += "\" request!"
        print(msg_out)

    # Define randomize2() method
    def randomize2(self,dir_in,data_file_in,par_in):
        """Method to randomize datasets"""

        # Part to randomly select PDBs for training and test datasets for
        # machine learning modeling for crystal structures
        #
        # Read regression methods (mlr_method) in self.mlregmp y_in
        # (e.g., ml_par.csv).
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through input file
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "test_size_in":
                test_size_in = float(handle_hash("str",str(line[1])))
            elif line[0] == "seed_in":
                seed_in = int(handle_hash("str",str(line[1])))

        # Close file
        fo.close()

        # Part to generate training and test datasets for machine learning
        # modeling using crystal structures

        # Instantiate an object of Dataset() class
        d2 = sp.Dataset(dir_in,data_file_in," ",test_size_in,seed_in)

        # Invoke read_pdb_access_codes() method
        d2.read_pdb_access_codes()

        # Invoke generate() method
        d2.generate()

    # Define randomize3() method
    def randomize3(self,dir_in,data_file_in,par_in):
        """Method to select datasets (user-defined pdb_codes_test_set.csv and
        pdb_codes_training_set.csv)"""

        # Part to select PDBs for training and test datasets for
        # machine learning modeling for crystal structures
        #
        # Read regression methods (mlr_method) in self.mlregmp y_in
        # (e.g., ml_par.csv).
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through input file
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "test_size_in":
                test_size_in = float(handle_hash("str",str(line[1])))
            elif line[0] == "seed_in":
                seed_in = int(handle_hash("str",str(line[1])))

        # Close file
        fo.close()

        # Part to generate training and test datasets for machine learning
        # modeling using crystal structures
        test_size_in = 0.3  # Only to have an input. It is not going to use it
        seed_in = 271828    # Only to have an input. It is not going to use it

        # Instantiate an object of Dataset() class
        d3 = sp.Dataset(dir_in,data_file_in," ",test_size_in,seed_in)

        # Invoke read_pdb_access_codes() method
        d3.read_pdb_access_codes()

        # Invoke generate() method
        d3.generate()

    # Define filter_data() method
    def filter_data(self,dir_in,data_file_in):
        """Method to filter datasets"""

        # Checking whether /backup folder exists
        my_backup_path = dir_in+"backup/"
        is_exist = os.path.exists(my_backup_path)
        print("\nChecking whether the specified path ",my_backup_path,
        "is an existing directory or not.")

        if is_exist:
            print("\nI've found ",my_backup_path," directory!")
        else:
            os.mkdir(my_backup_path)
            print("\nDirectory '% s' created" % my_backup_path)

        # Call filter_csv_xtal() method
        self.filter_csv_xtal(data_file_in)

        # Set up training set file
        training_sf_file_in = data_file_in.replace(".csv","_training.csv")

        # Set up test set file
        test_sf_file_in = data_file_in.replace(".csv","_test.csv")

        # Call filter_csv_xtal() method
        self.filter_csv_xtal(training_sf_file_in)

        # Call filter_csv_xtal() method
        self.filter_csv_xtal(test_sf_file_in)

        # Show message
        msg_out = "Finished the \"Filter Data Sets "
        msg_out += "\" request!"
        print(msg_out)

    # Define stats_a() method
    def stats_a(self,dir_in,data_file_in,par_in,str2add):
        """Method to carry out statistical analysis of features"""

        # Set up training set file
        data_file_in = data_file_in.replace(".csv","_training.csv")

        # Statistical Analysis for training set
        #
        # Instantiate an object of Stats class
        metrics1 = regression_metrics.Stats(self.program_root,dir_in,par_in,
                                            data_file_in,str2add)

        # Invoke read_stats_in() method
        metrics1.read_stats_in()

        # Invoke read_data() method
        metrics1.read_data()

        # Invoke bundle() method
        metrics1.bundle()

        # Set up test set file
        data_file_in = data_file_in.replace("_training.csv","_test.csv")

        # Statistical Analysis for test set
        #
        # Instantiate an object of Stats class
        metrics2 = regression_metrics.Stats(self.program_root,dir_in,par_in,
                                            data_file_in,str2add)

        # Invoke read_stats_in() method
        metrics2.read_stats_in()

        # Invoke read_data() method
        metrics2.read_data()

        # Invoke bundle() method
        metrics2.bundle()

        # Show message
        msg_o = "\n\nMetrics partially based on: Walsh I, "
        msg_o += "Fishman D, Garcia-Gasulla D, Titma T, Pollastri G; ELIXIR"
        msg_o += " Machine Learning Focus Group; Harrow J, Psomopoulos "
        msg_o += "FE, Tosatto SCE. DOME: recommendations for supervised "
        msg_o += "machine learning validation in biology. Nat Methods. 2021"
        msg_o += " Oct;18(10):1122-1127. \n"
        print(msg_o)

        # Show message
        msg_out = "Finished the \"Bivariate Analysis "
        msg_out += "\" request!"
        print(msg_out)

    # Define regression() method
    def regression(self,dir_in,data_file_in,par_in):
        """Method to generate regression models"""

        # Set up training set file
        data_file_in = data_file_in.replace(".csv","_training.csv")

        # Set up empty list
        list_of_mlr_methods = []

        # Read regression methods (mlr_method) in par_in (e.g., ml_par.csv)
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through input file to get mlr_methods
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                list_of_mlr_methods.append(mlr_method_in)

        # Close file
        fo.close()

        # For ML_ACCESS
        # Instantiate an object of GATE() class
        model = ML_ACCESS.GATE(self.program_root,dir_in,par_in,data_file_in)

        # Regression loop
        # Looping through list_of_mlr_methods
        for mlr_method in list_of_mlr_methods:

            # Show message
            print("Running method "+mlr_method+"...")

            # Invoke read_input() method
            model.read_input(mlr_method)

            # Invoke select_features() method
            model.select_features()

            # Invoke write_features()
            model.write_features()

            # Invoke generate() method
            model.generate()

        # Show message
        msg_out = "Finished the \"Regression Analysis "
        msg_out += "\" request!"
        print(msg_out)

    # Define apply_models() method
    def apply_models(self,dir_in,data_file_in,par_in_1,par_in_2):
        """Function to apply regression models"""

        # Try to open par_in_1 file (e.g., ml.csv)
        try:
            file2open = self.program_root+"misc/data/"+par_in_1
            fo_ml_in = open(file2open,"r")
            csv_ml_in = csv.reader(fo_ml_in)

            # Set up msg_out
            msg_out = "Available Regression Methods:\n"

            # Looping through csv_ml_in
            for line in csv_ml_in:
                if "#" not in str(line):
                    msg_out += str(line[0])+"\n"

            # Show message
            print(msg_out)

            # Close file
            fo_ml_in.close()

        # Handle IOError exception
        except IOError:
            print("\nIOError! I can't find "+file2open+" file!")

        # Set up training set file
        training_sf_file_in = data_file_in.replace(".csv","_training.csv")

        # Set up test set file
        test_sf_file_in = data_file_in.replace(".csv","_test.csv")

        # Set up an empty list
        all_mlr_methods = []

        # Read regression methos (mlr_method) in par_in_2 (e.g., ml_par.csv)
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in_2
            fo_ml_par = open(file2open,"r")
            csv_ml_par = csv.reader(fo_ml_par)
        except IOError:
            print("\nIOError! I can't find "+file2open+"!")

        # Looping through input file to get mlr_methods
        for line in csv_ml_par:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                all_mlr_methods.append(mlr_method_in)

        # Close file
        fo_ml_par.close()

        # Looping through regression methods
        for method2apply in all_mlr_methods:

            # Call joblib_model2() method for training set
            self.joblib_model2(training_sf_file_in,method2apply)

            # Call joblib_model2() method for test set
            self.joblib_model2(test_sf_file_in,method2apply)

        # Show message
        msg_out = "Finished the \"Apply Regression Model "
        msg_out += "\" request!"
        print(msg_out)

    # Define prep_inputs() methods
    def prep_inputs(self,par_in):
        """Method to prepare stats_01.csv, stats_02.csv, and  files.
        This method reads misc/data/exclude.csv file to get the labels not
        to be used as features for future statistical analysis and for
        regression modeling"""

        # Try to open exclude.csv
        try:
            file2open = self.program_root+"misc/data/exclude.csv"
            fo_exclude = open(file2open,"r")
            csv_exclude = csv.reader(fo_exclude)
        except IOError:
            msg_out = "\nIOError I can't find "+file2open+"!"
            print(msg_out)
            return

        # Set up an empty lists
        excluded_features = []
        selected_features = []
        ml_reg_methods = []

        # looping through csv_exclude
        for line in csv_exclude:
            for line1 in line:
                excluded_features.append(line1)

        # Close file
        fo_exclude.close()

        # Get binding affinity
        bind_in = self.target_in.replace("p","")

        # Try to open bind_####.csv file
        try:
            file2open = self.project_dir_string+"bind_"+bind_in+".csv"
            fo_bind = open(file2open,"r")
            csv_bind = csv.reader(fo_bind)
        except IOError:
            msg_out = "\nIOError I can't find "+file2open+"!"
            print(msg_out)
            return

        # Looping through csv_bind
        for line in csv_bind:
            for line1 in line:
                if line1 not in excluded_features:
                    selected_features.append(line1.strip())
            break

        # Close file
        fo_bind.close()

        # Create stats_01.csv file
        file2create_01 = self.program_root+"misc/data/stats_01.csv"
        fo_stats_01 = open(file2create_01,"w")

        # Set up string_out
        string_out = "# Define parameters for statistical analysis\n"
        string_out += "# Define string header with experimental data\n"
        string_out += "exp_string,"+self.target_in+"\n"
        string_out += "# Define features\n"
        string_out += "n_features_in,"+str(len(selected_features))+"\n"
        string_out += "features_in"
        for line in selected_features:
            string_out += ","+str(line)

        # Write content into stats_01.csv file
        fo_stats_01.write(string_out)

        # Close file
        fo_stats_01.close()

        # Read regression methods (mlr_method) in par_in (e.g., ml_par.csv)
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through input file to get mlr_methods
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                selected_features.append(mlr_method_in)
                ml_reg_methods.append(mlr_method_in)

        # Close file
        fo.close()

        # Create stats_02.csv file
        file2create = self.program_root+"misc/data/stats_02.csv"
        fo_stats_02 = open(file2create,"w")

        # Set up string_out
        string_out = "# Define parameters for statistical analysis\n"
        string_out += "# Define string header with experimental data\n"
        string_out += "exp_string,"+self.target_in+"\n"
        string_out += "# Define features\n"
        string_out += "n_features_in,"+str(len(selected_features))+"\n"
        string_out += "features_in"
        for line in selected_features:
            string_out += ","+str(line)

        # Write content for stats_02.csv file
        fo_stats_02.write(string_out)

        # Close file
        fo_stats_02.close()

        # Create ml_par.csv
        file2create = self.program_root+"misc/data/ml_par.csv"
        fo_ml_par = open(file2create,"w")

        # Set up string_out
        string_out = "# Set up preprocessing method from scikit-learn\n"
        string_out += "preprocessing,"+self.preprocessing_in+"\n"
        string_out += "# Set up machine-learning parameter file\n"
        string_out += "ml_parameters,"+self.ml_parameters_in+"\n"
        string_out += "# Set up input scoring function file\n"
        string_out += "scoring_function_file,"+self.scoring_function_file_in
        string_out += "\n# Set up input parameters\n"
        string_out += "n_features,"+str(self.s_n_features_in)+"\n"
        string_out += "features_in"

        # Looping through self.s_features_in
        for f in self.s_features_in:
            string_out += ","+f

        string_out += "\ntarget_in,"+self.target_in+"\n"
        string_out += "test_size_in,"+str(self.test_size_in)+"\n"
        string_out += "seed_in,"+str(self.seed_in)+"\n"
        string_out += "# Set up regression methods \n"

        # Looping through ml_reg_methods
        for line in ml_reg_methods:
            string_out += "mlr_method,"+str(line)+"\n"

        # Write content for stats_02.csv file
        fo_ml_par.write(string_out)

        # Close file
        fo_ml_par.close()

    # Define prep_ml_par() method
    def prep_ml_par(self,par_in,model_features):
        """Method to prepare ml_pav.csv file for a given set of festures"""

        # Set up empty lists
        #selected_features = []
        ml_reg_methods = []

        # Read regression methods (mlr_method) in par_in (e.g., ml_par.csv)
        # Try to open mlr_method
        try:
            file2open = self.program_root+"misc/data/"+par_in
            fo = open(file2open,"r")
            csv_in = csv.reader(fo)
        except IOError:
            sys.exit("\nIOError! I can't find "+file2open+"!")

        # Looping through input file to get mlr_methods
        for line in csv_in:
            if "#" in line[0]:
                continue
            elif line[0] == "mlr_method":
                mlr_method_in = handle_hash("str",str(line[1]))
                #selected_features.append(mlr_method_in)
                ml_reg_methods.append(mlr_method_in)

        # Close file
        fo.close()

        # Create ml_par.csv
        file2create = self.program_root+"misc/data/"+par_in
        fo_ml_par = open(file2create,"w")

        # Set up string_out
        string_out = "# Set up preprocessing method from scikit-learn\n"
        string_out += "preprocessing,"+self.preprocessing_in+"\n"
        string_out += "# Set up machine-learning parameter file\n"
        string_out += "ml_parameters,"+self.ml_parameters_in+"\n"
        string_out += "# Set up input scoring function file\n"
        string_out += "scoring_function_file,"+self.scoring_function_file_in
        string_out += "\n# Set up input parameters\n"
        string_out += "n_features,"+str(self.s_n_features_in)+"\n"

        string_out += "features_in"
        # Looping through model_features
        for f in model_features:
            string_out += ","+f

        string_out += "\ntarget_in,"+self.target_in+"\n"
        string_out += "test_size_in,"+str(self.test_size_in)+"\n"
        string_out += "seed_in,"+str(self.seed_in)+"\n"
        string_out += "# Set up regression methods \n"

        # Looping through ml_reg_methods
        for line in ml_reg_methods:
            string_out += "mlr_method,"+str(line)+"\n"

        # Write content for stats_02.csv file
        fo_ml_par.write(string_out)

        # Close file
        fo_ml_par.close()

    # Define get_features() method
    def get_features(self,dir_in,data_file_in,par_in,data4criterion,
                        x_n_features_in,x_n_set):
        """Method to get features to be used to explore the scoring function
        space trying different sets of features. The selection is based on the
        criterion and the number of features defined in x_n_features"""

        # Import section
        import math

        # Try to open "_test_stats_analysis_features.csv" or
        # "_training_stats_analysis_features.csv"
        file2open = data_file_in.replace(".csv",
                        "_"+data4criterion+"_stats_analysis_features.csv")
        try:
            fo_features = open(dir_in+file2open,"r")
            csv_features = csv.reader(fo_features)
        except IOError:
            msg_out = "\nIOError I can't find "+file2open+"!"
            print(msg_out)
            return

        # Set up an empty lists
        features_out = []
        models_out = []
        number_list = []
        self.mega_list = [] # It keeps a list of lists where each list holds
                            # a set of features

        # Set up an empty strings
        best_model_line_test = ""
        best_model_line_training = ""

        # Looping through csv_features first line
        for line in csv_features:
            break

        # Looping through csv_features
        i = 0
        for line in csv_features:
            if i < x_n_set:
                if "Affinity(kcal/mol)" not in str(line):
                    features_out.append(line[0].strip())
                    number_list.append(i)
                    i += 1
            else:
                break

        # Close file
        fo_features.close()

        # Show features
        print("\nSelected features for modeling: ",features_out)
        print("Number of features: ",len(features_out))

        # Show combination
        msg_out = "\n\nMLRegMPy will generate : "
        msg_out += str(math.comb(x_n_set, x_n_features_in))+" models!"
        print (msg_out)

        # Invoke mega_loop() method
        self.mega_loop(dir_in,number_list,x_n_features_in,features_out)

    # Define get_features_user_defined() method
    def get_features_user_defined(self,dir_in,ud_n_features_in,ud_features_in,
                                ud_n_set):
        """Method to get features to be used to explore the scoring function
        space trying different sets of features. The selection is defined
        by the user in ud_features_in, ud_n_set_in, and ud_n_features_in"""

        # Import section
        import math

        # Set up an empty list
        self.mega_list = [] # It keeps a list of lists where each list holds
                            # a set of features

        # Show features
        print("\nSelected features for modeling: ",ud_features_in)
        print("Number of features: ",len(ud_features_in))

        # Show combination
        msg_out = "\n\nMLRegMPy will generate : "
        msg_out += str(math.comb(ud_n_set, ud_n_features_in))+" models!"
        print (msg_out)

        # Set up a list of numbers
        number_list = list(range(0,ud_n_set))

        # Invoke mega_loop() method
        self.mega_loop(dir_in,number_list,ud_n_features_in,ud_features_in)

    # Define mega_loop() method
    def mega_loop(self,dir_in,number_list,n,features):
        """Loop to geneate combinations required for explore and user-defined
        options"""

        # Import section
        import itertools

        # Loop for regression models
        # Select set of features
        # Source: https://www.digitalocean.com/community/tutorials/permutation-and-combinatios-in-python
        com_set = itertools.combinations(number_list,n)

        # Assign zero to count_models
        count_models = 0

        # Set up header string
        lines_out = "Models"
        for k in range(n):
            lines_out += ","+"feature "+str(k)

        # Jump line
        lines_out += "\n"

        # This a major loop to get all features to be used in the generation
        # regeression models.
        # Looping through combinations (com_set)
        for i in com_set:
            list_i = list(i)

            # Select features for model
            iteration_features = []

            # Looping through list_i
            for j in list_i:
                iteration_features.append(features[j])

            # Update self.mega_list
            self.mega_list.append(iteration_features)

            # Show features
            print("\nRegression for features: ",iteration_features)

            # Update count_models
            count_models += 1

            # Create string with count_models
            count_models_str = fix_str_01(count_models,6,"0")

            # Update lines_out
            lines_out += count_models_str

            # Looping through iteration_features
            for k in range(n):
                lines_out += ","+iteration_features[k]

            # Jump line
            lines_out += "\n"

        # Open features.csv file
        fo_csv_out = open(dir_in+"features.csv","w")

        # Write lines_out
        fo_csv_out.write(lines_out)

        # Close file
        fo_csv_out.close()

    # Define sort_csv() method
    def sort_csv(self,dir_in,data_file_in,data_file_out,criterion):
        """Method to sort a csv file. The sorting is based on a given
        criteion"""

        # Import section
        import pandas as pd

        # Check criterion
        list_of_criteria = ["r2","rho","RMSE","MAE","R2","DOME","EDOMEr2",
                            "EDOMErho","EDOME"]
        if criterion not in list_of_criteria:
            msg_out = "\n\nIOError! Not specified keyword criterion_in!\n"
            msg_out += "Valid keywords: r2, rho, RMSE, MAE, R2, DOME, EDOMEr2, "
            msg_out += "EDOMErho, and EDOME"
            sys.exit(msg_out)

        # Source: https://www.usepandas.com/csv/sort-csv-data-by-column
        # Read in your .csv files as dataframes
        # df is a common standard for naming a dataframe. You can
        # name them something more descriptive as well.
        # Using a descriptive name is helpful when you are dealing
        # with multiple .csv files.
        df = pd.read_csv(dir_in+data_file_in)

        # Sort r2 and rho descending
        if criterion == "r2" or criterion == "rho":
            # the .sort_values method returns a new dataframe, so make sure to
            # assign this to a new variable.
            sorted_df = df.sort_values(by=[criterion], ascending=False)
        else:
            # the .sort_values method returns a new dataframe, so make sure to
            # assign this to a new variable.
            sorted_df = df.sort_values(by=[criterion], ascending=True)

        # Index=False is a flag that tells pandas not to write
        # the index of each row to a new column. If you'd like
        # your rows to be numbered explicitly, leave this as
        # the default, True
        sorted_df.to_csv(dir_in+data_file_out, index=False)

    # Define summarize() method
    def summarize(self,dataset_type,ml_criterion):
        """Method to summarize regression results"""

        # Set up empty string to get the best regression model for each
        # iteration
        best_model_lines_out = ""

        # Looping through generated models
        for count_models,line in enumerate(self.mega_list):

            # Set up features_string
            features_string = str(line)
            features_string = features_string.replace("[","")
            features_string = features_string.replace("]","")
            features_string = features_string.replace("'","")
            features_string = features_string.replace(",","")

            # Create string with count_models
            count_models_str = fix_str_01(count_models,6,"0")

            # Try to open scores4xtal_#####_stats_analysis_models_####.csv
            data_in = self.sf_file_in.replace(".csv",
                                "_"+dataset_type+"_stats_analysis_models.csv")
            data_out = data_in.replace("_models.csv",
                                        "_models_"+count_models_str+".csv")
            try:
                file2open = self.project_dir_string+data_out
                fo_models = open(file2open,"r")
                csv_models = csv.reader(fo_models)
            except IOError:
                msg_out = "\nIOError I can't find "+file2open+"!"
                print(msg_out)
                return

            # Looping through csv_models first line
            for line in csv_models:
                break

            # Looping through csv_models second line
            for data in csv_models:
                best_model_lines_out += features_string

                # Looping through data
                for data1 in data:
                    best_model_lines_out +=","+data1.strip()
                break

            # Jump a line
            best_model_lines_out += "\n"

            # Close file
            fo_models.close()

        # Create an output file
        fo = open(self.project_dir_string+"models_"+dataset_type+"_set.csv","w")

        # Write header
        header = "Model features,Methods,r,p-value1,r2,rho,p-value2,MSE,"
        header += "RMSE,RSS,MAE,R2,DOME,EDOMEr2,EDOMErho,EDOME\n"
        fo.write(header)

        # Write results
        fo.write(best_model_lines_out)

        # Close file
        fo.close()

        # Invoke sort_csv() method
        # outputs: update scores4xtal_test_stats_analysis_features.csv
        data_in = "models_"+dataset_type+"_set.csv"
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,ml_criterion)

    # Define single() method
    def single(self):
        """Method to generate a regression method for a specified set of
        features defined in mlr.in file. It is invoked when specified single
        keyword (e.g., python3 mlr.py mlr.in single > mlr.log &)"""

        # Here we got them all for a single regression model
        #
        # Invoke prep_inputs() method
        # output: stats_01.csv, stats_02.csv, and ml_par.csv
        self.prep_inputs(self.mlregmpy_in)

        # Invoke data_scaling() method
        # output: scores4xtal.csv
        self.data_scaling(self.project_dir_string,self.sf_file_in)

        # WFA 2023/10/19
        # To handle random-generated training and test sets
        if self.test_size_in > 0.0 and self.test_size_in < 1.0:

            # Invoke randomize1() method
            # outputs: pdb_codes_test_set.csv and pdb_codes_training_set.csv
            self.randomize1(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

            # Invoke randomize2() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize2(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # To handle user-defined training and test sets
        else:

            # Invoke randomize3() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize3(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # Invoke filter_data() method
        # output: update scores4xtal_test.csv and scores4xtal_training.csv
        self.filter_data(self.project_dir_string,self.sf_file_in)

        # Invoke stats_a() method
        # outputs: scores4xtal_test_stats_analysis_features.csv and
        # scores4xtal_training_stats_analysis_features.csv
        self.stats_a(self.project_dir_string,self.sf_file_in,"stats_01.csv",
                    "_stats_analysis_features")

        # Invoke sort_csv() method
        # outputs: update scores4xtal_test_stats_analysis_features.csv
        data_in = self.sf_file_in.replace(".csv",
                                        "_test_stats_analysis_features.csv")
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,
                    self.criterion_in)

        # Invoke sort_csv() method
        # outputs: update scores4xtal_training_stats_analysis_features.csv
        data_in = self.sf_file_in.replace(".csv",
                                    "_training_stats_analysis_features.csv")
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,
                        self.criterion_in)

        # Invoke regression() method
        # outputs: folder models
        self.regression(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # Invoke apply_models() method
        # output: columns with regression predictions added to
        # scores4xtal_test.csv and scores4xtal_training.csv
        self.apply_models(self.project_dir_string,self.sf_file_in,
                        self.ml_parameters_in,self.mlregmpy_in)

        # Invoke stats_a() method
        # outputs: scores4xtal_test_stats_analysis_models.csv and
        # scores4xtal_training_stats_analysis_models
        self.stats_a(self.project_dir_string,self.sf_file_in,"stats_02.csv",
                    "_stats_analysis_models")

        # Invoke sort_csv() method
        # outputs: update scores4xtal_test_stats_analysis_features.csv
        data_in = self.sf_file_in.replace(".csv",
                                        "_test_stats_analysis_models.csv")
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,
                        self.ml_criterion_in)

        # Invoke sort_csv() method
        # outputs: update scores4xtal_training_stats_analysis_features.csv
        data_in = self.sf_file_in.replace(".csv",
                                    "_training_stats_analysis_models.csv")
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,
                        self.ml_criterion_in)

    # Define explore() method
    def explore(self):
        """Method to generate combination of top-ranked features to create
        several regression models. It defines models with a fixed number of
        features (x_n_features_in). It carries out a combination of features.
        We have C(x_n_set,x_n_features_in) combinations of set of features."""

        # Here we got them all for multiple regression models
        #
        # Invoke prep_inputs() method
        # output: stats_01.csv, stats_02.csv, and ml_par.csv
        self.prep_inputs(self.mlregmpy_in)

        # Invoke data_scaling() method
        # output: scores4xtal.csv
        self.data_scaling(self.project_dir_string,self.sf_file_in)

        # WFA 2023/10/19
        # To handle random-generated training and test sets
        if self.test_size_in > 0.0 and self.test_size_in < 1.0:

            # Invoke randomize1() method
            # outputs: pdb_codes_test_set.csv and pdb_codes_training_set.csv
            self.randomize1(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

            # Invoke randomize2() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize2(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # To handle user-defined training and test sets
        else:

            # Invoke randomize3() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize3(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # Invoke filter_data() method
        # output: No new output only updates
        self.filter_data(self.project_dir_string,self.sf_file_in)

        # Invoke stats_a() method
        # outputs: scores4xtal_test_stats_analysis_features.csv and
        # scores4xtal_training_stats_analysis_features.csv
        self.stats_a(self.project_dir_string,self.sf_file_in,"stats_01.csv",
                    "_stats_analysis_features")

        # Invoke sort_csv() method
        # outputs: update scores4xtal_test_stats_analysis_features.csv
        data_in = self.sf_file_in.replace(".csv",
                                        "_test_stats_analysis_features.csv")
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,
                    self.criterion_in)

        # Invoke get_features() method
        self.get_features(self.project_dir_string,self.sf_file_in,
                    self.mlregmpy_in,
                    self.data4criterion_in,self.x_n_features_in,
                    self.x_n_set_in)

        # Each iteration of the following loop generates a regression
        # model. We vary the features not the number of features.
        #
        # Looping through self.mega_list
        for count_models, line in enumerate(self.mega_list):

            # Create string with count_models
            count_models_str = fix_str_01(count_models,6,"0")

            # Invoke prep_ml_par() method
            # output: ml_par.csv
            self.prep_ml_par(self.mlregmpy_in,line)

            # Invoke regression() method
            # output: folder models
            self.regression(self.project_dir_string,self.sf_file_in,
                            self.mlregmpy_in)

            # Invoke apply_models() method
            # outputs: columns with regression predictions added to
            # scores4xtal_test.csv and scores4xtal_training.csv
            self.apply_models(self.project_dir_string,self.sf_file_in,
                                self.ml_parameters_in,self.mlregmpy_in)

            # Invoke stats_a() method
            # outputs: scores4xtal_test_stats_analysis_models.csv and
            # scores4xtal_training_stats_analysis_models
            self.stats_a(self.project_dir_string,self.sf_file_in,
                        "stats_02.csv","_stats_analysis_models")

            # Invoke sort_csv() method
            # outputs: update scores4xtal_test_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                            "_test_stats_analysis_models.csv")
            data_out = data_in.replace("_models.csv",
                                           "_models_"+count_models_str+".csv")
            self.sort_csv(self.project_dir_string,data_in,data_out,
                                self.ml_criterion_in)

            # Invoke sort_csv() method
            # output: update scores4xtal_training_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                        "_training_stats_analysis_models.csv")
            data_out = data_in.replace("_models.csv",
                                           "_models_"+count_models_str+".csv")
            self.sort_csv(self.project_dir_string,data_in,data_out,
                                self.ml_criterion_in)

            # Copy scores4xtal_test.csv and scores4xtal_trainig.csv
            # before adding columns with regression results.
            file2copy_01 = self.sf_file_in.replace(".csv","_test.csv")
            aux_str_01 = "_test_"+count_models_str+".csv"
            file2copy_01a = self.sf_file_in.replace(".csv",aux_str_01)
            src_path_01 = self.project_dir_string+file2copy_01
            dst_path_01 = self.project_dir_string+file2copy_01a
            shutil.copy(src_path_01, dst_path_01)

            file2copy_02 = self.sf_file_in.replace(".csv","_training.csv")
            aux_str_02 = "_training_"+count_models_str+".csv"
            file2copy_02a = self.sf_file_in.replace(".csv",aux_str_02)
            src_path_02 = self.project_dir_string+file2copy_02
            dst_path_02 = self.project_dir_string+file2copy_02a
            shutil.copy(src_path_02, dst_path_02)

            # This step is necessary to get rid of the regression
            # results columns
            # Invoke randomize2() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize2(self.project_dir_string,self.sf_file_in,
                                self.mlregmpy_in)

            # Clean models folder
            # https://www.techiedelight.com/delete-all-files-directory-python/
            dir = self.project_dir_string+"models"
            for files in os.listdir(dir):
                path = os.path.join(dir, files)
                try:
                    shutil.rmtree(path)
                except OSError:
                    os.remove(path)

        # Out of the loop. Now to get best models for each set of features
        #
        # Invoke summarize() method
        self.summarize("test",self.ml_criterion_in)

        # Invoke summarize() method
        self.summarize("training",self.ml_criterion_in)

    # Define explore_user_defined() method
    def explore_user_defined(self):
        """Method to generate combination of user-defined features to generate
        several regression models. It defines models with a fixed number of
        features."""

        # Here we got them all for multiple regression models
        #
        # Invoke prep_inputs() method
        # output: stats_01.csv, stats_02.csv, and ml_par.csv
        self.prep_inputs(self.mlregmpy_in)

        # Invoke data_scaling() method
        # output: scores4xtal.csv
        self.data_scaling(self.project_dir_string,self.sf_file_in)

        # WFA 2023/10/19
        # To handle random-generated training and test sets
        if self.test_size_in > 0.0 and self.test_size_in < 1.0:

            # Invoke randomize1() method
            # outputs: pdb_codes_test_set.csv and pdb_codes_training_set.csv
            self.randomize1(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

            # Invoke randomize2() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize2(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # To handle user-defined training and test sets
        else:

            # Invoke randomize3() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize3(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # Invoke filter_data() method
        # output: No new output only updates
        self.filter_data(self.project_dir_string,self.sf_file_in)

        # Invoke stats_a() method
        # outputs: scores4xtal_test_stats_analysis_features.csv and
        # scores4xtal_training_stats_analysis_features.csv
        self.stats_a(self.project_dir_string,self.sf_file_in,"stats_01.csv",
                    "_stats_analysis_features")

        # Invoke sort_csv() method
        # outputs: update scores4xtal_test_stats_analysis_features.csv
        data_in = self.sf_file_in.replace(".csv",
                                        "_test_stats_analysis_features.csv")
        data_out = data_in
        self.sort_csv(self.project_dir_string,data_in,data_out,
                    self.criterion_in)

        # Invoke get_features_user_defined() method
        self.get_features_user_defined(self.project_dir_string,
                                        self.ud_n_features_in,
                                        self.ud_features_in,
                                        self.ud_n_set_in)

        # Each iteration of the following loop generates a regression
        # model. We vary the features not the number of features.
        #
        # Looping through self.mega_list
        for count_models, line in enumerate(self.mega_list):

            # Create string with count_models
            count_models_str = fix_str_01(count_models,6,"0")

            # Invoke prep_ml_par() method
            # output: ml_par.csv
            self.prep_ml_par(self.mlregmpy_in,line)

            # Invoke regression() method
            # output: folder models
            self.regression(self.project_dir_string,self.sf_file_in,
                            self.mlregmpy_in)

            # Invoke apply_models() method
            # outputs: columns with regression predictions added to
            # scores4xtal_test.csv and scores4xtal_training.csv
            self.apply_models(self.project_dir_string,self.sf_file_in,
                                self.ml_parameters_in,self.mlregmpy_in)

            # Invoke stats_a() method
            # outputs: scores4xtal_test_stats_analysis_models.csv and
            # scores4xtal_training_stats_analysis_models
            self.stats_a(self.project_dir_string,self.sf_file_in,
                        "stats_02.csv","_stats_analysis_models")

            # Invoke sort_csv() method
            # outputs: update scores4xtal_test_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                            "_test_stats_analysis_models.csv")
            data_out = data_in.replace("_models.csv",
                                           "_models_"+count_models_str+".csv")
            self.sort_csv(self.project_dir_string,data_in,data_out,
                                self.ml_criterion_in)

            # Invoke sort_csv() method
            # output: update scores4xtal_training_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                        "_training_stats_analysis_models.csv")
            data_out = data_in.replace("_models.csv",
                                           "_models_"+count_models_str+".csv")
            self.sort_csv(self.project_dir_string,data_in,data_out,
                                self.ml_criterion_in)

            # Copy scores4xtal_test.csv and scores4xtal_trainig.csv
            # before adding columns with regression results.
            file2copy_01 = self.sf_file_in.replace(".csv","_test.csv")
            aux_str_01 = "_test_"+count_models_str+".csv"
            file2copy_01a = self.sf_file_in.replace(".csv",aux_str_01)
            src_path_01 = self.project_dir_string+file2copy_01
            dst_path_01 = self.project_dir_string+file2copy_01a
            shutil.copy(src_path_01, dst_path_01)

            file2copy_02 = self.sf_file_in.replace(".csv","_training.csv")
            aux_str_02 = "_training_"+count_models_str+".csv"
            file2copy_02a = self.sf_file_in.replace(".csv",aux_str_02)
            src_path_02 = self.project_dir_string+file2copy_02
            dst_path_02 = self.project_dir_string+file2copy_02a
            shutil.copy(src_path_02, dst_path_02)

            # This step is necessary to get rid of the regression
            # results columns
            # Invoke randomize2() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize2(self.project_dir_string,self.sf_file_in,
                                self.mlregmpy_in)

            # Clean models folder
            # https://www.techiedelight.com/delete-all-files-directory-python/
            dir = self.project_dir_string+"models"
            for files in os.listdir(dir):
                path = os.path.join(dir, files)
                try:
                    shutil.rmtree(path)
                except OSError:
                    os.remove(path)

        # Out of the loop. Now to get best models for each set of features
        #
        # Invoke summarize() method
        self.summarize("test",self.ml_criterion_in)

        # Invoke summarize() method
        self.summarize("training",self.ml_criterion_in)

    # Define data_preparation4ml() method
    def data_preparation4ml(self):
        """Method to prepare docking simulation data for further application
        of a previously generated machine-learning model"""

        # Here we have all steps to prepare data to be ready for
        # application of a regression model
        #
        # Invoke prep_inputs() method
        # output: stats_01.csv, stats_02.csv, and ml_par.csv
        self.prep_inputs(self.mlregmpy_in)

        # Invoke data_scaling() method
        # output: scores4xtal.csv
        self.data_scaling(self.project_dir_string,self.sf_file_in)

        # Invoke randomize1() method
        # outputs: pdb_codes_test_set.csv and pdb_codes_training_set.csv
        self.randomize1(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # Invoke randomize2() method
        # outputs: scores4xtal_test.csv and scores4xtal_training.csv
        self.randomize2(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        # Invoke filter_data() method
        # output: update scores4xtal_test.csv and scores4xtal_training.csv
        self.filter_data(self.project_dir_string,self.sf_file_in)

    # Define bundle() method
    def bundle(self):
        """Method to run a selected mode"""

        # Select the actions for each mode
        if self.mode_in.upper() == "SINGLE-MODEL":
            # Invoke single() method
            self.single()

        elif self.mode_in.upper() == "EXPLORE-SFS":
            # Invoke explore() method
            self.explore()

        elif self.mode_in.upper() == "USER-DEFINED":
            # Invoke explore_user_defined() method
            self.explore_user_defined()

        elif self.mode_in.upper() == "PREPARE-DATA4ML":
            # Invoke data_preparation4ml() method
            self.data_preparation4ml()

        elif self.mode_in.upper() == "PREP":
            # Invoke prep_inputs() method
            # output: stats_01.csv, stats_02.csv, and ml_par.csv
            self.prep_inputs(self.mlregmpy_in)

        elif self.mode_in.upper() == "SCALING":
            # Invoke data_scaling() method
            # output: scores4xtal.csv
            self.data_scaling(self.project_dir_string,self.sf_file_in)

        elif self.mode_in.upper() == "RANDOM1":
            # Invoke randomize1() method
            # outputs: pdb_codes_test_set.csv and pdb_codes_training_set.csv
            self.randomize1(self.project_dir_string,self.sf_file_in,
                            self.mlregmpy_in)

        elif self.mode_in.upper() == "RANDOM2":
            # Invoke randomize2() method
            # outputs: scores4xtal_test.csv and scores4xtal_training.csv
            self.randomize2(self.project_dir_string,self.sf_file_in,
                            self.mlregmpy_in)

        elif self.mode_in.upper() == "FILTER":
            # Invoke filter_data() method
            # output: update scores4xtal_test.csv and scores4xtal_training.csv
            self.filter_data(self.project_dir_string,self.sf_file_in)

        elif self.mode_in.upper() == "STATS1":
            # Invoke stats_a() method
            # outputs: scores4xtal_test_stats_analysis_features.csv and
            # scores4xtal_training_stats_analysis_features.csv
            self.stats_a(self.project_dir_string,self.sf_file_in,"stats_01.csv",
                    "_stats_analysis_features")

            # Invoke sort_csv() method
            # outputs: update scores4xtal_test_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                        "_test_stats_analysis_features.csv")
            data_out = data_in
            self.sort_csv(self.project_dir_string,data_in,data_out,
                            self.criterion_in)

            # Invoke sort_csv() method
            # outputs: update scores4xtal_training_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                    "_training_stats_analysis_features.csv")
            data_out = data_in
            self.sort_csv(self.project_dir_string,data_in,data_out,
                            self.criterion_in)

        elif self.mode_in.upper() == "REG":
            # Invoke regression() method
            # outputs: folder models
            self.regression(self.project_dir_string,self.sf_file_in,
                        self.mlregmpy_in)

        elif self.mode_in.upper() == "APPLY":
            # Invoke apply_models() method
            # output: columns with regression predictions added to
            # scores4xtal_test.csv and scores4xtal_training.csv
            self.apply_models(self.project_dir_string,self.sf_file_in,
                        self.ml_parameters_in,self.mlregmpy_in)

        elif self.mode_in.upper() == "STATS2":
            # Invoke stats_a() method
            # outputs: scores4xtal_test_stats_analysis_models.csv and
            # scores4xtal_training_stats_analysis_models
            self.stats_a(self.project_dir_string,self.sf_file_in,"stats_02.csv",
                    "_stats_analysis_models")

            # Invoke sort_csv() method
            # outputs: update scores4xtal_test_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                        "_test_stats_analysis_models.csv")
            data_out = data_in
            self.sort_csv(self.project_dir_string,data_in,data_out,
                            self.ml_criterion_in)

            # Invoke sort_csv() method
            # outputs: update scores4xtal_training_stats_analysis_features.csv
            data_in = self.sf_file_in.replace(".csv",
                                    "_training_stats_analysis_models.csv")
            data_out = data_in
            self.sort_csv(self.project_dir_string,data_in,data_out,
                            self.ml_criterion_in)

        elif self.mode_in.upper() == "PLOT":
            # Invoke get_data() method
            self.get_data()

            # Invoke create() method
            self.create()

        else:
            msg_out = "\n\nIOError! Not specified keyword!\n"
            msg_out += "Valid keywords: single-model, explore-sfs, "
            msg_out += "user-defined, prep, scaling, random1, random2, filter, "
            msg_out += "stats1, reg, apply, stats2, and plot"
            print(msg_out)
            return