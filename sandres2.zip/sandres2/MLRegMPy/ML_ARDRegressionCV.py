#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define ARDRegressionCV() class
class ARDRegressionCV(object):
    """Class to carry out ARD Regression
    Automatic Relevance Determination Regression (ARD)

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : ndarray or scipy.sparse matrix, (n_samples, n_features) (data)
        y                       : ndarray, shape (n_samples,) or (n_samples, n_targets)
                                Target. Will be cast to X’s dtype if necessary

    Outputs
       rand_in                  : Random seed (to generate MDM format files)
       model                    : Regression model
       model,model.intercept_   : Independent term in decision function. Set to 0.0 if fit_intercept = False.
       model.coef_              : Coefficients of the regression model (mean of distribution)

    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_ARDRegressionCV() method
    def ml_scikit_ARDRegressionCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.ARDRegression
        Automatic Relevance Determination Regression (ARD)
        """

        # Import packages
        from sklearn.linear_model import ARDRegression
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            sys.exit("I can't find "+file2open+" file! Finishing program execution!")

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.ARDRegression.html
        #
        # string_reg_method = ARDRegression (Automatic Relevance Determination Regression)
        #
        #
        # n_iter: int, default=300
        # Maximum number of iterations.
        #
        # tol: float, default=1e-3
        # Stop the algorithm if w has converged.
        #
        # alpha_1: float, default=1e-6
        # Hyper-parameter : shape parameter for the Gamma distribution prior
        # over the alpha parameter.
        #
        # alpha_2: float, default=1e-6
        # Hyper-parameter : inverse scale parameter (rate parameter) for the
        # Gamma distribution prior over the alpha parameter.
        #
        # lambda_1: float, default=1e-6
        # Hyper-parameter : shape parameter for the Gamma distribution prior
        # over the lambda parameter.
        #
        # lambda_2: float, default=1e-6
        # Hyper-parameter : inverse scale parameter (rate parameter) for the
        # Gamma distribution prior over the lambda parameter.
        #
        # compute_score: bool, default=False
        # If True, compute the objective function at each step of the model.
        #
        # threshold_lambda: float, default=10 000
        # threshold for removing (pruning) weights with high precision from the
        # computation.
        #
        # fit_intercept: bool, default=True
        # whether to calculate the intercept for this model.
        # If set to false, no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # normalize: bool, default=False
        # This parameter is ignored when fit_intercept is set to False. If True,
        # the regressors X will be normalized before
        # regression by subtracting the mean and
        # dividing by the l2-norm. If you wish to standardize, please use
        # sklearn.preprocessing.StandardScaler
        # before calling fit on an estimator with normalize=False.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # verbose: bool, default=False
        # Verbose mode when fitting the model.

        # Show opening message
        line_cv = "with Cross-Validation"
        print("\nAutomatic Relevance Determination Regression "+line_cv)
        print("Regression parameters read from ml.in")

        # Looping through my_csv (ml.in)
        for line in my_csv:
            if line[0].strip() == "ARDRegressionCV":

                # For max_in
                max_in = int(line[1].strip())

                # For tol_in
                tol_in = float(line[2].strip())

                # For alpha_1_in
                alpha_1_in = float(line[3].strip())

                # For alpha_2_in
                alpha_2_in = float(line[4].strip())

                # For lambda_1_in
                lambda_1_in = float(line[5].strip())

                # For lambda_2_in
                lambda_2_in = float(line[6].strip())

                # For compute_score_in
                if line[7].strip() == "True":
                    compute_score_in = True
                elif line[7].strip() == "False":
                    compute_score_in = False
                else:
                    compute_score_in = False
                    print("Unrecognizable input!")

                # For threshold_lambda_in
                threshold_lambda_in = float(line[8].strip())

                # For fit_in
                if line[9].strip() == "True":
                    fit_in = True
                elif line[9].strip() == "False":
                    fit_in = False
                else:
                    fit_in = True
                    print("Unrecognizable input!")

                # For copy_in
                if line[10].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For ver_in
                if line[11].strip() == "True":
                    ver_in = True
                else:
                    ver_in = False

                # For rand_in
                rand_in = int(line[12].strip())

                # For cv_in
                cv_in = int(line[13].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("\nRegression method: ",line[0])
        print("Maximum number of iterations: {}".format(max_in))
        line_out2 = "Stop the algorithm if w has converged (tolerance)"
        print(line_out2+": {:.5e}".format(tol_in))
        print("Hyper-parameter (alpha_1): {:.5e}".format(alpha_1_in))
        print("Hyper-parameter (alpha_2): {:.5e}".format(alpha_2_in))
        print("Hyper-parameter (lambda_1): {:.5e}".format(lambda_1_in))
        print("Hyper-parameter (lambda_2): {:.5e}".format(lambda_2_in))
        print("Compute score at each iteration of the optimization? "+line[7])
        line_out8 = "Threshold for removing (pruning) weights with high "
        line_out8 += "precision from the computation"
        print(line_out8+": {:.5e}".format(threshold_lambda_in))
        print("Fit intercept? "+line[9])
        print("Copy x array? "+line[10])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[13])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of ARDRegression class
        model = ARDRegression(
                n_iter=max_in,                          # n_iter: int, default=300
                tol=tol_in,                             # tol: float, default=1e-3
                alpha_1=alpha_1_in,                     # alpha_1: float, default=1e-6
                alpha_2=alpha_2_in,                     # alpha_2: float, default=1e-6
                lambda_1=lambda_1_in,                   # lambda_1: float, default=1e-6
                lambda_2=lambda_2_in,                   # lambda_2: float, default=1e-6
                compute_score=compute_score_in,         # compute_score: bool, default=False
                threshold_lambda=threshold_lambda_in,   # threshold_lambda: float, default=10 000
                fit_intercept = fit_in,                 # fit_intercept: bool, default=True
                verbose=ver_in                          # verbose: bool, default=False
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_