#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define GradientBoostingRegressor() class
class GradientBoostingRegressor(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_GradientBoostingRegressor() method
    def ml_scikit_GradientBoostingRegressor(self):
        """
        Method to generate a multiple regression model using
        GradientBoostingRegressor
        """

        # Import packages
        from sklearn.ensemble import GradientBoostingRegressor
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.GradientBoostingRegressor.html
        #
        # string_reg_method = GradientBoostingRegressor
        #
        #
        # loss: {"ls","lad","huber","quantile"}, default=’ls’
        # Loss function to be optimized. ‘ls’ refers to least squares
        # regression. ‘lad’ (least absolute deviation) is a highly robust loss
        # function solely based on order information of the input variables.
        # ‘huber’ is a combination of the two. ‘quantile’ allows quantile
        # regression (use alpha to specify the quantile).
        #
        # learning_rate: float, default=0.1
        # Learning rate shrinks the contribution of each tree by learning_rate.
        # There is a trade-off between learning_rate and n_estimators.
        #
        # n_estimators: int, default=100
        # The number of boosting stages to perform. Gradient boosting is fairly
        # robust to over-fitting so a large number usually results in better
        # performance.
        #
        # subsample: float, default=1.0
        # The fraction of samples to be used for fitting the individual base
        # learners. If smaller than 1.0 this results in Stochastic Gradient
        # Boosting. subsample interacts with the parameter n_estimators.
        # Choosing subsample < 1.0 leads to a reduction of variance and an
        # increase in bias.
        #
        # min_samples_split: int or float, default=2
        # The minimum number of samples required to split an internal node:
        # If int, then consider min_samples_split as the minimum number.
        # If float, then min_samples_split is a fraction and
        # ceil(min_samples_split * n_samples) are the minimum number of samples
        # for each split.
        #
        # min_samples_leaf: int or float, default=1
        # The minimum number of samples required to be at a leaf node. A split
        # point at any depth will only be considered if it leaves at least
        # min_samples_leaf training samples in each of the left and right
        # branches. This may have the effect of smoothing the model, especially
        # in regression.
        # If int, then consider min_samples_leaf as the minimum number.
        # If float, then min_samples_leaf is a fraction and
        # ceil(min_samples_leaf * n_samples) are the minimum number of samples
        # for each node.
        #
        # min_weight_fraction_leaf: float, default=0.0
        # The minimum weighted fraction of the sum total of weights
        # (of all the input samples) required to be at a leaf node.
        # Samples have equal weight when sample_weight is not provided.
        #
        # max_depth: int, default=3
        # Maximum depth of the individual regression estimators. The maximum
        # depth limits the number of nodes in the tree. Tune this parameter
        # for best performance; the best value depends on the interaction of
        # the input variables.
        #
        # min_impurity_decrease: float, default=0.0
        # A node will be split if this split induces a decrease of the impurity
        # greater than or equal to this value.
        # The weighted impurity decrease equation is the following:
        # N_t / N * (impurity - N_t_R / N_t * right_impurity
        #            - N_t_L / N_t * left_impurity)
        # where N is the total number of samples, N_t is the number of samples
        # at the current node, N_t_L is the number of samples in the left child,
        # and N_t_R is the number of samples in the right child.
        # N, N_t, N_t_R and N_t_L all refer to the weighted sum, if
        # sample_weight is passed.
        #
        # init: estimator or ‘zero’, default=None
        # An estimator object that is used to compute the initial predictions.
        # init has to provide fit and predict. If ‘zero’, the initial raw
        # predictions are set to zero. By default a DummyEstimator is used,
        # predicting either the average target value (for loss=’ls’), or a
        # quantile for the other losses.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls the random seed given to each Tree estimator at each boosting
        # iteration. In addition, it controls the random permutation of the
        # features at each split (see Notes for more details). It also controls
        # the random spliting of the training data to obtain a validation set
        # if n_iter_no_change is not None. Pass an int for reproducible output
        # across multiple function calls.
        #
        # max_features: {"auto","sqrt","log2"}, int or float, default=None
        # The number of features to consider when looking for the best split:
        # If int, then consider max_features features at each split.
        # If float, then max_features is a fraction and
        # int(max_features * n_features) features are considered at each split.
        # If “auto”, then max_features=n_features.
        # If “sqrt”, then max_features=sqrt(n_features).
        # If “log2”, then max_features=log2(n_features).
        # If None, then max_features=n_features.
        # Choosing max_features < n_features leads to a reduction of variance
        # and an increase in bias.
        # Note: the search for a split does not stop until at least one valid
        # partition of the node samples is found, even if it requires
        # to effectively inspect more than max_features features.
        #
        # alpha: float, default=0.9
        # The alpha-quantile of the huber loss function and the quantile loss
        # function. Only if loss='huber' or loss='quantile'.
        #
        # verbose: int, default=0
        # Enable verbose output. If 1 then it prints progress and performance
        # once in a while (the more trees the lower the frequency). If greater
        # than 1 then it prints progress and performance for every tree.
        #
        # max_leaf_nodes: int, default=None
        # Grow trees with max_leaf_nodes in best-first fashion. Best nodes are
        # defined as relative reduction in impurity. If None then unlimited
        # number of leaf nodes.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit and
        # add more estimators to the ensemble, otherwise, just erase the
        # previous solution.
        #
        # validation_fraction: float, default=0.1
        # The proportion of training data to set aside as validation set for
        # early stopping. Must be between 0 and 1. Only used if n_iter_no_change
        # is set to an integer.
        #
        # n_iter_no_change: int, default=None
        # n_iter_no_change is used to decide if early stopping will be used to
        # terminate training when validation score is not improving. By default
        # it is set to None to disable early stopping. If set to a number, it
        # will set aside validation_fraction size of the training data as
        # validation and terminate training when validation score is not
        # improving in all of the previous n_iter_no_change numbers of
        # iterations.
        #
        # tol: float, default=1e-4
        # Tolerance for the early stopping. When the loss is not improving by
        # at least tol for n_iter_no_change iterations (if set to a number),
        # the training stops.
        #
        # ccp_alpha: non-negative float, default=0.0
        # Complexity parameter used for Minimal Cost-Complexity Pruning.
        # The subtree with the largest cost complexity that is smaller than
        # ccp_alpha will be chosen. By default, no pruning is performed.

        # Show message
        print("\nGradient Boosting Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "GradientBoostingRegressor":

                # For loss_in
                list_loss = ["ls","lad","huber","quantile"]
                if line[1] in list_loss:
                    loss_in = line[1]
                else:
                    print("\nIOError! Undefined string ",line[1])
                    return

                # For learning_rate_in
                learning_rate_in = float(line[2])

                # For n_estimators_in
                n_estimators_in = int(line[3])

                # For subsample_in
                subsample_in = float(line[4])

                # For min_samples_split_in
                if "." in line[5]:
                    min_samples_split_in = float(line[5])
                else:
                    min_samples_split_in = int(line[5])

                # For min_samples_leaf_in
                if "." in line[6]:
                    min_samples_leaf_in = float(line[6])
                else:
                    min_samples_leaf_in = int(line[6])

                # For min_weight_fraction_leaf_in
                min_weight_fraction_leaf_in = float(line[7])

                # For max_depth_in
                max_depth_in = int(line[8])

                # For min_impurity_decrease_in
                min_impurity_decrease_in = float(line[9])

                # For init_in
                if line[10] == "None":
                    init_in = None
                else:
                    init_in = line[10]

                # For random_state_in
                if line[11] == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[11])

                # For max_features_in
                list_max_features = ["auto","sqrt","log2"]
                if line[12] == "None":
                    max_features_in = None
                elif line[12] in list_max_features:
                    max_features_in = line[12]
                elif "." in line[12]:
                    max_features_in = float(line[12])
                else:
                    max_features_in = int(line[12])

                # For alpha_in
                alpha_in = float(line[13])

                # For verbose_in
                verbose_in = int(line[14])

                # For max_leaf_nodes_in
                if line[15] == "None":
                    max_leaf_nodes_in = None
                else:
                    max_leaf_nodes_in = int(line[15])

                # For warm_start_in
                if line[16] == "False":
                    warm_start_in = False
                else:
                    warm_start_in = True

                # For validation_fraction_in
                validation_fraction_in = float(line[17])

                # For n_iter_no_change_in
                if line[18] == "None":
                    n_iter_no_change_in = None
                else:
                    n_iter_no_change_in = int(Line[18])

                # For tol_in
                tol_in = float(line[19])

                # For ccp_alpha_in
                ccp_alpha_in = float(line[20])

                # For cv_in (set value to 5)
                cv_in = int(line[21])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Loss function to be optimized: ",line[1])
        print("Learning rate: ",line[2])
        print("The number of boosting stages to perform: ",line[3])
        print("Fraction of samples to be used for fitting: ",line[4])
        print("Minimum number of samples required to split an internal node: ",
        line[5])
        print("Minimum number of samples required to be at a leaf node: ",
        line[6])
        print("Minimum weighted fraction of the sum total of weights: ",line[7])
        print("Maximum depth of the individual regression estimators",line[8])
        print("Minimum impurity decrease: ",line[9])
        print("Estimator object that is used to compute the initial predictions",
        line[10])
        print("Random seed: ",line[11])
        print("Number of features to consider when looking for the best split: ",
        line[12])
        print("Alpha-quantile of the huber loss function and the quantile: ",
        line[13])
        print("Verbose output: ",line[14])
        print("Maximum leaf nodes: ",line[15])
        print("Warm start: ",line[16])
        print("Validation fraction: ",line[17])
        print("Tolerance for the early stopping: ",line[19])
        print("Complexity parameter: ",line[20])

        # Import warnings filter
        from warnings import simplefilter

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of GradientBoostingRegressor class
        ############################################################################
        model = GradientBoostingRegressor(
            loss=loss_in,                       # loss: {‘ls’, ‘lad’, ‘huber’, ‘quantile’}, default=’ls’
            #learning_rate-learning_rate_in,     # learning_rate: float, default=0.1
            n_estimators=n_estimators_in,       # n_estimators: int, default=100
            subsample=subsample_in,             # subsample: float, default=1.0
            min_samples_split=min_samples_split_in,     # min_samples_split: int or float, default=2
            min_samples_leaf=min_samples_leaf_in,       # min_samples_leaf: int or float, default=1
            min_weight_fraction_leaf=min_weight_fraction_leaf_in,   # min_weight_fraction_leaf: float, default=0.0
            max_depth=max_depth_in,             # max_depth: int, default=3
            min_impurity_decrease=min_impurity_decrease_in,     # min_impurity_decrease: float, default=0.0
            init=init_in,                       # init: estimator or ‘zero’, default=None
            random_state=random_state_in,       # random_state: int, RandomState instance or None, default=None
            max_features=max_features_in,       # max_features: {‘auto’,‘sqrt’,‘log2’}, int or float, default=None
            alpha=alpha_in,                     # alpha: float, default=0.9
            verbose=verbose_in,                 # verbose: int, default=0
            max_leaf_nodes=max_leaf_nodes_in,   # max_leaf_nodes: int, default=None
            warm_start=warm_start_in,           # warm_start: bool, default=False
            validation_fraction=validation_fraction_in,     # validation_fraction: float, default=0.1
            n_iter_no_change=n_iter_no_change_in,       # n_iter_no_change: int, default=None
            tol=tol_in,                         # tol: float, default=1e-4
            ccp_alpha=ccp_alpha_in              # ccp_alpha: non-negative float, default=0.0
            )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return model