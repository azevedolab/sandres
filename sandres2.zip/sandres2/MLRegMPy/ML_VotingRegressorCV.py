#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Define VotingRegressorCV() class
class VotingRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_VotingRegressorCV() method
    def ml_scikit_VotingRegressorCV(self):
        """
        Method to generate a multiple regression model using
        VotingRegressorCV
        """

        # Import packages
        from sklearn.linear_model import LinearRegression
        from sklearn.ensemble import RandomForestRegressor
        from sklearn.ensemble import VotingRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.VotingRegressor.html
        #
        # string_reg_method = VotingRegressorCV
        #
        #
        # Additional material
        # https://heartbeat.fritz.ai/random-forest-regression-in-python-using-scikit-learn-9e9b147e2153
        #
        #
        # For LinearRegression
        #
        # fit_intercept: bool, optional, default True
        # Whether to calculate the intercept for this model. If set to False, no
        # intercept will be used in calculations (i.e. data
        # is expected to be centered).
        #
        # normalize: bool, optional, default False
        # This parameter is ignored when fit_intercept is set to False. If True,
        # the regressors X will be normalized
        # before regression by subtracting the mean and dividing by the l2-norm.
        # If you wish to standardize, please
        # use sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # copy_X: bool, optional, default True
        # If True, X will be copied; else, it may be overwritten.
        #
        # n_jobs_lr: int or None, optional (default=None)
        # The number of jobs to use for the computation. This will only provide
        # speedup for n_targets > 1 and sufficient large
        # problems. None means 1 unless in a joblib.parallel_backend context.
        # -1 means using all processors.
        #
        # For RandonForestRegressor
        #
        # n_estimators: int, default=100
        # The number of trees in the forest.
        # Changed in version 0.22: The default value of n_estimators changed
        # from 10 to 100 in 0.22.
        #
        # criterion: {“mse”, “mae”}, default=”mse”
        # The function to measure the quality of a split. Supported criteria are
        # “mse” for the mean squared error, which is equal to variance reduction
        # as feature selection criterion, and “mae” for the mean absolute error.
        #
        # max_depth: int, default=None
        # The maximum depth of the tree. If None, then nodes are expanded until
        # all leaves are pure or until all leaves contain less than
        # min_samples_split samples.
        #
        # min_samples_split: int or float, default=2
        # The minimum number of samples required to split an internal node:
        # If int, then consider min_samples_split as the minimum number.
        # If float, then min_samples_split is a fraction and
        # ceil(min_samples_split * n_samples)
        # are the minimum number of samples for each split.
        # Changed in version 0.18: Added float values for fractions.
        #
        # min_samples_leaf: int or float, default=1
        # The minimum number of samples required to be at a leaf node. A split
        # point at any depth will only be considered if it leaves at least
        # min_samples_leaf training samples in each of the left and right
        # branches. This may have the effect of smoothing the model, especially
        # in regression.
        # If int, then consider min_samples_leaf as the minimum number.
        # If float, then min_samples_leaf is a fraction and
        # ceil(min_samples_leaf * n_samples) are the minimum number of samples
        # for each node.
        # Changed in version 0.18: Added float values for fractions.
        #
        # min_weight_fraction_leaf: float, default=0.0
        # The minimum weighted fraction of the sum total of weights
        # (of all the input samples) required to be at a leaf node. Samples have
        # equal weight when sample_weight is not provided.
        #
        # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
        # The number of features to consider when looking for the best split:
        # If int, then consider max_features features at each split.
        # If float, then max_features is a fraction and
        # round(max_features*n_features) features are considered at each split.
        # If “auto”, then max_features=n_features.
        # If “sqrt”, then max_features=sqrt(n_features).
        # If “log2”, then max_features=log2(n_features).
        # If None, then max_features=n_features.
        # Note: the search for a split does not stop until at least one valid
        # partition of the node samples is found, even if it requires to
        # effectively inspect more than max_features features.
        #
        # max_leaf_nodes: int, default=None
        # Grow trees with max_leaf_nodes in best-first fashion. Best nodes are
        # defined as relative reduction in impurity. If None then unlimited
        # number of leaf nodes.
        #
        # min_impurity_decrease: float, default=0.0
        # A node will be split if this split induces a decrease of the impurity
        # greater than or equal to this value.
        # The weighted impurity decrease equation is the following:
        # N_t / N * (impurity - N_t_R / N_t * right_impurity
        #            - N_t_L / N_t * left_impurity)
        # where N is the total number of samples, N_t is the number of samples
        # at the current node, N_t_L is the number of samples in the left child,
        # and N_t_R is the number of samples in the right child.
        # N, N_t, N_t_R and N_t_L all refer to the weighted sum, if
        # sample_weight is passed.
        #
        # min_impurity_split: float, default=None(Deprecated since version 0.19)
        # Threshold for early stopping in tree growth. A node will split if its
        # impurity is above the threshold, otherwise it is a leaf.
        # Deprecated since version 0.19: min_impurity_split has been deprecated
        # in favor
        # of min_impurity_decrease in 0.19. The default value of
        # min_impurity_split has changed
        # from 1e-7 to 0 in 0.23 and it will be removed in 1.0
        # (renaming of 0.25).
        # Use min_impurity_decrease instead.
        #
        # bootstrap: bool, default=True
        # Whether bootstrap samples are used when building trees.
        # If False, the whole dataset is used to build each tree.
        #
        # oob_score: bool, default=False
        # Whether to use out-of-bag samples to estimate the generalization
        # score. Only available if bootstrap=True.
        #
        # n_jobs: int, default=None
        # The number of jobs to run in parallel. fit, predict, decision_path and
        # apply are all parallelized over the trees. None means 1 unless in a
        # joblib.parallel_backend context. -1 means using all processors.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls both the randomness of the bootstrapping of the samples used
        # when building trees (if bootstrap=True) and the sampling of the
        # features to consider when looking for the best
        # split at each node (if max_features < n_features).
        #
        # verbose: int, default=0
        # Controls the verbosity when fitting and predicting.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit and
        # add more estimators to the ensemble, otherwise, just fit a whole new
        # forest.
        #
        # ccp_alpha: non-negative float, default=0.0
        # Complexity parameter used for Minimal Cost-Complexity Pruning.
        # The subtree with the largest cost complexity that is smaller than
        # ccp_alpha will be chosen.
        # By default, no pruning is performed.
        #
        # max_samples: int or float, default=None
        # If bootstrap is True, the number of samples to draw from X to train
        # each base estimator.
        # If None (default), then draw X.shape[0] samples.
        # If int, then draw max_samples samples.
        # If float, then draw max_samples * X.shape[0] samples.
        # Thus, max_samples should be in the interval (0, 1).
        #
        #
        # For VotingRegressorCV
        #
        # estimators (Note implemented as input): list of (str, stimator) tuples
        # Invoking the fit method on the VotingRegressorCV will fit clones of
        # those original estimators that will be stored in the class attribute
        # self.estimators_. An estimator can be set to 'drop' using set_params.
        #
        # weights_vr: array-like of shape (n_regressors,), default=None
        # Sequence of weights (float or int) to weight the occurrences of
        # predicted values before averaging. Uses uniform weights if None.
        #
        # n_jobs_vr: int, default=None
        # The number of jobs to run in parallel for fit. None means 1 unless in
        # a joblib.parallel_backend context. -1 means using all processors.
        #
        # verbose_vr: bool, default=False
        # If True, the time elapsed while fitting will be printed as it is completed.

        # Show message
        print("\nVoting Regressor with Cross-Validation")
        print("Regression parameters read from ml.csv")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "VotingRegressorCV":

                # For LinearRegression
                # For fit_intercept_in
                if line[1].strip() == "True":
                    fit_intercept_in = True
                else:
                    fit_intercept_in = False

                # For copy_X_in
                if line[2].strip() == "True":
                    copy_X_in = True
                else:
                    copy_X_in = False

                # For n_jobs_lr_in
                if line[3].strip() == "None":
                    n_jobs_lr_in = None
                else:
                    n_jobs_lr_in = int(line[3].strip())

                # For RandomForestRegressor
                # For n_estimators_in
                n_estimators_in = int(line[4].strip())

                # For criterion_in
                list_criteria = ["squared_error","absolute_error","poisson"]
                if line[5].strip() in list_criteria:
                    criterion_in = line[5].strip()
                else:
                    criterion_in = "squared_error"
                    print("Unrecognizable input!")

                # For max_depth_in
                try:
                    max_depth_in = int(line[6].strip())
                except:
                    max_depth_in = None

                # For min_samples_split_in
                if "." in str(line[7].strip()):
                    min_samples_split_in = float(line[7].strip())
                else:
                    min_samples_split_in = int(line[7].strip())

                # For min_samples_leaf_in
                if "." in str(line[8].strip()):
                    min_samples_leaf_in = float(line[8].strip())
                else:
                    min_samples_leaf_in = int(line[8].strip())

                # For min_weight_fraction_leaf_in
                min_weight_fraction_leaf_in = float(line[9].strip())

                # For max_features_in
                list_max_features = ["auto","sqrt","log2"]
                if line[10].strip() in list_max_features:
                    max_features_in = line[10].strip()
                elif "." in str(line[10].strip()):
                    max_features_in = float(line[10].strip())
                else:
                    max_features_in = int(line[10].strip())

                # For max_leaf_nodes_in
                if line[11].strip() == "None":
                    max_leaf_nodes_in = None
                else:
                    max_leaf_nodes_in = int(line[11].strip())

                # For min_impurity_decrease_in
                min_impurity_decrease_in = float(line[12].strip())

                # For bootstrap_in
                if line[13].strip() == "True":
                    bootstrap_in = True
                else:
                    bootstrap_in = False

                # For oob_score_in
                if line[14].strip() == "True":
                    oob_score_in = True
                else:
                    oob_score_in = False

                # For n_jobs_in
                if line[15].strip() == "None":
                    n_jobs_in = None
                else:
                    n_jobs_in = int(line[15].strip())

                # For random_state_in
                if line[16].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[16].strip())

                # For verbose_in
                verbose_in = int(line[17].strip())

                # For warm_start_in
                if line[18].strip() == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For ccp_alpha_in
                ccp_alpha_in = float(line[19].strip())

                # For max_samples_in
                if line[20].strip() == "None":
                    max_samples_in = None
                elif "." in str(line[20].strip()):
                    max_samples_in = float(line[20].strip())
                else:
                    max_samples_in = int(line[20].strip())

                # For VotingRegressor
                # For weights_vr_in
                if line[21].strip() == "None":
                    weights_vr_in = None
                elif "." in line[21].strip():
                    weights_vr_in = float(line[21].strip())
                else:
                    weights_vr_in = int(line[21].strip())

                # For n_jobs_vr_in
                if line[22].strip() == "None":
                    n_jobs_vr_in = None
                else:
                    n_jobs_vr_in = int(line[22].strip())

                # For verbose_vr_in
                if line[23].strip() == "True":
                    verbose_vr_in = True
                else:
                    verbose_vr_in = False

                # For cv_in (set value to 5)
                cv_in = int(line[24].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.csv
        # For LinearRegression
        print("Regression method: ",line[0])
        print("Fit intercept? "+line[1])
        print("Copy x array? "+line[2])
        print("The number of jobs to use for the computation: ",line[3])
        # For RandomForestRegressor
        print("Number of trees in the forest: {}".format(n_estimators_in))
        print("The function to measure the quality of a split: ",line[5])
        print("Maximum depth of the tree: ",line[6])
        print("Minimum number of samples required to split an internal node: ",
        line[7])
        print("Minimum number of samples required to be at a leaf node: ",
        line[8])
        print("Minimum weighted fraction of the sum total of weights: ",
        line[9])
        print("Number of features to consider when looking for the best split:",
        line[10])
        print("Grow trees with max_leaf_nodes in best-first fashion: ",line[11])
        print("Minimum impurity decrease: ",line[12])
        print("Whether bootstrap samples are used when building trees: ",
        line[13])
        m14 = "Whether to use out-of-bag samples to estimate the "
        m14 += "generalization score: "
        print(m14,line[14])
        print("Number of jobs to run in parallel: ",line[15])
        m16 = "Controls both the randomness of the bootstrapping of the "
        m16 += "samples: "
        print(m16,line[16])
        print("Controls the verbosity when fitting and predicting: ",line[17])
        m18 = "When set to True, reuse the solution of the previous call "
        m18 += "to fit: "
        print(m18,line[18])
        print("Complexity parameter used for Minimal Cost-Complexity Pruning: ",
        line[19])
        m20 = "If bootstrap is True, the number of samples to draw from X "
        m20 += "to train each base estimator: "
        print(m20,line[20])
        # For VotingRegressor
        line_out22 = "Sequence of weights (float or int) to weight the "
        line_out22 += "occurrences of predicted values before averaging: "
        print(line_out22,line[21])
        line_out23 = "Number of jobs to run in parallel for fit "
        line_out23 += "(VotingRegressor): "
        print(line_out23,line[22])
        line_out24 = "If True, the time elapsed while fitting will be printed "
        line_out24 += "as it is completed: "
        print(line_out24,line[23])
        print("Kfold class to build a N-fold cross-validation loop. N: ",
        line[24])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Set up model1 and model2
        # Instantiate an object of LinearRegression class
        model1 = LinearRegression(
            fit_intercept=fit_intercept_in, # fit_intercept: bool, optional, default True
            copy_X=copy_X_in,               # copy_X: bool, optional, default True
            n_jobs=n_jobs_lr_in             # n_jobs: int or None, optional (default=None)
            )

        # Instantiate an object of RandomForestRegressor class
        model2 = RandomForestRegressor(
            n_estimators=n_estimators_in,   # n_estimators: int, default=100
            criterion=criterion_in,         # criterion: {“mse”, “mae”}, default=”mse”
            max_depth=max_depth_in,         # max_depth: int, default=None
            min_samples_split=min_samples_split_in,    # min_samples_split: int or float, default=2
            min_samples_leaf=min_samples_leaf_in,      # min_samples_leaf: int or float, default=1
            min_weight_fraction_leaf=min_weight_fraction_leaf_in,   # min_weight_fraction_leaf: float, default=0.0
            max_features=max_features_in,   # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
            max_leaf_nodes=max_leaf_nodes_in,          # max_leaf_nodes: int, default=None
            min_impurity_decrease=min_impurity_decrease_in,
            bootstrap=bootstrap_in,         # bootstrap: bool, default=True
            oob_score=oob_score_in,         # oob_score: bool, default=False
            n_jobs=n_jobs_in,               # n_jobs: int, default=None
            random_state=random_state_in,   # random_state: int, RandomState instance or None, default=None
            verbose=verbose_in,             # verbose: int, default=0
            warm_start=warm_start_in,       # warm_start: bool, default=False
            ccp_alpha=ccp_alpha_in,         # ccp_alpha: non-negative float, default=0.0
            max_samples=max_samples_in      # max_samples: int or float, default=None
            )

        # Instantiate an object of VotingRegressor class
        ############################################################################
        model = VotingRegressor(
            [('lr',model1), ('rf',model2)],
            weights=weights_vr_in,          # weights: array-like of shape (n_regressors,), default=None
            n_jobs=n_jobs_vr_in,            # n_jobs: int, default=None
            verbose=verbose_vr_in           # verbose: bool, default=False
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model