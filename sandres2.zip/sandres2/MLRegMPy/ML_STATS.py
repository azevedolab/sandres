# Class to carry out basic statistical analysis of regression models
#
# Dr. Walter F. de Azevedo, Jr.
# https://azevedolab.net/
# 2021-07-26

# Import packages
import sys
import csv
import numpy as np
from joblib import load
from scipy.stats import spearmanr, pearsonr
from sklearn.metrics import mean_squared_error

# Define Analysis() class
class Analysis(object):
    """Class to carry out statistical analysis between experimental data and
    selected features.
    Features labels read from misc/data/#####features_in.csv
        e.g.
        Torsions,Q,Average Q,C,N,O,S,F,Gauss 1,Gauss 2,Repulsion,Hydrophobic,
        Hydrogen,Torsional

    Inputs
         program_root           : Program directory
         dir_in                 : Project directory
         sf_file_in             : Scoring function CSV file (features)

         For bundle() method
         exp_label              : Label with a string for experimental data, i.e. "log(Ki)"

    Outputs
        corr_s                  : Spearman's rank correlation coefficient
        pvalue_s                : p-value for Spearman correlation coefficient
        corr_p                  : Pearson's correlation coefficient
        pvalue_p                : p-value for Pearson correlation coefficient
        r2S                     : R-square
        rmse_model              : RMSE
        s_dev                   : Standard deviation
        rss                     : Residual sum of squares (RSS)
        y_feature                  : Predicted y

    """

    # Define constructor method
    def __init__(self,program_root,dir_in,sf_file_in,features_in_csv):
        """Constructor method"""

        # Define atributes
        self.program_root = program_root
        self.dir_in = dir_in
        self.sf_file_in = sf_file_in
        self.features_in_csv = features_in_csv

    # Define read_features() method
    def read_features(self,exp_label):
        """Method to read features in a CSV file"""

        # Set up empty lists
        list_out = []
        self.features = []

        # Read features
        # Try to open features_in.csv
        try:
            file2open = self.program_root+"misc/data/"+self.features_in_csv
            fo_features = open(file2open,"r")
            csv_features = csv.reader(fo_features)
        except IOError:
            sys.exit("\nIOError!I can't find "+file2open+" file!")

        # Looping through csv_features
        for line1 in csv_features:
            for line2 in line1:
                self.features.append(line2)

        # Close file
        fo_features.close()

        # Try to open a file
        try:
            file2open = self.dir_in+self.sf_file_in
            csv_in = open(file2open,"r")
            csv_lines = csv.reader(csv_in)
        except IOError:
            print("\nI can't find ",file2open," file!")
            return

        # Read CSV file first line only
        for line in csv_lines:
            headers = line
            break

        # Close file
        csv_in.close()

        # Reopen CSV file
        csv_in = open(file2open,"r")
        self.data = csv_in.readlines()

        # Close file
        csv_in.close()

        # Read CSV file and skips first line
        csv_data = np.genfromtxt (file2open, delimiter=",", skip_header = 1)

        # Get rows from CSV file
        aux_array = csv_data[:,0:11]    # 10
        self.rows = aux_array.shape[0]

        # Get indexes of features
        i = 0
        feature_indexes = []
        for line in headers:
            if line in self.features:
                feature_indexes.append(i)
            i += 1

        # Set up array
        self.columns = len(self.features)
        self.X = np.array([[0]*self.columns]*self.rows,float)  # np.array([[0]*column]*row,float)

        # Get feature data (X) in an array
        for i in range(self.rows):
            for j in range(self.columns):
                self.X[i][j]= csv_data[i][feature_indexes[j]]

        # Get target data (y)
        self.y = csv_data[:,headers.index(exp_label)]

    # Define basic() method
    def basic(self,label_in,y_feature):
        """Method to carry out some very basic statistical analysis of the
        predictive performance of a regression model"""

        # Invoke calc_RSS
        self.calc_RSS(self.y,y_feature)

        # Invoke calc_ESS
        self.calc_ESS(self.y,y_feature)

        # Get Spearman's rank and Pearson correlation coefficient and p-value
        self.corr_s,self.pvalue_s = spearmanr(self.y,y_feature)
        self.corr_p,self.pvalue_p = pearsonr(self.y,y_feature)

        # Basic statistics
        n = len(self.y)                                                 # Number of data points
        self.r2 = self.corr_p*self.corr_p                               # R-square
        self.mse = mean_squared_error(y_feature,self.y)                 # Mean squared error (mse)
        self.rmse_model = np.sqrt(mean_squared_error(y_feature,self.y)) # RMSE


        # Show statistical analysis
        print("\nStatistical Analysis of Regression Model")
        print("Spearman's rank correlation coefficient : {:.6f}".format(self.corr_s),
        "p-value: ",np.format_float_scientific(self.pvalue_s,precision=4,exp_digits=3))
        print("Pearson's correlation coefficient (r): {:.6f}".format(self.corr_p),"p-value: ",
        np.format_float_scientific(self.pvalue_p,precision=4,exp_digits=3))
        print("r"+u"\u00b2"+": {:.6f}".format(self.r2))
        print('MSE: {:.7f}'.format(self.mse))
        print('RMSE: {:.6f}'.format(self.rmse_model))
        print("Residual sum of squares (RSS): {:.6f}".format(self.rss))

        # Set up a line with statistical analysis
        self.stats_out = label_in+","+str(self.corr_p)+","+\
            str(self.pvalue_p)+","+str(self.r2)+","+str(self.corr_s)+","+\
            str(self.pvalue_s)+","+str(self.mse)+","+str(self.rmse_model)+","+\
            str(self.rss)+"\n"

    # Define calc_ESS() method
    def calc_ESS(self,y,y_feature):
        """Method to calculate Explained Sum of Squares (ESS)"""

        # Get number of data points
        n = len(y)

        # Set up array with zeros
        aux = np.zeros(n,dtype=float)

        # Calculate mean self.y_in
        mean_y_in = np.mean(y)

        # Looping through data points (self.y_in) and self.y_feature
        for i in range(n):
            aux[i] = (y_feature[i] - mean_y_in)**2

        # Calculate Explained Sum of Squares (ESS)
        self.ess = np.sum(aux)

    # Define calc_RSS() method
    def calc_RSS(self,y,y_feature):
        """Method to calculate Residual Sum of Squares (RSS)"""

        # Get number of data points
        n = len(y)

        # Set up array with zeros
        aux = np.zeros(n,dtype=float)

        # Calculate aux
        aux = (y - y_feature)**2

        # Calculate Residual Sum of Squares (RSS)
        self.rss = np.sum(aux)

    # Define bundle() method to pack all methods
    def bundle(self,exp_label):
        """Method to pack all methods necessary to add predicted values
        to a CSV file"""

        # Invoke read_features()
        self.read_features(exp_label)

        # Set up empty list
        lines_out = []

        # Set up arrays
        r2_array = np.zeros(self.columns)
        in_array = np.zeros(self.columns,dtype=int)

        # Open a new file
        #file2open = self.dir_in+"statistical_analysis_features.csv"
        file2open = self.dir_in+self.sf_file_in.replace(".csv","")
        file2open += "_stats4features.csv"
        fo_stats = open(file2open,"w")

        # Write headers
        headers = "Feature,r,p-value,r2,rho,p-value,MSE,RMSE,RSS\n"
        fo_stats.write(headers)

        # Looping through feature data
        y_in = np.zeros(self.rows)
        for j,line in enumerate(self.features):
            print(j,line)

            # Get feature data (X) in an array
            for i in range(self.rows):
                    y_in[i] = self.X[i][j]

            # Invoke basic() method
            self.basic(line,y_in)

            # Show result for each feature
            print(self.stats_out)

            # Add line
            lines_out.append(self.stats_out)

            # Write a line
            #fo_stats.write(self.stats_out)

            r2_array[j] = self.r2

        # Sort array
        sorted_array = np.sort(r2_array)
        out_array = np.flip(sorted_array)
        for i,r_2 in enumerate(out_array):
            #print(r_2)
            in_array[i] = np.where(r2_array == r_2)[0]

        for i in range(len(in_array)):
            #print(in_array[i])
            print(lines_out[in_array[i]])
            fo_stats.write(str(lines_out[in_array[i]]))

        # Close file
        fo_stats.close()