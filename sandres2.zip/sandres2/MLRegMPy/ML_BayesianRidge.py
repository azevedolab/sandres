#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define BayesianRidge() class
class BayesianRidge(object):
    """Class to carry out BayesianRidge regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : ndarray of shape (n_samples, n_features) Training data
        y                       : ndarray of shape (n_samples,)
                                Target values. Will be cast to X’s dtype if necessary

    Outputs
       rand_in                  : Random seed (to generate MDM format files)
       model                    : Regression model
       model.intercept_         : Independent term in decision function. Set to 0.0 if fit_intercept = False.
       model.coef_              : Coefficients of the regression model (mean of distribution)
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_BayesianRidge() method
    def ml_scikit_BayesianRidge(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.BayesianRidge
        """

        # Import packages
        from sklearn.linear_model import BayesianRidge
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.BayesianRidge.html
        #
        # string_reg_method = BayesianRidge
        #
        #
        # n_iter: int, default=300
        # Maximum number of iterations. Should be greater than or equal to 1.
        #
        # tol: float, default=1e-3
        # Stop the algorithm if w has converged.
        #
        # alpha_1: float, default=1e-6
        # Hyper-parameter : shape parameter for the Gamma distribution prior
        # over the alpha parameter.
        #
        # alpha_2: float, default=1e-6
        # Hyper-parameter : inverse scale parameter (rate parameter) for the
        # Gamma distribution prior over the alpha parameter.
        #
        # lambda_1: float, default=1e-6
        # Hyper-parameter : shape parameter for the Gamma distribution prior
        # over the lambda parameter.
        #
        # lambda_2: float, default=1e-6
        # Hyper-parameter : inverse scale parameter (rate parameter) for the
        # Gamma distribution prior over the lambda parameter.
        #
        # alpha_init: float, default=None
        # Initial value for alpha (precision of the noise). If not set,
        # alpha_init is 1/Var(y).
        #
        # lambda_init: float, default=None
        # Initial value for lambda (precision of the weights). If not set,
        # lambda_init is 1.
        #
        # compute_score: bool, default=False
        # If True, compute the log marginal likelihood at each iteration of the
        # optimization.
        #
        # fit_intercept: bool, default=True
        # Whether to calculate the intercept for this model. The intercept is
        # not treated as a probabilistic parameter and thus has no associated
        # variance.
        # If set to False, no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # normalize: bool, default=False
        # This parameter is ignored when fit_intercept is set to False. If True,
        # the regressors X will be normalized before regression by subtracting
        # the mean and
        # dividing by the l2-norm. If you wish to standardize, please use
        # sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # verbose: bool, default=False
        # Verbose mode when fitting the model.
        #
        # Paper about Bayesian Ridge applied to scoring function development:
        # Su M, Feng G, Liu Z, Li Y, Wang R. Tapping on the Black Box:
        # How Is the Scoring Power of a Machine-Learning Scoring Function
        # Dependent on the Training Set? J Chem Inf Model.
        # 2020 Mar 23;60(3):1122-1136. doi: 10.1021/acs.jcim.9b00714.
        # Epub 2020 Mar 3. PMID: 32085675.
        # https://pubmed.ncbi.nlm.nih.gov/32085675/

        # Show message
        print("\nMethod: Bayesian Ridge Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "BayesianRidge":

                # For max_in
                max_in = int(line[1].strip())

                # For tol_in
                tol_in = float(line[2].strip())

                # For alpha_1_in
                alpha_1_in = float(line[3].strip())

                # For alpha_2_in
                alpha_2_in = float(line[4].strip())

                # For lambda_1_in
                lambda_1_in = float(line[5].strip())

                # For lambda_2_in
                lambda_2_in = float(line[6].strip())

                # For alpha_init_in
                if line[7].strip() == "None":
                    alpha_init_in = None
                else:
                    alpha_init_in = float(line[7].strip())

                # For lambda_init_in
                if line[8].strip() == "None":
                    lambda_init_in = None
                else:
                    lambda_init_in = float(line[8].strip())

                # For compute_score_in
                if line[9].strip() == "True":
                    compute_score_in = True
                else:
                    compute_score_in = False

                # For fit_in
                if line[10].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For copy_in
                if line[11].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For ver_in
                if line[12].strip() == "True":
                    ver_in = True
                else:
                    ver_in = False

                # For rand_in
                rand_in = int(line[13].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Maximum number of iterations: {}".format(max_in))
        line_out2 = "Stop the algorithm if w has converged (tolerance)"
        print(line_out2+": {:.5e}".format(tol_in))
        print("Hyper-parameter (alpha_1): {:.5e}".format(alpha_1_in))
        print("Hyper-parameter (alpha_2): {:.5e}".format(alpha_2_in))
        print("Hyper-parameter (lambda_1): {:.5e}".format(lambda_1_in))
        print("Hyper-parameter (lambda_2): {:.5e}".format(lambda_2_in))
        print("Initial value for alpha (precision of the noise): "+line[7])
        print("Initial value for lambda (precision of the weights): "+line[8])
        print("Compute score at each iteration of the optimization? "+line[9])
        print("Fit intercept? "+line[10])
        print("Copy x array? "+line[11])
        print("Verbose mode when fitting the model: ",line[12])

        # Instantiate an object of BayesianRidge class
        model = BayesianRidge(
                n_iter=max_in,                  # n_iter: int, default=300
                tol=tol_in,                     # tol: float, default=1e-3
                alpha_1=alpha_1_in,             # alpha_1: float, default=1e-6
                alpha_2=alpha_2_in,             # alpha_2: float, default=1e-6
                lambda_1=lambda_1_in,           # lambda_1: float, default=1e-6
                lambda_2=lambda_2_in,           # lambda_2: float, default=1e-6
                alpha_init=alpha_init_in,       # alpha_init: float, default=None
                lambda_init=lambda_init_in,     # lambda_init: float, default=None
                compute_score=compute_score_in, # compute_score: bool, default=False
                fit_intercept = fit_in,         # fit_intercept: bool, default=True
                copy_X = copy_in,               # copy_X: bool, default=True
                verbose=ver_in                  # verbose: bool, default=False
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_