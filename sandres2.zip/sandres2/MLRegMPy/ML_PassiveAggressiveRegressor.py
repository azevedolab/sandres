#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define PassiveAggressiveRegressor() class
class PassiveAggressiveRegressor(object):
    """Class to carry out PassiveAggressiveRegressor

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : array-like, shape (n_samples, n_features). Training data.
        y                       : array-like, shape (n_samples,) or (n_samples, n_targets)
                                Target values.

    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : array, shape = [1] if n_classes == 2 else [n_classes]. Constants in decision function.
       model.coef_              : array, shape = [1, n_features] if n_classes == 2 else [n_classes, n_features]
                                Weights assigned to the features.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_PassiveAggressiveRegressor() method
    def ml_scikit_PassiveAggressiveRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.PassiveAggressiveRegressor
        """

        # Import packages
        from sklearn.linear_model import PassiveAggressiveRegressor
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.PassiveAggressiveRegressor.html
        #
        # string_reg_method = PassiveAggressiveRegressor
        #
        #
        # C: float
        # Maximum step size (regularization). Defaults to 1.0.
        #
        # fit_intercept: bool
        # Whether the intercept should be estimated or not. If False, the data
        # is assumed to be already centered.
        # Defaults to True.
        #
        # max_iter: int, optional (default=1000)
        # The maximum number of passes over the training data (aka epochs).
        # It only impacts the behavior in the fit method, and not the
        # partial_fit method.
        #
        # tol: float or None, optional (default=1e-3)
        # The stopping criterion. If it is not None, the iterations will stop
        # when (loss > previous_loss - tol).
        #
        # early_stopping: bool, default=False
        # Whether to use early stopping to terminate training when validation.
        # score is not improving.
        # If set to True, it will automatically set aside a fraction of training
        # data as validation and
        # terminate training when validation score is not improving by at least
        # tol for n_iter_no_change consecutive epochs.
        #
        # validation_fraction: float, default=0.1
        # The proportion of training data to set aside as validation set for
        # early stopping.
        # Must be between 0 and 1. Only used if early_stopping is True.
        #
        # n_iter_no_change: int, default=5
        # Number of iterations with no improvement to wait before early
        # stopping.
        #
        # shuffle: bool, default=True
        # Whether or not the training data should be shuffled after each epoch.
        #
        # verbose: integer, optional
        # The verbosity level
        #
        # loss: string, optional
        # The loss function to be used: epsilon_insensitive: equivalent to PA-I
        # in the reference paper.
        # squared_epsilon_insensitive: equivalent to PA-II in the reference
        # paper.
        #
        # epsilon: float
        # If the difference between the current prediction and the correct
        # label is below this threshold, the model is not updated.
        #
        # random_state: int, RandomState instance or None, optional,default=None
        # The seed of the pseudo random number generator to use when shuffling
        # the data.
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random.
        #
        # warm_start: bool, optional
        # When set to True, reuse the solution of the previous call to fit as
        # initialization, otherwise,
        # just erase the previous solution.
        # Repeatedly calling fit or partial_fit when warm_start is True can
        # result in a different solution
        # than when calling fit a single time because of the way the data is
        # shuffled.
        #
        # average: bool or int, optional
        # When set to True, computes the averaged SGD weights and stores the
        # result in the coef_ attribute.
        # If set to an int greater than 1, averaging will begin once the total
        # number of samples seen reaches average.
        # So average=10 will begin averaging after seeing 10 samples.

        # Show message
        print("\nPassive Aggressive Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "PassiveAggressiveRegressor":

                # For C_in
                C_in = float(line[1].strip())

                # For fit_in
                if line[2].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For max_in
                max_in = int(line[3].strip())

                # For tol_in
                try:
                    tol_in = float(line[4].strip())
                except:
                    tol_in = None

                # For early_stopping_in
                if line[5].strip() == "True":
                    early_stopping_in = True
                else:
                   early_stopping_in = False

                # For validation_fraction_in
                validation_fraction_in = float(line[6].strip())

                # For n_iter_no_change_in
                n_iter_no_change_in = int(line[7].strip())

                # For shuffle_in
                if line[8].strip() == "True":
                    shuffle_in = True
                else:
                    shuffle_in = False

                # For ver_in
                ver_in = int(line[9].strip())

                # For loss_in
                list_loss =["epsilon_insensitive","squared_epsilon_insensitive"]
                if line[10].strip() in list_loss:
                    loss_in = line[10].strip()
                else:
                    print("Unrecognizable input!")
                    loss_in = "epsilon_insensitive"

                # For epsilon_in
                epsilon_in = float(line[11].strip())

                # rand_in
                try:
                    rand_in = int(line[12].strip())
                except:
                    rand_in = None

                # For warm_start_in
                if line[13].strip() == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For average_in
                if line[14].strip() == "True":
                    average_in = True
                elif line[14].strip() == "False":
                    average_in = False
                else:
                    average_in = int(line[14].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Maximum step size (regularization): {:.5e}".format(C_in))
        print("Fit intercept? "+line[2])
        line_out3 = "Maximum number of passes over the training data"
        print(line_out3+": {}".format(max_in))
        print("The stopping criterion (tolerance): {:.5e}".format(tol_in))
        line_out5 = "Whether to use early stopping to terminate "
        print(line_out5+"training when validation: ",line[5])
        line_out6 = "Proportion of training data to set aside as validation "
        line_out6 += "set for early stopping"
        print(line_out6+": {:.5e}".format(validation_fraction_in))
        line_out7 = "Number of iterations with no improvement to wait "
        print(line_out7+"before early stopping: ",line[7])
        line_out8 = "Whether or not the training data should be shuffled after "
        print(line_out8+"each epoch: ",line[8])
        print("Verbose level: ",line[9])
        print("The loss function to be used: ",line[10])
        print("Epsilon: {:.5e}".format(epsilon_in))
        print("Random state: ",line[12])
        print("Warm start? ",line[13])
        print("Average? ",line[14])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of PassiveAggressiveRegressor class
        model = PassiveAggressiveRegressor(
                C=C_in,                                     # C: float
                fit_intercept=fit_in,                       # fit_intercept: bool
                max_iter=max_in,                            # max_iter: int, optional (default=1000)
                tol=tol_in,                                 # tol: float or None, optional (default=1e-3)
                early_stopping=early_stopping_in,           # early_stopping: bool, default=False
                validation_fraction=validation_fraction_in, # validation_fraction: float, default=0.1
                n_iter_no_change=n_iter_no_change_in,       # n_iter_no_change: int, default=5
                shuffle=shuffle_in,                         # shuffle: bool, default=True
                verbose=ver_in,                             # verbose: integer, optional
                loss=loss_in,                               # loss: string, optional
                epsilon=epsilon_in,                         # epsilon: float
                random_state=rand_in,                  # random_state: int, RandomState instance or None, optional, default=None
                warm_start=warm_start_in,                   # warm_start: bool, optional
                average=average_in                          # average: bool or int, optional
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Check whether rand_in == None for MDM
        if str(rand_in) == "None":
            rand_in = 1123581321

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_