#!/usr/bin/python
#
# Here we have regression methods implemented using scikit-learn library
# (Pedregosa et al., 2011)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the development of the programs SAnDReS (Xavier et al., 2016)
# and Taba (da Silva et al., 2020).
# These methods are usefull for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019).
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019; 2053: 275–281.
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O, Blondel M,
# Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A, Cournapeau D,
# Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning in Python.
# J Mach Learn Res, 2011, 12, 2825–2830.
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Walter F. de Azevedo Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila, Nayara M. Bernhardt Levin,
# Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems Biology
# Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Current Version 1.1.0. released on 12 January 2018.
#
# Xavier, M.M,; Heck, G.S.; de Avila, M.B.; Levin, N.M.; Pintro,  V.O.;  Carvalho, N.L.;
# Azevedo, W.F. Jr.
# SAnDReS a Computational Tool for Statistical Analysis of  Docking  Results  and
# Development  of  Scoring Functions.
# Comb.  Chem.  High Throughput Screen, 2016; 19(10): 801-812.
# DOI: 10.2174/1386207319666160927111347
#
###############################################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version and
# use it in the analysis of your # docking results. If you have any question regarding
# SAnDReS, please feel free to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico -
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0 and 308883/2014-4.
#
###############################################################################################################

# Define LassoCV() class
class LassoCV(object):
    """Class to carry out Lasso regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : {array-like}, shape (n_samples, n_features). Training data
        y                       : array-like, shape (n_samples,) or (n_samples, n_targets)
                                Target values

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float | array, shape (n_targets,) independent term in decision function.
       model.coef_              : array, shape (n_features,) | (n_targets, n_features) parameter vector
                                (w in the cost function formula)
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_LassoCV() method
    def ml_scikit_LassoCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoCV
        """

        # Import packages
        from sklearn.linear_model import LassoCV
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LassoCV.html
        #
        # string_reg_method = LassoCV
        #
        # alphas: numpy array, optional
        # List of alphas where to compute the models. If None alphas are set
        # automatically
        # alpha_0 = 0.1, # Starting value of the sequence
        # alpha_1 = 1,0, # Final value of the sequence
        # num_samples = 30, # Number of samples to generate
        #
        # fit_intercept: boolean, default True
        # whether to calculate the intercept for this model.
        # If set to false, no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # normalize: boolean, optional, default False
        # This parameter is ignored when fit_intercept is set to False.
        # If True, the regressors X will be normalized before regression by
        # subtracting the mean and dividing by the l2-norm.
        #
        # precompute: True | False | ‘auto’ | array-like
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # If set to 'auto' let us decide. The Gram matrix can also be passed as
        # argument.
        #
        # max_iter: int, optional
        # The maximum number of iterations
        #
        # tol: float, optional
        # The tolerance for the optimization: if the updates are smaller than
        # tol, the optimization code checks the dual gap for optimality and
        # continues until it is smaller than tol.
        #
        # copy_X: boolean, optional, default True
        # If True, X will be copied; else, it may be overwritten.
        #
        # cv: int, cross-validation generator or an iterable, optional
        # Determines the cross-validation splitting strategy. Possible inputs
        # for cv are:
        # None, to use the default 5-fold cross-validation,
        # integer, to specify the number of folds.
        # CV splitter,
        # An iterable yielding (train, test) splits as arrays of indices.
        #
        # n_jobs: int or None, optional (default=None)
        # Number of CPUs to use during the cross validation.
        # None means 1 unless in a joblib.parallel_backend context. -1 means
        # using all processors.
        #
        # positive: bool, optional
        # If positive, restrict regression coefficients to be positive
        #
        # random_state: int, RandomState instance or None, optional,default None
        # The seed of the pseudo random number generator that selects a random
        # feature to update.
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random.
        # Used when selection == ‘random’.
        #
        # selection: str, default ‘cyclic’
        # If set to ‘random’, a random coefficient is updated every iteration
        # rather than looping over features sequentially by default.
        # This (setting to ‘random’) often leads to significantly faster
        # convergence especially when tol is higher than 1e-4.

        # Show message
        print("Least absolute shrinkage and selection operator (LassoCV)")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "LassoCV":

                # For alpha_0 (minimum value)
                alpha_0 = float(line[1])

                # For alpha_1 (maximum value)
                alpha_1 = float(line[2])

                # For num_samples (number of samples)
                num_samples = int(line[3])

                # For fit_in
                if line[4] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For norm_in
                if line[5] == "True":
                    norm_in = True
                else:
                    norm_in = False

                # For pre_in
                if line[6] == "True":
                    pre_in = True
                elif line[6] == "False":
                    pre_in = False
                elif line[6] == "auto":
                    pre_in = "auto"
                else:
                    print("\nIOError! Undefined string ",line[6])
                    return

                # For max_in
                max_in = int(line[7])

                # For tol_in
                tol_in = float(line[8])

                # For copy_in
                if line[9] == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For cv_in
                cv_in = int(line[10])

                # For njobs_in
                njobs_in = int(line[11])

                # For pos_in
                if line[12] == "True":
                    pos_in = True
                else:
                    pos_in = False

                # For self.rand_in
                self.rand_in = int(line[13])

                # For sel_in
                sel_in = str(line[14])

                # Finish loop
                break

        # Close file
        fo.close()

        # Set up alphas_ array
        # Based on https://docs.scipy.org/doc/numpy-1.15.1/reference/generated/numpy.logspace.html
        alphas_ = np.logspace(alpha_0, alpha_1, num_samples)

        # Show summary
        print("Regression method: ",line[0])
        line_out1 = "Array of alpha values to try "
        print(line_out1+"(minimum alpha) = {:.5f}".format(np.min(alphas_)))
        print(line_out1+"(maximum alpha) = {:.5f}".format(np.max(alphas_)))
        print(line_out1+"(number of samples) = {}".format(num_samples))
        print("Fit intercept? "+line[4])
        print("Normalize? "+line[5])
        print("Pre compute? "+line[6])
        print("Copy x array? "+line[9])
        print("Maximum number of iterations: ",max_in)
        print("Tolerance for the optimization: {:.5f}".format(tol_in))
        print("Force the coefficients to be positive? "+line[12])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[10])
        print("Method for coefficients: "+line[14])
        print("Random seed: "+str(self.rand_in))

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of LassoCV class
        model = LassoCV(
                alphas = alphas_,               # alphas: numpy array, optional
                fit_intercept = fit_in,         # fit_intercept: boolean, default True
                normalize = norm_in,            # normalize: boolean, optional, default False
                precompute = pre_in,            # precompute: True | False | ‘auto’ | array-like
                max_iter = max_in,              # max_iter: int, optional
                tol = tol_in,                   # tol: float, optional
                copy_X = copy_in,               # copy_X: boolean, optional, default True
                cv = cv_in,                     # cv: int, cross-validation generator or an iterable, optional
                n_jobs = njobs_in,              # n_jobs: int or None, optional (default=None)
                positive = pos_in,              # positive: bool, optional
                random_state = self.rand_in,    # random_state: int, RandomState instance or None, optional
                selection = sel_in              # selection: str, default ‘cyclic’
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_