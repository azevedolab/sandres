#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Define LassoCV() class
class LassoCV(object):
    """Class to carry out Lasso regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : {array-like}, shape (n_samples, n_features). Training data
        y                       : array-like, shape (n_samples,) or (n_samples, n_targets)
                                Target values

    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : float | array, shape (n_targets,) independent term in decision function.
       model.coef_              : array, shape (n_features,) | (n_targets, n_features) parameter vector
                                (w in the cost function formula)
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_LassoCV() method
    def ml_scikit_LassoCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoCV
        """

        # Import packages
        from sklearn.linear_model import Lasso # Not LassoCV from scikit-learn
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Lasso.html
        #
        # string_reg_method = LassoCV
        #
        # alpha: float, default=1.0
        #Constant that multiplies the L1 term. Defaults to 1.0. alpha = 0 is
        # equivalent to an ordinary least square, solved by the
        # LinearRegression object. For numerical reasons, using alpha = 0 with
        # the Lasso object is not advised. Given this, you should use the
        # LinearRegression object.
        #
        # fit_intercept: bool, default=True
        # Whether to calculate the intercept for this model. If set to False,
        # no intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # precompute: bool or array-like of shape (n_features, n_features),
        # default=False
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # The Gram matrix can also be passed as argument. For sparse input this
        # option is always False to preserve sparsity.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # max_iter: int, default=1000
        # The maximum number of iterations.
        #
        # tol: float, default=1e-4
        # The tolerance for the optimization: if the updates are smaller than
        # tol, the optimization code checks the dual gap for optimality and
        # continues until it is smaller than tol.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit as
        # initialization, otherwise, just erase the previous solution.
        # See the Glossary.
        #
        # positive: bool, default=False
        # When set to True, forces the coefficients to be positive.
        #
        # random_state: int, RandomState instance, default=None
        # The seed of the pseudo random number generator that selects a random
        # feature to update. Used when selection == ‘random’. Pass an int for
        # reproducible output across multiple function calls. See Glossary.
        #
        # selection: {‘cyclic’, ‘random’}, default=’cyclic’
        # If set to ‘random’, a random coefficient is updated every iteration
        # rather than looping over features sequentially by default. This
        # (setting to ‘random’) often leads to significantly faster convergence
        # especially when tol is higher than 1e-4.
        #
        # Show message
        print("Least absolute shrinkage and selection operator (LassoCV)")
        print("Regression parameters read from ml.csv")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "LassoCV":

                # For alpha_in
                alpha_in = float(line[1].strip())

                # For fit_in
                if line[2].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For precompute_in
                if line[3].strip() == "True":
                    precompute_in = True
                else:
                    precompute_in = False

                # For copy_in
                if line[4].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For max_iter_in
                max_iter_in = int(line[5].strip())

                # For tol_in
                tol_in = float(line[6].strip())

                # For warm_start_in
                if line[7].strip() == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For positive_in
                if line[8].strip() == "True":
                    positive_in = True
                else:
                    positive_in = False

                # For rand_in
                if line[9].strip() == "None":
                    rand_in = None
                else:
                    rand_in = int(line[9].strip())

                # For selection_oi
                list_selection = ["cyclic","random"]
                if line[10].strip() in list_selection:
                    selection_in = line[10].strip()
                else:
                    selection_in = "cyclic"
                    print("Unrecognizable input!")

                # For cv_in
                cv_in = int(line[11].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Set up alphas_ array
        # Based on https://docs.scipy.org/doc/numpy-1.15.1/reference/generated/numpy.logspace.html
        #alphas_ = np.logspace(alpha_0, alpha_1, num_samples)

        # Show input parameters read from ml.csv
        print("Regression method: ",line[0])
        print("Constant that multiplies the L1 term: ",line[1])
        print("Whether to calculate the intercept for this model: ",line[2])
        print("Whether to use a precomputed Gram matrix: ",line[3])
        print("If True, X will be copied: ",line[4])
        print("The maximum number of iterations: ",line[5])
        print("The tolerance for the optimization: ",line[6])
        print("When set to True, reuse the solution of the previous call: ",
        line[7])
        print("Forces the coefficients to be positive: ",line[8])
        print("The seed of the pseudo random number generator: ",line[9])
        print("Type of selection: ",line[10])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[11])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of Lasso class
        model = Lasso(
                alpha = alpha_in,               # alpha: float, default=1.0
                fit_intercept = fit_in,         # fit_intercept: bool, default=True
                precompute = precompute_in,     # precompute: bool, default=False
                copy_X = copy_in,               # copy_X: bool, default=True
                max_iter = max_iter_in,         # max_iter: int, default=1000
                tol = tol_in,                   # tol: float, default=1e-4
                warm_start = warm_start_in,     # warm_start: bool, default=False
                positive = positive_in,         # positive: bool, default=False
                random_state = rand_in,    # random_state: int, default=None
                selection = selection_in        # selection: {‘cyclic’, ‘random’}, default=’cyclic’
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_