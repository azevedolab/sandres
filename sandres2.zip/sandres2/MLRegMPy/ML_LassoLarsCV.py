#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define LassoLarsCV() class
class LassoLarsCV(object):
    """Class to carry out LassoLarsCV regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : array-like of shape (n_samples, n_features). Training data.
        y                       : array-like of shape (n_samples,) or (n_samples, n_targets)
                                Target values.

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or array-like of shape (n_targets,) Independent term in decision function.
       model.coef_              : array-like of shape (n_features,) or (n_targets, n_features)
                                Parameter vector (w in the formulation formula).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_LassoLarsCV() method
    def ml_scikit_LassoLarsCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.LassoLarsCV
        """

        # Import packages
        from sklearn.linear_model import LassoLars
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LassoLars.html
        #
        # string_reg_method = LassoLarsCV
        #
        # alpha: float, default=1.0
        # Constant that multiplies the penalty term. Defaults to 1.0. alpha = 0
        # is equivalent to an ordinary least square, solved by LinearRegression.
        # For numerical reasons, using alpha = 0 with the LassoLarsCV object is
        # not advised and you should prefer the LinearRegression object.
        #
        # fit_intercept: bool, default=True
        # whether to calculate the intercept for this model. If set to false, no
        # intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # verbose: bool or int, default=False
        # Sets the verbosity amount
        #
        # normalize: bool, default=True
        # This parameter is ignored when fit_intercept is set to False.
        # If True, the regressors X will be normalized before regression by
        # subtracting the mean and dividing by the l2-norm. If you wish to
        # standardize,
        # please use sklearn.preprocessing.StandardScaler before calling fit on
        # an estimator with normalize=False.
        #
        # precompute: bool, ‘auto’ or array-like, default=’auto’
        # Whether to use a precomputed Gram matrix to speed up calculations.
        # If set to 'auto' let us decide. The Gram matrix can also be passed as
        # argument.
        #
        # max_iter:int, default=500
        # Maximum number of iterations to perform.
        #
        # eps: float, optional
        # The machine-precision regularization in the computation of the
        # Cholesky diagonal factors. Increase this for very ill-conditioned
        # systems.
        # Unlike the tol parameter in some iterative optimization-based
        # algorithms, this parameter does not control the tolerance of the
        # optimization.
        # By default, np.finfo(np.float).eps is used.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.
        #
        # positive: bool, default=False
        # Restrict coefficients to be >= 0. Be aware that you might want to
        # remove fit_intercept which is set True by default.
        # Under the positive restriction the model coefficients will not
        # converge to the ordinary-least-squares solution for small values of
        # alpha.
        # Only coefficients up to the smallest alpha value
        # (alphas_[alphas_ > 0.].min()
        # when fit_path=True) reached by the stepwise Lars-Lasso algorithm are
        # typically in congruence with the solution of the coordinate descent
        # Lasso estimator.

        # Show message
        print("\nRegression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "LassoLarsCV":

                # For alpha_min
                alpha_min = float(line[1])

                # For alpha_max
                alpha_max = float(line[2])

                # For n_samples
                n_samples = int(line[3])

                # For fit_in
                if line[4] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For ver_in
                if line[5] == "True":
                    ver_in = True
                elif line[5] == "False":
                    ver_in = False
                else:
                    ver_in = int(line[5])

                # For norm_in
                if line[6] == "True":
                    norm_in = True
                else:
                    norm_in = False

                # For pre_in
                if line[7] == "True":
                    pre_in = True
                elif line[7] == "False":
                    pre_in = False
                else:
                    pre_in = line[7]

                # For max_in
                max_in = int(line[8])

                # For eps_in
                eps_in = float(line[9])

                # For copy_in
                if line[10] == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For pos_in
                if line[11] == "True":
                    pos_in = True
                else:
                    pos_in = False

                # For cv_in
                cv_in = int(line[12])

                # For self.rand_in
                self.rand_in = int(line[13])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Minimum alpha : {:.5e}".format(alpha_min))
        print("Maximum alpha : {:.5e}".format(alpha_max))
        print("Fit intercept? "+line[4])
        print("Normalize? "+line[6])
        print("Pre compute? "+line[7])
        print("Maximum number of iterations: {}".format(max_in))
        print("The machine-precision regularization (eps): {}".format(eps_in))
        print("Copy x array? "+line[10])
        print("Force the coefficients to be positive? "+line[11])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Set up alpha_array
        alpha_array =  np.linspace(alpha_min, alpha_max, num=n_samples)

        # Set up empty list
        residuals = []

        # Looping through alpha_array
        print("Optimizing alpha.")
        for alpha_in in alpha_array:

            # Show progress points
            print(end=".")

            # Instantiate an object of LassoLars class
            model = LassoLars(
                    alpha = alpha_in,           # alpha: float, default=1.0
                    fit_intercept = fit_in,     # fit_intercept: bool, default=True
                    verbose=ver_in,             # verbose: bool or int, default=False
                    normalize = norm_in,        # normalize: bool, default=True
                    precompute = pre_in,        # precompute: bool, ‘auto’ or array-like, default=’auto’
                    max_iter = max_in,          # max_iter:int, default=500
                    eps=eps_in,                 # eps: float, optional
                    copy_X = copy_in,           # copy_X: bool, default=True
                    positive = pos_in           # positive: bool, default=False
                    )

            # Call fit method
            model.fit(self.X, self.y)

            # Calculate residue
            residuals.append(np.mean((model.predict(self.X) - self.y)**2))

        print("\nDone!")

        # Get model for minimum residual
        minimum_index = np.argmin(residuals)

        # Instantiate an object of LassoLars class
        model = LassoLars(
                alpha=alpha_array[minimum_index],   # alpha: float, optional
                fit_intercept = fit_in,             # fit_intercept: bool, default=True
                verbose=ver_in,                     # verbose: bool or int, default=False
                normalize = norm_in,                # normalize: bool, default=True
                precompute = pre_in,                # precompute: bool, ‘auto’ or array-like, default=’auto’
                max_iter = max_in,                  # max_iter:int, default=500
                eps=eps_in,                         # eps: float, optional
                copy_X = copy_in,                   # copy_X: bool, default=True
                positive = pos_in                   # positive: bool, default=False
                )

        # Show information about the best model
        print("Best alpha : {:.5f}".format(alpha_array[minimum_index]))

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_