#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Define ExtraTreeRegressorCV() class
class ExtraTreeRegressorCV(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_ExtraTreeRegressorCV() method
    def ml_scikit_ExtraTreeRegressorCV(self):
        """
        Method to generate a multiple regression model using
        ExtraTreeRegressorCV
        """

        # Import packages
        from sklearn.tree import ExtraTreeRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.tree.ExtraTreeRegressor.html
        #
        # string_reg_method = ExtraTreeRegressorCV
        #
        #
        # criterion: {“squared_error”, “friedman_mse”}, default=”squared_error”
        # The function to measure the quality of a split. Supported criteria
        # are “squared_error” for the mean squared error, which is equal to
        # variance reduction as feature selection criterion and “mae” for
        # the mean absolute error.
        #
        # splitter: {"best","random"}, default="random"
        # The strategy used to choose the split at each node. Supported
        # strategies are “best” to choose the best split and “random” to choose
        # the best random split.
        #
        # max_depth: int, default=None
        # The maximum depth of the tree. If None, then nodes are expanded until
        # all leaves are pure or until all leaves contain less than
        # min_samples_split samples.
        #
        # min_samples_split: int or float, default=2
        # The minimum number of samples required to split an internal node:
        # If int, then consider min_samples_split as the minimum number.
        # If float, then min_samples_split is a fraction and
        # ceil(min_samples_split * n_samples) are the minimum number of samples
        # for each split.
        #
        # min_samples_leaf: int or float, default=1
        # The minimum number of samples required to be at a leaf node. A split
        # point at any depth will only be considered if it leaves at least
        # min_samples_leaf training samples in each of the left and right
        # branches. This may have the effect of smoothing the model, especially
        # in regression.
        # If int, then consider min_samples_leaf as the minimum number.
        # If float, then min_samples_leaf is a fraction and
        # ceil(min_samples_leaf * n_samples) are the minimum number of samples
        # for each node.
        #
        # min_weight_fraction_leaf: float, default=0.0
        # The minimum weighted fraction of the sum total of weights
        # (of all the input samples) required to be at a leaf node. Samples
        # have equal weight when sample_weight is not provided.
        #
        # max_features: int, float or {“auto”, “sqrt”, “log2”}, default=None
        # The number of features to consider when looking for the best split:
        # If int, then consider max_features features at each split.
        # If float, then max_features is a fraction
        # and int(max_features * n_features) features are considered at
        # each split.
        # If “auto”, then max_features=n_features.
        # If “sqrt”, then max_features=sqrt(n_features).
        # If “log2”, then max_features=log2(n_features).
        # If None, then max_features=n_features.
        # Note: the search for a split does not stop until at least one valid
        # partition of the node samples is found, even if it requires to
        # effectively inspect more than max_features features.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls the randomness of the estimator. The features are always
        # randomly permuted at each split, even if splitter is set to "best".
        # When max_features < n_features, the algorithm will select max_features
        # at random at each split before finding the best split among them. But
        # the best found split may vary across different runs, even
        # if max_features=n_features. That is the case, if the improvement of
        # the criterion is identical for several splits and one split has to be
        # selected at random. To obtain a deterministic behaviour during
        # fitting, random_state has to be fixed to an integer.
        #
        # min_impurity_decrease: float, default=0.0
        # A node will be split if this split induces a decrease of the impurity
        # greater than or equal to this value.
        # The weighted impurity decrease equation is the following:
        # N_t / N * (impurity - N_t_R / N_t * right_impurity
        # - N_t_L / N_t * left_impurity)
        # where N is the total number of samples, N_t is the number of samples
        # at the current node, N_t_L is the number of samples in the left child,
        # and N_t_R is the number of samples in the right child.
        # N, N_t, N_t_R and N_t_L all refer to the weighted sum, if
        # sample_weight is passed.
        #
        # max_leaf_nodes: int, default=None
        # Grow a tree with max_leaf_nodes in best-first fashion. Best nodes are
        # defined as relative reduction in impurity. If None then unlimited
        # number of leaf nodes.
        #
        # ccp_alpha: non-negative float, default=0.0
        # Complexity parameter used for Minimal Cost-Complexity Pruning. The
        # subtree with the largest cost complexity that is smaller than
        # ccp_alpha will be chosen. By default, no pruning is performed.

        # Show message
        print("\nExtremely Randomized Tree Regressor")
        print("Regression parameters read from ml.csv")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "ExtraTreeRegressorCV":

                # For criterion_in
                list_criteria = ["squared_error","friedman_mse"]
                if line[1].strip() in list_criteria:
                    criterion_in = line[1].strip()
                else:
                    criterion_in = "squared_error"
                    print("Unrecognizable input!")

                # For splitter_in
                list_splitter = ["best","random"]
                if line[2].strip() in list_splitter:
                    splitter_in = line[2].strip()
                else:
                    splitter_in = "random"
                    print("Unrecognizable input!")

                # For max_depth_in
                try:
                    max_depth_in = int(line[3].strip())
                except:
                    max_depth_in = None

                # For min_samples_split_in
                if "." in str(line[4].strip()):
                    min_samples_split_in = float(line[4].strip())
                else:
                    min_samples_split_in = int(line[4].strip())

                # For min_samples_leaf_in
                if "." in str(line[5].strip()):
                    min_samples_leaf_in = float(line[5].strip())
                else:
                    min_samples_leaf_in = int(line[5].strip())

                # For min_weight_fraction_leaf_in
                min_weight_fraction_leaf_in = float(line[6].strip())

                # For max_features_in
                list_max_features = ["auto","sqrt","log2"]
                if line[7].strip() in list_max_features:
                    max_features_in = line[7].strip()
                elif line[7].strip() == "None":
                    max_features_in = None
                elif "." in str(line[7].strip()):
                    max_features_in = float(line[7].strip())
                else:
                    max_features_in = int(line[7].strip())

                # For random_state_in
                if line[8].strip() == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[8].strip())

                # For min_impurity_decrease_in
                min_impurity_decrease_in = float(line[9].strip())

                # For max_leaf_nodes_in
                if line[10].strip() == "None":
                    max_leaf_nodes_in = None
                else:
                    max_leaf_nodes_in = int(line[10].strip())

                # For ccp_alpha_in
                ccp_alpha_in = float(line[11].strip())

                # For cv_in
                cv_in = int(line[12].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Function to measure the quality of a split: ",line[1])
        print("Strategy used to choose the split at each node: ",line[2])
        print("Maximum depth of the tree: ",line[3])
        print("Minimum number of samples required to split an internal node: ",
        line[4])
        print("Minimum number of samples required to be at a leaf node: ",
        line[5])
        line_out6 = "Minimum weighted fraction of the sum total of weights "
        line_out6 += "required to be at a leaf node: "
        print(line_out6,line[6])
        print("Number of features to consider when looking for the best split: ",
        line[7])
        print("Used to pick randomly the max_features used at each split: ",
        line[8])
        print("Minimum impurity decrease: ",line[9])
        print("Grow trees with max_leaf_nodes in best-first fashion: ",line[10])
        print("Complexity parameter used for Minimal Cost-Complexity Pruning: ",
        line[11])
        print("Kfold class to build a N-fold cross-validation loop. N = ",
        line[12])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of ExtraTreeRegressor class
        ########################################################################
        model = ExtraTreeRegressor(
            criterion=criterion_in,         # criterion: {“squared_error”, “friedman_mse”}, default=”squared_error”
            splitter=splitter_in,           # splitter: {"best","random"}, default="random"
            max_depth=max_depth_in,         # max_depth: int, default=None
            min_samples_split=min_samples_split_in,    # min_samples_split: int or float, default=2
            min_samples_leaf=min_samples_leaf_in,      # min_samples_leaf: int or float, default=1
            min_weight_fraction_leaf=min_weight_fraction_leaf_in,   # min_weight_fraction_leaf: float, default=0.0
            max_features=max_features_in,   # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=auto
            random_state=random_state_in,   # random_state: int, RandomState instance or None, default=None
            min_impurity_decrease=min_impurity_decrease_in,     # min_impurity_decrease: float, default=0.0
            max_leaf_nodes=max_leaf_nodes_in,          # max_leaf_nodes: int, default=None
            ccp_alpha=ccp_alpha_in          # ccp_alpha: non-negative float, default=0.0
            )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return model