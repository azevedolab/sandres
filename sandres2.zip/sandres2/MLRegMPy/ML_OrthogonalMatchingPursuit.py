#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define OrthogonalMatchingPursuit() class
class OrthogonalMatchingPursuit(object):
    """Class to carry out orthogonal matching pursuit regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : array-like, shape (n_samples, n_features). Training data.
        y                       : array-like, shape (n_samples,) or (n_samples, n_targets)
                                Target values. Will be cast to X’s dtype if necessary

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or array, shape (n_targets,) independent term in decision function.
       model.coef_              : array, shape (n_features,) or (n_targets, n_features) parameter vector (w in the formula)
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y,num_indep_var):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y
        self.num_indep_var = num_indep_var

    # Define ml_scikit_OrthogonalMatchingPursuit() method
    def ml_scikit_OrthogonalMatchingPursuit(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.svm.OrthogonalMatchingPursuit
        """

        # Import packages
        from sklearn.linear_model import OrthogonalMatchingPursuit
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.OrthogonalMatchingPursuit.html
        #
        # string_reg_method = OrthogonalMatchingPursuit
        #
        #
        # n_nonzero_coefs: int, optional
        # Desired number of non-zero entries in the solution. If None
        # (by default) this value is set to 10% of n_features.
        #
        # tol: float, optional
        # Maximum norm of the residual. If not None, overrides n_nonzero_coefs.
        #
        # fit_intercept: boolean, optional
        # whether to calculate the intercept for this model. If set to false, no
        # intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # normalize: boolean, optional, default True
        # This parameter is ignored when fit_intercept is set to False. If True,
        # the regressors X will be normalized before regression by subtracting
        # the mean and dividing by the l2-norm.
        # If you wish to standardize, please use
        # sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # precompute: {True, False, ‘auto’}, default ‘auto’
        # Whether to use a precomputed Gram and Xy matrix to speed up
        # calculations.
        # Improves performance when n_targets or n_samples is very large. Note
        # that if you already have such matrices, you can pass them directly to
        # the fit method.

        # Show message
        print("\nOrthogonal Matching Pursuit Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "OrthogonalMatchingPursuit":

                # For fit_in
                if line[1] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For norm_in
                if line[2] == "True":
                    norm_in = True
                else:
                    norm_in = False

                # For pre_in
                if line[3] == "True":
                    pre_in = True
                else:
                    pre_in = False

                # For cv_in
                cv_in = int(line[4])

                # For self.rand_in (for MDM file)
                self.rand_in = int(line[5])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        line_out1 = "Number of non-zero entries in the solution: "
        print(line_out1,self.num_indep_var-1)
        print("Fit intercept? "+line[1])
        print("Normalize? ", line[2])
        print("Pre-compute? ",line[3])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of OrthogonalMatchingPursuit class
        model = OrthogonalMatchingPursuit(
                n_nonzero_coefs=self.num_indep_var-1,   # n_nonzero_coefs: int, optional
                fit_intercept=fit_in,                   # fit_intercept: boolean, optional
                normalize=norm_in,                      # normalize: boolean, optional, default True
                precompute=pre_in                       # precompute: {True, False, ‘auto’}, default ‘auto’
                )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_