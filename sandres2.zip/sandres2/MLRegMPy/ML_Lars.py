#!/usr/bin/env python3
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2022                                                             #
################################################################################
#
# Define Lars() class
class Lars(object):
    """Class to carry out Lars regression
    Least Angle Regression model a.k.a. LAR

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        x                       : array-like of shape (n_samples, n_features). Training data.
        y                       : array-like of shape (n_samples,) or (n_samples, n_targets)
                                Target values.

    Outputs
       rand_in                  : Random seed
       model                    : Regression model
       model.intercept_         : float or array-like of shape (n_targets,)
                                Independent term in decision function.
       model.coef_              : array-like of shape (n_features,) or (n_targets, n_features)
                                Parameter vector (w in the formulation formula).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_Lars() method
    def ml_scikit_Lars(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.Lars
        """

        # Import packages
        from sklearn.linear_model import Lars
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Lars.html
        #
        # string_reg_method = Lars
        #
        # fit_intercept: bool, default=True
        # Whether to calculate the intercept for this model. If set to false, no
        # intercept will be used in calculations
        # (i.e. data is expected to be centered).
        #
        # verbose: bool or int, default=False
        # Sets the verbosity amount
        #
        # normalize: bool, default=True
        # This parameter is ignored when fit_intercept is set to False. If True,
        # the regressors X will be normalized before
        # regression by subtracting the mean and dividing by the l2-norm. If you
        # wish to standardize, please use
        # sklearn.preprocessing.StandardScaler before calling fit on an
        # estimator with normalize=False.
        #
        # precompute: bool, ‘auto’ or array-like , default=’auto’
        # Whether to use a precomputed Gram matrix to speed up calculations. If
        # set to 'auto' let us decide.
        # The Gram matrix can also be passed as argument.
        #
        # n_nonzero_coefs: int, default=500
        # Target number of non-zero coefficients. Use np.inf for no limit.
        #
        # eps: float, optional
        # The machine-precision regularization in the computation of the
        # Cholesky diagonal factors.
        # Increase this for very ill-conditioned systems. Unlike the tol
        # parameter in some iterative
        # optimization-based algorithms, this parameter does not control the
        # tolerance of the optimization.
        #
        # copy_X: bool, default=True
        # If True, X will be copied; else, it may be overwritten.

        # Show message
        print("\nLeast Angle Regression (LAR)")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0].strip() == "Lars" and line[0].strip() != "LassoLars":

                # For fit_in
                if line[1].strip() == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For ver_in
                if line[2].strip() == "True":
                    ver_in = True
                elif line[2].strip() == "False":
                    ver_in = False
                else:
                    ver_in = int(line[2].strip())

                # For pre_in
                if line[3].strip() == "True":
                    pre_in = True
                elif line[3].strip() == "False":
                    pre_in = False
                else:
                    pre_in = line[3].strip()

                # For non_zero_in
                non_zero_in = int(line[4].strip())

                # For eps_0
                eps_0 = float(line[5].strip())

                # For eps_1
                eps_1 = float(line[6].strip())

                # For n_samples_in
                n_samples_in = int(line[7].strip())

                # For copy_in
                if line[8].strip() == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For fit_path_in
                if line[9].strip() == "True":
                    fit_path_in = True
                else:
                    fit_path_in = False

                # For jitter_in
                if line[10].strip() == "None":
                    jitter_in = None
                else:
                    jitter_in = float(line[10].strip())

                # For rand_in (for MDM)
                rand_in = int(line[11].strip())

                # Finish loop
                break

        # Close file
        fo.close()

        # Show input parameters read from ml.in
        print("Regression method: ",line[0])
        print("Fit intercept? "+line[1])
        print("Pre compute? "+line[4])
        print("Target number of non-zero coefficients: {}".format(non_zero_in))
        print("Machine-precision regularization (minimum):{:.5e}".format(eps_0))
        print("Machine-precision regularization (maximum):{:.5e}".format(eps_1))
        print("Copy x array? ",line[8])
        print("If True the full path is stored in the coef_path_ attribute: ",
        line[9])
        m10 = "Upper bound on a uniform noise parameter to be added to the "
        m10 += "y values: "+line[10]
        print(m10)
        print("Determines random number generation for jittering: ",line[11])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Set up eps_array
        eps_array =  np.linspace(eps_0, eps_1, num=n_samples_in)

        # Set up empty list
        residuals = []

        # Looping through alpha_array
        print("Optimizing eps...")
        for eps_in in eps_array:

            # Show progress points
            print(end=".")

            # Instantiate an object of Lars class
            model = Lars(
                    fit_intercept = fit_in,         # fit_intercept: bool, default=True
                    verbose = ver_in,               # verbose: bool or int, default=False
                    precompute = pre_in,            # precompute: bool, ‘auto’ or array-like , default=’auto’
                    n_nonzero_coefs = non_zero_in,  # n_nonzero_coefs: int, default=500
                    eps = eps_in,                   # eps: float, optional
                    copy_X = copy_in,               # copy_X: boolean, optional, default True
                    fit_path = fit_path_in,         # fit_path: bool, default=True
                    jitter = jitter_in              # jitterfloat, default=None
                    )

            # Call fit method
            model.fit(self.X, self.y)

            # Calculate residue
            residuals.append(np.mean((model.predict(self.X) - self.y)**2))

        print("\nDone!")

        # Get model for minimum residual
        minimum_index = np.argmin(residuals)

        # Instantiate an object of Lars class
        model = Lars(
                fit_intercept = fit_in,         # fit_intercept: bool, default=True
                verbose = ver_in,               # verbose: bool or int, default=False
                precompute = pre_in,            # precompute: bool, ‘auto’ or array-like , default=’auto’
                n_nonzero_coefs = non_zero_in,  # n_nonzero_coefs: int, default=500
                eps = eps_array[minimum_index], # eps: float, optional
                copy_X = copy_in,               # copy_X: boolean, optional, default True
                fit_path = fit_path_in,         # fit_path: bool, default=True
                jitter = jitter_in              # jitterfloat, default=None
                )

        # Show information about the best model
        print("Best eps : {:.5f}".format(eps_array[minimum_index]))

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return rand_in,model,model.intercept_,model.coef_