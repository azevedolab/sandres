#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
###############################################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    MLRegMPy is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    MLRegMPy is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MLRegMPy.  If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################################################
#
# Contact
# MLRegMPy, SAnDReS, and Taba are in continuous development, feel free
# to download the latest version and use them in your machine learning
# modelling. If you have any question regarding
# MLRegMPy, SAnDReS, and Taba, please feel free
# to e-mail me: walter@azevedolab.net
#
# Funding
# Funding Agency: Conselho Nacional de Desenvolvimento Científico e Tecnológico-
# National Counsel of Technological
# and Scientific Development (www.cnpq.br)
# Principal Investigator : Walter F. de Azevedo Jr., Ph.D
# Process Numbers: 472590/2012-0, 308883/2014-4, and 309029/2018-0.
#
###############################################################################################################
#
# Define PoissonRegressor() class
class PoissonRegressor(object):
    """Class to carry out linear regression

    Inputs
        file_in                 : csv file with regression parameters
        X                       : {array-like, sparse matrix} of shape (n_samples, n_features)
                                Training data
        y                       : array-like of shape (n_samples,) or (n_samples, n_targets)
                                Target values. Will be cast to X’s dtype if necessary
    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float or array of shape of (n_targets,). Independent term in the linear model.
                                Set to 0.0 if fit_intercept = False.
       model.coef_              : array of shape (n_features, ) or (n_targets, n_features)
                                Estimated coefficients for the linear regression problem.
                                If multiple targets are passed during the fit (y 2D), this is a 2D array of shape (n_targets, n_features),
                                while if only one target is passed, this is a 1D array of length n_features.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_PoissonRegressor() method
    def ml_scikit_PoissonRegressor(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.PoissonRegressor
        """

        # Import libraries
        from sklearn.linear_model import PoissonRegressor
        from sklearn.model_selection import KFold, cross_val_score
        from sklearn.metrics import mean_squared_error
        from warnings import simplefilter
        import numpy as np
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.PoissonRegressor.html#sklearn.linear_model.PoissonRegressor
        #
        # string_reg_method = PoissonRegressor
        #
        #
        # alpha: float, default=1.0
        # Constant that multiplies the penalty term and thus determines the
        # regularization strength. alpha = 0 is equivalent to unpenalized GLMs.
        # In this case, the design matrix X must have full column rank
        # (no collinearities).
        #
        # fit_intercept: bool, default=True
        # Specifies if a constant (a.k.a. bias or intercept) should be added to
        # the linear predictor (X @ coef + intercept).
        #
        # max_iter: int, default=100
        # The maximal number of iterations for the solver.
        #
        # tol: float, default=1e-4
        # Stopping criterion. For the lbfgs solver, the iteration will stop
        # when max{|g_j|, j = 1, ..., d} <= tol where g_j is the j-th component
        # of the gradient (derivative) of the objective function.
        #
        # warm_start: bool, default=False
        # If set to True, reuse the solution of the previous call to fit as
        # initialization for coef_ and intercept_ .
        #
        # verbose: int, default=0
        # For the lbfgs solver set verbose to any positive number for verbosity.

        # Show message
        print("\nPoisson Regression")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "PoissonRegressor":

                # For alpha_in
                alpha_in = float(line[1])

                # For fit_intercept_in
                if line[2] == "True":
                    fit_intercept_in = True
                else:
                    fit_intercept_in = False

                # For max_iter_in
                max_iter_in = int(line[3])

                # For tol_in
                tol_in = float(line[4])

                # For warm_start_in
                if line[5] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For verbose_in
                verbose_in = int(line[6])

                # For cv_in
                cv_in = int(line[7])

                # For self.rand_in
                self.rand_in = int(line[8])

                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Alpha: ",line[1])
        line_out2 = "Specifies if a constant should be added to the "
        line_out2 += "linear predictor: "
        print(line_out2,line[2])
        print("Maximal number of iterations for the solver: ",line[3])
        print("Stopping criterion: ",line[4])
        line_out5 = "If set to True, reuse the solution of the previous call "
        line_out5 += "to fit as initialization: "
        print(line_out5,line[5])
        print("Number for verbosity: ",line[6])

        # Instantiate an object of PoissonRegressor class
        model = PoissonRegressor(
                alpha=alpha_in,         # alpha: float, default=1.0
                fit_intercept=fit_intercept_in,     # fit_intercept: bool, default=True
                max_iter=max_iter_in,   # max_iter: int, default=100
                tol=tol_in,             # tol: float, default=1e-4
                warm_start=warm_start_in,   # warm_start: bool, default=False
                verbose=verbose_in      # verbose: int, default=0
                )

        # Set up k-fold class
        # Kfold class to build a 5 fold cross-validation loop and test the
        # generalization ability of linear regression. With cross-validation, we
        # generally obtain a more conservative estimate(that is, the error is
        # larger).
        # The cross-validation estimate is a better estimate of how well we
        # could generalize to predict on unseen data.
        #
        # Reference:
        # Coelho LP, Richert W. (2015) Building Machine Learning Systems with
        # Python. 2nd ed. Packt Publishing Ltd. Birmingham UK. 301 pp.
        # See page 162 (Cross-validation for regression)
        kf = KFold(n_splits=cv_in) # Set up cv_in =5

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Set up an array
        p = np.zeros_like(self.y)

        # Looping through kf.split()
        for train,test in kf.split(self.X):

            # Generate regression model
            model.fit(self.X[train], self.y[train])

            # Assign predicted values for internal test set
            p[test] = model.predict(self.X[test])

        # Show RMSE for test set
        rmse_cv = np.sqrt(mean_squared_error(p, self.y))
        print('\nRMSE on 5-fold CV for test set: {:.2}'.format(rmse_cv))

        # Show average coefficient of determination using 5-fold crossvalidation
        scores = cross_val_score(model,self.X,self.y,cv=kf)
        m1 = "Average coefficient of determination using 5-fold crossvalidation"
        print("\n"+m1+":",np.mean(scores))

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_