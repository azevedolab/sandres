#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# Da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define RandomForestRegressor() class
class RandomForestRegressor(object):
    """Class to combine predictors using stacking


    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       :ndarray or sparse matrix of shape (n_samples, n_features)
                                The input data.
        y                       : ndarray of shape (n_samples,) or (n_samples, n_outputs)
                                The target values (class labels in classification, real numbers in regression).

    Output
       model                    : Regression model
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_RandomForestRegressor() method
    def ml_scikit_RandomForestRegressor(self):
        """
        Method to generate a multiple regression model using
        RandomForestRegressor
        """

        # Import packages
        from sklearn.ensemble import RandomForestRegressor
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html
        #
        # string_reg_method = RandomForestRegressor
        #
        #
        # https://heartbeat.fritz.ai/random-forest-regression-in-python-using-scikit-learn-9e9b147e2153
        #
        # n_estimators: int, default=100
        # The number of trees in the forest.
        # Changed in version 0.22: The default value of n_estimators changed
        # from 10 to 100 in 0.22.
        #
        # criterion: {“mse”, “mae”}, default=”mse”
        # The function to measure the quality of a split. Supported criteria are
        # “mse” for
        # the mean squared error, which is equal to variance reduction as
        # feature selection criterion, and “mae” for the mean absolute error.
        # New in version 0.18: Mean Absolute Error (MAE) criterion.
        #
        # max_depth: int, default=None
        # The maximum depth of the tree. If None, then nodes are expanded until
        # all leaves are pure or until all leaves contain less than
        # min_samples_split samples.
        #
        # min_samples_split: int or float, default=2
        # The minimum number of samples required to split an internal node:
        # If int, then consider min_samples_split as the minimum number.
        # If float, then min_samples_split is a fraction and
        # ceil(min_samples_split * n_samples)
        # are the minimum number of samples for each split.
        # Changed in version 0.18: Added float values for fractions.
        #
        # min_samples_leaf: int or float, default=1
        # The minimum number of samples required to be at a leaf node. A split
        # point at any depth will only be considered if it leaves at least
        # min_samples_leaf training samples in each of the left and right
        # branches. This may have the effect of smoothing the model, especially
        # in regression.
        # If int, then consider min_samples_leaf as the minimum number.
        # If float, then min_samples_leaf is a fraction and
        # ceil(min_samples_leaf * n_samples)
        # are the minimum number of samples for each node.
        # Changed in version 0.18: Added float values for fractions.
        #
        # min_weight_fraction_leaf: float, default=0.0
        # The minimum weighted fraction of the sum total of weights
        # (of all the input samples) required to be at a leaf node. Samples
        # have equal weight when sample_weight is not provided.
        #
        # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
        # The number of features to consider when looking for the best split:
        # If int, then consider max_features features at each split.
        # If float, then max_features is a fraction and
        # round(max_features * n_features)
        # features are considered at each split.
        # If “auto”, then max_features=n_features.
        # If “sqrt”, then max_features=sqrt(n_features).
        # If “log2”, then max_features=log2(n_features).
        # If None, then max_features=n_features.
        # Note: the search for a split does not stop until at least one valid
        # partition of the node samples is found, even if it requires to
        # effectively inspect more than max_features features.
        #
        # max_leaf_nodes: int, default=None
        # Grow trees with max_leaf_nodes in best-first fashion. Best nodes are
        # defined as relative reduction in impurity. If None then unlimited
        # number of leaf nodes.
        #
        # min_impurity_decrease: float, default=0.0
        # A node will be split if this split induces a decrease of the impurity
        # greater than or equal to this value.
        # The weighted impurity decrease equation is the following:
        # N_t / N * (impurity - N_t_R / N_t * right_impurity
        #            - N_t_L / N_t * left_impurity)
        # where N is the total number of samples, N_t is the number of samples
        # at the current node, N_t_L is the number of samples in the left child,
        # and N_t_R is the number of samples in the right child.
        # N, N_t, N_t_R and N_t_L all refer to the weighted sum, if
        # sample_weight is passed.
        #
        # min_impurity_split: float, default=None(Deprecated since version 0.19)
        # Threshold for early stopping in tree growth. A node will split if its
        # impurity is above the threshold, otherwise it is a leaf.
        # Deprecated since version 0.19: min_impurity_split has been deprecated
        # in favor of min_impurity_decrease in 0.19. The default value of
        # min_impurity_split has changed from 1e-7 to 0 in 0.23 and it will be
        # removed in 1.0 (renaming of 0.25).
        # Use min_impurity_decrease instead.
        #
        # bootstrap: bool, default=True
        # Whether bootstrap samples are used when building trees.
        # If False, the whole dataset is used to build each tree.
        #
        # oob_score: bool, default=False
        # Whether to use out-of-bag samples to estimate the generalization
        # score.
        # Only available if bootstrap=True.
        #
        # n_jobs: int, default=None
        # The number of jobs to run in parallel. fit, predict, decision_path and
        # apply are all parallelized over the trees. None means 1 unless in a
        # joblib.parallel_backend context. -1 means using all processors.
        #
        # random_state: int, RandomState instance or None, default=None
        # Controls both the randomness of the bootstrapping of the samples used
        # when building trees(if bootstrap=True) and the sampling of the
        # features to consider when looking for the best
        # split at each node (if max_features < n_features). See Glossary for details.
        #
        # verbose: int, default=0
        # Controls the verbosity when fitting and predicting.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit and
        # add more estimators to the ensemble, otherwise, just fit a whole new
        # forest.
        #
        # ccp_alpha: non-negative float, default=0.0
        # Complexity parameter used for Minimal Cost-Complexity Pruning.
        # The subtree with the largest cost complexity that is smaller than
        # ccp_alpha will be chosen.
        # By default, no pruning is performed. See Minimal Cost-Complexity
        # Pruning for details.
        #
        # max_samples: int or float, default=None
        # If bootstrap is True, the number of samples to draw from X to train
        # each base estimator.
        # If None (default), then draw X.shape[0] samples.
        # If int, then draw max_samples samples.
        # If float, then draw max_samples * X.shape[0] samples.
        # Thus, max_samples should be in the interval (0, 1).
        # New in version 0.22.

        # Show message
        print("\nRandom Forest Regressor")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "RandomForestRegressor":

                # For n_estimators_in
                n_estimators_in = int(line[1])

                # For criterion_in
                criterion_in = line[2]

                # For max_depth_in
                try:
                    max_depth_in = int(line[3])
                except:
                    max_depth_in = None

                # For min_samples_split_in
                if "." in str(line[4]):
                    min_samples_split_in = float(line[4])
                else:
                    min_samples_split_in = int(line[4])

                # For min_samples_leaf_in
                if "." in str(line[5]):
                    min_samples_leaf_in = float(line[5])
                else:
                    min_samples_leaf_in = int(line[5])

                # For min_weight_fraction_leaf_in
                min_weight_fraction_leaf_in = float(line[6])

                # For max_features_in
                list_max_features = ["auto","sqrt","log2"]
                if line[7] in list_max_features:
                    max_features_in = line[7]
                elif line[7] == "None":
                    max_features_in = None
                elif "." in str(line[7]):
                    max_features_in = float(line[7])
                else:
                    max_features_in = int(line[7])

                # For max_leaf_nodes_in
                if line[8] == "None":
                    max_leaf_nodes_in = None
                else:
                    max_leaf_nodes_in = int(line[8])

                # For min_impurity_decrease_in
                min_impurity_decrease_in = float(line[9])

                # For bootstrap_in
                if line[10] == "True":
                    bootstrap_in = True
                else:
                    bootstrap_in = False

                # For oob_score_in
                if line[11] == "True":
                    oob_score_in = True
                else:
                    oob_score_in = False

                # For n_jobs_in
                if line[12] == "None":
                    n_jobs_in = None
                else:
                    n_jobs_in = int(line[12])

                # For random_state_in
                if line[13] == "None":
                    random_state_in = None
                else:
                    random_state_in = int(line[13])

                # For verbose_in
                verbose_in = int(line[14])

                # For warm_start_in
                if line[15] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For ccp_alpha_in
                ccp_alpha_in = float(line[16])

                # For max_samples_in
                if line[17] == "None":
                    max_samples_in = None
                elif "." in str(line[17]):
                    max_samples_in = float(line[17])
                else:
                    max_samples_in = int(line[17])

                # For cv_in (set value to 5)
                cv_in = int(line[18])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Number of trees in the forest: {}".format(n_estimators_in))
        print("The function to measure the quality of a split: ",line[2])
        print("The maximum depth of the tree: ",line[3])
        line_out4 = "Minimum number of samples required to "
        print(line_out4+"split an internal node: ",line[4])
        print(line_out4+"be at a leaf node: ",line[5])
        print("Minimum weighted fraction of the sum total of weights: ",line[6])
        line_out7 = "Number of features to consider when looking for the "
        print(line_out7+"best split: ",line[7])
        print("Grow trees with max_leaf_nodes in best-first fashion: ",line[8])
        print("Minimum impurity decrease: ",line[9])
        line_out10 = "Whether bootstrap samples are used when building trees: "
        print(line_out10,line[10])
        line_out11 = "Whether to use out-of-bag samples to estimate the "
        print(line_out11+"generalization score: ",line[11])
        print("The number of jobs to run in parallel: ",line[12])
        line_out13 = "Controls both the randomness of the bootstrapping of "
        print(line_out13+"the samples: ",line[13])
        print("Controls the verbosity when fitting and predicting: ",line[14])
        line_out15 = "When set to True, reuse the solution of the previous "
        print(line_out15+"call to fit: ",line[15])
        print("Complexity parameter used for Minimal Cost-Complexity Pruning: ",
        line[16])
        line_out17 = "If bootstrap is True, the number of samples to draw from "
        print(line_out17+"X to train each base estimator: ",line[17])

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of RandomForestRegressor class
        ############################################################################
        model = RandomForestRegressor(
            n_estimators=n_estimators_in,   # n_estimators: int, default=100
            criterion=criterion_in,         # criterion: {“mse”, “mae”}, default=”mse”
            max_depth=max_depth_in,         # max_depth: int, default=None
            min_samples_split=min_samples_split_in,    # min_samples_split: int or float, default=2
            min_samples_leaf=min_samples_leaf_in,      # min_samples_leaf: int or float, default=1
            min_weight_fraction_leaf=min_weight_fraction_leaf_in,   # min_weight_fraction_leaf: float, default=0.0
            max_features=max_features_in,   # max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
            max_leaf_nodes=max_leaf_nodes_in,          # max_leaf_nodes: int, default=None
            min_impurity_decrease=min_impurity_decrease_in,
            bootstrap=bootstrap_in,         # bootstrap: bool, default=True
            oob_score=oob_score_in,         # oob_score: bool, default=False
            n_jobs=n_jobs_in,               # n_jobs: int, default=None
            random_state=random_state_in,   # random_state: int, RandomState instance or None, default=None
            verbose=verbose_in,             # verbose: int, default=0
            warm_start=warm_start_in,       # warm_start: bool, default=False
            ccp_alpha=ccp_alpha_in,         # ccp_alpha: non-negative float, default=0.0
            max_samples=max_samples_in      # max_samples: int or float, default=None
            #min_impurity_split=None
            )

        # Invoke fit method
        model.fit(self.X,self.y)

        # Return model and parameters
        return model