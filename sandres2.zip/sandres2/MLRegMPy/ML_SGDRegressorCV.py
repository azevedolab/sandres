#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define SGDRegressorCV() class
class SGDRegressorCV(object):
    """Class to carry out SGD regression
    Stochastic Gradient Descent Regression

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : {array-like, sparse matrix}, shape (n_samples, n_features). Training data
        y                       : ndarray of shape (n_samples,)
                                Target values

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : ndarray of shape (1,). The intercept term.
       model.coef_              : ndarray of shape (n_features,). Weights assigned to the features.
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_SGDRegressorCV() method
    def ml_scikit_SGDRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.SGDRegressorCV
        Note: SGDRegressorCV is well suited for regression problems with a large number of training samples (> 10.000),
        for other problems we recommend Ridge, Lasso, or ElasticNet.
        """

        # Import packages
        from sklearn.linear_model import SGDRegressor
        from sklearn.preprocessing import StandardScaler
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.SGDRegressor.html
        #
        # string_reg_method = SGDRegressorCV
        #
        #
        # loss: str, default=’squared_loss’
        # The loss function to be used. The possible values are ‘squared_loss’,
        #‘huber’, ‘epsilon_insensitive’, or
        # ‘squared_epsilon_insensitive’
        # The ‘squared_loss’ refers to the ordinary least squares fit. ‘huber’
        # modifies ‘squared_loss’ to focus less on getting
        # outliers correct by switching
        # from squared to linear loss past a distance of epsilon.
        # ‘epsilon_insensitive’ ignores errors less than epsilon and
        # is linear past that;
        # this is the loss function used in SVR. ‘squared_epsilon_insensitive’
        # is the same but becomes squared loss past
        # a tolerance of epsilon.
        #
        # penalty: {‘l2’, ‘l1’, ‘elasticnet’}, default=’l2’
        # The penalty (aka regularization term) to be used. Defaults to ‘l2’
        # which is the standard regularizer
        # for linear SVM models.
        # ‘l1’ and ‘elasticnet’ might bring sparsity to the model
        # (feature selection) not achievable with ‘l2’.
        #
        # alpha: float, default=0.0001
        # Constant that multiplies the regularization term. Also used to
        # compute learning_rate when set to ‘optimal’.
        #
        # l1_ratio: float, default=0.15
        # The Elastic Net mixing parameter, with
        # 0 <= l1_ratio <= 1. l1_ratio=0 corresponds to L2 penalty,
        # l1_ratio=1 to L1.
        #
        # fit_intercept: bool, default=True
        # Whether the intercept should be estimated or not. If False, the data
        # is assumed to be already centered.
        #
        # max_iter: int, default=1000
        # The maximum number of passes over the training data (aka epochs).
        # It only impacts the behavior in the fit method,
        # and not the partial_fit method.
        #
        # tol: float, default=1e-3
        # The stopping criterion. If it is not None, the iterations will stop
        # when (loss > best_loss - tol)
        # for n_iter_no_change consecutive epochs.
        #
        # shuffle: bool, default=True
        # Whether or not the training data should be shuffled after each epoch.
        #
        # verbose: int, default=0
        # The verbosity level.
        #
        # epsilon: float, default=0.1
        # Epsilon in the epsilon-insensitive loss functions; only if loss is
        # ‘huber’, ‘epsilon_insensitive’, or
        # ‘squared_epsilon_insensitive’.
        # For ‘huber’, determines the threshold at which it becomes less
        # important to get the prediction exactly right.
        # For epsilon-insensitive, any differences between the current
        # prediction and the correct label are ignored
        # if they are less than this threshold.
        #
        # random_state: int, RandomState instance, default=None
        # The seed of the pseudo random number generator to use when shuffling
        # the data.
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random.
        #
        # learning_rate: string, default=’invscaling’
        # The learning rate schedule:
        # ‘constant’:
        # eta = eta0
        # ‘optimal’:
        # eta = 1.0 / (alpha * (t + t0)) where t0 is chosen by a heuristic
        # proposed by Leon Bottou.
        # ‘invscaling’: [default]
        # eta = eta0 / pow(t, power_t)
        # ‘adaptive’:
        # eta = eta0, as long as the training keeps decreasing.
        # Each time n_iter_no_change consecutive epochs fail to decrease
        # the training loss by tol or fail to increase validation score by
        # tol if early_stopping is True, the current learning
        # rate is divided by 5.
        #
        # eta0: double, default=0.01
        # The initial learning rate for the ‘constant’, ‘invscaling’ or
        # ‘adaptive’ schedules. The default value is 0.01.
        #
        # power_t: double, default=0.25
        # The exponent for inverse scaling learning rate.
        #
        # warm_start: bool, default=False
        # When set to True, reuse the solution of the previous call to fit as
        # initialization, otherwise, just erase the
        # previous solution. See the Glossary.
        # Repeatedly calling fit or partial_fit when warm_start is True can
        # result in a different solution than
        # when calling fit a single time because of the
        # way the data is shuffled. If a dynamic learning rate is used, the
        # learning rate is adapted depending on
        # the number of samples already seen.
        # Calling fit resets this counter, while partial_fit will result in
        # increasing the existing counter.
        #
        # average: bool or int, default=False
        # When set to True, computes the averaged SGD weights and stores the
        # result in the coef_ attribute.
        # If set to an int greater than 1, averaging will begin once the total
        # number of samples seen reaches average.
        # So average=10 will begin averaging after seeing 10 samples.

        # Show message
        print("\nStochastic Gradient Descent Regression with Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        print("\nRegression parameters read from ml.in")
        for line in my_csv:
            if line[0] == "SGDRegressorCV":

                # For lo_in
                loss_in = line[1]

                # For pena_in
                if line[2] == "None":
                    penalty_in = None
                else:
                    penalty_in = line[2]

                # For alpha_in
                alpha_in = float(line[3])

                # For li_ratio_in
                l1_ratio_in = float(line[4])

                # For fit_intercept_in
                if line[5] == "True":
                    fit_intercept_in = True
                else:
                    fit_intercept_in = False

                # For max_in
                max_in = int(line[6])

                # For tol_in
                tol_in = float(line[7])

                # For shuffle_in
                if line[8] == "True":
                    shuffle_in = True
                else:
                    shuffle_in = False

                # For ver_in
                ver_in = int(line[9])

                # For epsilon_in
                epsilon_in = float(line[10])

                # For self.rand_in
                if line[11] == "None":
                    self.rand_in = None
                else:
                    self.rand_in = int(line[11])

                # For learning_rate_in
                learning_rate_in = line[12]

                # For eta0_in
                eta0_in = float(line[13])

                # For power_t_in
                power_t_in = float(line[14])

                # For warm_start_in
                if line[15] == "True":
                    warm_start_in = True
                else:
                    warm_start_in = False

                # For average_in
                if line[16] == "True":
                    average_in = True
                else:
                    average_in = False

                # For cv_in (set value to 5)
                cv_in = int(line[17])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Alpha = {:.5e}".format(alpha_in))
        print("Average = ",average_in)
        print("Epsilon = {:.5e}".format(epsilon_in))
        print("Eta0 = {:.5e}".format(eta0_in))
        print("Fit_intercept = ",fit_intercept_in)
        print("L1_ratio = {:.5e}".format(l1_ratio_in))
        print("Learning rate = ",learning_rate_in)
        print("Loss = ",loss_in)
        print("Penalty = ",penalty_in)
        print("Power_t = {:.5e}".format(power_t_in))
        print("Random_state = ",self.rand_in)
        print("Shuffle = ",shuffle_in)
        print("Warm_start = ",warm_start_in)
        note_out = "Note: SGDRegressorCV is well suited for regression problems "
        note_out += "with a large number of training samples (> 10.000)"
        print(note_out)

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Stochastic Gradient Descent is sensitive to feature scaling, so it is
        # highly recommended to scale your data
        scaler = StandardScaler()
        scaler.fit(self.X)  # Don't cheat - fit only on training data
        self.X = scaler.transform(self.X)

        # Instantiate an object of SGDRegressor class
        model = SGDRegressor(
                loss=loss_in,                   # loss: str, default=’squared_loss’
                penalty=penalty_in,             # penalty: {‘l2’, ‘l1’, ‘elasticnet’}, default=’l2’
                alpha=alpha_in,                 # alpha: float, default=0.0001
                l1_ratio=l1_ratio_in,           # l1_ratio: float, default=0.15
                fit_intercept=fit_intercept_in, # fit_intercept: bool, default=True
                max_iter = max_in,              # max_iter: int, default=1000
                tol = tol_in,                   # tol: float, default=1e-3
                shuffle=shuffle_in,             # shuffle: bool, default=True
                verbose=ver_in,                 # verbose: int, default=0
                epsilon=epsilon_in,             # epsilon: float, default=0.1
                random_state=self.rand_in,      # random_state: int, RandomState instance, default=None
                learning_rate=learning_rate_in, # learning_rate: string, default=’invscaling’
                eta0=eta0_in,                   # eta0: double, default=0.01
                power_t=power_t_in,             # power_t: double, default=0.25
                warm_start=warm_start_in,       # warm_start: bool, default=False
                average=average_in              # average: bool or int, default=False
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_