#!/usr/bin/python
#
# Machine Learning Regression Methods in Python (MLRegMPy)
#
# MLRegMPy: A Python package for regression methods using Python.
# In this package, we have regression methods implemented using
# scikit-learn library (Pedregosa et al., 2011;
# Bitencourt-Ferreira & Azevedo, 2019a)
# (https://scikit-learn.org/stable/modules/linear_model.html).
#
# This code was developed by Dr. Walter F. de Azevedo, Jr. and is the main
# engine used in the programs SAnDReS (Xavier et al., 2016) and Taba
# (da Silva et al., 2020).
# These methods are useful for the exploration of the scoring function space
# (Heck et al., 2017; Bitencourt-Ferreira & Azevedo, 2019b) to develop
# computational models targeted to specific protein systems.
#
# References:
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Machine Learning to Predict Binding
# Affinity. Methods Mol Biol. 2019a; 2053: 251–273.
# DOI: 10.1007/978-1-4939-9752-7_16
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019a; 2053: 275–281.
# DOI: 110.1007/978-1-4939-9752-7_17
#
# da Silva AD, Bitencourt-Ferreira G, de Azevedo WF Jr. Taba: A Tool to Analyze
# the Binding Affinity. J Comput Chem. 2020; 41(1): 69-73.
# DOI: 10.1002/jcc.26048
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand-Binding
# Affinity. Curr Med Chem. 2017; 24(23): 2459–2470.
# DOI: 10.2174/0929867324666170623092503
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011; 12: 2825–2830.
# arXiv:1201.0490
#
###############################################################################################################
#
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
# with help from
# Mariana M. Xavier, Gabriela Sehnem Heck, Mauricio B. de Avila,
# Nayara M. Bernhardt Levin, Val de Oliveira Pintro, and Nathalia L. Carvalho.
#
# SAnDReS became operational on 12 January 2016 at the Computational Systems
# Biology Laboratory in Porto Alegre, RS Brazil as version number 1.0.1.
#
# Xavier MM, Heck GS, de Avila MB, Levin NM, Pintro VO, Carvalho NL,
# Azevedo WF Jr. SAnDReS a Computational Tool for Statistical Analysis of
# Docking Results and Development of Scoring Functions.
# Comb Chem High Throughput Screen. 2016; 19(10): 801–812.
# DOI: 10.2174/1386207319666160927111347
#
# Define TheilSenRegressorCV() class
class TheilSenRegressorCV(object):
    """Class to carry out regression with TheilSenRegressorCV

    Inputs
        program_root            : Program directory
        file_in                 : csv file with regression parameters
        X                       : numpy array of shape [n_samples, n_features]. Training data
        y                       : numpy array of shape [n_samples]
                                Target values

    Outputs
       self.rand_in             : Random seed
       model                    : Regression model
       model.intercept_         : float. Estimated intercept of regression model.
       model.coef_              : array, shape = (n_features). Coefficients of the regression model (median of distribution).
    """

    # Define constructor method
    def __init__(self,program_root,file_in,X,y):
        """Constructor method"""

        # Set up attributes
        self.program_root = program_root
        self.file_in = file_in
        self.X = X
        self.y = y

    # Define ml_scikit_TheilSenRegressorCV() method
    def ml_scikit_TheilSenRegressorCV(self):
        """
        Method to generate a multiple regression model using
        sklearn.linear_model.TheilSenRegressor
        """

        # Import packages
        from sklearn.linear_model import TheilSenRegressor
        from MLRegMPy import ML_cross_validation as cv
        from warnings import simplefilter
        import csv
        import sys

        # Try to open self.file_in
        file2open = self.program_root+"misc/data/"+self.file_in
        try:
            fo =  open(file2open,"r")
            my_csv = csv.reader(fo)
        except IOError:
            m0 = "I can't find "+file2open+" file! Finishing program execution!"
            sys.exit(m0)

        # Definitions taken from
        # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.TheilSenRegressor.html
        #
        # string_reg_method = TheilSenRegressorCV
        #
        #
        # fit_intercept: boolean, optional, default True
        # Whether to calculate the intercept for this model. If set to false, no
        # intercept will be used in calculations.
        #
        # copy_X: boolean, optional, default True
        # If True, X will be copied; else, it may be overwritten.
        #
        # max_subpopulation: int, optional, default 1e4
        # Instead of computing with a set of cardinality ‘n choose k’,
        # where n is the number of samples and k is the number of subsamples
        # (at least number of features), consider only a stochastic
        # subpopulation of a given maximal size if ‘n choose k’ is larger than
        # max_subpopulation.
        # For other than small problem sizes this parameter will determine
        # memory usage and runtime if n_subsamples is not changed.
        #
        # n_subsamples: int, optional, default None
        # Number of samples to calculate the parameters. This is at least the
        # number of features (plus 1 if fit_intercept=True)
        # and the number of samples as a maximum. A lower number leads to a
        # higher breakdown point and a low efficiency
        # while a high number leads to a low breakdown point and a high
        # efficiency.
        # If None, take the minimum number of subsamples leading to maximal
        # robustness.
        # If n_subsamples is set to n_samples, Theil-Sen is identical to least
        # squares.
        #
        # max_iter: int, optional, default 300
        # Maximum number of iterations for the calculation of spatial median.
        #
        # tol: float, optional, default 1.e-3
        # Tolerance when calculating spatial median.
        #
        # random_state:int, RandomState instance or None, optional, default None
        # A random number generator instance to define the state of the random
        # permutations generator.
        # If int, random_state is the seed used by the random number generator;
        # If RandomState instance, random_state is the random number generator;
        # If None, the random number generator is the RandomState instance used
        # by np.random.
        #
        # n_jobs: int or None, optional (default=None)
        # Number of CPUs to use during the cross validation.
        # None means 1 unless in a joblib.parallel_backend context. -1 means
        # using all processors.
        #
        # verbose: boolean, optional, default False
        # Verbose mode when fitting the model.

        # Show message
        print("\nTheil Sen Regressor witj Cross-Validation")
        print("Regression parameters read from ml.in")

        # Looping through my_csv
        for line in my_csv:
            if line[0] == "TheilSenRegressorCV":

                # For fit_in
                if line[1] == "True":
                    fit_in = True
                else:
                    fit_in = False

                # For copy_in
                if line[2] == "True":
                    copy_in = True
                else:
                    copy_in = False

                # For max_subpopulation_in
                max_subpopulation_in = int(line[3])

                # For n_subsamples_in
                try:
                    n_subsamples_in = int(line[4])
                except:
                    n_subsamples_in = None

                # For max_in
                max_in = int(line[5])

                # For tol_in
                tol_in = float(line[6])

                # For self.rand_in
                self.rand_in = int(line[7])

                # For n_jobs_in
                try:
                    n_jobs_in = int(line[8])
                except:
                    n_jobs_in = None

                # For verbose_in
                if line[9] == "True":
                    verbose_in = True
                else:
                    verbose_in = False

                # For cv_in (set value to 5)
                cv_in = int(line[10])

                # Finish loop
                break

        # Close file
        fo.close()

        # Show summary
        print("Regression method: ",line[0])
        print("Fit intercept? "+line[1])
        print("Copy x array? "+line[2])
        print("Maximal size of subpopulation: {}".format(max_subpopulation_in))
        print("Number of samples to calculate the parameters: ",line[4])
        print("Maximum number of iterations: {}".format(max_in))
        print("Tolerance: {:.5e}".format(tol_in))
        print("A random number generator instance: ",self.rand_in)

        # Ignore all future warnings
        simplefilter(action='ignore', category=DeprecationWarning)

        # Instantiate an object of TheilSenRegressor class
        model = TheilSenRegressor(
                fit_intercept=fit_in,                   # fit_intercept: boolean, optional, default True
                copy_X=copy_in,                         # copy_X: boolean, optional, default True
                max_subpopulation=max_subpopulation_in, # max_subpopulation: int, optional, default 1e4
                n_subsamples=n_subsamples_in,           # n_subsamples: int, optional, default None
                max_iter=max_in,                        # max_iter: int, optional, default 300
                tol=tol_in,                             # tol: float, optional, default 1.e-3
                random_state=self.rand_in,              # random_state: int, RandomState instance or None
                n_jobs=n_jobs_in,                       # n_jobs: int or None, optional (default=None)
                verbose=verbose_in                      # verbose: boolean, optional, default False
                )

        # Instantiate an object of ML_cross_validation() class
        v1 = cv.ValidationLoop(model,self.X,self.y,cv_in)

        # Invoke build() method
        model = v1.build()

        # Return model and parameters
        return self.rand_in,model,model.intercept_,model.coef_