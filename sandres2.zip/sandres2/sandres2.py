#!/usr/bin/env python3
#
################################################################################
# SAnDReS 2.0.0
# Statistical Analysis of Docking Results and Scoring functions
# Written by Dr. Walter F. de Azevedo, Jr.
#
# SAnDReS 2.0.0 became operational on 12 January 2024 at azevedolab.net
# in Alfenas,MG Brazil.
#
# SAnDReS 2.0.0 (de Azevedo et al., 2024) is a development of SAnDReS 1.0
# (Xavier et al., 2016; Bitencourt-Ferreira & de Azevedo, 2019). This new
# version added novel features in machine learning, docking engine, and binding
# data. Due to the constant progress of Protein Data Bank (Berman et al., 2020),
# SAnDReS needed to redesign its downloading scripts. SAnDReS 2.0.0 has an
# integrated interface for downloading structural and affinity data. This new
# version uses the most recent regression techniques available on Scikit-Learn
# (Pedregosa et al., 2011). These methods permit us to build targeted scoring
# functions using the energy terms implemented in AutoDock Vina 1.2
# (Trott & Olson, 2010; Eberhardt et al., 2021).
# SAnDReS can create a machine learning model
# (Bitencourt-Ferreira & de Azevedo, 2019) specific to a protein system. In
# summary, SAnDReS 2.0.0 integrates one of the most developed docking programs
# (AutoDock Vina 1.2.3) with recent machine learning techniques available in
# Scikit-Learn 1.3.0. All this is in an integrated tool with a user-friendly
# graphical interface. This integrated computational tool allows us to create
# machine-learning models targeted to a protein system of interest.
# SAnDReS 2.0.0 is a powerful software to explore the Scoring Function Space
# (SFS) (Heck et al., 2017). This exploration of the SFS makes it possible to
# build models with superior predictive power compared to classical ones
# (Bitencourt-Ferreira et al., 2021).
#
# References
# Berman HM, Vallat B, Lawson CL. The data universe of structural biology.
# IUCrJ. 2020;7(Pt 4):630-638. doi: 10.1107/S205225252000562X.
# PMID: 32695409; PMCID: PMC7340255.
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. SAnDReS: A Computational Tool for
# Docking. Methods Mol Biol. 2019;2053:51-65. doi: 10.1007/978-1-4939-9752-7_4.
# PMID: 31452098.
#
# Bitencourt-Ferreira G, de Azevedo WF Jr. Exploring the Scoring Function Space.
# Methods Mol Biol. 2019;2053:275-281. doi: 10.1007/978-1-4939-9752-7_17.
# PMID: 31452111.
#
# Bitencourt-Ferreira G, Rizzotto C, de Azevedo Junior WF. Machine
# Learning-Based Scoring Functions, Development and Applications with SAnDReS.
# Curr Med Chem. 2021;28(9):1746-1756. doi: 10.2174/0929867327666200515101820.
# PMID: 32410551.
#
# de Azevedo WF Jr, Quiroga R, Villarreal MA, da Silveira NJF,
# Bitencourt-Ferreira G, da Silva AD, Veit-Acosta M, Oliveira PR, Tutone M,
# Biziukova N, Poroikov V, Tarasova O, Baud S. SAnDReS 2.0: Development of
# machine-learning models to explore the scoring function space. J Comput Chem.
# 2024; 45(27): 2333-2346. PMID: 38900052.
# [DOI: 10.1002/jcc.27449](https://doi.org/10.1002/jcc.27449)
# [PubMed](https://pubmed.ncbi.nlm.nih.gov/38900052/)
#
# Heck GS, Pintro VO, Pereira RR, de Ávila MB, Levin NMB, de Azevedo WF.
# Supervised Machine Learning Methods Applied to Predict Ligand- Binding
# Affinity. Curr Med Chem. 2017;24(23):2459-2470.
# doi: 10.2174/0929867324666170623092503. PMID: 28641555.
#
# Pedregosa F, Varoquaux G, Gramfort A, Michel V, Thirion B, Grisel, O,
# Blondel M, Prettenhofer P, Weiss R, Dubourg V, Verplas J, Passos A,
# Cournapeau D, Brucher M, Perrot M, Duchesnay E. Scikitlearn: Machine Learning
# in Python. J Mach Learn Res. 2011;12:2825-2830.
#
# Trott O, Olson AJ. AutoDock Vina: improving the speed and accuracy of docking
# with a new scoring function, efficient optimization, and multithreading.
# J Comput Chem. 2010;31(2):455-61. doi: 10.1002/jcc.21334. PMID: 19499576;
# PMCID: PMC3041641.
#
# Xavier MM, Heck GS, Avila MB, Levin NMB, Pintro VO, Carvalho NL, Azevedo WF.
# SAnDReS a Computational Tool for Statistical Analysis of Docking Results and
# Development of Scoring Functions. Comb Chem High Throughput Screen.
# 2016;19(10):801-812. doi: 10.2174/1386207319666160927111347. PMID: 27686428.
#
################################################################################
#                                                                              #
# Current Version 2.0.0.                                                       #
#                                                                              #
################################################################################
#
#  GNU General Public License
#  This file is part of SAnDReS.
#
#    SAnDReS is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    SAnDReS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with SAnDReS.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
#
# Contact
# SAnDReS is in continuous development, feel free to download the latest version
# and use it in the analysis of your docking results. If you have any question
# regarding SAnDReS, please feel free to e-mail me: walter@azevedolab.net
#
# Researchers involved in this project
# Walter Filgueira de Azevedo Jr., Nelson José Freitas da Silveira,
# Rodrigo Quiroga, Marcos Ariel Villarreal, Gabriela Bitencourt-Ferreira,
# Amauri Duarte da Silva, Martina Veit-Acosta, Patricia Rufino Oliveira,
# Marco Tutone, Nadezhda Biziukova, Vladimir Poroikov, Olga Tarasova and
# Stéphaine Baud.
#
# Universities and research centers participating in this project
# Departamento de Física do Instituto de Ciências Exatas da UNIFAL-MG
# Instituto de Investigaciones en Fisicoquímica de Córdoba (INFIQC),
# CONICET-Departamento de Química Teórica y Computacional, Facultad de Ciencias
# Químicas, Universidad Nacional de Córdoba, Ciudad Universitaria, Córdoba,
# Argentina.
# Laboratório de Modelagem Molecular e Simulação Computacional da UNIFAL-MG
# Pontifícia Universidade Católica do Rio Grande do Sul – PUCRS
# Programa de Pós-Graduação em Tecnologias da Informação e Gestão em Saúde,
# Universidade Federal de Ciências da Saúde de Porto Alegre, Porto Alegre
# Western Michigan University, Kalamazoo, Michigan, USA.
# Escola de Artes, Ciências e Humanidades da Universidade de São Paulo
# Dipartimento di Scienze e Tecnologie Biologiche Chimiche e Farmaceutiche
# (STEBICEF), Università di Palermo, Palermo, Italy.
# Institute of Biomedical Chemistry, Moscow, Russia
# Laboratoire SiRMa, UMR CNRS/URCA 7369, UFR Sciences Exactes et Naturelles,
# Université de Reims Champagne-Ardenne, CNRS, MEDYC, Reims, France
#
# Funding
# The Brazilian National Council for Scientific and Technological Development
# (CNPq) (Process 306298/2022-8) supports this research project. This study was
# financed in part by the Coordenação de Aperfeiçoamento de Pessoal de Nível
# Superior - Brazil (CAPES) – Finance Code 001. MVA acknowledges Diether
# Haenicke Scholarship from Western Michigan University. ОТ, NB, and VP thank
# the Program for Basic Research in the Russian Federation for a long-term
# period 2021–2030 (project No. 122030100170-5). R.Q and M.A.V thank Secyt-UNC
# for their financial support.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# [Scopus](https://www.scopus.com/authid/detail.uri?authorId=7006435557)       #
# [GitHub](https://github.com/azevedolab)                                      #
# October 2, 2024                                                              #
################################################################################
#
# Import packages
import os
import sys
from tools import tkinter_tools as tk_tools
import warnings

# Ignore warnings
warnings.filterwarnings('ignore')

# Set up program root directory
program_root = os.getcwd()+"/"

# Set the directory where Python scripts are
sys.path.append(program_root)

# Instantiate an object of GUI() class
gui1 = tk_tools.GUI(program_root)

# Invoke a open_main_gui() method
gui1.open_main_gui()